/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"

#define display_packet_dumps g_argument_packets
#define process_packet server_process_packet

/*
655536 possible packet id's / 8
PACKET_NAME_SPACE is not a packet -- it is a size.
You knew that already, right?
*/
#define PACKET_NAME_SPACE 8192

const char *packet_type_string[] = {"PACKET_AVAILABLE_PACKET_TYPES", "PACKET_SELECT_PACKET_TYPES", "PACKET_PING_REQUEST", "PACKET_PING_RESPONSE", "PACKET_IDLE_PING", "PACKET_AUTHENTICATE", "PACKET_CONNECT", "PACKET_DISCONNECT", "PACKET_CHAT_MESSAGE", "PACKET_ANNOUNCE_PLAYER", "PACKET_DENOUNCE_PLAYER", "PACKET_PLAYER_ABILITIES", "PACKET_MAP_LOADING", "PACKET_RANDOM_GARBAGE", "PACKET_MAP_SETUP", "PACKET_MAP_PROPERTIES", "PACKET_MAP_FILL", "PACKET_MAP_DATA", "PACKET_MAP_TOTAL_RESET", "PACKET_MAP_TOTAL_DATA", "PACKET_BUFFER_RESET", "PACKET_BUFFER_APPEND", "PACKET_BUFFER_IS_MAP_DATA", "PACKET_BUFFER_IS_FILE_DATA", "PACKET_MOVE_PLAYER", "PACKET_MAP_MODIFY", "PACKET_FILE_REQUEST", "PACKET_TEXTURE_SETUP", "PACKET_GROUP_SETUP", "PACKET_BLOCK_SETUP", "PACKET_MENU_REQUEST", "PACKET_MENU_RESPONSE", "PACKET_MENU_RESET", "PACKET_MENU_TEXT", "PACKET_MENU_LINK", "PACKET_MENU_CHECK", "PACKET_MENU_RADIO", "PACKET_MENU_INPUT", "PACKET_MENU_BUTTON", "PACKET_MENU_NULL", "PACKET_MENU_PASSWORD", "PACKET_MENU_RESIZE", "PACKET_SKY_BOX", "PACKET_CLIENT_VERSION", "PACKET_COOKIE", "PACKET_PLAYER_PROPERTIES", "PACKET_MENU_TEXTURE", "PACKET_SERVER_NAME", "PACKET_PROJECTILE_CREATE", "PACKET_PROJECTILE_COLLISION"};

char *PACKET_NULL = NULL;
void set_default_sendable_packets (char *data) {
    packet_set_available (data, PACKET_AVAILABLE_PACKET_TYPES);
    packet_set_available (data, PACKET_SELECT_PACKET_TYPES);
    packet_set_available (data, PACKET_PING_REQUEST);
    packet_set_available (data, PACKET_PING_RESPONSE);
    packet_set_available (data, PACKET_IDLE_PING);
    packet_set_available (data, PACKET_AUTHENTICATE);
    packet_set_available (data, PACKET_CONNECT);
    packet_set_available (data, PACKET_DISCONNECT);
    packet_set_available (data, PACKET_CHAT_MESSAGE);
    packet_set_available (data, PACKET_ANNOUNCE_PLAYER);
    packet_set_available (data, PACKET_DENOUNCE_PLAYER);
    packet_set_available (data, PACKET_PLAYER_ABILITIES);
    packet_set_available (data, PACKET_MAP_LOADING);    
    packet_set_available (data, PACKET_MAP_SETUP);
    packet_set_available (data, PACKET_MAP_PROPERTIES);
    packet_set_available (data, PACKET_MAP_FILL);
    packet_set_available (data, PACKET_MAP_DATA);
    packet_set_available (data, PACKET_MAP_TOTAL_RESET);
    packet_set_available (data, PACKET_MAP_TOTAL_DATA);
    packet_set_available (data, PACKET_BUFFER_RESET);
    packet_set_available (data, PACKET_BUFFER_APPEND);
    packet_set_available (data, PACKET_BUFFER_IS_MAP_DATA);
    packet_set_available (data, PACKET_BUFFER_IS_FILE_DATA);
    packet_set_available (data, PACKET_MOVE_PLAYER);
    packet_set_available (data, PACKET_MAP_MODIFY);
//    packet_set_available (data, PACKET_FILE_REQUEST);    
	packet_set_available (data, PACKET_TEXTURE_SETUP);	
    packet_set_available (data, PACKET_GROUP_SETUP);
    packet_set_available (data, PACKET_BLOCK_SETUP);    
//    packet_set_available (data, PACKET_MENU_REQUEST);
//    packet_set_available (data, PACKET_MENU_RESPONSE);
    packet_set_available (data, PACKET_MENU_RESET);    
    packet_set_available (data, PACKET_MENU_TEXT);
    packet_set_available (data, PACKET_MENU_LINK);    
    packet_set_available (data, PACKET_MENU_CHECK);
    packet_set_available (data, PACKET_MENU_RADIO);    
    packet_set_available (data, PACKET_MENU_INPUT);
    packet_set_available (data, PACKET_MENU_BUTTON);    
    packet_set_available (data, PACKET_MENU_ERASE);    
    packet_set_available (data, PACKET_CLIENT_VERSION);
	packet_set_available (data, PACKET_PLAYER_PROPERTIES);
    packet_set_available (data, PACKET_MENU_TEXTURE);
	packet_set_available (data, PACKET_SERVER_NAME);		
	packet_set_available (data, PACKET_PROJECTILE_CREATE);			
	packet_set_available (data, PACKET_PROJECTILE_COLLISION);
    packet_set_available (data, PACKET_SKY_BOX);
    return;
}

void set_default_receivable_packets (char *data) {
    packet_set_available (data, PACKET_AVAILABLE_PACKET_TYPES);
    packet_set_available (data, PACKET_SELECT_PACKET_TYPES);
    packet_set_available (data, PACKET_MENU_REQUEST);
    packet_set_available (data, PACKET_MENU_RESPONSE);
    packet_set_available (data, PACKET_DISCONNECT);
    packet_set_available (data, PACKET_PING_REQUEST);
    packet_set_available (data, PACKET_PING_RESPONSE);
    packet_set_available (data, PACKET_IDLE_PING);
    packet_set_available (data, PACKET_AUTHENTICATE);	
    packet_set_available (data, PACKET_CLIENT_VERSION);
//    packet_set_available (data, PACKET_MENU_RESIZE);
	packet_set_available (data, PACKET_PORTAL_COOKIE);
	packet_set_available (data, PACKET_TEXTURE_SETUP);	
	packet_set_available (data, PACKET_FILE_REQUEST);		
	packet_set_available (data, PACKET_CHAT_MESSAGE);			
	packet_set_available (data, PACKET_MAP_MODIFY);
	packet_set_available (data, PACKET_MAP_FILL);
	packet_set_available (data, PACKET_MAP_DATA);
	packet_set_available (data, PACKET_MOVE_PLAYER);
	packet_set_available (data, PACKET_PROJECTILE_CREATE);			
	packet_set_available (data, PACKET_PROJECTILE_COLLISION);			
    return;
}

void packet_set_available(char *str, int packet_type) {
	int index = packet_type / 8;
	int bit = 1 << (packet_type % 8);
	str[index] |= bit;
}

void packet_set_unavailable(char *str, int packet_type) {
	int index = packet_type / 8;
	int bit = 1 << (packet_type % 8);
	str[index] &= ~bit;
}


int packet_is_sendable(int packet_type, char *packet_list) {
	/*
	This function returns true if a packet type is accepted by the server, or
	false if it is not.  It is not necessary to use this function, since the
	packet_send() function below does a similar check, and so you can typically
	just do this:

	packet_send(PACKET_THIS) || packet_send(PACKET_THAT) || whatever();

	However, in some cases it is desireable to know beforehand whether or not a
	particular packet type will be sent, and that is what this function is for.
	*/

	if (packet_type < 0 || packet_type >= PACKET_TYPE_LIMIT) return 0;
	int index = packet_type / 8;
	int bit = 1 << (packet_type % 8);
	return (packet_list[index] & bit) != 0;
}


static inline int packet_send_retarded (struct user *puser, int packet_type, va_list ooo) {
    int ret = 1;
    
    // Retarded?  Yes.  No direct way to pass variable-length arguments, so you need
    // a function to call a function.  Anyway, perhaps making it inline reduces some of the 
    // retardedness.
    
    if (puser->socket == 0) return (1);
    
    if (puser->current_mode == USER_DISCONNECT) return (1);
    
	MUTEX_LOCK (user_mutex_write[puser->idx - 1]);

	/*
	This function sends all packet types.  Arguments vary by packet type.
	Packets will not be sent if the packet type was not requested.
	Return value is 1 if the packet was sent or 0 if it was not sent.
	So you can choose which type of packet to send like this:
	packet_send(PACKET_THIS, data, data) || packet_send(PACKET_THAT, data);
	*/

	if (packet_type < 0 || packet_type > PACKET_TYPE_LIMIT) {
		printf("packet_send(): Packet type %d is out of range!\n", packet_type);
		easy_die("I tried to send an invalid packet!", 1);
	}

	log_printf (puser, LDEBUG, "packet_send> %d (%s)", packet_type, packet_type_to_string(packet_type));  

	if (!packet_is_sendable (packet_type, puser->sendable_packets)) {
		if (display_packet_dumps) printf("\e[1;31mOur list of available packets does not include %s\e[0m\n", packet_type_to_string(packet_type));
		log_printf (puser, LWARNING, "Packet %s not to be sent.", packet_type_to_string(packet_type));
		ret = 0; goto end;
	}

	char packet[65560];
	int *p = (void *) packet;
	*p = packet_type;
	#define header_size 4
	#define data_size (*((unsigned short*) (packet + 2)))
	#define packet_size (header_size + data_size)
	#define packet_data (packet + header_size)

	data_size = 0; // In case it isn't set below.

	#define DATA(OFFSET, TYPE) *((TYPE*) (packet_data + OFFSET))

	if (packet_type == PACKET_IDLE_PING) {
		process_send_raw_data(puser, packet, packet_size);

	} else if (packet_type == PACKET_AVAILABLE_PACKET_TYPES) {
		char *vector = va_arg(ooo, char*);
		data_size = 8192;

		process_send_raw_data(puser, packet, header_size);
		process_send_raw_data(puser, vector, data_size);

	} else if (packet_type == PACKET_SELECT_PACKET_TYPES) {
		char *vector = va_arg(ooo, char*);
		for (data_size = PACKET_NAME_SPACE; data_size > 0; data_size--) {
			if (vector[data_size - 1] != 0) break;
		}

		process_send_raw_data(puser, packet, header_size);
		process_send_raw_data(puser, vector, data_size);

	} else if (packet_type == PACKET_PING_REQUEST) {
		char *data_pointer = va_arg(ooo, char*);
		data_size = va_arg(ooo, int);
		process_send_raw_data(puser, packet, header_size);
		if (data_size > 0) process_send_raw_data(puser, data_pointer, data_size);

	} else if (packet_type == PACKET_PING_RESPONSE) {
		char *data_pointer = va_arg(ooo, char*);
		data_size = va_arg(ooo, int);
		process_send_raw_data(puser, packet, header_size);
		if (data_size > 0) process_send_raw_data(puser, data_pointer, data_size);

	} else if (packet_type == PACKET_MOVE_PLAYER) {
		DATA(0, float) = va_arg(ooo, double);
		DATA(4, float) = va_arg(ooo, double);
		DATA(8, float) = va_arg(ooo, double);
		DATA(12, float) = va_arg(ooo, double);
		DATA(16, float) = va_arg(ooo, double);
		DATA(20, unsigned char) = va_arg(ooo, int);
        
		data_size = 20 + (DATA(20, unsigned char) != 0);
		process_send_raw_data(puser, packet, packet_size);

	} else if (packet_type == PACKET_GROUP_SETUP) {
		char *block_ids;
		char *group_desc;
		DATA(0, unsigned char) = va_arg(ooo, int);
		block_ids = va_arg(ooo, char*);
		group_desc = va_arg(ooo, char*);

		char temp[1024];

		_strncpy (temp, block_ids, 1024);
		char *cp;
		cp = strchr (temp, 0);
		cp++;
		_strncpy (cp, group_desc, 64);

		data_size = 2 + strlen(block_ids) + strlen (group_desc);
		process_send_raw_data(puser, packet, header_size + 1);
		process_send_raw_data(puser, temp, data_size - 1);

	} else if (packet_type == PACKET_MAP_MODIFY) {
		DATA(0, unsigned short) = va_arg(ooo, int);
		DATA(2, unsigned short) = va_arg(ooo, int);
		DATA(4, unsigned short) = va_arg(ooo, int);
		DATA(6, unsigned char) = va_arg(ooo, int);
		DATA(7, unsigned char) = va_arg(ooo, int);
		data_size = 7 + (DATA(7, unsigned char) != 0);
		process_send_raw_data(puser, packet, packet_size);

	} else if (packet_type == PACKET_MAP_FILL) {
		DATA(0, short) = va_arg(ooo, int);
		DATA(2, short) = va_arg(ooo, int);
		DATA(4, short) = va_arg(ooo, int);
		DATA(6, short) = va_arg(ooo, int);
		DATA(8, short) = va_arg(ooo, int);
		DATA(10, short) = va_arg(ooo, int);
		DATA(12, unsigned char) = va_arg(ooo, int);
		data_size = 13;
		process_send_raw_data(puser, packet, packet_size);

	} else if (packet_type == PACKET_CHAT_MESSAGE) {
		DATA(0, unsigned char) = va_arg(ooo, int);
		char *message = va_arg(ooo, char*);
		data_size =  strlen(message) + 1;
		process_send_raw_data(puser, packet, header_size + 1);
		process_send_raw_data(puser, message, data_size - 1);

	} else if (packet_type == PACKET_MAP_LOADING) {
		DATA(0, unsigned char) = va_arg(ooo, int);
		char *message = va_arg(ooo, char*);

		if (message == 0) {
			data_size =  0;
			process_send_raw_data(puser, packet, header_size);
		} else {
			data_size =  strlen(message) + 1;
			process_send_raw_data(puser, packet, header_size + 1);
			process_send_raw_data(puser, message, data_size - 1);
		}

	} else if (packet_type == PACKET_AUTHENTICATE) {
		// Since data must come from login server, the parameter here is
		// just a pointer to the 52-byte data that goes in the packet.

		char *pointer = va_arg(ooo, char*);
		if (pointer != NULL) {
			memmove(packet_data, pointer, 52);
			data_size = 52;
		}
		process_send_raw_data(puser, packet, packet_size);

	} else if (packet_type == PACKET_DISCONNECT) {
		DATA(0, unsigned char) = va_arg(ooo, int);
		DATA(1, unsigned char) = va_arg(ooo, int);
		char *message = va_arg(ooo, char*);
		data_size = 2 + strlen(message);
		process_send_raw_data(puser, packet, header_size + 2);
		process_send_raw_data(puser, message, data_size - 2);

	} else if (packet_type == PACKET_MAP_PROPERTIES) {
		DATA(0, unsigned int) = va_arg(ooo, int);
		DATA(4, float) = va_arg(ooo, double);
		data_size = 8;

		process_send_raw_data(puser, packet, packet_size);

	} else if (packet_type == PACKET_MAP_SETUP) {
		DATA(0, unsigned short) = va_arg(ooo, int);
		DATA(2, unsigned short) = va_arg(ooo, int);
		DATA(4, unsigned short) = va_arg(ooo, int);
		DATA(6, unsigned short) = va_arg(ooo, int);
		data_size = 8;

		process_send_raw_data(puser, packet, packet_size);

	} else if (packet_type == PACKET_PLAYER_ABILITIES) {
		DATA(0, int) = va_arg(ooo, int);
		DATA(4, int) = va_arg(ooo, int);
		DATA(8, unsigned short) = va_arg(ooo, int);
		data_size = 10;

		process_send_raw_data(puser, packet, packet_size);

	} else if (packet_type == PACKET_MENU_RESET) {
		unsigned char fuck[8];
		fuck[0] = va_arg(ooo, int);
		fuck[1] = va_arg(ooo, int);
		fuck[2] = va_arg(ooo, int);
		fuck[3] = va_arg(ooo, int);

		if (fuck[0] == 0 && fuck[1] == 0 && fuck[2] == 0) data_size = 0;
		else {
			data_size = 4;
			DATA(0, unsigned char) = fuck[0];
			DATA(1, unsigned char) = fuck[1];
			DATA(2, unsigned char) = fuck[2];
			DATA(3, unsigned char) = fuck[3];
		}

		process_send_raw_data(puser, packet, packet_size);

	} else if (packet_type == PACKET_MENU_TEXT) {
		DATA(0, unsigned char) = va_arg(ooo, int);
		DATA(1, unsigned char) = va_arg(ooo, int);
		DATA(2, unsigned char) = va_arg(ooo, int);
		char *message = va_arg(ooo, char*);

		data_size = 3 + strlen(message);
		process_send_raw_data(puser, packet, header_size + 3);
		process_send_raw_data(puser, message, data_size - 3);

	} else if (packet_type == PACKET_MENU_INPUT) {
		DATA(0, unsigned char) = va_arg(ooo, int);
		DATA(1, unsigned char) = va_arg(ooo, int);
		DATA(2, unsigned char) = va_arg(ooo, int);
		DATA(3, unsigned char) = va_arg(ooo, int);
		DATA(4, unsigned char) = va_arg(ooo, int);
		DATA(5, unsigned char) = va_arg(ooo, int);
		DATA(6, unsigned char) = va_arg(ooo, int);
		DATA(7, unsigned char) = va_arg(ooo, int);

		char *message = va_arg(ooo, char*);
		int msglen = 0;
		if (message != NULL) msglen = strlen(message);

		data_size = 8 + msglen;
		process_send_raw_data(puser, packet, header_size + 8);
		process_send_raw_data(puser, message, data_size - 8);

	} else if (packet_type == PACKET_MENU_CHECK) {
		DATA(0, unsigned char) = va_arg(ooo, int);
		DATA(1, unsigned char) = va_arg(ooo, int);
		DATA(2, unsigned char) = va_arg(ooo, int);
		DATA(3, unsigned char) = va_arg(ooo, int);
		DATA(4, unsigned char) = va_arg(ooo, int);
		DATA(5, unsigned char) = va_arg(ooo, int);

		char *message = va_arg(ooo, char*);
		int msglen = 0;
		if (message != NULL) msglen = strlen(message);

		data_size = 6 + msglen;
		process_send_raw_data(puser, packet, header_size + 6);
		process_send_raw_data(puser, message, data_size - 6);

	} else if (packet_type == PACKET_MENU_RADIO) {
		DATA(0, unsigned char) = va_arg(ooo, int);
		DATA(1, unsigned char) = va_arg(ooo, int);
		DATA(2, unsigned char) = va_arg(ooo, int);
		DATA(3, unsigned char) = va_arg(ooo, int);
		DATA(4, unsigned char) = va_arg(ooo, int);
		DATA(5, unsigned char) = va_arg(ooo, int);

		char *message = va_arg(ooo, char*);

		int msglen = 0;
		if (message != PACKET_NULL) msglen = strlen(message);

		data_size = 6 + msglen;
		process_send_raw_data(puser, packet, header_size + 6);
		if (message != PACKET_NULL) process_send_raw_data(puser, message, data_size - 6);

	} else if (packet_type == PACKET_MENU_LINK) {
		DATA(0, unsigned char) = va_arg(ooo, int);
		DATA(1, unsigned char) = va_arg(ooo, int);
		DATA(2, unsigned char) = va_arg(ooo, int);
		DATA(3, unsigned char) = va_arg(ooo, int);
		DATA(4, unsigned char) = va_arg(ooo, int);
		DATA(5, unsigned char) = va_arg(ooo, int);

		char *message = va_arg(ooo, char*);

		int msglen = 0;
		if (message != PACKET_NULL) msglen = strlen(message);

		data_size = 6 + msglen;
		process_send_raw_data(puser, packet, header_size + 6);
		if (message != PACKET_NULL) process_send_raw_data(puser, message, data_size - 6);

	} else if (packet_type == PACKET_MENU_BUTTON) {
		DATA(0, unsigned char) = va_arg(ooo, int);
		DATA(1, unsigned char) = va_arg(ooo, int);
		DATA(2, unsigned char) = va_arg(ooo, int);
		DATA(3, unsigned char) = va_arg(ooo, int);
		DATA(4, unsigned char) = va_arg(ooo, int);
		DATA(5, unsigned char) = va_arg(ooo, int);
		DATA(6, unsigned char) = va_arg(ooo, int);

		char *message = va_arg(ooo, char*);

		int msglen = 0;
		if (message != NULL) msglen = strlen(message);

		data_size = 7 + msglen;
		process_send_raw_data(puser, packet, header_size + 7);
		process_send_raw_data(puser, message, data_size - 7);

	} else if (packet_type == PACKET_MENU_TEXTURE) {
		DATA(0, unsigned char) = va_arg(ooo, int);
		DATA(1, unsigned char) = va_arg(ooo, int);
		DATA(2, unsigned char) = va_arg(ooo, int);
		DATA(3, unsigned char) = va_arg(ooo, int);
		DATA(4, unsigned char) = va_arg(ooo, int);
		DATA(5, short) = va_arg(ooo, int);
		DATA(7, unsigned char) = va_arg(ooo, int);
		DATA(8, unsigned char) = va_arg(ooo, int);
		DATA(9, unsigned char) = va_arg(ooo, int);
		DATA(10, unsigned char) = va_arg(ooo, int);

		data_size = 11;

		process_send_raw_data(puser, packet, packet_size);

	} else if (packet_type == PACKET_ANNOUNCE_PLAYER) {
		DATA(0, unsigned char) = va_arg(ooo, int);
		DATA(1, unsigned char) = va_arg(ooo, int);
		char *message = va_arg(ooo, char*);

		int msglen = 24;

		data_size = 2 + msglen;
		process_send_raw_data(puser, packet, header_size + 2);
		process_send_raw_data(puser, message, data_size - 2);

	} else if (packet_type == PACKET_DENOUNCE_PLAYER) {
		DATA(0, unsigned char) = va_arg(ooo, int);
		data_size = 1;
		process_send_raw_data(puser, packet, header_size + 1);

	} else if (packet_type == PACKET_TEXTURE_SETUP) {
		char *sha1;  
		DATA(0, short) = va_arg(ooo, int);
		sha1 = va_arg(ooo, char *);
		DATA(22, float) = va_arg(ooo, double);
		DATA(26, float) = va_arg(ooo, double);
		DATA(30, float) = va_arg(ooo, double);
		DATA(34, unsigned int) = va_arg(ooo, int);

		memmove (packet+6, sha1, 20);

		data_size = 38;
		process_send_raw_data(puser, packet, packet_size);

	} else if (packet_type == PACKET_BUFFER_IS_FILE_DATA ) {
		data_size = 0;
		process_send_raw_data(puser, packet, packet_size);

	} else if (packet_type == PACKET_BUFFER_RESET) {
		data_size = 0;
		process_send_raw_data(puser, packet, packet_size);

	} else if (packet_type == PACKET_MAP_TOTAL_RESET) {
		data_size = 0;
		process_send_raw_data(puser, packet, packet_size);

	} else if (packet_type == PACKET_BUFFER_APPEND) {
		char *payload = va_arg(ooo, char*);
		int length = va_arg(ooo, int);

		data_size = length;
		process_send_raw_data(puser, packet, header_size);
		process_send_raw_data(puser, payload, data_size);

	} else if (packet_type == PACKET_MAP_TOTAL_DATA) {
		char *payload = va_arg(ooo, char*);
		int length = va_arg(ooo, int);

		data_size = length;
		process_send_raw_data(puser, packet, header_size);
		process_send_raw_data(puser, payload, data_size);

	} else if (packet_type == PACKET_BUFFER_IS_MAP_DATA) {
		DATA(0, short) = va_arg(ooo, int);
		DATA(2, short) = va_arg(ooo, int);
		DATA(4, short) = va_arg(ooo, int);

		DATA(6, short) = va_arg(ooo, int);
		DATA(8, short) = va_arg(ooo, int);
		DATA(10, short) = va_arg(ooo, int);

		data_size = 12;
		process_send_raw_data(puser, packet, packet_size);

	} else if (packet_type == PACKET_BLOCK_SETUP) {
		DATA(0, unsigned char) = va_arg(ooo, int);
		DATA(1, short) = va_arg(ooo, int);
		DATA(3, short) = va_arg(ooo, int);
		DATA(5, short) = va_arg(ooo, int);
		DATA(7, short) = va_arg(ooo, int);
		DATA(9, short) = va_arg(ooo, int);
		DATA(11, short) = va_arg(ooo, int);
		DATA(13, unsigned int) = va_arg(ooo, int);
		char *message = va_arg(ooo, char*);

		data_size = 17 + strlen (message);
		process_send_raw_data(puser, packet, header_size + 17);
		process_send_raw_data(puser, message, data_size - 17);

	} else if (packet_type == PACKET_SKY_BOX) {
		DATA(0, short) = va_arg(ooo, int); 
        DATA(2, short) = va_arg(ooo, int); 
        DATA(4, short) = va_arg(ooo, int); 
        DATA(6, short) = va_arg(ooo, int); 
        DATA(8, short) = va_arg(ooo, int); 
        DATA(10, short) = va_arg(ooo, int); 
        DATA(12, char) = va_arg(ooo, int);         

		data_size = 13;
		process_send_raw_data(puser, packet, header_size + data_size);

	} else if (packet_type == PACKET_MAP_DATA) {
		DATA(0, short) = va_arg(ooo, int);
		DATA(2, short) = va_arg(ooo, int);
		DATA(4, short) = va_arg(ooo, int);
		DATA(6, short) = va_arg(ooo, int);
		DATA(8, short) = va_arg(ooo, int);
		DATA(10, short) = va_arg(ooo, int);
		int p = va_arg(ooo, int);
		char *message = va_arg(ooo, char*);
/*			int vx = DATA(6, short) - DATA(0, short) + 1;
			int vy = DATA(8, short) - DATA(2, short) + 1;
			int vz = DATA(10, short) - DATA(4, short) + 1;


		int expected_size =  vx * vy * vz;
		printf ("Expected: %ix%ix%i, %i\n", vx, vy, vz, expected_size);
*/
		data_size = 12 + p;

		process_send_raw_data(puser, packet, header_size + 12);
		process_send_raw_data(puser, message, data_size - 12);

	} else if (packet_type == PACKET_CLIENT_VERSION ) {
		DATA(0, unsigned char) = va_arg(ooo, int);
		DATA(1, int) = va_arg(ooo, int);    
		data_size = 5;
		process_send_raw_data(puser, packet, header_size + 5);

	} else if (packet_type == PACKET_PLAYER_PROPERTIES) {
        DATA(0, char) = va_arg(ooo, int);
        DATA(1, short) = va_arg(ooo, int);

        if (DATA(1, short) == -1) data_size = 1;
        else data_size = 3;
        process_send_raw_data(puser, packet, packet_size);


	} else if (packet_type == PACKET_SERVER_NAME ) {
		char *cp = va_arg(ooo, char*);
		if (cp == NULL) {
			data_size = 0;
			process_send_raw_data(puser, packet, header_size);	
		} else {
			int length =strlen (cp); 
			data_size = length;
			process_send_raw_data(puser, packet, header_size);
			process_send_raw_data(puser, cp, length);
		}

	} else if (packet_type == PACKET_PROJECTILE_CREATE) {
        float x, y, z, u, v;
        int type = va_arg(ooo, int);
        x = va_arg(ooo, double);
        y = va_arg(ooo, double);
        z = va_arg(ooo, double);
        u = va_arg(ooo, double);
        v = va_arg(ooo, double);
	
//		printf (">%fx%fx%f %f,%f\n", x, y, z, u, v);
		
		DATA(0, unsigned char) = type;
		DATA(1, float) = x;
		DATA(5, float) = y;
		DATA(9, float) = z;
		DATA(13, float) = u;
		DATA(17, float) = v;
		data_size = 21;
		
//		printf ("Send projectile create to %s\n", puser->name);
		process_send_raw_data(puser, packet, packet_size);
		
	} else {
		log_printf (NULL, LERROR, "Packet %s needs to be defined in packet_send_retarded().", packet_type_to_string(packet_type));
		easy_die("Tried to send a packet type I don't know how to send.", 1);
	}

	end:

	MUTEX_UNLOCK (user_mutex_write[puser->idx - 1]);
	return (ret);
}

const char *packet_type_to_string(int packet_type) {
	static char unknown[64];
	if (packet_type >= 0 && packet_type < PACKET_TYPE_LIMIT) {
		return packet_type_string[packet_type];
	}
	sprintf(unknown, "[Unknown Packet Type %d]", packet_type);
	return unknown;
}

int packet_send (struct user *puser, int packet_type, ...) {
    va_list ooo;
    va_start(ooo, packet_type);    
    int ret = packet_send_retarded (puser, packet_type, ooo);
    va_end (ooo);
    return (ret);
}

void packet_broadcast (struct map *pmap, int mode, struct user *puser_exclude, int packet_type, ...) {
    int a;
    va_list ooo;

    for (a = 1; a < NUM_USERS; a++) {
		if (user[a].current_mode == USER_NOT_CONNECTED) continue;
        if (pmap != NULL && pmap != user[a].map) continue;

		if (mode != -1 && user[a].current_mode != mode) {
			log_printf (&user[a], LDEBUG, "packet_broadcast: not sent to %i because mode is %i", a, user[a].current_mode);
			continue;
		}
        if (&user[a] == puser_exclude) continue;

        log_printf (NULL, LDEBUG, "Broadcast: Send to %i",  a);
        
        //va_list needs to be reset for each call. 
        va_start(ooo, packet_type);        
        packet_send_retarded (&user[a], packet_type, ooo);
        va_end(ooo);
    }
	return;  
}
