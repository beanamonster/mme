/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"

/*map_last_sync stores the next unix timestamp in which to save the map.
it is initialized to zero.*/

/*
signal handler, windows fix
Windows has its own signal handler on top of the normal signal handler.
The windows signal handler runs as a thread, instead of a jump.  The
signal handler thread must remain running in order for the server to
complete its shutdown, so we have an infinite loop calling sleep.
*/

#ifdef WIN32
int win32_signal( DWORD fdwCtrlType ) { 
    switch( fdwCtrlType ) { 
    case CTRL_C_EVENT: 
    case CTRL_CLOSE_EVENT: 
    case CTRL_BREAK_EVENT: 
        the_signal_handler (SIGTERM);
        for (;;) Sleep (1);
        return TRUE; 
    default: 
      return FALSE; 
    }
} 
 

#endif
/*
If the process is killed, perform an orderly shutdown
of the server.  
*/
static double lag_stamp = 0;

void the_signal_handler (int signum) {
	if (g_bind_socket != -1) close (g_bind_socket);
    #ifdef WIN32
	signal (SIGTERM,  SIG_IGN);	
    #else 
   	signal (SIGTERM,  SIG_DFL);	
    #endif
//	signal (SIGABRT,  SIG_DFL);	
	signal (SIGINT,  SIG_DFL);	
    
    #ifdef LINUX
	signal (SIGQUIT,  SIG_DFL);
    #endif

    server_shutdown ();
}
void server_shutdown () {
	int a;
    /*Send "the server is rebooting" disconnect message to everyone who is 
    connected to the server.*/
    
	for (a = 1; a < NUM_USERS; a++) {
		if (user[a].current_mode == USER_NOT_CONNECTED) continue;
		if (strcmp (g_shutdown_type, "restart") == 0)
			user_disconnect (&user[a], DISCONNECT_REBOOT, config.restart_dead_time, g_shutdown_message);
		else 
			user_disconnect (&user[a], DISCONNECT_NULL, 0, g_shutdown_message);
	}

    //Start shutdown sequence
	g_server_shutdown_timeout = 0;
	log_printf (NULL, LWARNING, "server will shut down");
}

/*
In linux, a child process must have waitpid called on it at least once, otherwise
it becomes a zombie when it exits.  
The server announce runs as a forked process in linux, so this has to be here.
In windows, the announce code is called within the map server process.  This means
that announce problems will potentially hang the server in windows (windows does not
have fork()). Eventually I'll either make announce run as a separate program, or
perhaps as a thread.  
*/

#ifdef LINUX
void handler_sigchld () {
    int w = 0;
	waitpid (-1, &w, WNOHANG);
}
#endif

int main (int argc, char **argv) {
    /* Initialize malloc wrapper in easy.c.  The malloc wrapper
    helps keep malloc from eating itself, and also serves as a 
    way to point out buffer overflows*/

	kill_server = 0;
	_malloc_init();
    time_t t;    
    int a, ret;
    int active_connections = 0;
	g_lag_max = 0;
    char *cp;

    /* seed the random number generator*/	  
    time (&t);
    srand (t);
    g_stdin_open = 1;

    g_server_shutdown_timeout = -1;
	g_bind_socket = -1;
    
    /* These are the default values for our command line flags. */
    g_argument_packets = 0;
    g_debug_mode = 0;
	g_print_to_stdout = 1;    

    for (a = 1; a < argc; a++) {
        if (strcmp ("--packets", argv[a]) == 0) g_argument_packets = 1;
        else if (strcmp ("--debug", argv[a]) == 0) g_debug_mode = 1;		
        else if (strcmp ("--no_stdout", argv[a]) == 0) g_print_to_stdout = 0;				
		else {
            printf ("%s is not a valid option.\n", argv[a]);
            return (1);
        }
    }

    // initialize the user space by wiping all of the records    
    memset (&user, 0, sizeof (struct user) * NUM_USERS);
    for (a = 0; a < NUM_USERS; a++) MUTEX_INIT (user_mutex_write[a]);
    
    // Move to the exe's directory.
    #ifdef WIN32
        char temp[256];
        GetModuleFileName(0, temp, 256);
        cp=strrchr (temp, '\\');
        if (cp != 0) {
            temp[cp-temp] = 0;
        	chdir (temp);
        }
    #else 
    // this is a horrible solution, but unless you want to read /proc,
    // it's pretty much all you have.  There is no guarantee that
	// argv[0] will be a full path.
	    char temp[256];
        _strncpy (temp, argv[0], 255);
        cp = strrchr (temp, '/');
        if (cp != 0) *cp = 0;
        chdir (temp);
    
    #endif
    
    /* open log.txt for logging, and set the file descriptor
    buffer to zero.  Setting the buffer to zero makes writing
    to the log file much slower, but also makes sure that
    all~ of the data gets written in the event of a crash.
    (When you are most likely to want that data)
    */
    char file_temp[PATH_MAX];
    snprintf (file_temp, PATH_MAX, "%s/log.txt", PATH_LOGS);
	g_log_file_handle = fopen (file_temp, "ab");
	if (g_log_file_handle != 0) setbuf (g_log_file_handle, 0);

    setbuf (stdout, 0);    

    socket_initialize (); // This has wsastartup in it.
    log_printf (NULL, LNOTE, "MME Map Server, build #%i, %i-bit", build_version, sizeof (size_t) * 8);    
	get_interface_thing ();
    easy_mkdir (PATH_AREAS);    
    easy_mkdir (PATH_MAPS);
    easy_mkdir (PATH_USERS);
    easy_mkdir (PATH_LOGS);
    easy_mkdir (PATH_LUA);
    easy_mkdir (PATH_PRIVATE_MAIL);
		
    fd_set rfds, wfds;
    struct timeval tv;
    
    signal (SIGTERM,  (void*)the_signal_handler);	
//    signal (SIGABRT,  (void*)the_signal_handler);	
    signal (SIGABRT,  (void*)the_signal_handler);	
	signal (SIGINT,  (void*)the_signal_handler);	

    #ifdef LINUX
	    signal (SIGQUIT, (void* ) the_signal_handler);	
        signal (SIGCHLD, (void *) handler_sigchld);    
    #else 
		SetConsoleCtrlHandler((void *)win32_signal, TRUE);
        printf (" * * Type /quit and press ENTER to safely shutdown server * *\n");    
    #endif

//    backtrace_initalize();
    map_server_initialize (0);

    time_t tt; time (&tt);
    config.restart_dead_time += 1 + (tt - t);	

    int max_socket = 0;
    	
	lag_stamp = easy_time();  	
    while (!kill_server) {
//		malloc_canary_test ();
		double lag_measurement = easy_time() - lag_stamp;
		lag_stamp = easy_time();
		
		if (lag_measurement > 2) {
			log_printf (NULL, LWARNING, "Lag of %02.02f", lag_measurement);
		}

    	if (lag_measurement > g_lag_max) {
			g_lag_max = lag_measurement;
		}
        
		if (g_stdin_open) console_proc () ;
		npc_proc ();
		map_flow_proc () ;
		process_server_periodic();
//        paint_proc();
//		map_grass_proc ();


        FD_ZERO (&rfds);
        FD_ZERO (&wfds);        
		
		if (g_server_shutdown_timeout == -1) {
			if (g_bind_socket != -1) {
    		    FD_SET (g_bind_socket, &rfds);
		        max_socket = g_bind_socket;
			} else {
				max_socket = 0;
			}
		} else max_socket = 0;

       	user_send_player_updates (0);

    	active_connections = 0;
		int nodelay = 0;

		for ( a = 1; a < NUM_USERS; a++) {
			int pstate = process_user_connection_health (&user[a]);
			if (pstate == USER_NOT_CONNECTED) continue;
			
            if (user[a].write_length > 0) {
                FD_SET (user[a].socket, &wfds);
				nodelay = 1;
            }
            if (user[a].read_length > 0) nodelay = 1;
			
			if (user[a].current_mode != USER_DISCONNECT) {
	            FD_SET (user[a].socket, &rfds);
			}
			active_connections ++;			
            if (user[a].socket > max_socket) max_socket = user[a].socket;
		}
        
		if (active_connections == 0 && g_server_shutdown_timeout == 0) {
			kill_server = 1;
			continue;
		}

        tv.tv_sec = 0;
        if (nodelay == 0) tv.tv_usec = 10000;
		else tv.tv_usec = 1;
        
        ret = select(max_socket + 1, &rfds, &wfds, 0, &tv);
        if (ret < 1) continue;
        if (FD_ISSET (g_bind_socket, &rfds) && g_bind_socket != -1) {
            user_connection_setup();
        } 

        for (a = 1; a < NUM_USERS; a++) {
			if (user[a].current_mode == USER_NOT_CONNECTED) continue;
			process_user_connection_read (&user[a], FD_ISSET (user[a].socket, &rfds));
			if (FD_ISSET (user[a].socket, &wfds)) 
				process_user_connection_write (&user[a]);
		}
    }
	if (config.config_sync) config_save ();
    else log_printf (NULL, LNOTE, "config.txt not updated; use \"/set server.config_sync 1\" to enable");
    map_disk_sync (1) ;    
    log_printf (NULL, LNOTE, "Server exiting, saving maps..");
    map_close_all();
   
    log_printf (NULL, LNOTE, "Saving log file");
	if (g_log_file_handle != 0) { fclose (g_log_file_handle); g_log_file_handle = 0;}
 
    lua_hook_call ("mme_global_event_shutdown", NULL);    

	if (g_debug_mode) alloc_exit();
	easy_die (NULL, 1);
    return (1);	
}

void map_server_initialize (int reload) {
    request_initialize ();
	rank_initialize ();
	config_initialize (); 
    map_initialize ();       
	console_initialize (); 	
//    paint_initialize();

    user_connection_history_initialize ();

    if (config.announce_disabled) {
        log_printf (NULL, LWARNING, "Announcments are disabled; Only local clients allowed.");
    }
    if (rank_count_active () == 0) {
        log_printf (NULL, LWARNING, "No ranks have been defined; using internal defaults.");
        rank_use_internal_defaults();
    }
    if (map_count_active () <= 0) {
        log_printf (NULL, LWARNING, "No maps are loaded; assuming new configuration.");
        if (texture_palette_count_active () == 0) {
            if (texture_palette_load ("textures")) {
                if (!map_load_file (&map_array[0], "default.map")) {
                    map_create ("default.map", 1024, 1024, 192, 64);
                    map_load_file (&map_array[0], "default.map");
                } else log_printf (NULL, LNOTE, "Existing map found");
                config_save();
            }
        }
    }

    lua_initialize();    
    
	lua_hook_call ("mme_global_event_startup", NULL);

	config.online = 0;
	config_server_online (1);

}
