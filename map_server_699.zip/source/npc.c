#include "global.h"

#define PLAYER_HEIGHT 1.66

void npc_verify_position (struct npc *pnpc) {
    if (pnpc->position.x < 0) pnpc->position.x = 0;
    if (pnpc->position.y < 0) pnpc->position.y = 0;
    if (pnpc->position.z < 0) pnpc->position.z = 0;

    if (pnpc->position.x >= pnpc->map->dimension.x) pnpc->position.x = pnpc->map->dimension.x - 1;
    if (pnpc->position.y >= pnpc->map->dimension.y) pnpc->position.y = pnpc->map->dimension.y - 1;
    if (pnpc->position.z >= pnpc->map->dimension.z) pnpc->position.z = pnpc->map->dimension.z - 1;
}

int chance (int percent) {
	int b;
	b=1+(int) (100.0 * (rand() / (RAND_MAX + 1.0)));
	if (b<=percent) return (1);
	return (0);
}

struct user * npc_target_user_closest (struct npc *pnpc) ; 

struct npc *npc_find_empty () {
	int a;
	for (a = 0; a < NUM_NPCS; a++) {
		if (npc[a].active == 0) {
			memset (&npc[a], 0, sizeof (struct npc));
			npc[a].id = a;
			return (&npc[a]);
		}
	}
	
	return (NULL);
}

void npc_initialize () {
	memset (&npc_type, 0, sizeof (npc_type));
	memset (&npc, 0, sizeof (npc));
}

int npc_find_type_empty () {
	int a;
	for (a = 0; a < NUM_NPC_TYPES; a++) {
		if (npc_type[a].name[0] == 0) return (a);
	}
	return (-1);
}

int npc_find_type_by_name (char *name) {
	int a;
	for (a = 0; a < NUM_NPC_TYPES; a++) {
		if (strcasecmp (name, npc_type[a].name) == 0) return (a);
	}
	return (-1);
}

struct npc_type * npc_find_type_struct_by_name (char *name) {
	int a;
	for (a = 0; a < NUM_NPC_TYPES; a++) {
		if (strcasecmp (name, npc_type[a].name) == 0) return ((void *)&npc_type[a]);
	}
	return ((void *)NULL);
}

void npc_proc () {
	int a;
	time_t t;
	time (&t);
	int update = 0;	

	for (a = 0; a < NUM_NPCS; a++) {
		struct npc *pnpc = &npc[a];

		if (pnpc->active == 0) continue;
		if (easy_time() < pnpc->stamp) continue;
		pnpc->stamp = easy_time() + 0.125;
		
		if (pnpc->type->thing_type == 0) {
			struct user *duser;

			duser = npc_target_user_closest (pnpc);

			if (duser != NULL) {
				pnpc->target_position.x = duser->position.x;
				pnpc->target_position.y = duser->position.y;
				pnpc->target_position.z = duser->position.z;
			}
			npc_move (pnpc, pnpc->target_position.x, pnpc->target_position.y, pnpc->target_position.z, 0);
            npc_verify_position (pnpc);
            
			npc_attack_user_closest (pnpc);

			npc_damage_me (pnpc);

			if (pnpc->hitpoints <= 0) {
				pnpc->active = 0;
				packet_broadcast (pnpc->map, USER_CONNECTED,  0, PACKET_DENOUNCE_PLAYER, a + 127);		
			}
		} else if (pnpc->type->thing_type == 1) {
		
			#define NPC_SEE_NOTHING 0
			#define NPC_SEE_PLAYER 1
			#define NPC_SEE_NPC 2
			#define NPC_SEE_BLOCK 3
			
			struct user *uarray[8192];
			char new_mask[8192];
			memset (new_mask, 0, 8192);
			int num;
			num = npc_can_see (pnpc, NPC_SEE_PLAYER, (void *)&uarray, 127);
			int b = 0; 


			for (b = 0; b < num; b++) {
				if (!bit_is_set (uarray[b]->idx, pnpc->umask)) {
					//user_message (uarray[b], "Hi %i..", uarray[b]->id - 1);
					if (chance (pnpc->type->randomness)) {
						if (chance (30)) {
							npc_add (pnpc->map, "zippy", pnpc->position.x, pnpc->position.y, pnpc->position.z);
						} else {
							npc_add (pnpc->map, "zombie", pnpc->position.x, pnpc->position.y, pnpc->position.z);						
						}
					}
					
					
					bit_set (uarray[b]->idx, new_mask);

				} else bit_set (uarray[b]->idx, new_mask);
			}
	

			for (b = 1; b < NUM_USERS; b++) {
				if (bit_is_set (b, pnpc->umask) && (!bit_is_set (b, new_mask))) {
					//user_message (&user[b], "Bye");
				}
			
			}
			memmove (pnpc->umask, new_mask, 32);
			
		} else if (pnpc->type->thing_type == 2) {
		
			if (easy_time() > pnpc->decay_stamp) {
				pnpc->food--;
				pnpc->decay_stamp = easy_time() + pnpc->type->decay;
				printf ("decay %i \n", pnpc->food);
			
			}
		
			struct user *uarray[8192];
			char new_mask[8192];
			memset (new_mask, 0, 8192);
			int num;
			num = npc_can_see (pnpc, NPC_SEE_PLAYER, (void *)&uarray, 127);
			int b = 0; 


			for (b = 0; b < num; b++) {
				if (!bit_is_set (uarray[b]->idx, pnpc->umask)) {
					pnpc->comfort --;
					pnpc->fun --;
					bit_set (uarray[b]->idx, new_mask);

				} else bit_set (uarray[b]->idx, new_mask);
			}
	

			for (b = 1; b < NUM_USERS; b++) {
				if (bit_is_set (b, pnpc->umask) && (!bit_is_set (b, new_mask))) {
					//pnpc->comfort ++;
				}
			
			}
			memmove (pnpc->umask, new_mask, 32);			
			memset (new_mask, 0, 8192);			
			struct npc *narray[8192];			
			
			num = npc_can_see (pnpc, NPC_SEE_NPC, (void *)&narray, 127);
			b = 0;


			for (b = 0; b < num; b++) {
				if (!bit_is_set (narray[b]->id, pnpc->umask)) {
					if (strcmp (pnpc->type->name, narray[b]->type->name) == 0) {
						pnpc->comfort ++;
					} else {
						pnpc->comfort --;
						pnpc->fun --;
					}
					bit_set (narray[b]->id, new_mask);

				} else bit_set (narray[b]->id, new_mask);
			}
	

			for (b = 1; b < NUM_NPCS; b++) {
				if (bit_is_set (b, pnpc->umask) && (!bit_is_set (b, new_mask))) {
					//pnpc->comfort ++;
				}
			
			}
			memmove (pnpc->umask, new_mask, 32);			
			update = 0;
			if (pnpc->proc == NULL) {
				#define NPC_THRESHOLD 6
				int low = -1; 
				if (pnpc->food < NPC_THRESHOLD)  {update = 1; pnpc->proc = (void *)f_npc_find_food; low = pnpc->food;}
				if (pnpc->water < NPC_THRESHOLD || pnpc->water < low)  {update = 1; pnpc->proc = (void *)f_npc_find_water; low = pnpc->water;}
				if (pnpc->comfort < NPC_THRESHOLD || pnpc->comfort < low)  {update = 1; pnpc->proc = (void *)f_npc_find_comfort; low = pnpc->comfort;}
				if (pnpc->social < NPC_THRESHOLD || pnpc->social < low)  {update = 1; pnpc->proc = (void *)f_npc_find_social; low = pnpc->social;}
			
			}
			if (pnpc->proc == NULL) {
				pnpc->proc = (void *)f_npc_random_movement;
				update = 1;
			}
			
			if (pnpc->proc != NULL) {
				pnpc->proc (pnpc, update);

			} 
			
			
		
		}
	}
}
int f_npc_random_movement (struct npc *pnpc, int init) {
	if (init) {
		pnpc->proc = (void *)f_npc_random_movement;
		if (!chance (pnpc->type->randomness) && init == 1) {
			printf ("ignore move\n");
			pnpc->proc = NULL;
			return (0);
		}
		int distance = (int) ((float)pnpc->type->sight * (rand() / (RAND_MAX + 1.0)));		
		int direction = (int) (8.0 * (rand() / (RAND_MAX + 1.0)));
		if (direction == 0) {
			pnpc->target_position.x = pnpc->position.x + distance;
		} else if (direction == 1) {
			pnpc->target_position.x = pnpc->position.x - distance;
		} else if (direction == 2) {
			pnpc->target_position.y = pnpc->position.y + distance;
		} else if (direction == 3) {
			pnpc->target_position.y = pnpc->position.y - distance;
		} else if (direction == 4) {
			pnpc->target_position.x = pnpc->position.x - distance;
			pnpc->target_position.y = pnpc->position.y - distance;
		} else if (direction == 5) {
			pnpc->target_position.x = pnpc->position.x + distance;
			pnpc->target_position.y = pnpc->position.y + distance;
		} else if (direction == 6) {
			pnpc->target_position.x = pnpc->position.x + distance;
			pnpc->target_position.y = pnpc->position.y - distance;
		} else if (direction == 7) {
			pnpc->target_position.x = pnpc->position.x - distance;
			pnpc->target_position.y = pnpc->position.y + distance;
		}			
		
		printf ("New: %ix%i\n", (int)pnpc->target_position.x, (int)pnpc->target_position.y);
		if (pnpc->target_position.x < 0) pnpc->target_position.x = 0;
		if (pnpc->target_position.y < 0) pnpc->target_position.y = 0;
		if (pnpc->target_position.z < 0) pnpc->target_position.z = 0;
		return (0);
	}
	if (!npc_move (pnpc, pnpc->target_position.x, pnpc->target_position.y, pnpc->target_position.z, 0)) {
		pnpc->proc = NULL;
		printf ("move complete\n");
	}
	

    return (1);
}

int f_npc_initialize (struct npc *pnpc, int init) {
	printf ("NPC initialize\n");
	pnpc->food = 10;
	pnpc->water = 10;
	pnpc->comfort = 10;
	pnpc->social = 10;
	pnpc->proc = NULL;
	return (0);
}
int f_npc_find_food (struct npc *pnpc, int init) {
	printf ("find food: %i %i/%i\n", pnpc->id, pnpc->food, NPC_THRESHOLD	);
	if (init) {
	printf ("food init\n");
		int x = 0, y = 0, z = 0;
		int div = pnpc->type->sight / 2;
		z = pnpc->position.z - 1;
		for (int a = 0; a < div; a++) {
			int xmin = pnpc->position.x - a;
			int xmax = pnpc->position.x + a;
			int ymin = pnpc->position.y - a;
			int ymax = pnpc->position.y + a;

			if (xmin < 0) xmin = 0;
			if (ymin < 0) ymin = 0;
			if (xmax >= pnpc->map->dimension.x) xmax = pnpc->map->dimension.x - 1;
			if (ymax >= pnpc->map->dimension.y) ymax = pnpc->map->dimension.y - 1;
		
			for (x = xmin; x < xmax; x++) {
				for (y = ymin; y < ymax; y++) {
					z = surface_height (pnpc->map, x, y, (int)pnpc->position.z - 1);
				
					unsigned char *block = map_get_block_pointer (pnpc->map, x, y, z);
					if (block == NULL) {printf ("Help! %ix%ix%i\n", x, y, z); continue;}
					if (*block == 61) {
					
						if (npc_move (pnpc, x, y, pnpc->position.z, 1)) {
							pnpc->target_position.x = x;
							pnpc->target_position.y = y;
							pnpc->target_position.z = z;

							printf ("Grass at %ix%ix%i\n", x, y, z);		
							x = -1;
							goto out;
						}
					}
				}
			}		
		}
		
		out:
		
		if (x != -1) {
			f_npc_random_movement (pnpc, 2);
			pnpc->proc = (void *)f_npc_random_movement;
			printf ("no food.  Randomly move.\n");
		}		
	
		return (0);
	}
	
	if (!npc_move (pnpc, pnpc->target_position.x, pnpc->target_position.y, pnpc->target_position.z, 0)) {
		printf ("failed move; pick something else.\n");
		f_npc_random_movement (pnpc, 2);
		pnpc->proc = (void *)f_npc_random_movement;

	}
	
	unsigned char *block = map_get_block_pointer (pnpc->map, (int)pnpc->position.x, (int)pnpc->position.y, (int)pnpc->position.z -1 );
	if (block == NULL) {
		printf ("uh oh %ix%ix%i\n",(int) pnpc->position.x, (int)pnpc->position.y, (int)pnpc->position.z);
		return (0);
	}

	if (*block == 61) {
		pnpc->food ++;
		printf ("Chomp! %ix%ix%i\n", (int)pnpc->position.x, (int)pnpc->position.y,(int) pnpc->position.z - 1);
		*block = 255;
	    packet_broadcast (pnpc->map, -1, NULL, PACKET_MAP_MODIFY,(int) pnpc->position.x,(int) pnpc->position.y,(int) pnpc->position.z - 1, (unsigned char) *block, 0);
	}
	
	if (pnpc->food == 10) {
		pnpc->proc = NULL;
		printf ("full\n");
	} else {
		f_npc_find_food (pnpc, 1) ;
	}
	
    return (1);	
}
int f_npc_find_water (struct npc *pnpc, int init) {
	pnpc->food = 10;
	pnpc->proc = NULL;
	printf ("find water %i\n", pnpc->id);
    return (0);
}
int f_npc_find_comfort (struct npc *pnpc, int init) {
	pnpc->comfort = 10;
	pnpc->proc = NULL;
	printf ("find comfort: %i\n", pnpc->id);
    return (0);
}
int f_npc_find_social (struct npc *pnpc, int init) {
	pnpc->social = 10;
	pnpc->proc = NULL;
	printf ("find social: %i\n", pnpc->id);
    return (0);
}


int surface_height (struct map *pmap, int x, int y, int z) {

	unsigned char *block = map_get_block_pointer (pmap, x, y, z);
	
	int tz = z;
	if (*block == 255) {
		while (1) {
			block = map_get_block_pointer (pmap, x, y, tz);
			if (*block != 255) break;
			tz --;
			if (tz < 1) break;
		}
		//if (*block == 61) printf ("down grass at %ix%ix%i\n", x, y, tz);
		return (tz);
	} else {
		while (1) {
			block = map_get_block_pointer (pmap, x, y, tz);
			if (*block != 255) break;
			tz ++;
			if (tz + 1 >= pmap->dimension.z) break;
		}

		//if (*block == 61) printf ("up grass at %ix%ix%i\n", x, y, tz);
		return (tz);
	}
}


void bit_set (int the_bit, char *str) {
	int index = the_bit / 8;
	int bit = 1 << (the_bit % 8);
	str[index] |= bit;
};

int bit_is_set (int the_bit, char *packet_list) {
	if (the_bit < 0 || the_bit >= 32) return 0;
	int index = the_bit / 8;
	int bit = 1 << (the_bit % 8);
	return (packet_list[index] & bit) != 0;
};

int npc_can_see (struct npc *pnpc, int type, void **data, int data_elements) {
	if (type == NPC_SEE_PLAYER) {
		int a;
		int b = 0;

		for (a = 1; a < NUM_USERS; a++) {
			if (user[a].current_mode != USER_CONNECTED) continue;
			if (distance_from_xy ((int) pnpc->position.x, (int) pnpc->position.y,
					(int) user[a].position.x, (int) user[a].position.y) > pnpc->type->sight) continue;

			((struct user **) data )[b] = &user[a];

			b++;
			if (b >= data_elements) break;
		}
		return (b);		
	} else if (type == NPC_SEE_NPC) {
		int a;
		int b = 0;

		for (a = 1; a < NUM_NPCS; a++) {
			if (!npc[a].active) continue;
			if (distance_from_xy ((int) pnpc->position.x, (int) pnpc->position.y,
					(int) npc[a].position.x, (int) npc[a].position.y) > pnpc->type->sight) continue;

			((struct npc **) data )[b] = &npc[a];

			b++;
			if (b >= data_elements) break;
		}
		return (b);
		
	}
    return (0);
}


int distance_from_xy (int fx, int fy, int tx, int ty) {
	int distance = 0;
	int x = iabs (fx - tx);
	int y = iabs (fy - ty);
//	int z = iabs (fz - tz);
	
	if (x > distance) distance = x;
	if (y > distance) distance = y;
	//if (z > distance) distance = z;	

	return (distance);
}

int npc_move (struct npc *pnpc, int new_x, int new_y, int new_z, int test) {

	time_t t;
	time (&t);
	int update  = 0;

	struct float_xyzuv new_position;
	float x = pnpc->position.x;
	float y = pnpc->position.y;


	new_position.x =  pnpc->position.x;
	new_position.y =  pnpc->position.y;
	new_position.z =  pnpc->position.z;		
	new_position.u =  pnpc->position.u;
	new_position.v =  pnpc->position.v;



	float px = new_x - new_position.x;
	float py = new_y - new_position.y;

	float move_x, move_y;

	if (fabs(px) >= pnpc->type->speed) move_x = pnpc->type->speed;
	else move_x = fabs(px);

	if (fabs(py) >= pnpc->type->speed) move_y = pnpc->type->speed;
	else move_y = fabs(py);		


	if (px > 0.5) new_position.x += move_x;
	if (px < -0.5) new_position.x -= move_x;


	if (py > 0.5) new_position.y += move_y;
	if (py < -0.5) new_position.y -= move_y;


	if (new_position.x < 1) new_position.x = 1;
	if (new_position.y < 1) new_position.y = 1;

	if (new_position.x > pnpc->map->dimension.x - 1) new_position.x = pnpc->map->dimension.x - 1;
	if (new_position.y > pnpc->map->dimension.y - 1) new_position.y = pnpc->map->dimension.y - 1;

	int p;
	int step_up = ((float) 0.4 / pnpc->map->scale) + 1;

	if (!npc_move_blocked (pnpc, (int)new_position.x, (int)new_position.y, (int)new_position.z)) {
		update = 1;
		goto move;
	}

	for (p = 1; p < step_up; p++) {
		if (!npc_move_blocked (pnpc, (int)new_position.x, (int)new_position.y, (int)new_position.z+p)) {
			update = 1;
			new_position.z += p;
			goto move;
		}
	}

	if (!npc_move_blocked (pnpc, (int)new_position.x, (int)pnpc->position.y, (int)new_position.z)) {
		update = 1;		
		new_position.y = pnpc->position.y;
		goto move;

	}

	if (!npc_move_blocked (pnpc, (int)pnpc->position.x, (int)new_position.y, (int)new_position.z)) {
		update = 1;	
		new_position.x = pnpc->position.x;
		goto move;
	}

	log_printf (NULL, LDEBUG, "Stuck %0.0fx%0.0fx%0.0f", pnpc->position.x, pnpc->position.y, pnpc->position.z);

	move:;;

	while (!npc_move_blocked (pnpc, (int)new_position.x, (int)new_position.y, (int)new_position.z - 1)) {
		new_position.z --;
	}

	if (pnpc->position.z - new_position.z > step_up) {
		printf ("fall\n");
	}		

//	end:;;

	if (!update) return (0);


	if (new_position.z < 0) new_position.z = 0;

	x = new_position.x - x;
	y = new_position.y - y;
	new_position.u = atan2 (y, x);

	log_printf (NULL, LDEBUG, ">> %f %f", x, y);
	
	if (pnpc->position.x == new_position.x && 
	pnpc->position.y == new_position.y && 
	pnpc->position.z == new_position.z) return (0);
	
	pnpc->position.x = new_position.x;
	pnpc->position.y = new_position.y;
	pnpc->position.z = new_position.z;
	pnpc->position.u = new_position.u;
	pnpc->position.v = new_position.v;

	if (!test) {
		log_printf (NULL, LDEBUG, "Pos %0.0fx%0.0fx%0.0f %f %f %f", pnpc->position.x, pnpc->position.y, pnpc->position.z, pnpc->position.u, x, y);
		float tz = pnpc->position.z + (PLAYER_HEIGHT / pnpc->map->scale); //if (tz > 0) tz--;	
    	packet_broadcast (pnpc->map, USER_CONNECTED, 0, PACKET_MOVE_PLAYER, 
		    	(float)pnpc->position.x, (float)pnpc->position.y, (float)tz, 
		    	(float)pnpc->position.u, (float)pnpc->position.v, pnpc->id + 127);
	}
	return (1);
}

int npc_move2 (struct npc *pnpc, int from_x, int from_y, int from_z, int new_x, int new_y, int new_z) {

	time_t t;
	time (&t);
//	int update  = 0;

	struct int_xyz current_position;
	struct int_xyz new_position;
	
	new_position.x = current_position.x = from_x;
	new_position.y = current_position.y = from_y;
	new_position.z = current_position.z = from_z;
	
	
	while (1) {
		if (new_position.x == new_x && new_position.y == new_y) break;
		
		int px = new_x - current_position.x;
		int py = new_y - current_position.y;
		
		if (px) new_position.x ++;
		else new_position.y --;
	
		if (py) new_position.y ++;
		else new_position.y --;
	
		if (new_position.x < 0) new_position.x = 0;
		if (new_position.y < 0) new_position.y = 0;	
		if (new_position.x >= pnpc->map->dimension.x - 1) new_position.x = pnpc->map->dimension.x - 1;
		if (new_position.y >= pnpc->map->dimension.y - 1) new_position.y = pnpc->map->dimension.y - 1;	
		
		
		int p;
		int step_up = ((float) 0.4 / pnpc->map->scale) + 1;

		if (!npc_move_blocked (pnpc, new_position.x, new_position.y, new_position.z)) {
			//update = 1;
			goto move;
		}

		for (p = 1; p < step_up; p++) {
			if (!npc_move_blocked (pnpc, new_position.x, new_position.y, new_position.z+p)) {
				//update = 1;
				new_position.z += p;
				goto move;
			}
		}

		if (!npc_move_blocked (pnpc, new_position.x, from_y, new_position.z)) {
			//update = 1;		
			new_position.y = from_y;
			goto move;

		}

		if (!npc_move_blocked (pnpc, from_x, new_position.y, new_position.z)) {
			//update = 1;	
			new_position.x = from_x;
			goto move;
		}
		
		
		return (0);
		
		move:;;
		
		
		while (!npc_move_blocked (pnpc, new_position.x, new_position.y, new_position.z - 1)) {
			new_position.z --;
		}
		if (new_position.z < 0) new_position.z = 0;
		
		current_position.x = new_position.x;
		current_position.y = new_position.y;
		current_position.z = new_position.z;

		packet_broadcast (pnpc->map, USER_CONNECTED, 0, PACKET_MAP_MODIFY, current_position.x, current_position.y, current_position.z, 1, 0);		
	}
	return (1);
}

int iabs (int p) {
	if (p < 0) p = 0 - p;
	return (p);
}

int in_width_xyz (struct map *pmap, int sx, int sy, int sz, int vx, int vy, int vz) {
	int wide = (0.4 / pmap->scale) + 1;
//	int tall = (PLAYER_HEIGHT / pmap->scale) + 1;
	
	int dwide = wide / 2;
	int drop = 0;	
	
	int p = iabs(sx - vx);
	if ( p < dwide) {
		drop++;
	}
    
	p = iabs(sy - vy);
	if ( p < dwide) {
		drop++;
	}
	if (drop == 2) return (1);

	return (0);
}

int npc_move_blocked (struct npc *pnpc, int sx, int sy, int sz) {
	int x, y, z;

	x = sx;
	y = sy;
	z = sz;
	int b;
	
	int wide = (0.4 / pnpc->map->scale) + 1;
	int tall = (PLAYER_HEIGHT / pnpc->map->scale) + 1;
	
	int dwide = wide / 2;

	for (z = sz ; z < sz + tall; z ++) {
		for (x = sx - dwide; x <= sx + dwide; x++) {
			for (y = sy - dwide; y <= sy + dwide; y++) {	
				b = (unsigned char) map_get (pnpc->map, (struct short_xyz){ x, y, z});
				if (b != 255 ) {
					log_printf (NULL, LDEBUG, "Stuck at %ix%ix%i by block %i", x, y, z, b);
					return (1);
				}
	
			}
		}
	}
	
	int a;
	for (a = 1; a < NUM_USERS; a++) {
		if (user[a].current_mode != USER_CONNECTED) continue;
		if (user[a].map != pnpc->map) continue;

		if (in_width_xyz (pnpc->map, (int) user[a].position.x, (int) user[a].position.y, (int) user[a].position.z, sx, sy, sz)) {
			
			return (1);
		}
	}
	

	for (a = 1; a < NUM_NPCS; a++) {
		if (npc[a].active == 0) continue;
		if (npc[a].map != pnpc->map) continue;
		if (&npc[a] == pnpc) continue;
		if (npc[a].type->thing_type != 0) continue;

		if (in_width_xyz (pnpc->map ,(int) npc[a].position.x, (int) npc[a].position.y, (int) npc[a].position.z, sx, sy, sz)) {

			return (1);
		}
	}

	return (0);

}

void npc_announce (struct user *puser) {
	int a;
	for (a = 0; a < NUM_NPCS; a++) {
		if (npc[a].active && npc[a].map == puser->map ) {
			char *name = "\x00";
			float tz = npc[a].position.z + (PLAYER_HEIGHT / npc[a].map->scale);// if (tz > 0) tz--;
    		packet_send (puser, PACKET_MOVE_PLAYER, 
		    		(float)npc[a].position.x, (float)npc[a].position.y, (float)tz,
		    		(float)npc[a].position.u, (float)npc[a].position.v, a + 127);

			packet_send (puser, PACKET_ANNOUNCE_PLAYER, a + 127, 11, name);	
            texture_skin_change (puser, a+127, npc[a].type->skin);
		}
	}
}

struct user * npc_target_user_closest (struct npc *pnpc) {
	int idx = -1;
	int target_distance = -1;
	int distance = -1;
	int a;
	for (a = 1; a <	 NUM_USERS; a++) {
		if (user[a].current_mode != USER_CONNECTED) continue;
		int x, y, z;
		
		x = user[a].position.x - pnpc->position.x; if (x < 0) x = 0 - x;
		y = user[a].position.y - pnpc->position.y; if (y < 0) y = 0 - y;
		z = user[a].position.z - pnpc->position.z; if (z < 0) z = 0 - z;		
		if (x > y) distance = x;
		else distance = y;
		if (distance < z) distance = z;
		
		if (distance < target_distance || target_distance == -1) {
			idx = a;
			target_distance = distance;
		}
	}
	if (idx == -1) return (NULL);
	return (&user[idx]);
}

void npc_attack_user_closest (struct npc *pnpc) {
	if (!chance (pnpc->type->attack_chance)) return;

	struct user *puser = npc_target_user_closest (pnpc);
	if (puser == NULL) return;

	if (puser->hitpoints == 0) return;		
	
	int z = puser->position.z - pnpc->position.z;
	int x = puser->position.x - pnpc->position.x;
	int y = puser->position.y - pnpc->position.y;

	if (z < 0) z = 0 - z;
	if (x < 0) x = 0 - x;
	if (y < 0) y = 0 - y;

	if (z <= (PLAYER_HEIGHT / pnpc->map->scale) && x <= pnpc->type->attack_range && y <= pnpc->type->attack_range) {

		puser->hitpoints -= pnpc->type->strength;
		if (puser->hitpoints <= 0) {
			puser->hitpoints = 0;
            menu_killed_dialog (puser, MENU_CREATE);			
		} else {
			user_message (puser, MUSER, "You have taken %i points of damage!", pnpc->type->strength);
		}
	
	}
}

void npc_damage_me (struct npc *pnpc) {
	int x = (int)pnpc->position.x;
	int y = (int)pnpc->position.y;
	int z = (int)pnpc->position.z - 1;
    
    if (z < 0) z = 0;
	
	unsigned char block = pnpc->map->data[(z * npc->map->dimension.y + y) * npc->map->dimension.x + x];
	if (block ==  148 || block == 151) {
		pnpc->hitpoints -= 3;
	}
}


int npc_add (struct map *pmap, char *name, int x, int y, int z) {
	if (name == NULL) {
		return (-1);
	}
	struct npc *pnpc = npc_find_empty();
	pnpc->type = (void *)npc_find_type_struct_by_name (name);
	if (pnpc->type == NULL) {
		//user_message (puser, "npc_add: %s is not a valid type name.", name);
		return (-1);
	}

	pnpc->active = 1;
	pnpc->map = pmap;
	pnpc->hitpoints = pnpc->type->hitpoints;

	pnpc->position.x = (float )x;
	pnpc->position.y = (float)y;
	pnpc->position.z = (float)z;
	pnpc->proc = (void *)f_npc_initialize;

	pnpc->mode = 0;
	pnpc->stamp = 0;

    if (pnpc->type->hitpoints <= 0) {
        log_printf (NULL, LWARNING, "Npc type %s has no hitpoints; adjusting to 1.", pnpc->type->name);
        pnpc->type->hitpoints = pnpc->hitpoints = 1;
    }


	float tz = pnpc->position.z + (PLAYER_HEIGHT / pnpc->map->scale); //if (tz > 0) tz--;
	packet_broadcast (pnpc->map, USER_CONNECTED, 0, PACKET_MOVE_PLAYER, 
		    (float)pnpc->position.x, (float)pnpc->position.y, (float)tz, 
    		(float)pnpc->position.u, (float)pnpc->position.v, (unsigned char)pnpc->id + 127);

	char *npc_name = "\x00";
	packet_broadcast (pnpc->map, USER_CONNECTED, 0, PACKET_ANNOUNCE_PLAYER, pnpc->id + 127, 11, npc_name);				
    texture_skin_change_broadcast (pnpc->map, NULL, pnpc->id + 127, pnpc->type->skin);
    
    return (pnpc->id);

}

void npc_remove (int id) {
	if (id < 0 || id >= NUM_NPCS) {
		log_printf (NULL, LERROR, "npc_remove: %i is not a valid index value.", id);
	}
	if (!npc[id].active) return;
	packet_broadcast (npc[id].map, USER_CONNECTED,  0, PACKET_DENOUNCE_PLAYER, id + 127);
	npc[id].active = 0;
	return;		
}


int in_model (int x, int y, int z, float mx, float my, float mz) {


    return (0);
}
