/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"

#define NUM_MENUS 32

int menu_set_check(int i) {
	if (i == 1) return (i | 4);
	return (0);
}

struct menu_stack {
	struct menu_stack_item {
		char *pointer;
		char *memory;
		char *memory_reference;
		int memory_size;
	} item[NUM_MENUS];
	int menu_stack_index;
	int menu_draw;
} menu_stack[NUM_USERS];

struct menu_stack_item *menu_get_current_stack_item (struct user *puser) {
	struct menu_stack *d;
	d = &menu_stack[puser->idx];
	return (&d->item[d->menu_stack_index]);
}

void menu_stack_clear (struct user *puser) {
	struct menu_stack *d;
	if (puser->idx < 0 || puser->idx > 255) {
		log_printf (puser, LERROR, "menu_stack_clear: invalid user id: %i", puser->idx);
	}	
	d = &menu_stack[puser->idx];
	int a;
	for (a = 0; a < NUM_MENUS; a++) {
		if (d->item[a].memory_size != 0) {
			_free (d->item[a].memory);
		}
        memset (&d->item[a], 0, sizeof (struct menu_stack_item));
	}
	
	d->menu_stack_index = 0;
	d->menu_draw = 0;
	log_printf (puser, LDEBUG, "menu_stack_clear");
    packet_send(puser, PACKET_MENU_RESET, 0, 0, 0);
}

void menu_stack_set (struct user *puser, void *vp) {
	struct menu_stack *d;
	d = &menu_stack[puser->idx];
	
	menu_stack_clear (puser);
	
	d->menu_draw = 0;
	d->menu_stack_index = 0;
	d->item[d->menu_stack_index].pointer = vp;

	log_printf (puser, LDEBUG, "menu_stack_set: %i is %x", d->menu_stack_index, (char *)d->item[d->menu_stack_index].pointer);
}


void menu_stack_push (struct user *puser, void *vp) {
	struct menu_stack *d;
	d = &menu_stack[puser->idx];
	
	if (d->menu_stack_index + 1 >= NUM_MENUS) {
		log_printf (puser, LERROR, "menu_stack_push: out of menu space");
		menu_stack_set (puser, vp);
		return;
	
	}

	if (d->item[d->menu_stack_index].pointer != 0)
		d->menu_stack_index ++;
		
	d->item[d->menu_stack_index].pointer = vp;
	d->menu_draw = 0;
	
	log_printf (puser, LDEBUG, "menu_stack_push: %i is %x", d->menu_stack_index, d->item[d->menu_stack_index].pointer);


}
void menu_stack_pop (struct user *puser) {
	struct menu_stack *d;
	d = &menu_stack[puser->idx];

	log_printf (puser, LDEBUG, "menu_stack_pop: %i is %x", d->menu_stack_index, d->item[d->menu_stack_index].pointer);	
    
    d->item[d->menu_stack_index].pointer = 0;        
	if (d->item[d->menu_stack_index].memory_size != 0) {
		_free (d->item[d->menu_stack_index].memory);
		d->item[d->menu_stack_index].memory_size = 0;
	}
    if (d->menu_stack_index == 0) return;
    
	d->menu_stack_index --;        
   	d->menu_draw = 1;

}


void *menu_stack_push_init (struct user *puser, void *vfp, void *mem_addr, int alloc_size) {
	struct menu_stack_item *m;

	menu_stack_push (puser, vfp);

	m = menu_get_current_stack_item (puser);
	
	if (m->memory_size != 0) {
		_free (m->memory);
		m->memory_size = 0;
		m->memory = NULL;
	}
	
	if (mem_addr == NULL) {
		m->memory_size = alloc_size;
		m->memory = _malloc (alloc_size);
		memset (m->memory, 0, alloc_size);
	} else {
		m->memory_size = 0;
		m->memory = mem_addr;
	}

	return (m->memory);
}

void *menu_get_current_stack_item_memory (struct user *puser) {
	struct menu_stack *d;
	d = &menu_stack[puser->idx];
	return (d->item[d->menu_stack_index].memory);
}

void menu_proc (struct user *puser, int id) {
	struct menu_stack *d;
	d = &menu_stack[puser->idx];
	int (*menu_pointer)(struct user *, int);
	redo:

	log_printf (puser, LDEBUG, "menu_proc: %i is %x", d->menu_stack_index, d->item[d->menu_stack_index].pointer);
	
	if (d->item[d->menu_stack_index].pointer == 0) {
		log_printf (puser, LDEBUG, "Menu pointer is null");	
		return;
	}

	menu_pointer = (void *) d->item[d->menu_stack_index].pointer;

	menu_pointer (puser, id);	

	if (d->menu_draw) {
		d->menu_draw = 0;
		id = MENU_DRAW;
		log_printf (puser, LDEBUG, "DrAW");
		goto redo;
	}
}


int menu_command_parse (struct user *puser, int *number, int *name, int *value, int *flags, unsigned char *text) {
	int ret = 0;
	*number = -1;
	*name = -1;	
	*value = -1;
	*flags = -1;
	text[0] = 0;
	
	if (puser->menu_data_size > 0) *number = (unsigned char )puser->menu_data[0];
	if (puser->menu_data_size > 1) *name = (unsigned char )puser->menu_data[1];	
	if (puser->menu_data_size > 2) *value = (unsigned char )puser->menu_data[2];
	if (puser->menu_data_size > 3) *flags = (unsigned char )puser->menu_data[3];
	if (puser->menu_data_size > 4) {
		memmove (text, puser->menu_data + 4, puser->menu_data_size - 4);
		text[puser->menu_data_size - 4] = 0;
		ret = puser->menu_data_size - 4;
	}
	return (ret);
}
	



void menu_kill (struct user *puser) {
    packet_send(puser, PACKET_MENU_RESET, 0, 0, 0);
    log_printf (puser, LDEBUG, "menu killed");
}


struct d_menu_player_data {
    char user[256][25];
    char selected_user[25];
    char tf;
    
};
