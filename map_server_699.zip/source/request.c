#include "global.h"


void request_initialize () {
    memset (&file_request, 0, sizeof (struct file_request));
}

struct file_request *file_request_struct_find_empty() {
	int a;
	for (a = 0; a < NUM_FILE_REQUESTS; a++) {
		if (file_request[a].active == 0) return (&file_request[a]);
	}
	return (NULL);
}

void request_file_add (char *file) {
	struct file_request *d = file_request_struct_find_empty();
	if (d == NULL) {
		log_printf (NULL, LERROR, "file_request_add: no space left for [%s]", file);
		return;
	}
	
    if (!sha1_file (file, (char *)d->sha1)) {
        log_printf (NULL, LERROR, "request_add_file %s cannot be opened to read sha1", file);
		return;
    }  
	
	_strncpy (d->file, file, 256);
	d->active = 1;
}

void request_queue_by_sha1 (struct user *puser, char *sha1) {

	int a;
	for (a = 1; a < NUM_FILE_REQUESTS; a++) {
		if (!puser->file_request[a].active) break;
	}
	if (a == NUM_FILE_REQUESTS) {
		log_printf (puser, LERROR, "request_queue_by_sha1: request table is full, not adding file to queue");
        return;
	}
    
    int b;
	for (b = 0; b < NUM_FILE_REQUESTS; b++) {
		if (memcmp (sha1, &file_request[b].sha1, 20) == 0) {
			memmove (&puser->file_request[a], &file_request[b], sizeof (struct file_request));
            puser->file_request[a].active = 1;
			break;
		}
	}
    if (b == NUM_FILE_REQUESTS) {
        log_printf (puser, LERROR, "request_queue_by_sha1: sha1 not loaded");
    } else {
    
        puser->file_request_flag = 1;
    }
}


void request_send_proc (struct user *puser) {
    log_printf (NULL, LDEBUG, "request_send %i/%i", puser->data_offset, puser->data_length);
    int b;
    FILE *fn1;
	
	time (&puser->idle_stamp);	
	
    if (puser->data_offset >= puser->data_length) {
        if (puser->file_request[0].active == 0) {
            for (b = 1; b < NUM_FILE_REQUESTS; b++) {
                if (puser->file_request[b].active) {
                    memmove (&puser->file_request[0], &puser->file_request[b], sizeof (struct file_request));
                    puser->file_request[b].active = 0;
                    break;
                }
            }
            if (b == NUM_FILE_REQUESTS || !puser->file_request[0].active) {
                puser->file_request_flag = 0;
                puser->data_length = 0;
                puser->data_offset = 0;
            
                log_printf (NULL, LDEBUG, "No request left to send.");
                return;
            }
        }
        
        fn1 = fopen (puser->file_request[0].file, "rb");
        if (fn1 == 0) {
            log_printf (puser, LERROR, "file_send_proc: file [%s] can't be found.", puser->file_request[0].file);
            puser->data_size = 0;
            puser->file_request[0].active = 0;
            return;
        }
        struct stat st;
        
        fstat (fileno(fn1), &st);
        
        puser->data = _realloc (puser->data, st.st_size + 1);
        
        fread (puser->data, st.st_size, 1, fn1);
        fclose (fn1);
        
        puser->data_size = st.st_size;
        puser->data_length = st.st_size;
        puser->data_offset = 0;
        
        unsigned char sha[20];
        sha1 ((char *)sha, puser->data, puser->data_size);
        
        if (memcmp (sha, puser->file_request[0].sha1, 20) != 0) {
            unsigned char s1[128];
            unsigned char s2[128];
            
            sha1_to_str ((char *)s1, (char *)puser->file_request[0].sha1);
            sha1_to_str ((char *)s2, (char *)sha);
            
            log_printf (puser, LERROR, "file %s's sha1 does not match the one read at load time %s : %s", s1, s2);
        }
        
        packet_send (puser, PACKET_BUFFER_RESET);
        log_printf (NULL, LDEBUG, "File %s has been queued", puser->file_request[0].file);
    } 

    if (puser->data_offset <= puser->data_length && puser->file_request[0].active) {

        int data_left = puser->write_size - puser->write_length;
        
        log_printf (puser, LDEBUG, "Texture %s: Buffer has %i bytes left; texture has %i bytes left", 
            puser->file_request[0].file, data_left, puser->data_length - puser->data_offset);
        
        if (data_left > 0) {
            if (data_left > puser->data_length - puser->data_offset) data_left = puser->data_length - puser->data_offset;
            
            // Make sure that data is sent in packets which are less than 64k,
            // since this is the maximum data that will fit into a packet.
            if (data_left > 32767) data_left = 32767;
            
            packet_send (puser, PACKET_BUFFER_APPEND, puser->data + puser->data_offset, data_left);
            
            puser->data_offset += data_left;
            
            if (puser->data_offset >= puser->data_length) {
                log_printf (puser, LDEBUG, "Texture %s: transmission complete", puser->file_request[0].file);
                
                packet_send (puser, PACKET_BUFFER_IS_FILE_DATA);
                puser->file_request[0].active = 0;
            }
            
    
        } else {
            log_printf (puser, LDEBUG, "file_request send pending buffer depleation");
        }
    }
}
