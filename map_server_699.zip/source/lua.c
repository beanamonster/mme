#include "global.h"

#define NUM_LUA_HOOKFILES	 32

static int lua_broke (lua_State *L) ;

struct lua_hookfile {
	lua_State* L;
	char file[256];
} static lua_hookfile[NUM_LUA_HOOKFILES];


int lua_hookfile_load (char *file) {	
    char path[PATH_MAX];
    snprintf (path, PATH_MAX, "%s/%s", PATH_LUA, file);

    if (access (path, F_OK) == -1) {
        log_printf (NULL, LWARNING, "%s: Cannot run lua file %s: %s", __func__, path, strerror (errno));
        return (0);
    }
	
	struct lua_hookfile *lf = lua_hookfile_struct_find (path);
	if (lf != NULL) {
		lua_close (lf->L);
		lf->L = NULL;
	} else {
		lf = lua_hookfile_new (path);
	}

	if (lf == NULL) {
		log_printf (NULL, LWARNING, "%s: %s; no hookfile space left.", __func__, file);
        return (0);
	}

    lf->L = luaL_newstate();
    luaL_openlibs(lf->L);
    lua_exec_init (lf->L);

    if (luaL_loadfile(lf->L, path) != 0) {
        lua_broke(lf->L);
        log_printf (NULL, LWARNING, "%s: %s could not be started.", __func__, path);
        return (0);
    }    

    if (lua_pcall(lf->L, 0, LUA_MULTRET, 0)) {
        lua_broke(lf->L); 
    }
    return (1);
}


int lua_hookfile_remove (char * file) {
	int a;
	for (a = 0 ;a < NUM_LUA_HOOKFILES; a++) {
		if (strcmp (file, lua_hookfile[a].file) == 0) {
			lua_hookfile[a].file[0] = 0;
			if (lua_hookfile[a].L != NULL) {
				lua_close (lua_hookfile[a].L);
				lua_hookfile[a].L = NULL;
			}
			return (1);
		}
	}
    return (0);
}

void lua_hookfile_list (struct user *puser) {
	int a;
	for (a = 0 ;a < NUM_LUA_HOOKFILES; a++) {
        if (lua_hookfile[a].file[0] == 0) continue;
        if (lua_hookfile[a].L == NULL) continue;
        
        user_message (puser, MUSER, "%s", lua_hookfile[a].file); 
    }
}

void lua_exterminate () {
	int a;
	for (a = 0 ;a < NUM_LUA_HOOKFILES; a++) {
		if (lua_hookfile[a].file[0] != 0) {
			lua_hookfile[a].file[0] = 0;
			if (lua_hookfile[a].L != NULL) {
				lua_close (lua_hookfile[a].L);
				lua_hookfile[a].L = NULL;
			}
		}
	}
}

struct lua_hookfile * lua_hookfile_new (char *file) {
	int a;
	int fe = -1;
	for (a = 0; a < NUM_LUA_HOOKFILES; a++) {
		if (fe == -1 && lua_hookfile[a].file[0] == 0) fe = a;
		if (strcmp (file, lua_hookfile[a].file) == 0) break;
	}
	if (a == NUM_LUA_HOOKFILES) a = fe;
	if (a == -1) {
		log_printf (NULL, LWARNING, "lua_hookfile_new: No more space for hookfiles.");
		return (NULL);
	}
	lua_hookfile[a].L = NULL;
	_strncpy (lua_hookfile[a].file, file, 256);
	return (&lua_hookfile[a]);
}

void lua_initialize () {
	memset (&lua_hookfile, 0, sizeof (lua_hookfile));
    lua_exec (&user[0], "startup.lua", NULL);
//	lua_exec (&user[0], config.lua_startup_file, NULL);
}


static int lua_variable_refresh (lua_State *L) ;

int lua_parameter_expand (lua_State *L, char *func_name, char *parameters, ...) {
    va_list ooo;
    va_start(ooo, parameters);
    int num = strlen (parameters);
    int a;
    int ret = 1;
    
    for (a = 0; a < num; a ++) {
        int p = a - num ;
        if (parameters[a] == 's') {
            if (!lua_isstring (L, p)) {
                ret = 0;
                log_printf (NULL, LWARNING, "%s: Parameter %i must be a string", func_name, a);
            } else {
                char **i = (char **) va_arg(ooo, char *);
                *i = (char *) lua_tostring (L, p);  
            }
        } else if (parameters[a] == 'n') {
            if (!lua_isnumber (L, p)) {
                ret = 0;
                log_printf (NULL, LWARNING, "%s: Parameter %i must be a number", func_name, a);
            } else {
                int *i = (int*) va_arg(ooo, int*);
                *i = lua_tointeger(L, p);
            }        
        } else if (parameters[a] == 'f') {
            if (!lua_isnumber (L, p)) {
                ret = 0;
                log_printf (NULL, LWARNING, "%s: Parameter %i must be a number", func_name, a);
            } else {
				
                float *i = (float*) va_arg(ooo, float*);
				lua_Number fc = lua_tonumber(L, p);
                *i = (float) fc;
            }      			
        } else if (parameters[a] == '?') {
            if (lua_isnumber (L, p)) {
                char temp[32];
                snprintf (temp, 32, "%i", (int)lua_tointeger(L, p));
               
                char **i = (char **) &temp;
                *i = (char *) lua_tostring (L, p);  
               
            } else if (lua_isstring (L, p)) {
                char **i = (char **) va_arg(ooo, char*);
                 *i = (char *) lua_tostring (L, p);  
            }
        } else {
            log_printf (NULL, LERROR, "lua_parameter_expand: %x is not a valid parameter type", parameters[a]);
        }
    }    
    
    va_end (ooo);

    return (ret);
}


struct lua_hookfile* lua_hookfile_struct_find (char *name) {
	int a;
	for (a = 0; a < NUM_LUA_HOOKFILES; a++) {
		if (strcasecmp (lua_hookfile[a].file, name) == 0) return (&lua_hookfile[a]);
	}
	return (NULL);
}


int lua_hook_call (char *hook_name, struct user *puser, ...) {
    lua_State *L = NULL;
    
    int ret = -1;
    int arguments = 0;
	va_list ooo;	
	int a;
	L = NULL;
	
	for (a = 0; a < NUM_LUA_HOOKFILES; a++) {
	    arguments = 0;
		if (lua_hookfile[a].file[0] == 0) continue;
	    lua_getglobal (lua_hookfile[a].L, hook_name);	
		
    	if(!lua_isfunction(lua_hookfile[a].L, -1)) {
        	lua_pop (lua_hookfile[a].L, 1);
        	continue; 
    	} else {
	//		log_printf (puser, LDEBUG, "lua_hook_call: %s contains %s", lua_hookfile[a].file, hook_name);
			L = lua_hookfile[a].L;

    		va_start(ooo, puser);

    		if (strcmp (hook_name, "mme_user_packet_menu_reponse") == 0) {
        		lua_pushlstring (L, puser->name, strlen(puser->name)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;        
        		char *cp = va_arg(ooo, char *);
        		int length = va_arg(ooo, int);
        		lua_pushlstring (L, cp, length);arguments++;        
        		lua_pushnumber (L, length); arguments ++;

			} else if (strcmp (hook_name, "mme_user_event_connected") == 0) {
        		lua_pushlstring (L, puser->name, strlen(puser->name)); arguments++;

    		} else if (strcmp (hook_name, "mme_user_event_position_changed") == 0) {
        		lua_pushlstring (L, puser->name, strlen(puser->name)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, double)); arguments++;    
        		lua_pushnumber (L, va_arg(ooo, double)); arguments++;    
        		lua_pushnumber (L, va_arg(ooo, double)); arguments++;    
        		lua_pushnumber (L, va_arg(ooo, double)); arguments++;    
        		lua_pushnumber (L, va_arg(ooo, double)); arguments++;    
        		lua_pushnumber (L, va_arg(ooo, double)); arguments++;    
        		lua_pushnumber (L, va_arg(ooo, double)); arguments++;    
        		lua_pushnumber (L, va_arg(ooo, double)); arguments++;    
        		lua_pushnumber (L, va_arg(ooo, double)); arguments++;    
        		lua_pushnumber (L, va_arg(ooo, double)); arguments++;    

    		} else if (strcmp (hook_name, "mme_user_receive_packet_file_request") == 0) {        
        		lua_pushlstring (L, puser->name, strlen(puser->name)); arguments++;
        		char poop[45];
        		sha1_to_str (poop, va_arg(ooo, char *));
        		lua_pushlstring (L, poop, strlen (poop));arguments++;

    		} else if (strcmp (hook_name, "mme_user_receive_packet_chat_message") == 0) {                
        		lua_pushlstring (L, puser->name, strlen(puser->name)); arguments++;
        		char *cp = va_arg(ooo, char *);
        		lua_pushlstring (L, cp, strlen (cp));arguments++;

    		} else if (strcmp (hook_name, "mme_user_format_chat_message") == 0) {                
        		lua_pushlstring (L, puser->name, strlen(puser->name)); arguments++;
        		char *cp = va_arg(ooo, char *);
        		lua_pushlstring (L, cp, strlen (cp));arguments++;

    		} else if (strcmp (hook_name, "mme_user_receive_packet_map_fill") == 0) {
        		lua_pushlstring (L, puser->name, strlen(puser->name)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;                   

    		} else if (strcmp (hook_name, "mme_user_receive_packet_map_modify") == 0) {        
        		lua_pushlstring (L, puser->name, strlen(puser->name)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;                    

    		} else if (strcmp (hook_name, "mme_user_receive_packet_menu_request") == 0) {
        		lua_pushlstring (L, puser->name, strlen(puser->name)); arguments++;

    		} else if (strcmp (hook_name, "mme_user_event_player_announced") == 0) {
        		lua_pushlstring (L, puser->name, strlen(puser->name)); arguments++;

    		} else if (strcmp (hook_name, "mme_user_map_modify_allow") == 0) {        
        		lua_pushlstring (L, puser->name, strlen (puser->name)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;
        		lua_pushnumber (L, va_arg(ooo, int)); arguments++;                    

    		} else if (strcmp (hook_name, "mme_user_command") == 0) {
				char *cmd = va_arg(ooo, char *);
	       		char *cp = va_arg(ooo, char *);
				if (cp == NULL) cp = "  \x00";

        		lua_pushlstring (L, puser->name, strlen (puser->name)); arguments++;
        		lua_pushstring (L, cmd); arguments++;
        		lua_pushstring (L, cp); arguments++;
				
			} else if (strcmp (hook_name, "mme_user_event_map_loading") == 0) {
        		lua_pushstring (L, puser->name); arguments++;
				lua_pushnumber (L, va_arg(ooo, int)); arguments++;
				lua_pushnumber (L, va_arg(ooo, int)); arguments++;
    		}
			va_end (ooo);

			lua_variable_refresh (L);
    		if (lua_pcall(L, arguments, 1, 0)) {lua_broke(L); ret = -1; goto end;}
			int tret = -1;
    		switch (lua_type(L, lua_gettop( L ) ))   {
    		case LUA_TNUMBER: tret = lua_tointeger(L, lua_gettop( L )); break;
    		case LUA_TBOOLEAN: tret = lua_toboolean (L, lua_gettop(L )); break;
    		default:
        		log_printf (NULL, LWARNING, "hooks must return numbers or boolean\n");
    		}
    		lua_pop(L, 1);

			if (tret) ret = 1;
		}
	}
	end:
    
	if (ret == -1) return (0);
    return (ret);       
}


static int lua_broke (lua_State *L) {
	for (int a = 0; a < NUM_LUA_HOOKFILES; a++) {
	    if (lua_hookfile[a].L == L) {
			lua_hookfile[a].file[0] = 0;
		}
	}   
    log_printf (NULL, LERROR, "Lua died; stopping instance");
    log_printf (NULL, LERROR, "[%s]", lua_tostring(L, -1));  
    lua_close (L);
    L = NULL;
   
    return 1;
}


static int lua_time (lua_State *L) {
    lua_pushnumber(L, easy_time());
    return (1);
}

static int lua_map_draw_sphere (lua_State *L) {
	struct user u;
	char *file;
	
    int x, y, z, r, block;
    log_printf (NULL, LDEBUG, "lua_map_draw_sphere");

    if (!lua_parameter_expand (L, "lua_map_draw_sphere", "snnnnn", &file, &x, &y, &z, &r, &block)) return (0);
	
	memmove (&u, &user[0], sizeof (struct user));
	u.map = map_struct_find_by_filename (file);
	
	if (u.map == NULL) {
		log_printf (NULL, LWARNING, "lua_map_draw_sphere: map file %s is not loaded", file);
		lua_pushnumber(L, 0);
		return (1);
	}

	map_draw_sphere (&u, x, y, z, r, block);
	lua_pushnumber(L, 1);
	return (1);
}



static int lua_map_modify_block (lua_State *L) {
	char *name;
    int  x, y, z, block;
    log_printf (NULL, LDEBUG, "lua_map_modify_block");

    if (!lua_parameter_expand (L, "lua_map_modify_block", "snnnn", &name, &x, &y, &z, &block)) return (0);

    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
		log_printf (NULL, LWARNING, "lua_map_modify_block: map file %s is not loaded.", name);
    }
	
	map_modify (puser->map, (struct short_xyz){x, y, z}, block);
	
	packet_broadcast (puser->map, -1, NULL, PACKET_MAP_MODIFY, (short)x, (short)y, (short)z, (unsigned char) block);

	lua_pushnumber(L, 1);
	return (1);

}

static int lua_user_get (lua_State *L) {
    char *name, *parameter;
    log_printf (NULL, LDEBUG, "lua_user_get");

    if (!lua_parameter_expand (L, "lua_user_get", "ss", &name, &parameter)) return (0);

    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_get: %s is not connected", name);
        return (0);
    }
    
    if (strcmp (parameter, "current_mode") == 0) {
        lua_pushnumber(L, puser->current_mode);
        return 1;

    } else if (strcmp (parameter, "name") == 0) {
        lua_pushstring(L, puser->name);
        return 1;

    } else if (strcmp (parameter, "chat_name") == 0) {
        lua_pushstring(L, user_name (puser, 0));
        return 1;

    } else if (strcmp (parameter, "ip_address") == 0) {
        lua_pushstring(L, puser->ip_address);
        return 1;
		
    } else if (strcmp (parameter, "rank_name") == 0) {
        lua_pushstring(L, puser->rank_name);
        return 1;
		
    } else if (strcmp (parameter, "uid") == 0) {
        lua_pushnumber(L, puser->uid);
        return 1;
		
    } else if (strcmp (parameter, "color") == 0) {
		char colorthing[] = {"1234567890abcdef"};
	
		char yip[32];
		yip[0] = colorthing[puser->color - 1];
		yip[1] = 0;

		lua_pushstring(L, yip);
        return 1;
		
    } else if (strcmp (parameter, "socket") == 0) {
        lua_pushnumber(L, puser->socket);
        return 1;
		
    } else if (strcmp (parameter, "new") == 0) {
        lua_pushnumber(L, puser->new);
        return 1;
		
    } else if (strcmp (parameter, "client_version") == 0) {
        lua_pushnumber(L, puser->client_version);
        return 1;

    } else if (strcmp (parameter, "skin_name") == 0) {
        lua_pushstring(L, puser->skin_name);
        return 1;
        
    } else if (strcmp (parameter, "map_id") == 0) {
        lua_pushnumber(L, puser->map->id);
        return 1;    
		
//    } else if (strcmp (parameter, "map_data") == 0) {
//        lua_pushnumber(L, puser->map->data);
//        return 1;        
		
    } else if (strcmp (parameter, "who_enabled") == 0) {
        lua_pushnumber(L, puser->who);
        return 1;                
		
    } else if (strcmp (parameter, "position_x") == 0) {
        lua_pushnumber(L, puser->position.x);
        return 1;

    } else if (strcmp (parameter, "position_y") == 0) {
        lua_pushnumber(L, puser->position.y);
        return 1;

    } else if (strcmp (parameter, "position_z") == 0) {
        lua_pushnumber(L, puser->position.z);
        return 1;

    } else if (strcmp (parameter, "position_u") == 0) {
        lua_pushnumber(L, puser->position.u);
        return 1;

    } else if (strcmp (parameter, "position_v") == 0) {
        lua_pushnumber(L, puser->position.v);
        return 1;

    } else {
		log_printf (NULL, LWARNING, "lu_user_get: %s is unknown.", parameter);
		lua_pushnil(L);
		return (1);
	}
    
	return (0);
}

static int lua_user_set (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_set");
    char *name, *parameter;

    if (!lua_parameter_expand (L, "lua_user_set", "ss", &name, &parameter)) return (0);
    
    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_set: %s is not connected", name);
        return (0);
    }
    
    if (strcmp (parameter, "current_mode") == 0) {
        puser->current_mode = lua_tointeger (L, -1);
        return 1;

    } else if (strcmp (parameter, "name") == 0) {
        _strncpy (puser->name, lua_tostring (L, -1), 25);
        return 1;

    } else if (strcmp (parameter, "color") == 0) {
        puser->color = lua_tointeger (L, -1);

        return 1;

    } else if (strcmp (parameter, "skin_name") == 0) {
        char temp[32];
        _strncpy (temp, lua_tostring (L, -1), 32);
        
        int id =  skin_texture_find_id_by_name (puser->map->palette, temp);
        if (id == -1) {
            log_printf (puser, LWARNING, "mme_user_set: skin not found"); 
            return (1);
        }
        
        strcpy (puser->skin_name, puser->map->palette->skin[id].name);
        puser->skin_id = puser->map->palette->skin[id].texture->id;

        packet_broadcast (puser->map, USER_CONNECTED, puser, PACKET_PLAYER_PROPERTIES, 
                puser->idx, puser->skin_id);
        
        return 1;
        
    } else if (strcmp (parameter, "error_message") == 0) {
        _strncpy (puser->error_message, lua_tostring (L, -1), 256);
        return 1;

    } else if (strcmp (parameter, "who_enabled") == 0) {
        puser->who = lua_tointeger (L, -1);
        return 1;                
    }
    
    log_printf (NULL, LDEBUG, "[%s]", parameter);
    
//  int current_mode     = luaL_checkint(L, 1);
//  printf ("Current mode = %i\n", current_mode);
	return (0);
}


static int lua_map_get (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_map_get");
    int idx = 0;
    char *parameter;

    if (!lua_parameter_expand (L, "lua_map_get", "ns", &idx, &parameter)) return (0);
 
    if (strcmp (parameter, "dimension.x") == 0) {
        lua_pushnumber(L, map_array[idx].dimension.x);
        return 1;

    } else if (strcmp (parameter, "dimension.y") == 0) {
        lua_pushnumber(L, map_array[idx].dimension.y);
        return 1;

    } else if (strcmp (parameter, "dimension.z") == 0) {
        lua_pushnumber(L, map_array[idx].dimension.z);
        return 1;

    } else if (strcmp (parameter, "sealevel") == 0) {
        lua_pushnumber(L, map_array[idx].sealevel);
        return 1;

    } else if (strcmp (parameter, "file") == 0) {
        lua_pushstring(L, map_array[idx].file);
        return 1;

    } else if (strcmp (parameter, "build_rank_name") == 0) {
        lua_pushstring(L, map_array[idx].build_rank_name);
        return 1;

    } else if (strcmp (parameter, "scale") == 0) {
        lua_pushnumber(L, map_array[idx].scale);
        return 1;

    } else if (strcmp (parameter, "block_palette_name") == 0) {
        lua_pushstring(L, map_array[idx].block_palette_name);
        return 1;
    }    
    
    log_printf (NULL, LDEBUG, "[%s]", parameter);

	return (0);
}

static int lua_map_set (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_map_set");
    char *parameter, *value;
	char *map_file;

    if (!lua_parameter_expand (L, "lua_map_set", "ss?", &map_file, &parameter, &value)) return (0);
	
	struct map *pmap = map_struct_find_by_filename (map_file);
	if (pmap == NULL) {
		log_printf (NULL, LWARNING, "lua_map_set: The map file %s is not loaded.", map_file);
		return (0);
	}
    
	int ret = 1;
    
    if (strcmp (parameter, "sealevel") == 0) pmap->sealevel = atoi (value);
    else if (strcmp (parameter, "spawn_x") == 0) pmap->spawn.x = atof (value);
	else if (strcmp (parameter, "spawn_y") == 0) pmap->spawn.y = atof (value);
	else if (strcmp (parameter, "spawn_z") == 0) pmap->spawn.z = atof (value);
	else if (strcmp (parameter, "spawn_u") == 0) pmap->spawn.u = atof (value);
	else if (strcmp (parameter, "spawn_v") == 0) pmap->spawn.v = atof (value);
	else if (strcmp (parameter, "file") == 0) _strncpy (pmap->file, value, 255);
	else if (strcmp (parameter, "build_rank_name") == 0) _strncpy (pmap->build_rank_name, value, 32);
	else if (strcmp (parameter, "scale") == 0) {
		float f = atof (value);
		if (f < 0.1) f = 0.1;
		if (f > 1.0) f = 1.0;
		pmap->scale = f;
	}
	else if (strcmp (parameter, "block_palette_name") == 0) _strncpy (pmap->block_palette_name, value, 32);
	else {
		log_printf (NULL, LWARNING, "lua_map_set: Unknown variable [%s]", parameter);
		ret = 0;
	}
	lua_pushnumber(L, ret);
    return (1);
}

static int lua_user_disconnect (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_disconnect");
    
    char *name, *reason, *str;
    int delay;
    
    if (!lua_parameter_expand (L, "lua_user_disconnect", "ssns", &name, &reason, &delay, &str)) return (0);    

    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_disconnect: %s is not connected", name);
        lua_pushnumber(L, 0);
        return (1);
    }
    int reason_number = 0;
    if (strcasecmp (reason, "ERROR") == 0) reason_number = 1;
    else if (strcasecmp (reason, "REBOOT") == 0) reason_number = 2;
    else if (strcasecmp (reason, "FULL") == 0) reason_number = 3;
    else if (strcasecmp (reason, "IDLE") == 0) reason_number = 4;
    else if (strcasecmp (reason, "KICK") == 0) reason_number = 5;
    else if (strcasecmp (reason, "BAN") == 0) reason_number = 6;
    else if (strcasecmp (reason, "RANDOM") == 0) reason_number = 7;
    else log_printf (NULL, LWARNING, "lua_user_disconnect: %s is not a valid reason; defaulting to NULL.", reason);
    
    user_disconnect (puser, reason_number, delay, str);
    
    lua_pushnumber(L, 1);
    return (1);
}





static int lua_user_show_message_file (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_show_message_file");
    char *name, *file;
    
    if (!lua_parameter_expand (L, "lua_user_show_message_file", "ss", &name, &file)) return (0);        

    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_show_message_file: %s is not connected", name);
        lua_pushnumber(L, 0);
        return (1);
    }
    
    user_show_message_file (puser, file);
    lua_pushnumber(L, 1);
    return 1;
}


static int lua_user_show_message_file_dialog (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_show_message_file_dialog");
    char *name, *file;

    if (!lua_parameter_expand (L, "lua_user_show_message_file_dialog", "ss", &name, &file)) return (0);            

    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_show_message_file_dialog: %s is not connected", name);
        lua_pushnumber(L, 0);
        return (1);
    }
    user_show_message_file_dialog (puser, file);
    lua_pushnumber(L, 1);
    return 1;
}



static int lua_user_message_dialog (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_message_dialog");
    char *name, *message;

    if (!lua_parameter_expand (L, "lua_user_message_dialog", "ss", &name, &message)) return (0);            

    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_message_dialog: %s is not connected", name);
        lua_pushnumber(L, 0);
        return (1);
    }

    menu_dialog (puser, MENU_CREATE, "Message", message, "OK");
    lua_pushnumber(L, 1);
    return 1;
}

/*
static int lua_user_announce (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_announce");
    
    char *name, *message;
    if (!lua_parameter_expand (L, "lua_user_announce", "ss", &name, &message)) return (0);            
    
    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_announce: %s is not connected", name);
        lua_pushnumber(L, 0);
        return (1);
    }
    
    user_announce_player (puser, message);
    
    lua_pushnumber(L, 1);
    return 1;
}*/

static int lua_user_chat_private (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_chat_private");
    
    char *name, *message;
    if (!lua_parameter_expand (L, "lua_user_chat_private", "ss", &name, &message)) return (0);            
    
    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_chat_private: %s is not connected", name);
        lua_pushnumber(L, 0);
        return (1);
    }
    
    user_chat_private (puser, message);
    
    lua_pushnumber(L, 1);
    return 1;
}

static int lua_global_add_to_list (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_global_add_to_list");
    
    char *name, *file;

    if (!lua_parameter_expand (L, "lua_global_add_to_list", "ss", &name, &file)) return (0);            

    add_to_list (name, file);    
    
    lua_pushnumber(L, 1);
    return 1;
}


static int lua_global_remove_from_list (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_global_remove_from_list");
    char *name, *file;

    if (!lua_parameter_expand (L, "lua_global_remove_from_list", "ss", &name, &file)) return (0);            
    
    lua_pushnumber(L, remove_from_list (name, file));
    return 1;
}


static int lua_global_in_list (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_global_in_list");

    char *name, *file;

    if (!lua_parameter_expand (L, "lua_global_in_list", "ss", &name, &file)) return (0);            
 
    
    lua_pushnumber(L, in_list (name, file));
    return 1;
}



static int lua_user_kick (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_kick");
    char *name, *destname, *reason;
    if (!lua_parameter_expand (L, "lua_user_kick", "sss", &name, &destname, &reason)) return (0);                
    
    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_kick: %s is not connected", name);
        lua_pushnumber(L, 0);
        return (1);
    }
        
    int id;
    if (user_id_by_name (puser->map, destname, &id)) {
        user_kick (puser, id, reason);
    } else user_message (puser, MUSER, "%s does not appear to be a user; did you spell it correctly?", destname); 

    
    lua_pushnumber(L, 1);
    return 1;
}

static int lua_user_ban (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_ban");
    
    char *name, *destname, *reason;
    
    if (!lua_parameter_expand (L, "lua_user_ban", "sss", &name, &destname, &reason)) return (0);                
    
    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_ban: %s is not connected", name);
        lua_pushnumber(L, 0);
        return (1);
    }
        
    int id;
    if (user_id_by_name (puser->map, destname, &id)) {
        user_ban (puser, id, reason);
    } else user_message (puser, MUSER, "%s does not appear to be a user; did you spell it correctly?", destname); 
    
    lua_pushnumber(L, 1);
    return 1;
}

static int lua_user_ipban (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_ipban");
    char *name, *destname, *reason;
    
    if (!lua_parameter_expand (L, "lua_user_ipban", "sss", &name, &destname, &reason)) return (0);                
    
    
    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_ipban: %s is not connected", name);
        lua_pushnumber(L, 0);
        return (1);
    }
        
    int id;
    if (user_id_by_name (puser->map, destname, &id)) {
        user_ipban (puser, id, reason);
    } else user_message (puser, MUSER, "%s does not appear to be a user; did you spell it correctly?", destname); 

    
    lua_pushnumber(L, 1);
    return 1;
}


static int lua_user_map_switch (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_map_switch");
    
    char *name, *map_name;
    
    if (!lua_parameter_expand (L, "lua_user_map_switch", "ss", &name, &map_name)) return (0);
    
    
    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_map_switch: %s is not connected", name);
        lua_pushnumber(L, 0);
        return (1);
    }
      
    user_map_switch (puser, map_name);
    
    lua_pushnumber(L, 1);
    return 1;
}


static int lua_send_map_region (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_send_map_region");
    char *name;
    int lx, ly, lz, ux, uy, uz;

    if (!lua_parameter_expand (L, "lua_send_map_region", "snnnnnn", &name, &lx, &ly, &lz, &ux, &uy, &uz)) return (0);
    
    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_send_map_region: %s is not connected", name);
        return (0);
    }

    struct short_xyz c;
    for (c.x = lx; c.x <= ux; c.x++) {
        for (c.y = ly; c.y <= uy; c.y++) {
            for (c.z = lz; c.z <= uz; c.z++) {
                packet_send (puser, PACKET_MAP_MODIFY, c.x, c.y, c.z, map_get(puser->map, c), 0);
            }
        }
    }
    return (0);

}

static int lua_send_player_announce (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_send_player_announce");
    char *name, *announce_name;
    int color, number;

    if (!lua_parameter_expand (L, "lua_send_player_announce", "snns", &name, &color, &number, &announce_name)) return (0);
    
    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_send_player_announce: %s is not connected", name);
        return (0);
    }

    packet_send (puser, PACKET_ANNOUNCE_PLAYER, (unsigned char)number, (unsigned char)color, announce_name);
    return (0);
}

static int lua_send_player_denounce (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_send_player_denounce");
    char *name;
    int number;
    
    if (!lua_parameter_expand (L, "lua_send_player_denounce", "sn", &name, &number)) return (0);    
    
    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_send_player_announce: %s is not connected", name);
        return (0);
    }

    packet_send (puser, PACKET_DENOUNCE_PLAYER, (unsigned char)number);

    return (0);
}


static int lua_hookfile_load_lua (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_hookfile");
    char *file;
    
    if (!lua_parameter_expand (L, "lua_hookfile", "s", &file)) return (0);    
	
    char path[PATH_MAX];
    snprintf (path, PATH_MAX, "%s/%s", PATH_LUA, file);

    if (access (path, F_OK) == -1) {
        log_printf (NULL, LWARNING, "lua_hookfile: Cannot run lua file %s: %s", path, strerror (errno));
	    lua_pushnumber(L, 0);		
        return (1);
    }
	
	struct lua_hookfile *lf = lua_hookfile_struct_find (path);
	if (lf != NULL) {
		lua_close (lf->L);
		lf->L = NULL;
	} else {
		lf = lua_hookfile_new (path);
	}
//	struct lua_hookfile *lf = lua_hookfile_new (path);
	if (lf == NULL) {
		log_printf (NULL, LWARNING, "lua_hookfile: %s; no hookfile space left.", file);
	    lua_pushnumber(L, 0);		
        return (1);
	}

    lf->L = luaL_newstate();
    luaL_openlibs(lf->L);
    lua_exec_init (lf->L);

    if (luaL_loadfile(lf->L, path) != 0) {
        lua_broke(lf->L);
        log_printf (NULL, LWARNING, "lua_hookfile: %s could not be started.", path);
	    lua_pushnumber(L, 0);		
        return (1);
    }    

    if (lua_pcall(lf->L, 0, LUA_MULTRET, 0)) {
        lua_broke(lf->L); 
    }
//	else lua_hookfile_remove (path);
	lua_pushnumber(L, 1);		
    return (1);
}



static int lua_send_move_player (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_send_move_player");
    char *name;
    int x, y, z, u, v;
    int id;
    
    if (!lua_parameter_expand (L, "lua_send_move_player", "snnnnnn", &name, &x, &y, &z, &u, &v, &id)) return (0);    
    
    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_send_player_announce: %s is not connected", name);
        return (0);
    }
 
    packet_send (puser, PACKET_MOVE_PLAYER, (float)x, (float)y, (float)z, (float)u, (float)v, (unsigned char) id);

    return (0);
}


static int lua_map_get_block (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_map_get_block");
    int x, y, z;    
	char *map_file;
    
    if (!lua_parameter_expand (L, "lua_map_get_block", "snnn", &map_file, &x, &y, &z)) return (0);    
    
    log_printf (NULL, LDEBUG, "lua_map_get_block  %ix%ix%i", x, y, z);
    
	struct map *pmap = map_struct_find_by_filename (map_file);
	if (pmap == NULL) {
		log_printf (NULL, LWARNING, "lua_map_get_block: The map file %s is not loaded.", map_file);
		return (0);
	}
    
    int type = map_get (pmap, ((struct short_xyz){ x, y, z}));
    
    lua_pushnumber(L, type);
    return (1);
}


static int lua_user_message (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_message");
    char *name, *message;
    if (!lua_parameter_expand (L, "lua_user_message", "ss", &name, &message)) return (0);

    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_message: %s is not connected", name);
        return (0);
    }
   
    user_message (puser, MNULL, "%s", message);
    return 0;
}


static int lua_user_message_broadcast (lua_State *L) {
    static char *function_name = "lua_user_message_broadcast";
    
    log_printf (NULL, LDEBUG, function_name);
    char *name, *message;

    if (!lua_parameter_expand (L, function_name, "ss", &name, &message)) return (0);

    struct user *puser;
    if (strcasecmp (name, "null") == 0) puser = NULL;
    else {
        puser = user_attached_find_by_name (name);
        if (puser == NULL) {
            log_printf (puser, LWARNING, "%s: %s is not connected", function_name, name);
            return (0);
        }
    }

    user_message_broadcast (puser, MNULL, "%s", message);
    return (0);
}

static int lua_send_packet_map_modify (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_send_packet_map_modify");

    char *name;
    int x, y, z, type;
    if (!lua_parameter_expand (L, "lua_send_packet_map_modify", "snnnn", &name, &x, &y, &z, &type)) return (0);
    
    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "mme_packet_send: %s is not connected", name);
        return (0);
    }
    log_printf (puser, LDEBUG, "[%s] %ix%ix%i: %i", name, x, y, z, type);
    
    packet_send (puser, PACKET_MAP_MODIFY, x, y, z, type, 0);        

    return 0;
}

static int lua_user_menu_reset (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_menu_reset");
    char *name;
    int number, column, line, flags;

    if (!lua_parameter_expand (L, "lua_user_menu_reset", "snnnn", &name, &number, &column, &line, &flags)) return (0);
    
    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_menu_reset: %s is not connected", name);
        return (0);
    }

    packet_send (puser, PACKET_MENU_RESET, number, column, line, flags);

    return (0);
}

static int lua_user_menu_kill (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_menu_kill");
    char *name;

    if (!lua_parameter_expand (L, "lua_user_menu_kill", "s", &name)) return (0);
    
    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_menu_kill: %s is not connected", name);
        return (0);
    }

  	menu_kill (puser);

    return (0);
}


static int lua_user_menu_text (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_menu_text");
    char *name, *text;
    int index, column, line;
    
    if (!lua_parameter_expand (L, "lua_user_menu_text", "snnns", &name, &index, &column, &line, &text)) return (0);

    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_menu_text: %s is not connected", name);
        return (0);
    }

	packet_send(puser, PACKET_MENU_TEXT, (unsigned char)index, (unsigned char)column, (unsigned char)line, text);

    return (0);
}

static int lua_user_menu_map_loading (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_menu_map_loading");
    char *name, *text;
    int percent;
    
    if (!lua_parameter_expand (L, "lua_user_menu_map_loading", "ssn", &name, &text, &percent)) return (0);

    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_menu_map_loading: %s is not connected", name);
        return (0);
    }

	packet_send(puser, PACKET_MAP_LOADING, percent, text);

    return (0);
}

static int lua_user_menu_link (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_menu_link");
    char *name, *text;
    int index, column, line, menu_name, menu_value, flags;
    
    if (!lua_parameter_expand (L, "lua_user_menu_link", "snnnnnns", &name, &index, &column, &line, &menu_name, &menu_value, &flags, &text)) return (0);

    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_menu_link: %s is not connected", name);
        return (0);
    }

	packet_send(puser, PACKET_MENU_LINK, index, column, line, menu_name, menu_value, flags, text);

    return (0);
}


static int lua_user_menu_button (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_menu_button");
    char *name, *text;
    int index, column, line, width, menu_name, menu_value, flags;
    
    if (!lua_parameter_expand (L, "lua_user_menu_button", "snnnnnnns", &name, &index, &column, &line, &menu_name, &menu_value, &width, &flags, &text)) return (0);
    
    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_menu_button: %s is not connected", name);
        return (0);
    }

	packet_send(puser, PACKET_MENU_BUTTON, index, column, line, menu_name, menu_value, width, flags, text);

    return (0);
}


static int lua_user_menu_radio (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_menu_radio");
    
    char *name, *text;
    int index, column, line,  menu_name, menu_value, flags;
    
    if (!lua_parameter_expand (L, "lua_user_menu_radio", "snnnnnns", &name, &index, &column, &line, &menu_name, &menu_value, &flags, &text)) return (0);
    
    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_menu_radio: %s is not connected", name);
        return (0);
    }

	packet_send(puser, PACKET_MENU_RADIO, index, column, line, menu_name, menu_value, flags, text);

    return (0);
}

static int lua_user_menu_input (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_menu_input");
    
    char *name, *text;
    int index, column, line,  menu_name, menu_value, flags;
    
    if (!lua_parameter_expand (L, "lua_user_menu_input", "snnnnnns", &name, &index, &column, &line, &menu_name, &menu_value, &flags, &text)) return (0);
    
    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_menu_input: %s is not connected", name);
        return (0);
    }

	packet_send(puser, PACKET_MENU_INPUT, index, column, line, menu_name, menu_value, flags, text);
    return (0);
}

static int lua_user_menu_check (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_menu_check");

    char *name, *text;
    int index, column, line,     menu_name, menu_value, flags;
    
    if (!lua_parameter_expand (L, "lua_user_menu_check", "snnnnnns", &name, &index, &column, &line, &menu_name, &menu_value, &flags, &text)) return (0);

    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
        log_printf (puser, LWARNING, "lua_user_menu_check: %s is not connected", name);
        return (0);
    }

	packet_send(puser, PACKET_MENU_CHECK, index, column, line, menu_name, menu_value, flags, text);

    return (0);
}

static int lua_global_connected_users (lua_State *L) {
    if (!lua_istable (L, -1)) {log_printf (NULL, LWARNING, " lua_global_connected_users: Parameter must be a table"); return (0);}    

    int a;
    int b = 1;
    for (a = 1; a < NUM_USERS; a++) {
        if (user[a].current_mode != USER_CONNECTED) continue;

        lua_pushvalue(L, b);   
        lua_pushstring(L, user[a].name);
        lua_rawseti(L, 1, b);  
        b++;        
    }

    lua_pushnumber(L, b - 1);
    return (1);
}

static void set_field_int (lua_State *L, char *str, int v) {
	lua_pushstring (L, str);	
	lua_pushinteger (L, v);
	lua_settable(L, -3);
}

static void set_field_string (lua_State *L, char *str, char * v) {
	lua_pushstring (L, str);	
	lua_pushstring (L, v);
	lua_settable(L, -3);
}

static void set_field_number (lua_State *L, char *str, double v) {
	lua_pushstring (L, str);	
	lua_pushnumber (L, v);
	lua_settable(L, -3);
}

static int lua_variable_refresh (lua_State *L) {
    int a;

    lua_newtable(L);
    for (a = 0; a < NUM_USERS; a++) {    
        if (user[a].current_mode < USER_CONNECTING || user[a].current_mode == USER_DISCONNECT) continue;
	    lua_newtable(L);		
		set_field_string (L, "name", user[a].name);
		set_field_string (L, "chat_name", user_name (&user[a], 0));
		set_field_string (L, "rank_name", user[a].rank_name);
		set_field_string (L, "skin_name", user[a].skin_name);

		if (user[a].map != NULL) set_field_string (L, "map_file", user[a].map->file);

		set_field_string (L, "ip_address", user[a].ip_address);
		set_field_int (L, "id", user[a].idx);
		set_field_int (L, "current_mode", user[a].current_mode);
		set_field_int (L, "new", user[a].new);
		set_field_int (L, "client_version", user[a].client_version);
		set_field_int (L, "uid", user[a].uid);
		set_field_int (L, "socket", user[a].socket);
		set_field_number (L, "position_x", user[a].position.x);
		set_field_number (L, "position_y", user[a].position.y);
		set_field_number (L, "position_z", user[a].position.z);
		set_field_number (L, "position_u", user[a].position.u);
		set_field_number (L, "position_v", user[a].position.v);

		char colorthing[] = {"1234567890abcdef"};
	
		char yip[32];
		yip[0] = colorthing[user[a].color - 1];
		yip[1] = 0;

		set_field_string (L, "color", yip);
		lua_setfield (L, -2, user[a].name);
    }
    lua_setglobal(L, "mme_user");    

    lua_newtable(L);
    for (a = 0; a < NUM_MAPS; a++) {    
        if (!map_array[a].active) continue;
		
	    lua_newtable(L);		
		set_field_string (L, "file", map_array[a].file);
		set_field_string (L, "build_rank_name", map_array[a].build_rank_name);
		set_field_string (L, "block_palette_name", map_array[a].block_palette_name);
		set_field_int (L, "id", map_array[a].id);
		set_field_int (L, "dimension_x", map_array[a].dimension.x);
		set_field_int (L, "dimension_y", map_array[a].dimension.y);
		set_field_int (L, "dimension_z", map_array[a].dimension.z);	
		set_field_int (L, "sealevel", map_array[a].sealevel);	
		set_field_int (L, "save_counter", map_array[a].save_counter);
		set_field_int (L, "map_journal", map_array[a].map_journal);
		set_field_int (L, "area_map", map_array[a].area_map);
		set_field_int (L, "grass_block", map_array[a].grass_block);
		set_field_int (L, "dirt_block", map_array[a].dirt_block);
		set_field_int (L, "border_block", map_array[a].border_block);
		set_field_int (L, "area_num_x", map_array[a].area_num_x);
		set_field_int (L, "area_num_y", map_array[a].area_num_y);
		set_field_int (L, "area_border_size", map_array[a].area_border_size);
		set_field_int (L, "area_x", map_array[a].area_x);
		set_field_int (L, "area_y", map_array[a].area_y);
		set_field_number (L, "spawn_x", map_array[a].spawn.x);
		set_field_number (L, "spawn_y", map_array[a].spawn.y);
		set_field_number (L, "spawn_z", map_array[a].spawn.z);
		set_field_number (L, "spawn_u", map_array[a].spawn.u);
		set_field_number (L, "spawn_v", map_array[a].spawn.v);
		set_field_number (L, "scale", map_array[a].scale);
		lua_setfield (L, -2, map_array[a].file);
    }
    lua_setglobal(L, "mme_map");    
	
    lua_newtable(L);
    for (a = 0; a < NUM_RANKS; a++) {    
        if (!rank[a].name[0]) continue;
		
	    lua_newtable(L);		
		set_field_string (L, "name", rank[a].name);
		set_field_string (L, "promote_to", rank[a].promote_to);
		set_field_string (L, "motd_file", rank[a].motd_file);
		set_field_int (L, "id", rank[a].id);
		set_field_int (L, "can_chat", rank[a].can_chat);
		set_field_int (L, "can_build", rank[a].can_build);
		set_field_int (L, "chat_color", rank[a].color);	
		set_field_int (L, "can_fly", rank[a].can_fly);	
		set_field_int (L, "can_sonic_fly", rank[a].can_sonic_fly);	
		set_field_int (L, "can_noclip", rank[a].can_noclip);	
		set_field_number (L, "cuboid_size_limit_meters", rank[a].cuboid_size_limit_meters);		
		set_field_number (L, "cuboid_volume_limit_meters", rank[a].cuboid_volume_limit_meters);		
		
		char colorthing[] = {"1234567890abcdef"};
	
		char yip[32];
		yip[0] = colorthing[rank[a].color - 1];
		yip[1] = 0;
		set_field_string (L, "color", yip);		
		lua_setfield (L, -2, rank[a].name);
    }
    lua_setglobal(L, "mme_rank"); 	
	
    lua_newtable(L);
    for (a = 0; a < NUM_NPC_TYPES; a++) {    
        if (npc_type[a].name[0] == 0) continue;
	    lua_newtable(L);		
		set_field_string (L, "name", npc_type[a].name);
		set_field_string (L, "skin", npc_type[a].skin);
		set_field_int (L, "thing_type", npc_type[a].thing_type);
		set_field_int (L, "hitpoints", npc_type[a].hitpoints);
		set_field_int (L, "defense", npc_type[a].defense);	
		set_field_int (L, "strength", npc_type[a].strength);	
		set_field_int (L, "attack_range", npc_type[a].attack_range);	
		set_field_int (L, "attack_chance", npc_type[a].attack_chance);	

		set_field_int (L, "randomnes", npc_type[a].randomness);	
		set_field_int (L, "hunger", npc_type[a].hunger);	
		set_field_int (L, "energy", npc_type[a].energy);	
		set_field_int (L, "comfort", npc_type[a].comfort);	
		set_field_int (L, "sight", npc_type[a].sight);	
		set_field_number (L, "speed", npc_type[a].speed);
		set_field_number (L, "decay", npc_type[a].decay);
		lua_setfield (L, -2, npc_type[a].name);
    }
    lua_setglobal(L, "mme_npc_type"); 	
    lua_newtable(L);
    for (a = 0; a < NUM_MAPS; a++) {    
        if (!npc[a].active) continue;
	    lua_newtable(L);		
		set_field_string (L, "type_name", npc[a].type->name);
		set_field_string (L, "map_file", npc[a].map->file);
		set_field_string (L, "user_spawned", npc[a].user_spawn);
		set_field_int (L, "id", npc[a].id);
		set_field_int (L, "skin_id", npc[a].skin_id);
		set_field_int (L, "mode", npc[a].mode);
		set_field_int (L, "hitpoints", npc[a].hitpoints);	
		set_field_int (L, "hunger", npc[a].hunger);	
		set_field_int (L, "energy", npc[a].energy);	
		set_field_int (L, "comfort", npc[a].comfort);	
		set_field_number (L, "position_x", npc[a].position.x);
		set_field_number (L, "position_y", npc[a].position.y);
		set_field_number (L, "position_z", npc[a].position.z);
		set_field_number (L, "position_u", npc[a].position.u);
		set_field_number (L, "position_v", npc[a].position.v);
		char poo[32]; sprintf (poo, "%i", npc[a].id);
		lua_setfield (L, -2, poo);
    }
    lua_setglobal(L, "mme_npc"); 	
	
    return (0);
}


static int lua_user_rank_command_allowed (lua_State *L) {
    char *function_name = "lua_user_rank_command_allowed";
    log_printf (NULL, LDEBUG, function_name);
    int ret = 0;
    char *name, *cmd;

    if (!lua_parameter_expand (L, function_name, "ss", &name, &cmd)) return (0);
    
    struct rank *prank = rank_find_struct_by_name (name);
    if (prank == NULL) {
        log_printf (NULL, LWARNING, "%s: rank %s is unknown.", function_name, name);
        lua_broke(L);
        return (0);
    }

    ret = rank_command_allowed (prank, cmd);
    lua_pushnumber(L, ret);
    return (1);
}

static int lua_user_rank_menu_allowed (lua_State *L) {
    char *function_name = "lua_user_rank_menu_allowed";
    log_printf (NULL, LDEBUG, "%s", function_name);
    int ret = 0;

    char *name, *cmd;

    if (!lua_parameter_expand (L, function_name, "ss", &name, &cmd)) return (0);
    
    struct rank *prank = rank_find_struct_by_name (name);
    if (prank == NULL) {
        log_printf (NULL, LWARNING, "%s: rank %s is unknown.", function_name, name);
        lua_broke(L);
        return (0);
    }
        
    ret = rank_menu_allowed (prank, cmd);
    
    lua_pushnumber(L, ret);
    return (1);

}

static int lua_user_rank_name_by_lowest (lua_State *L) {
    char *function_name = "lua_user_rank_name_by_lowest";
    log_printf (NULL, LDEBUG, "%s", function_name);

    struct rank *prank = rank_struct_by_lowest ();
    
    lua_pushstring(L, prank->name);
    return (1);
}

static int lua_user_rank_id_by_highest (lua_State *L) {
    char *function_name = "lua_user_rank_id_by_highest";
    log_printf (NULL, LDEBUG, "%s", function_name);
    
    lua_pushnumber(L, rank_id_by_highest());
    return (1);
}

static int lua_user_rank_name_by_highest (lua_State *L) {
    char *function_name = "lua_user_rank_name_by_highest";
    log_printf (NULL, LDEBUG, "%s", function_name);


    struct rank *prank = rank_struct_by_highest ();
    
    lua_pushstring(L, prank->name);
    return (1);
}

static int lua_user_rank_id_by_name (lua_State *L) {
    char *function_name = "lua_user_rank_id_by_name";
    log_printf (NULL, LDEBUG, "%s", function_name);
    int ret = 0;

    char *name;

    if (!lua_parameter_expand (L, function_name, "s", &name)) return (0);
    
    ret = rank_id_by_name (name);
    
    lua_pushnumber(L, ret);
    return (1);
}

static int lua_user_rank_variable_get (lua_State *L) {
    char *function_name = "lua_user_rank_variable_get";
    log_printf (NULL, LDEBUG, "%s", function_name);

    char *name, *variable;

    if (!lua_parameter_expand (L, function_name, "ss", &name, &variable)) return (0);
    
    struct rank *prank = rank_find_struct_by_name (name);
    if (prank == NULL) {
        log_printf (NULL, LWARNING, "%s: rank %s is unknown.", function_name, name);
        lua_broke(L);
        return (0);
    }
    
    if (strcasecmp (variable, "name") == 0) {
        lua_pushstring(L, prank->name);
    } else if (strcasecmp (variable, "id") == 0) {
        lua_pushnumber(L, prank->id);
    } else if (strcasecmp (variable, "promote_to") == 0) {
        lua_pushstring(L, prank->promote_to);
    } else if (strcasecmp (variable, "can_chat") == 0) {
        lua_pushnumber(L, prank->can_chat);
    } else if (strcasecmp (variable, "can_build") == 0) {
        lua_pushnumber(L, prank->can_build);
    } else if (strcasecmp (variable, "can_fly") == 0) {
        lua_pushnumber(L, prank->can_fly);
    } else if (strcasecmp (variable, "can_sonic_fly") == 0) {
        lua_pushnumber(L, prank->can_sonic_fly);
    } else if (strcasecmp (variable, "can_noclip") == 0) {
        lua_pushnumber(L, prank->can_noclip);
    } else if (strcasecmp (variable, "color") == 0) {
		char colorthing[] = {"1234567890abcdef"};
		char yip[32];
		yip[0] = colorthing[prank->color - 1];
		yip[1] = 0;

		lua_pushstring(L, yip);

    } else if (strcasecmp (variable, "transferable") == 0) {
        lua_pushnumber(L, prank->transferable);
    } else {
        log_printf (NULL, LWARNING, "%s: variable %s is unknown.", function_name, variable);
        lua_broke(L);
        return (0);
    }
    return (1);
}

static int lua_user_rank_variable_put (lua_State *L) {
    char *function_name = "lua_user_rank_variable_put";
    log_printf (NULL, LDEBUG, "%s", function_name);

    char *name, *variable, *value;

    if (!lua_parameter_expand (L, function_name, "ss?", &name, &variable, &value)) return (0);
    
    struct rank *prank = rank_find_struct_by_name (name);
    if (prank == NULL) {
        log_printf (NULL, LWARNING, "%s: rank %s is unknown.", function_name, name);
        lua_broke(L);
        return (0);
    }
    
    if (strcasecmp (variable, "name") == 0) {
        _strncpy (prank->name, value, 32);
    } else if (strcasecmp (variable, "id") == 0) {
        prank->id = atoi (value);
    } else if (strcasecmp (variable, "promote_to") == 0) {
        _strncpy (prank->promote_to, value, 32);
    } else if (strcasecmp (variable, "can_chat") == 0) {
        prank->can_chat = atoi (value);
    } else if (strcasecmp (variable, "can_build") == 0) {
        prank->can_build = atoi (value);
    } else if (strcasecmp (variable, "can_fly") == 0) {
        prank->can_fly = atoi (value); 
    } else if (strcasecmp (variable, "can_sonic_fly") == 0) {
        prank->can_sonic_fly = atoi (value);
    } else if (strcasecmp (variable, "can_noclip") == 0) {
        prank->can_noclip = atoi (value);
    } else if (strcasecmp (variable, "color") == 0) {
        prank->color = atoi (value);
    } else if (strcasecmp (variable, "transferable") == 0) {
        prank->transferable = atoi (value);
    } else {
        log_printf (NULL, LWARNING, "%s: variable %s is unknown.", function_name, variable);
        lua_broke(L);
        return (0);
    }

    return (0);
}


static int lua_user_rank_promote_limits (lua_State *L) {
    char *function_name = "lua_user_rank_promote_limits";
    log_printf (NULL, LDEBUG, "%s", function_name);

    char *name;

    if (!lua_parameter_expand (L, function_name, "s", &name)) return (0);
    
    struct rank *prank = rank_find_struct_by_name (name);
    if (prank == NULL) {
        log_printf (NULL, LWARNING, "%s: rank %s is unknown.", function_name, name);
        lua_broke(L);
        return (0);
    }
    
    int value = 0;
    if (!rank_struct_promote_limits (prank, &value)) value = -1;
    lua_pushnumber(L, value);
    
    return (1);
}

static int lua_user_rank_compare_by_name (lua_State *L) {
    char *function_name = "lua_user_rank_compare_by_name";
    log_printf (NULL, LDEBUG, "%s", function_name);

    char *name1, *name2;

    if (!lua_parameter_expand (L, function_name, "ss", &name1, &name2)) return (0);
    
    lua_pushnumber(L, rank_compare_by_name (name1, name2));
    return (1);
}

static int lua_user_valid (lua_State *L) {
    char *function_name = "lua_user_valid";
    log_printf (NULL, LDEBUG, "%s", function_name);

    char *name1;

    if (!lua_parameter_expand (L, function_name, "s", &name1)) return (0);
    
	int junk = 0;
    lua_pushnumber(L, user_id_by_name (NULL, name1, &junk));
    return (1);
}

static int lua_server_get (lua_State *L) {
    char *parameter;
    log_printf (NULL, LDEBUG, "lua_server_get");

    if (!lua_parameter_expand (L, "lua_server_get", "s", &parameter)) return (0);
    
    if (strcmp (parameter, "external_address") == 0) {
        lua_pushstring(L, config.external_address);
        return 1;
    } else if (strcmp (parameter, "name") == 0) {
        lua_pushstring(L, config.name);
        return 1;
    } else if (strcmp (parameter, "connection_limit") == 0) {
		lua_pushnumber (L, config.connection_limit);
		return 1;
    } else if (strcmp (parameter, "connection_timeout") == 0) {
		lua_pushnumber (L, config.connection_timeout);
		return 1;
    } else if (strcmp (parameter, "restart_deadtime") == 0) {
		lua_pushnumber (L, config.restart_dead_time);
		return 1;
    } else if (strcmp (parameter, "local_connections") == 0) {
		lua_pushnumber (L, config.local_connections);
		return 1;
    } else if (strcmp (parameter, "announce_disabled") == 0) {
		lua_pushnumber (L, config.announce_disabled);
		return 1;
    } else if (strcmp (parameter, "default_rank_name") == 0) {
		lua_pushstring (L, config.default_rank_name);
		return 1;
    } else if (strcmp (parameter, "minimum_client_version") == 0) {
		lua_pushnumber (L, config.minimum_client_version);
		return 1;
    } else if (strcmp (parameter, "online") == 0) {
		lua_pushnumber (L, config.online);
		return 1;
    } else if (strcmp (parameter, "ansi") == 0) {
		lua_pushnumber (L, config.ansi);
		return 1;
    } else if (strcmp (parameter, "pause_exit") == 0) {
		lua_pushnumber (L, config.pause_exit);
		return 1;

    } else if (strcmp (parameter, "debug_mode") == 0) {
		lua_pushnumber (L, g_debug_mode);
		return 1;
    }
    
    log_printf (NULL, LDEBUG, "[%s]", parameter);
    return 0;
}

static int lua_server_set (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_server_set");
    char *parameter,  *value;

    if (!lua_parameter_expand (L, "lua_server_set", "ss", &parameter, &value)) return (0);

    if (strcmp (parameter, "external_address") == 0) {
		_strncpy (config.external_address, lua_tostring (L, -1), 255);
		g_force_announcement = 1;
        return 1;
    } else if (strcmp (parameter, "name") == 0) {
		_strncpy (config.name, lua_tostring (L, -1), 63);
		g_force_announcement = 1;
        return 1;
    } else if (strcmp (parameter, "connection_limit") == 0) {
        config.connection_limit = lua_tointeger (L, -1);	
		g_force_announcement = 1;
		return 1;
    } else if (strcmp (parameter, "connection_timeout") == 0) {
        config.connection_timeout = lua_tointeger (L, -1);	
		g_force_announcement = 1;
		return 1;
    } else if (strcmp (parameter, "restart_deadtime") == 0) {
        config.restart_dead_time = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "local_connections") == 0) {
        config.local_connections = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "announce_disabled") == 0) {
		lua_pushnumber (L, config.announce_disabled);
        config.announce_disabled = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "default_rank_name") == 0) {
		_strncpy (config.default_rank_name, lua_tostring (L, -1), 32);
		return 1;
    } else if (strcmp (parameter, "minimum_client_version") == 0) {
        config.minimum_client_version = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "online") == 0) {
		config_server_online (lua_tointeger (L, -1));
		return 1;
    } else if (strcmp (parameter, "ansi") == 0) {
		config.ansi = lua_tointeger (L, -1);
		return 1;
    } else if (strcmp (parameter, "pause_exit") == 0) {
		config.pause_exit = lua_tointeger (L, -1);
		return 1;
    } else if (strcmp (parameter, "debug_mode") == 0) {
		g_debug_mode = lua_tointeger (L, -1);
		return 1;
    }
    
    log_printf (NULL, LDEBUG, "[%s]", parameter);
    return 0;
}

static int lua_npc_type_set (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_npc_type_set");
    char  *name, *parameter,  *value;

    if (!lua_parameter_expand (L, "lua_npc_type_set", "sss", &name, &parameter, &value)) return (0);
	
	int idx = npc_find_type_by_name (name);
	if (idx == -1) {
        log_printf (NULL, LWARNING, "lua_npc_type_set: npc type %s is not defined", name);
        lua_broke(L);
        return (0);
	}

    if (strcmp (parameter, "skin") == 0) {
		_strncpy (npc_type[idx].skin, lua_tostring (L, -1), 32);
		return 1;
		
    } else if (strcmp (parameter, "speed") == 0) {
        npc_type[idx].speed = (float)lua_tonumber (L, -1);	
		return 1;
    } else if (strcmp (parameter, "hitpoints") == 0) {
        npc_type[idx].hitpoints = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "defense") == 0) {
        npc_type[idx].defense = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "thing_type") == 0) {
        npc_type[idx].thing_type = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "strength") == 0) {
        npc_type[idx].strength = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "attack_range") == 0) {
        npc_type[idx].attack_range = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "attack_chance") == 0) {
        npc_type[idx].attack_chance = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "randomness") == 0) {
        npc_type[idx].randomness = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "hunger") == 0) {
        npc_type[idx].hunger = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "comfort") == 0) {
        npc_type[idx].comfort = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "sight") == 0) {
        npc_type[idx].sight = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "decay") == 0) {
        npc_type[idx].decay = (float)lua_tonumber (L, -1);	
		return 1;
    } else if (strcmp (parameter, "name") == 0) {
		_strncpy (npc_type[idx].name, lua_tostring (L, -1), 32);
		return 1;
    } else {
		log_printf (NULL, LERROR, "lua_npc_type_set: %s is not a valid variable: %s", parameter);
	}
    
    log_printf (NULL, LDEBUG, "[%s]", parameter);
    return 0;
}
static int lua_npc_set (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_npc_set");
    char  *parameter,  *value;
	int idx = -1;

    if (!lua_parameter_expand (L, "lua_npc_set", "nss", &idx, &parameter, &value)) return (0);
	
	if (idx == -1 || idx >= NUM_NPCS) {
        log_printf (NULL, LWARNING, "lua_npc_set: npc id %i is not valid", idx);
		return (0);
	}
	
	if (!npc[idx].active) {
        log_printf (NULL, LWARNING, "lua_npc_set: npc id %i is not active", idx);
		return (0);
	}
		
    if (strcmp (parameter, "id") == 0) {
        npc[idx].id = (float)lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "mode") == 0) {
        npc[idx].mode = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "mode") == 0) {
        npc[idx].mode = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "position_x") == 0) {
        npc[idx].position.x = (float)lua_tonumber (L, -1);	
		return 1;
    } else if (strcmp (parameter, "position_y") == 0) {
        npc[idx].position.y = (float)lua_tonumber (L, -1);	
		return 1;
    } else if (strcmp (parameter, "position_z") == 0) {
        npc[idx].position.z = (float)lua_tonumber (L, -1);	
		return 1;
    } else if (strcmp (parameter, "position_u") == 0) {
        npc[idx].position.u = (float)lua_tonumber (L, -1);	
		return 1;
    } else if (strcmp (parameter, "position_v") == 0) {
        npc[idx].position.v = (float)lua_tonumber (L, -1);	
		return 1;
    } else if (strcmp (parameter, "target_position_x") == 0) {
        npc[idx].target_position.x = (float)lua_tonumber (L, -1);	
		return 1;
    } else if (strcmp (parameter, "target_position_y") == 0) {
        npc[idx].target_position.y = (float)lua_tonumber (L, -1);	
		return 1;
    } else if (strcmp (parameter, "target_position_z") == 0) {
        npc[idx].target_position.z = (float)lua_tonumber (L, -1);	
		return 1;
    } else if (strcmp (parameter, "food") == 0) {
        npc[idx].food = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "water") == 0) {
        npc[idx].water = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "health") == 0) {
        npc[idx].health = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "hunger") == 0) {
        npc[idx].hunger = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "comfort") == 0) {
        npc[idx].comfort = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "fun") == 0) {
        npc[idx].fun = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "social") == 0) {
        npc[idx].social = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "bladder") == 0) {
        npc[idx].bladder = lua_tointeger (L, -1);	
		return 1;
    } else if (strcmp (parameter, "user_spawned") == 0) {
		_strncpy (npc[idx].user_spawn, lua_tostring (L, -1), 32);
		return 1;
    } else {
		log_printf (NULL, LERROR, "lua_npc_set: %s is not a valid variable: %s", parameter);
	}
    
    log_printf (NULL, LDEBUG, "[%s]", parameter);
    
//  int current_mode     = luaL_checkint(L, 1);
//  printf ("Current mode = %i\n", current_mode);
  return 0;
}
static int lua_npc_remove (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_npc_remove");
	int idx = -1;

    if (!lua_parameter_expand (L, "lua_npc_remove", "n", &idx)) return (0);
	
	if (idx == -1 || idx >= NUM_NPCS) {
        log_printf (NULL, LWARNING, "lua_npc_remove: npc id %i is not valid", idx);
		return (0);
	}
	
	if (!npc[idx].active) {
        log_printf (NULL, LWARNING, "lua_npc_remove: npc id %i is not active", idx);
		return (0);
	}
	printf ("Remove #%i\n", idx);
	npc_remove (idx) ;
	return (0);
}


static int lua_map_load (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_map_load");
    char  *map_file;

    if (!lua_parameter_expand (L, "lua_map_load", "s", &map_file)) return (0);

	struct map *pmap = map_struct_find_by_filename (map_file);
	if (pmap == NULL) pmap = map_struct_find_empty ();
	if (pmap != NULL) {
		pmap->area_map = 0;	
		map_load_file (pmap, map_file);
	}
	
	if (pmap == NULL) {
		log_printf (NULL, LWARNING, "Map %s could not be loaded.", map_file);
		lua_pushnumber (L, 0);
		return (1);
	}
	
	lua_pushnumber (L, 1);
	return (1);
}

/*
	writing to the metatable is handled through __newindex
*/
int mme_server__newindex(lua_State *L) {
    if(lua_isstring(L, 2)) {
        char * idx = (char *)lua_tostring(L, 2);


		if (strcmp (idx, "name") == 0) {
	        if (lua_isstring (L, -1)) {
				_strncpy (config.name, lua_tostring (L, -1), 32);  
				g_force_announcement = 1;
			} else {
				printf ("name must have a string assigned to it.\n");
			}
		} else if (strcmp (idx, "external_address") == 0) {
	        if (lua_isstring (L, -1)) {
				g_force_announcement = 1;
				_strncpy (config.external_address, lua_tostring (L, -1), 255);  
			} else {
				printf ("external_address must have a string assigned to it.\n");
			}
		} else if (strcmp (idx, "default_rank_name") == 0) {
	        if (lua_isstring (L, -1)) {
				_strncpy (config.default_rank_name, lua_tostring (L, -1), 32);  
			} else {
				printf ("default_rank_name must have a string assigned to it.\n");
			}
		} else if (strcmp (idx, "connection_limit") == 0) {
	        if (lua_isnumber (L, -1)) {
				g_force_announcement = 1;	
				config.connection_limit = lua_tonumber (L, -1);
			} else {
				printf ("connection_limit must have a number assigned to it.\n");
			}			
		} else if (strcmp (idx, "connection_timeout") == 0) {
	        if (lua_isnumber (L, -1)) {
				config.connection_timeout = lua_tonumber (L, -1);
			} else {
				printf ("connection_timeout must have a number assigned to it.\n");
			}			
		} else if (strcmp (idx, "restart_deadtime") == 0) {
	        if (lua_isnumber (L, -1)) {
				config.restart_dead_time = lua_tonumber (L, -1);
			} else {
				printf ("restart_deadtime must have a number assigned to it.\n");
			}	
			
		} else if (strcmp (idx, "online") == 0) {
	        if (lua_isnumber (L, -1)) {
				g_force_announcement = 1;
				config.online = lua_tonumber (L, -1);
			} else {
				printf ("online must have a number assigned to it.\n");
			}			
		} else {
			printf ("mme_server: unknown variable [%s]\n", idx);
		}
    }
    return 0;
}

/*
	reading from the metatable is handled through __index
*/
int mme_server__index(lua_State *L) {

    if (!lua_isstring(L,2)) {
		printf ("yikes\n");
		return (0);
	}
    char * idx = (char *)lua_tostring(L,2);
	if (strcmp ("name", idx) == 0) lua_pushlstring (L, config.name, strlen(config.name));
	else {
		printf ("mme_server: unknown variable [%s]\n", idx);
	}

	return (1);
}

const luaL_Reg mme_server_metareg[] = {
    {"__index", mme_server__index},
    {"__newindex", mme_server__newindex},
    {NULL, NULL}};

/*
	writing to the metatable is handled through __newindex
*/
int mme_map__newindex(lua_State *L) {
    if(lua_isstring(L,2)) {
		printf ("idx [%s] map [%s] variable [%s] value [%s]\n", lua_tostring(L,2), lua_tostring(L,1), lua_tostring(L,0), lua_tostring(L,-1));
    }
    return 0;
}

/*
	reading from the metatable is handled through __index
*/
int mme_map__index(lua_State *L) {

    if (!lua_isstring(L,2)) {
		printf ("yikes\n");
		return (0);
	}
    char * idx = (char *)lua_tostring(L,2);
	if (strcmp ("name", idx) == 0) lua_pushlstring (L, config.name, strlen(config.name));
	else {
		printf ("mme_server: unknown variable [%s]\n", idx);
	}

	return (1);
}

const luaL_Reg mme_map_metareg[] = {
    {"__index", mme_map__index},
    {"__newindex", mme_map__newindex},
    {NULL, NULL}};

void pppp (lua_State *L) {
	lua_newtable(L);

	luaL_newmetatable(L, "mme_server");
	luaL_setfuncs(L, mme_server_metareg, 0);
	lua_setmetatable(L, -2);

	lua_setglobal(L, "mme_server");    

	lua_newtable(L);

	luaL_newmetatable(L, "name");
	luaL_setfuncs(L, mme_map_metareg, 0);
	lua_setmetatable(L, -2);

	luaL_newmetatable(L, "mme_map");
	luaL_setfuncs(L, mme_map_metareg, 0);
	lua_setmetatable(L, -2);

	lua_setglobal(L, "mme_map");    
}

static int lua_user_teleport (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_teleport");
	char *name;
	double x, y, z, u, v;

    if (!lua_parameter_expand (L, "lua_user_teleport", "snnnnn", &name, &x, &y, &z, &u, &v)) return (0);
	
    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
		log_printf (NULL, LWARNING, "lua_user_teleport: user %s is not connected", puser->name);
		lua_pushnumber (L, 0);
		return (1);
    }
	puser->position.x = x;
	puser->position.y = y;	
	puser->position.z = z;
	puser->position.u = u;
	puser->position.v = v;
	
	packet_send(puser, PACKET_MOVE_PLAYER, x, y, z, u, v, 0);
	packet_broadcast (puser->map, -1, NULL, PACKET_MOVE_PLAYER, x, y, z, u, v, puser->idx);
	
	lua_pushnumber (L, 1);
	return (1);
}

static int lua_server_shutdown (lua_State *L) {
	int timeout = 0;
	char *message;
    if (!lua_parameter_expand (L, "lua_server_shutdown", "ns", &timeout, &message)) return (0);
	strcpy (g_shutdown_type, "shutdown");
	time (&g_server_shutdown_timeout);
	_strncpy (g_shutdown_message, message, 256);
	g_server_shutdown_timeout += timeout;
	lua_pushnumber (L, 1);
	return (1);
}

static int lua_server_restart (lua_State *L) {
	int timeout = 0;
	char *message;
    if (!lua_parameter_expand (L, "lua_server_restart", "ns", &timeout, &message)) return (0);
	strcpy (g_shutdown_type, "restart");
	time (&g_server_shutdown_timeout);
	_strncpy (g_shutdown_message, message, 256);
	g_server_shutdown_timeout += timeout;
	lua_pushnumber (L, 1);
	return (1);
}
	
static int lua_server_shutdown_cancel (lua_State *L) {
	g_server_shutdown_timeout = -1;
	lua_pushnumber (L, 1);	
	return (1);
}

static int lua_palette_load (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_palette_load");
	char *name;
    if (!lua_parameter_expand (L, "lua_map_palette_load", "s", &name)) return (0);

	struct palette *p = texture_find_palette_struct_by_name (name);
	
	if (p == NULL) p = texture_find_palette_empty ();
	if (p == NULL) {
		log_printf (NULL, LERROR, "No space for more block palettes.");
		lua_pushnumber (L, 0);
		return (1);
	}

	block_initialize (p, name);
	
	lua_pushnumber (L, 1);
	return (1);
}
    
static int lua_map_create (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_map_create");
	char *filename;
	int x, y, z, sealevel, area_mode;
	float scale;
	char *dirt_name, *grass_name;

    if (!lua_parameter_expand (L, "lua_map_create", "snnnnfssn", &filename, &x, &y, &z, &sealevel, &scale, &dirt_name, &grass_name, &area_mode)) return (0);

    struct map *pmap = map_struct_find_empty ();
    if (pmap == NULL) {
        log_printf (NULL, LWARNING, "map_create: Map table is full.  Please unload a map first.");
		lua_pushnumber (L, 0);
        return (1);
    }
	
	int a;
	int first_block_palette = -1;
	for (a = 0; a < NUM_PALETTES; a++) {
		if (block_palette[a].active) break;
	}
	if (a == NUM_PALETTES) {
		//user_message (puser, "map_create: No block palettes are defined; map not created.");
		log_printf (NULL, LWARNING, "map_create: No block palettes are defined; map not created.");
		lua_pushnumber (L, 0);
		return (1);
	}
	first_block_palette = a;

    int dirt = texture_block_by_description (&block_palette[first_block_palette], dirt_name);
    int grass = texture_block_by_description (&block_palette[first_block_palette], grass_name);
	
	if (scale < 0.1) {
		log_printf (NULL, LWARNING, "map_create: map scale must be at least 0.1.  Defaulting to 0.1");
		scale = 0.1;
	}
	if (scale > 1.0) {
		log_printf (NULL, LWARNING, "map_create: map scale must be at no greater than 1.0.  Defaulting to 1.0");
		scale = 1.0;
	}

	_strncpy (pmap->file, filename, 255);
	strcpy (pmap->build_rank_name, "guest");
	strcpy (pmap->block_palette_name, block_palette[first_block_palette].path);
 	pmap->scale = scale;
	pmap->map_journal = 0;
	pmap->sealevel = sealevel;
	pmap->dimension.x = x;
	pmap->dimension.y = y;
	pmap->dimension.z = z; 
	pmap->spawn.x = pmap->dimension.x / 2;
	pmap->spawn.y = pmap->dimension.y / 2;
	pmap->spawn.z = pmap->sealevel + (1.6 / scale) + 1 ;
	pmap->spawn.u = 0;
	pmap->spawn.v = 0;
	pmap->area_map = 0;
	pmap->dirt_block = dirt;
	pmap->grass_block = grass;
	pmap->border_block = grass;	
	pmap->area_map = area_mode;

	char path[PATH_MAX];
	
	if (pmap->area_map) {
		pmap->area_num_x = 5;
		pmap->area_num_y = 5;
		pmap->area_border_size = 8;
		pmap->area_x = (pmap->dimension.x - 48) / 5;
		pmap->area_y = (pmap->dimension.y - 48) / 5;

	
		snprintf (path, PATH_MAX, "%s/%s",  PATH_AREAS, pmap->file);
	    easy_mkdir (path);    
		
		snprintf (path, PATH_MAX, "%s/%s/properties", PATH_AREAS, pmap->file);
		if (access (path, F_OK) == 0) {
//				log_printf (NULL, LWARNING, "Map file already exists.  Choose a different name.", path);
			pmap->file[0] = 0;
			lua_pushnumber (L, 0);
			return (1);
		}
		int dx = (pmap->area_border_size * pmap->area_num_x) + pmap->area_border_size + (pmap->area_num_x * pmap->area_x);
		int dy = (pmap->area_border_size * pmap->area_num_y) + pmap->area_border_size + (pmap->area_num_y * pmap->area_y);
	    dx /= 32; dx *= 32;
	    dy /= 32; dy *= 32;
		pmap->dimension.x = dx;
		pmap->dimension.y = dy;
		pmap->dimension.z /= 32; pmap->dimension.z *= 32;
		pmap->area_num_total = pmap->area_num_x * pmap->area_num_y;
		map_save (pmap);
	
	} else {	
		snprintf (path, PATH_MAX, "%s/%s", PATH_MAPS, pmap->file);
		if (access (path, F_OK) == 0) {
//				log_printf (NULL, LWARNING, "Map file already exists.  Choose a different name.", path);
			pmap->file[0] = 0;
			lua_pushnumber (L, 0);
			return (1);
		}
    	map_generate (pmap, 255, dirt, grass);
	}

    map_save (pmap);
	log_printf (NULL, LNOTE, "Map %s has been created.  Use /map_load \"%s\" to load it.", pmap->file, pmap->file);

	lua_pushnumber (L, 1);
	return (1);
}  


static int lua_map_sync (lua_State *L) {
	map_disk_sync(0);
	lua_pushnumber (L, 1);	
	return (1);
}

static int lua_user_afk (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_afk");
	char *name, *message;

    if (!lua_parameter_expand (L, "lua_user_afk", "ss", &name,  &message)) return (0);
	
    struct user *puser = user_connected_find_by_name (name);
    if (puser == NULL) {
		log_printf (NULL, LWARNING, "lua_user_afk: user %s is not connected", puser->name);
		lua_pushnumber (L, 0);
		return (1);
    }
	
    user_afk_toggle (puser, message);	
	
	lua_pushnumber (L, 1);
	return (1);
}

static int lua_npc_create_type (lua_State *L) {
	char *name;
	if (!lua_parameter_expand (L, "lua_npc_create_type", "s", &name)) return (0);

	if (npc_find_type_by_name (name) != -1) {
		log_printf (NULL, LWARNING, "lua_npc_create_type: npc type %s is already in use.", name);
		lua_pushnumber (L, 0);		
		return (1);
	}
		
	int idx = npc_find_type_empty();
	if (idx == -1) {
		log_printf (NULL, LWARNING, "lua_npc_create_type: npc type table is full.");
		return (0);
	}
	
	_strncpy (npc_type[idx].name, name, 32);	
	
	lua_pushnumber (L, 1);		
	return (1);
}


static int lua_npc_spawn_type (lua_State *L) {
	char *name, *map_name;
	int x, y, z;
	if (!lua_parameter_expand (L, "lua_npc_spawn_type", "ssnnn", &map_name, &name, &x, &y, &z)) return (0);
	
	struct map *pmap = map_struct_find_by_filename (map_name);
	if (pmap == NULL) {
		log_printf (NULL, LWARNING, "lua_npc_spawn_type: Map %s is not loaded.", map_name);
		lua_pushnumber (L, 0);		
		return (1);
	}

	int r = npc_add (pmap, name, x, y, z);
	lua_pushnumber (L, r);		
	return (1);

}

static int lua_map_replace_block (lua_State *L) {
	int fx, fy, fz, tx, ty, tz;
	char *old_type, *new_type; 
	
	char *map_name;

	if (!lua_parameter_expand (L, "lua_map_replace_block", "snnnnnns", &map_name, &fx, &fy, &fz, &tx, &ty, &tz, &old_type, &new_type)) return (0);
	
	struct map *pmap = map_struct_find_by_filename (map_name);
	if (pmap == NULL) {
		log_printf (NULL, LWARNING, "lua_map_replace_block: Map %s is not loaded.", map_name);
		lua_pushnumber (L, 0);		
		return (1);
	}
	
	unsigned char old_block = atoi (old_type);
	unsigned char new_block = atoi (new_type);
	
	if (old_block == 0) {
		old_block = texture_block_by_description (pmap->palette, old_type);
		if (old_block == 0) {
			log_printf (NULL, LWARNING, "lua_map_replace_block: old: %s is not a known block name, or number.", old_type);
			lua_pushnumber (L, 0);		
			return (1);
		}
	}
	
	if (new_block == 0) {
		new_block = texture_block_by_description (pmap->palette, new_type);
		if (new_block == 0) {
			log_printf (NULL, LWARNING, "lua_map_replace_block: new: %s is not a known block name, or number.", new_type);
			lua_pushnumber (L, 0);		
			return (1);
		}
	}

	int change = 0;
	if (tx > pmap->dimension.x) tx = pmap->dimension.x;
	if (ty > pmap->dimension.y) ty = pmap->dimension.y;
	if (tz > pmap->dimension.z) tz = pmap->dimension.z;
	
	if (tx < fx) tx = fx + 1;
	if (ty < fy) ty = fy + 1;
	if (tz < fz) tz = fz + 1;
	
	for (int z = fz; z < tz ; z++) {
		for (int x = fx; x < tx; x++) {
			for (int y = fy; y < ty; y++) {
				if ((unsigned char)BLOCK (pmap, x, y, z) == old_block) {
					map_block_change (pmap, x, y, z, new_block, 0);
					change++;
				}
			}
		}
	}
	lua_pushnumber (L, 1);
	return (1);
}



static int lua_map_region_save (lua_State *L) {
	int fx, fy, fz, tx, ty, tz;

	
	char *map_src, *map_dest ;

	if (!lua_parameter_expand (L, "lua_map_region_save", "ssnnnnnn", &map_dest, &map_src, &fx, &fy, &fz, &tx, &ty, &tz)) return (0);
	
	struct map *pmap_src = map_struct_find_by_filename (map_src);
	if (pmap_src == NULL) {
		log_printf (NULL, LWARNING, "lua_map_region_save: Source map %s is not loaded.", map_src);
		lua_pushnumber (L, 0);		
		return (1);
	}
	
	int ret = map_region_save (pmap_src, map_dest, fx, fy, fz, tx, ty, tz);
	
	lua_pushnumber (L, ret);
	return (1);
}


static int lua_map_region_load (lua_State *L) {
	int fx, fy, fz, tx, ty, tz;

	char *map_src, *map_dest;

	if (!lua_parameter_expand (L, "lua_map_region_load", "ssnnnnnn", &map_dest, &map_src, &fx, &fy, &fz, &tx, &ty, &tz)) return (0);
	
	struct map *pmap_dest = map_struct_find_by_filename (map_src);
	if (pmap_dest == NULL) {
		log_printf (NULL, LWARNING, "lua_map_region_load: destination map %s is not loaded.", map_dest);
		lua_pushnumber (L, 0);		
		return (1);
	}
	
	int ret = map_region_load (pmap_dest, map_src, fx, fy, fz, tx, ty, tz);
	
	lua_pushnumber (L, ret);
	return (1);
}

static int lua_user_undo (lua_State *L) {
	char *name;
	int seconds;
	if (!lua_parameter_expand (L, "lua_user_undo", "sn", &name, &seconds)) return (0);
	
    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
		log_printf (NULL, LWARNING, "lua_user_undo: %s is not connected.", name);
		lua_pushnumber (L, 0);
		return (1);
    }	
	
	if (seconds < 1) seconds = 1;
	map_undo_undo (puser, seconds);
	
	
	lua_pushnumber (L, 1);
	return (1);
}


static int lua_map_unload (lua_State *L) {
	char *name;

	if (!lua_parameter_expand (L, "lua_map_unload", "s", &name)) return (0);
	
	if (map_count_active() <= 1) {
		log_printf (NULL, LWARNING, "lua_map_unload: I can't unload the only loaded map.");
		return (0);
	}
	
	struct map *pmap = map_struct_find_by_name (name);
	if (pmap == NULL) pmap = map_struct_find_by_filename (name);

	if (pmap != NULL) map_unload (pmap);
	else {
//		user_message (puser, MUSER, "There is no map loaded with the filename [%s].", str);
		log_printf (NULL, LWARNING, "There is no loaded map with the filename [%s]", name);
		lua_pushnumber (L, 0);
		return (1);
	}
	
	lua_pushnumber (L, 1);
	return (1);
}

static int lua_run_string (lua_State *L) {
	char *name, *memory, *parameters;
	if (!lua_parameter_expand (L, "lua_run_string", "ss", &name, &memory, &parameters)) return (0);

    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
		log_printf (NULL, LWARNING, "lua_run_string: %s is not connected.", name);
		lua_pushnumber (L, 0);
		return (1);
    }	

	lua_pushnumber (L, lua_exec_mem (puser, memory, parameters));
	return (1);
}


static int lua_user_command_allowed (lua_State *L) {
	char *name, *command;
	if (!lua_parameter_expand (L, "lua_user_command_allowed", "ss", &name, &command)) return (0);

    struct user *puser = user_attached_find_by_name (name);
    if (puser == NULL) {
		log_printf (NULL, LWARNING, "lua_user_command_allowed: %s is not connected.", name);
		lua_pushnumber (L, 0);
		return (1);
    }


	if (!rank_command_allowed (puser->rank, command)) {

		lua_pushnumber (L, 0);		
		return (1);
	}    

	lua_pushnumber (L, 1);
	return (1);
}

static int lua_system (lua_State *L) {
	char *exec;
	if (!lua_parameter_expand (L, "lua_system", "s", &exec)) return (0);
	
	int v = system (exec);

	lua_pushnumber (L, v);
	return (1);
}


static int lua_user_is_connected (lua_State *L) {
    log_printf (NULL, LDEBUG, "lua_user_is_connected");
	char *name;
	int ret = 1;
    if (!lua_parameter_expand (L, "lua_user_rank_required", "s", &name)) return (0);
	
    struct user *puser = user_connected_find_by_name (name);
    if (puser == NULL) {
		ret = 0;
    }
	lua_pushnumber (L, ret);
	return (1);
}


void lua_exec_init (lua_State *L) {
	pppp (L);
    lua_register(L, "mme_user_get", lua_user_get);
    lua_register(L, "mme_user_set", lua_user_set);        
    lua_register(L, "mme_map_get", lua_map_get);    
    lua_register(L, "mme_map_set", lua_map_set);    
    lua_register(L, "mme_user_send_message", lua_user_message);    
    lua_register(L, "mme_user_send_packet_map_modify", lua_send_packet_map_modify);        
    lua_register(L, "mme_user_send_message_broadcast", lua_user_message_broadcast);  
    lua_register(L, "mme_map_get_block", lua_map_get_block);  
    lua_register(L, "mme_user_send_map_region", lua_send_map_region);  
    lua_register(L, "mme_time", lua_time);
	lua_register(L, "mme_user_valid", lua_user_valid);
    lua_register(L, "mme_user_ipban", lua_user_ipban);
    lua_register(L, "mme_user_ban", lua_user_ban);    
    lua_register(L, "mme_user_kick", lua_user_kick);    
    lua_register(L, "mme_global_in_list", lua_global_in_list);    
    lua_register(L, "mme_global_remove_from_list", lua_global_remove_from_list);    
    lua_register(L, "mme_global_add_to_list", lua_global_add_to_list);    
    lua_register(L, "mme_user_chat_private", lua_user_chat_private);    
    lua_register(L, "mme_user_show_message_file_dialog", lua_user_show_message_file_dialog);    
    lua_register(L, "mme_user_show_message_file", lua_user_show_message_file);    
    lua_register(L, "mme_user_disconnect", lua_user_disconnect);    
    lua_register(L, "mme_user_map_switch", lua_user_map_switch);
    lua_register(L, "mme_user_menu_reset", lua_user_menu_reset);    
	lua_register(L, "mme_user_menu_kill", lua_user_menu_kill);
    lua_register(L, "mme_user_menu_link", lua_user_menu_link);    
    lua_register(L, "mme_user_menu_text", lua_user_menu_text);    
    lua_register(L, "mme_user_menu_map_loading", lua_user_menu_map_loading);    
    lua_register(L, "mme_user_menu_check", lua_user_menu_check);
    lua_register(L, "mme_user_menu_radio", lua_user_menu_radio);    
    lua_register(L, "mme_user_menu_button", lua_user_menu_button);    
    lua_register(L, "mme_user_menu_input", lua_user_menu_input);    
    lua_register(L, "mme_global_connected_users", lua_global_connected_users);    
    lua_register(L, "mme_user_send_player_announce", lua_send_player_announce);  
    lua_register(L, "mme_user_send_player_denounce", lua_send_player_denounce);  
    lua_register(L, "mme_user_send_move_player", lua_send_move_player);      
    lua_register(L, "mme_user_message_dialog", lua_user_message_dialog);    
    lua_register(L, "mme_user_rank_command_allowed", lua_user_rank_command_allowed);    
    lua_register(L, "mme_lua_user_rank_menu_allowed", lua_user_rank_menu_allowed);    
    lua_register(L, "mme_user_rank_name_by_lowest", lua_user_rank_name_by_lowest);    
    lua_register(L, "mme_user_rank_id_by_highest", lua_user_rank_id_by_highest);    
    lua_register(L, "mme_user_rank_name_by_highest", lua_user_rank_name_by_highest);
    lua_register(L, "mme_user_rank_id_by_name", lua_user_rank_id_by_name);        
    lua_register(L, "mme_user_rank_variable_get", lua_user_rank_variable_get);
    lua_register(L, "mme_user_rank_variable_put", lua_user_rank_variable_put);
    lua_register(L, "mme_user_rank_promote_limits", lua_user_rank_promote_limits);
    lua_register(L, "mme_user_rank_compare_by_name", lua_user_rank_compare_by_name);    
    lua_register(L, "mme_hookfile_load", lua_hookfile_load_lua);   	
    lua_register(L, "mme_map_draw_sphere", lua_map_draw_sphere);   		
    lua_register(L, "mme_map_modify_block", lua_map_modify_block); 
    lua_register(L, "mme_npc_spawn_type", lua_npc_spawn_type); 
    lua_register(L, "mme_server_get", lua_server_get);
    lua_register(L, "mme_server_set", lua_server_set);        
    lua_register(L, "mme_map_load", lua_map_load);        	
    lua_register(L, "mme_user_teleport", lua_user_teleport);        		
    lua_register(L, "mme_server_shutdown", lua_server_shutdown);	
    lua_register(L, "mme_server_restart", lua_server_restart);	
    lua_register(L, "mme_server_shutdown_cancel", lua_server_shutdown_cancel);		
	lua_register(L, "mme_palette_load", lua_palette_load);
	lua_register(L, "mme_map_create", lua_map_create);
	lua_register(L, "mme_map_sync", lua_map_sync);
	lua_register(L, "mme_npc_create_type", lua_npc_create_type);	
	lua_register(L, "mme_map_replace_block", lua_map_replace_block);	
	lua_register(L, "mme_map_region_save", lua_map_region_save);
	lua_register(L, "mme_map_region_load", lua_map_region_load);
	lua_register(L, "mme_user_undo", lua_user_undo);
	lua_register(L, "mme_map_unload", lua_map_unload);
	lua_register(L, "mme_user_afk", lua_user_afk);
	lua_register(L, "mme_lua_run_string", lua_run_string);
	lua_register(L, "mme_user_command_allowed", lua_user_command_allowed);
	lua_register(L, "mme_user_is_connected", lua_user_is_connected);
	lua_register(L, "mme_npc_type_set", lua_npc_type_set);
	lua_register(L, "mme_npc_set", lua_npc_set);
	lua_register(L, "mme_npc_remove", lua_npc_remove);
	lua_register(L, "mme_system", lua_system);	
	
    
    /*
    lua_register(L, "mme_", lua_);    
    lua_register(L, "mme_", lua_);    
    lua_register(L, "mme_", lua_);    
    lua_register(L, "mme_", lua_);    
    lua_register(L, "mme_", lua_);    
    lua_register(L, "mme_", lua_);    
    lua_register(L, "mme_", lua_);    
    lua_register(L, "mme_", lua_);    
    lua_register(L, "mme_", lua_);    
    lua_register(L, "mme_", lua_);    
    lua_register(L, "mme_", lua_);    
    lua_register(L, "mme_", lua_);    */
    return;
}





int lua_exec (struct user *puser, char *file, char *args) {
    lua_State* L;
    int ret = 1;
    char path[PATH_MAX];
	if (!(file[0] == '.' && (file[1] == '/' || file[1] == '\\'))) {
	    snprintf (path, PATH_MAX, "%s/%s", PATH_LUA, file);
	} else {
		_strncpy (path, file, PATH_MAX);
	}


    
    if (access (path, F_OK) == -1) {
        log_printf (NULL, LWARNING, "lua_exec: Cannot run lua file %s: %s", path, strerror (errno));
        return (0);
    
    }
    
    L = luaL_newstate();
    luaL_openlibs(L);
    
    lua_exec_init (L);
    
    
    lua_pushstring (L, args);
    lua_setglobal (L, "mme_arguments");
    
    
    if (luaL_loadfile(L, path) != 0) {
        lua_broke(L);
        log_printf (puser, LNOTE, "lua_exec: %s could not be started.", path);
        return (0);
    }    
    
    
    if (lua_pcall(L, 0, LUA_MULTRET, 0)) {
        lua_broke(L); 
        ret = 0;
    }
    
    lua_close (L);
    return (ret);
}

int lua_exec_mem (struct user *puser, char *memory, char *args) {
    lua_State* L;
    int ret = 1;

    L = luaL_newstate();
    luaL_openlibs(L);
    
    lua_exec_init (L);
    
    
    lua_pushstring (L, args);
    lua_setglobal (L, "mme_arguments");
	
	
    if (luaL_dostring (L, memory) != 0) {
        lua_broke(L);
        log_printf (puser, LNOTE, "lua_exec: the code [%s] could not be run.", memory);
		ret = 0;
    }    
    
	lua_close (L);    
    return (ret);
}
/*

void lua_exec_hooks () {
    lua_enabled = 0;
    struct stat st;
    if (lua_hook == NULL) {

        if (stat (MAIN_LUA_FILE, &st) == -1) {
            return ;
        }

        lua_hook = luaL_newstate();
        luaL_openlibs(lua_hook);

        lua_exec_init (lua_hook);

	    if (luaL_loadfile(lua_hook, MAIN_LUA_FILE) != 0) {
            lua_broke(lua_hook);

            log_printf (NULL, LNOTE, "Lua hooks not started.");
    
        } else {
            if (lua_pcall(lua_hook, 0, LUA_MULTRET, 0)) {lua_broke(lua_hook); }
        }
    }
    return;

}*/
