/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"
static time_t map_last_sync = 0;
extern char receivable_packet_types[8192];

void process_server_periodic() {
	time_t t;
    time (&t);

	if (g_server_shutdown_timeout != -1) {

		if (t > g_server_shutdown_timeout && g_server_shutdown_timeout != 0) {
			g_server_shutdown_timeout = 0;
			server_shutdown ();
		} else {
			static time_t stamp;
			if (t > stamp) {
				stamp = t + ((g_server_shutdown_timeout - t) / 2);

				char temp[1024];

				time_ago (t, g_server_shutdown_timeout, temp);
				char *cp = strrchr (temp, ' '); if (cp != NULL) *cp = 0;

				if (strcasecmp (temp, "just") != 0) user_message_broadcast (NULL, MSYSTEM, "\e\x04Server will %s in \e\x01%s\e\x04 (%s)", g_shutdown_type, temp, g_shutdown_message);
			}
		}
	}

    lua_hook_call ("mme_global_event_idle", NULL);
	
    announce_server(g_force_announcement);
    g_force_announcement = 0;

	if (t >= map_last_sync) {
        map_disk_sync (0);
        map_last_sync = t + 60;
    }
    
}		

int process_user_connection_health (struct user *puser) {
	time_t t;
	time (&t);

    if (puser->current_mode == USER_NOT_CONNECTED) goto end;

    if ((puser->current_mode == USER_DISCONNECT && puser->write_length == 0) || g_kill_server) {
		if (puser->waiting_for_map) {
			log_printf (puser, LWARNING, "Waiting for map thread to terminate");
			goto end;
		}
        event_user_disconnect (puser);

        log_printf (puser, LDEBUG, "Connection Closed");
        closesocket (puser->socket);
		user_mode_set (puser, USER_NOT_CONNECTED);
        puser->socket = 0;
		user_deallocate (puser);

		// Let the login server know about the number of people connected
		g_force_announcement = 1;
        goto end;
    } 
	
	

	if (config.connection_timeout != 0 && (t - puser->idle_stamp > config.connection_timeout && puser->idle_stamp != 0)) {
        if (!lua_hook_call ("mme_user_event_afk", puser)) {
			log_printf (puser, LNOTE, "%s will be disconnected due to inactivity", puser->name);
            snprintf (puser->disconnect_message, 128, "Player %s was AFK for too long.", puser->name);                
			user_disconnect (puser, DISCONNECT_IDLE, 0, "You were AFK for too long.");
    		puser->idle_stamp = 0;
        } else puser->idle_stamp = t;
	}

	if (!puser->afk && config.afk_timeout != 0 && (t - puser->idle_stamp > config.afk_timeout && puser->idle_stamp != 0)) {
        char temp[80];
        float f = t - puser->idle_stamp;
        f /= 60.0;
        sprintf (temp, "(automatic) idle for %0.0f minutes", f);
		user_afk_set (puser, temp);
	}

	//last_io is for detecting broken sockets that don't look broken..
	if (t - puser->last_io > 180 && !g_kill_server) {
        if (!lua_hook_call ("mme_user_event_unresponsive", puser)) {
			log_printf (puser, LDEBUG, "Connection may be dead");
            snprintf (puser->disconnect_message, 128, "Player %s is not responding, and has been disconnected.", puser->name);				
			user_mode_set (puser, USER_DISCONNECT);
			puser->write_length = 0;
        } else puser->last_io = t;
	}

	if (t > puser->last_idle_ping && puser->current_mode == USER_CONNECTED) {
        if (!lua_hook_call ("mme_user_event_ping", puser)) {
        }
		log_printf (puser, LDEBUG, "Send idle ping > = 10");
        
		packet_send (puser, PACKET_IDLE_PING, 0);
        time(&puser->last_idle_ping);
        puser->last_idle_ping += 10;
	}

    event_proc (puser);
    user_dead_test (puser);

	end:
	return (puser->current_mode);
}

		
int process_user_connection_read (struct user *puser, int new_data) {		
	int len;

	puser->process_stamp = easy_time();
    int size_left = puser->read_size - puser->read_length;

	if (size_left > 0 && new_data) {
        len = recv (puser->socket, &puser->read_buffer[puser->read_length], size_left, 0);
        if (len == -1) {
			if ((errno != EWOULDBLOCK && errno != EINTR)) {
	            log_printf (puser, LNOTE,  "Connection terminated by remote: %i %s", errno, strerror (errno));
                snprintf (puser->disconnect_message, 128, "%s has disconnected (recv): %s", puser->name, strerror (socket_error));
				puser->write_length = 0;
				user_mode_set (puser, USER_DISCONNECT);
				return (0);
			}
        } else if (len == 0) {
			user_mode_set (puser, USER_DISCONNECT);
			puser->write_length = 0;
                snprintf (puser->disconnect_message, 128, "%s has disconnected (recv): eof", puser->name);
			log_printf (puser, LNOTE, "Connection terminated by remote.");
			return (0);
		}

        puser->read_length += len;
	}				

	char *buffer = puser->read_buffer;
	char *buffer_data = &puser->read_buffer[4];
	unsigned int length = puser->read_length ;
	double read_stop = easy_time() + 0.003f;
	
	while (length > 3) {
		unsigned short packet_type = ((short *) buffer)[0];
		unsigned short packet_data_length = ((short *) buffer)[1];
	
		if (packet_data_length + 4 > length) {
			log_printf (puser, LDEBUG, "Waiting packet %i is missing %i bytes", packet_type, (packet_data_length + 4) - length );
			break;
		}
        if (easy_time() > read_stop) {
            log_printf (puser, LDEBUG, "Preempted packet processing");
            break;
        }

		process_packet (puser, packet_type, buffer_data, packet_data_length);	
		
		memmove (puser->read_buffer, &puser->read_buffer[4 + packet_data_length], puser->read_size - (4 + packet_data_length));
		length -= 4 + packet_data_length;
	}
	puser->read_length = length;
    time (&puser->last_io);

	return (0);
}

int process_user_connection_write (struct user *puser) {		
	int mutexed = 0;
   	int len;
	if (puser->write_buffer == 0) return (0);

    MUTEX_LOCK (user_mutex_write[puser->idx - 1]); mutexed = 1;

    unsigned int write_length = puser->write_length;
    if (write_length > 65536) write_length = 65536;
	
	if (puser->write_length > 0) {

		len = send (puser->socket, puser->write_buffer, write_length, 0);
    	if (len == -1) {
        	if (errno != EAGAIN && errno != EINTR) {
            	log_printf (puser, LDEBUG, "user send error: %i %i %s", len, errno, strerror (errno));
            	snprintf (puser->disconnect_message, 128, "%s has disconnected (send): %s", puser->name, strerror (socket_error));
				user_mode_set (puser, USER_DISCONNECT);
				puser->write_length = 0;
        	}

		} else if (len > 0) {
    		memmove (puser->write_buffer, &((char *)puser->write_buffer)[len], puser->write_size - len);
    		puser->write_length -= len;

	    	time (&puser->last_io);
		}
	}

	if (mutexed) MUTEX_UNLOCK (user_mutex_write[puser->idx - 1]);
	
	return (puser->current_mode);
}

int process_packet(struct user *puser, unsigned short packet_type, char *data, unsigned short size) {
    int ret = 1;
    int a;
    log_printf (puser, LDEBUG, "<%s: size = %i", packet_type_to_string(packet_type), size);
	
    if (!packet_is_sendable (packet_type, puser->receivable_packets)) {
		log_printf (puser, LWARNING, "packet_parse_stream: Received unselected packet type %d (%s).", packet_type, packet_type_to_string(packet_type));
		return (1);
 	}

    // Any one of the packets can indicate that a user has fully connected.
    if (puser->current_mode == USER_CONNECTING || puser->current_mode == USER_NEW_MAP) {
        if ((packet_type == PACKET_PING_RESPONSE && size == 1 && (unsigned char )data[0] == 0x55) || 
            //packet_type == PACKET_MOVE_PLAYER ||
            packet_type == PACKET_MAP_MODIFY ||
            packet_type == PACKET_MAP_FILL ||
            packet_type == PACKET_MENU_REQUEST ||
            packet_type == PACKET_CHAT_MESSAGE) {

            	event_map_loading_complete (puser);     
        }
    }
		
	if (packet_type != PACKET_IDLE_PING && packet_type != PACKET_PING_REQUEST && packet_type != PACKET_PING_RESPONSE ) {
		if (puser->current_mode == USER_CONNECTED) {
        	time_t old_stamp = puser->idle_stamp;
        	time (&puser->idle_stamp);	

        	if (puser->afk && puser->idle_stamp - old_stamp >= 5) {
            	user_afk_clear (puser, "(automatic) Activity detected");
        	}     
		} else {
			time (&puser->idle_stamp);
		}
    }
    
	if (packet_type == PACKET_AVAILABLE_PACKET_TYPES) {
	    log_printf (puser, LDEBUG, "Client has sent its list of supported packet types ");
		if (size > 8192) {
			log_printf (puser, LWARNING, "PACKET_SELECT_PACKET_TYPES data should be 8192 or fewer bytes, not %d bytes.", size);
		}
        
	    packet_send(puser, PACKET_SELECT_PACKET_TYPES, puser->receivable_packets);
		memset (puser->receivable_packets, 0, 8192);
		memmove (puser->receivable_packets, data, size);

	} else if (packet_type == PACKET_SELECT_PACKET_TYPES) {
	    log_printf (puser, LDEBUG, "Selecting from client-supported packet types");
		if (size > 8192) {
			log_printf (puser, LDEBUG, "PACKET_SELECT_PACKET_TYPES data should be 8192 or fewer bytes, not %d bytes.", size);
		}

		memset (puser->sendable_packets, 0, 8192);
		memmove(puser->sendable_packets, data, size);

		char missing[4096] = {"Your client is missing the following required packet types: "};
		int base_strlen = strlen (missing);
	
		if (!packet_is_sendable(PACKET_PING_REQUEST, puser->sendable_packets) )
			strcat (missing, "PACKET_PING_REQUEST, ");		
		
		if (!packet_is_sendable(PACKET_PING_RESPONSE, puser->sendable_packets) )
			strcat (missing, "PACKET_PING_RESPONSE, ");
			
		if (!packet_is_sendable(PACKET_IDLE_PING, puser->sendable_packets) )
			strcat (missing, "PACKET_IDLE_PING, ");
			
		if (!packet_is_sendable(PACKET_CONNECT, puser->sendable_packets) )
			strcat (missing, "PACKET_CONNECT, ");		
		
		if (!packet_is_sendable(PACKET_DISCONNECT, puser->sendable_packets) )
			strcat (missing, "PACKET_DISCONNECT, ");

		if (!packet_is_sendable(PACKET_MENU_RESET, puser->sendable_packets)) 
			strcat (missing, "PACKET_MENU_RESET, ");		
		
		if (!packet_is_sendable(PACKET_MENU_TEXT, puser->sendable_packets) )
			strcat (missing, "PACKET_MENU_TEXT, ");
		
		if (!packet_is_sendable(PACKET_MENU_LINK, puser->sendable_packets)) 
			strcat (missing, "PACKET_MENU_LINK, ");		
		
		if (!packet_is_sendable(PACKET_MENU_CHECK, puser->sendable_packets)) 
			strcat (missing, "PACKET_MENU_CHECK, ");
		
		if (!packet_is_sendable(PACKET_MENU_RADIO, puser->sendable_packets)) 
			strcat (missing, "PACKET_MENU_RADIO, ");
					
		if (!packet_is_sendable(PACKET_MENU_INPUT, puser->sendable_packets))
			strcat (missing, "PACKET_MENU_INPUT ");
		
		if (!packet_is_sendable(PACKET_MENU_BUTTON, puser->sendable_packets))
			strcat (missing, "PACKET_MENU_BUTTON, ");
			
//		if (!packet_is_sendable(PACKET_MENU_SALTED_PASSWORD, puser->sendable_packets))
//			strcat (missing, "PACKET_MENU_SALTED_PASSWORD, ");		

		if (strlen (missing) > base_strlen) {
	        user_disconnect (puser, DISCONNECT_NULL, 1, missing);
			log_printf (puser, LNOTE, missing);
		} else {
            packet_send(puser, PACKET_MENU_RESET, 0, 0, 0);
            packet_send(puser, PACKET_MAP_LOADING, 0, "Authenticating..");        
		    user_mode_set (puser, USER_AUTHENTICATE);
        }

	} else if (packet_type == PACKET_PING_REQUEST) {
		packet_send(puser, PACKET_PING_RESPONSE, data, size);
    
    } else if (packet_type == PACKET_MENU_RESPONSE) {
		int menu_number = -1;
		int menu_name = -1;
		int menu_value = -1;
		int menu_flags = -1;
		unsigned char menu_char[65535]; 
        memset (menu_char, 0, 65535);
	    if (size > 0) menu_number = (unsigned char ) data[0];
	    if (size > 1) menu_name = (unsigned char )data[1];	
	    if (size > 2) menu_value = (unsigned char ) data[2];
	    if (size > 3) menu_flags = (unsigned char ) data[3];
	    if (size > 4) {
		    memmove (menu_char, data + 4, size - 4);
		    menu_char[size - 4] = 0;
		    ret = size - 4;
	    }
        if (lua_hook_call ("mme_user_packet_menu_reponse", puser, menu_number, menu_name, menu_value, menu_flags, menu_char, ret)) {
            goto end;
        }        
        
		puser->menu_data = data;
		puser->menu_data_size = size;
		menu_proc (puser, MENU_COMMAND);
        
    } else if (packet_type == PACKET_FILE_REQUEST) {
        char temp[127];
            sha1_to_str (temp, data);
            printf ("texture request [%s]\n", temp);
    
        request_queue_by_sha1 (puser, data);
/*    
        char temp[1024];
        struct texture  *ptexture;
 		puser->textures_sent ++;
        
        ptexture = texture_find_by_sha1 (puser->map->palette, data);
        
        if (lua_hook_call ("mme_user_receive_packet_file_request", puser, data)) {
            goto end;
        }        
        
        if (ptexture == NULL) {
            sha1_to_str (temp, data);
            log_printf (puser, LERROR, "Invalid texture sha: %s", temp);
        } else {
        
        	int fe = -1;
        	for (a = 1; a < CLIENT_TEXTURE_LIMIT; a++) {
            	if (puser->texture_request[a] == ptexture) {
					log_printf (puser, LDEBUG, "Texture already requested: %s", ptexture->file);
					ret = 1;
					goto end;
				}
            	if (puser->texture_request[a] == 0 && fe == -1) fe = a;
           	}

        	if (a == CLIENT_TEXTURE_LIMIT && fe != -1) a = fe;
        	if (a == CLIENT_TEXTURE_LIMIT) {
            	log_printf (puser, LERROR, "Ran out of texture request space!");
           	}

        	puser->texture_request[a] = ptexture;
        	puser->texture_request_flag = 1;
			log_printf (puser, LDEBUG, "Texture queued: %s", ptexture->file);
 		}
		*/
    } else if (packet_type == PACKET_PING_RESPONSE ) {
	
    } else if (packet_type == PACKET_IDLE_PING ) {        
    
    } else if (packet_type == PACKET_DISCONNECT ) {
        if (lua_hook_call ("mme_user_receive_packet_disconnect", puser, data)) {
            goto end;
        }        
    
	    char *reason = "No description given";
        if (size > 3) {
            reason = data + 2;
            reason[size-3] = 0;
        }
        
        log_printf (puser, LDEBUG, "PACKET_DISCONNECT: reason = %i, [%s]", data[0], reason);
		user_mode_set (puser, USER_DISCONNECT);
        
    } else if (packet_type == PACKET_MOVE_PLAYER) {
        struct move_player {
            float x;
            float y;
            float z;
            float u;
            float v;
            unsigned char id;
        }__attribute__((__packed__))  *mp;
        
        mp = (void *)data;
        
        event_player_position_changed (puser, (struct float_xyzuv) {mp->x, mp->y, mp->z, mp->u, mp->v});
		
        puser->position.x = mp->x;
        puser->position.y = mp->y;
        puser->position.z = mp->z;
        puser->position.u = mp->u;
        puser->position.v = mp->v;
    
    } else if (packet_type == PACKET_MAP_MODIFY) {
        struct map_modify *m = (struct map_modify *)data;
//        int original_block = (unsigned char)BLOCK (puser->map, m->x, m->y, m->z);
        if (lua_hook_call ("mme_user_receive_packet_map_modify", puser, m->x, m->y, m->z, m->type, m->who)) {
            goto end;
        }        

        
        modify_client_map (puser, (struct map_modify *) data, 0);
        
        /*if (puser->paint) {
            printf ("paint\n");
            if (m->type != 0 && m->type != 255)  {
            
                paint_start (puser, m->x, m->y, m->z, original_block, m->type, 1, 0);
            
            } else {
                printf ("Paint cancelled %i\n", m->type);
            }
            
            puser->paint = 0;
        } */       


    } else if (packet_type == PACKET_CHAT_MESSAGE) {
        char *message, *output;
		message = _malloc (size + 1024);
		output = _malloc (size + 1024);
        memmove (message, data + 1, size - 1);
        message[size - 1] = 0;
        
        if (lua_hook_call ("mme_user_receive_packet_chat_message", puser, message)) {
            _free (message);
            _free (output);
            goto end;
        }
		
		int b = 0;
		int spc = 3;
		for (a = 0; a < size; a++) {
			if (data[a + 1] == ' ' && spc > 0) spc --;
			else if (data[a + 1] != ' ') spc = 3;
			if (spc != 0) {
				message[b] = data[a + 1];
				b++;
			}
		
		}
		size = b;

        if (size - 1 > 200) {
            size = 201;
            user_message (puser, MUSER, "|4Your message has been truncated to 200 characters.  You may want to download a newer version of the client, as it can help you with the length of your messages.");
        }
		message[size - 1] = 0;
		
		b = 0;
		for (a = 0; a < size; a++) {
			if (message[a] == '|') { a++; continue;}
			output[b] = message[a];
			b++;
		
		}
		output[b] = 0;
        FILE *fn1;
		fn1 = fopen ("chat.txt", "ab");
		if (fn1 != 0) {
			struct tm *e;			
			time_t t;
			time (&t);
			e=localtime(&t);
    		fprintf (fn1, "%02i-%02i %02i:%02i:%02i %s: %s\r\n",
                        		e->tm_mon+1, e->tm_mday, e->tm_hour,
                        		e->tm_min, e->tm_sec, puser->name, message);
			fclose (fn1);
		}

		if (message[0] == '/') command_proc (puser, message + 1);
		else if (message[0] == '@') {
			user_chat_private (puser, message+1);

		} else {
			user_message_chat (puser, message);
		}

        _free (message);
		_free (output);
        
    } else if (packet_type == PACKET_MAP_FILL) {
        struct map_fill *mf = (struct map_fill *)data;

        if (lua_hook_call ("mme_user_receive_packet_map_fill", puser, mf->lower_x, mf->lower_y, mf->lower_z, mf->upper_x, mf->upper_y, mf->upper_z, mf->type, mf->who)) {
            goto end;
        }        
		map_client_fill (puser, (struct map_fill *) data, size);

    
    } else if (packet_type == PACKET_AUTHENTICATE) {
	    if (user_authenticate (puser, (struct packet_authenticate_data *) data, size)) {
        	user_set_write_event (puser, user_send_map);
//            user_set_write_event (puser, menu_management_timeout) ;
		} else {
			user_mode_set (puser, USER_DISCONNECT);
		}
        
    } else if (packet_type == PACKET_MENU_REQUEST) {
        //menu_connected_players (puser);
        if (lua_hook_call ("mme_user_receive_packet_menu_request", puser)) {
            goto end;
        }         
        
        menu_connected_players (puser, MENU_CREATE);
    } else if (packet_type == PACKET_CLIENT_VERSION) {
        struct client_version {
            unsigned char format;
            unsigned int version;
        } __attribute__((__packed__));
        struct client_version *cv = (void *)data;
        
        if (cv->format == 0) { 
            puser->client_version = cv->version;
        }
        if (lua_hook_call ("mme_user_receive_packet_client_version", puser, cv->version)) {
            goto end;
        }        
    
	} else if (packet_type == PACKET_MAP_DATA) {
		map_update_compressed_data (puser, (unsigned char *)data, size);
    
	} else if (packet_type == PACKET_PROJECTILE_CREATE) {
		if (!puser->map->violence) goto end;
        struct projectile_create {
            unsigned char type;
            float x;
            float y;
            float z;
            float u;
            float v;
        } __attribute__((__packed__))*p = (void *)data;

        packet_broadcast (puser->map, USER_CONNECTED, puser, PACKET_PROJECTILE_CREATE, 
            (unsigned char) p->type, (float) p->x, (float)p->y, (float)p->z, (float)p->u, (float)p->v);

	} else if (packet_type == PACKET_PROJECTILE_COLLISION) {
		if (!puser->map->violence) goto end;
        struct projectile_collision {
            unsigned char type;
            float x;
            float y;
            float z;
            unsigned char hit_type;            
            unsigned char hit_id;
        } __attribute__((__packed__)) *p = (void *)data;

        if (p->hit_type == 0) {
            struct map_modify m;
            m.x = floor (p->x);
            m.y = floor (p->y);
            m.z = floor (p->z);
			if (m.x < 0 || m.y < 0 || m.z < 0 || m.x >= puser->map->dimension.x || m.y >= puser->map->dimension.y || m.z >= puser->map->dimension.z) goto end;
            m.type = 255;
            m.who = 0;
            struct block *pblock = &puser->map->palette->block[(unsigned char)BLOCK (puser->map, m.x, m.y, m.z)];
            if (pblock->explosiveness > 0.0) map_explosion (puser, m.x, m.y, m.z);
            else  if (puser->map->palette->block[p->hit_id].damage)
                    modify_client_map (puser, &m, 1);

        } else if (p->hit_type == 1) {
            if (p->hit_id > 126) {
                int idx = p->hit_id - 127;
                int damage = (5 + (int) (2.0 * (rand() / (RAND_MAX + 1.0))));
                npc[idx].hitpoints -= damage;
            } else if (p->hit_id > 0 && user[p->hit_id].current_mode == USER_CONNECTED) {

                int damage = 5 + (int) (2.0 * (rand() / (RAND_MAX + 1.0)));
                user_damage (puser, &user[p->hit_id], damage);
            }
        }
    } else if (packet_type == PACKET_MENU_RESIZE) {

    } else {
        log_printf (NULL, LERROR, "Packet %s needs to be defined in process_packet().", packet_type_to_string(packet_type));
    }
    end:
    return (ret);
}

void process_send_raw_data (struct user *puser, char *packet, size_t size) {
	if (size == 0) {
		log_printf (puser, LDEBUG, "server_send_raw_data: size is zero");
		return;
	}
	if (packet == 0 || packet == NULL) {
		log_printf (puser, LDEBUG, "server_send_raw_data: packet is zero/null");
		return;
	}

    if (size + puser->write_length > puser->write_size) {
        size_t new_size = puser->write_size + size + 1 + DEFAULT_BUFFER_SIZE;

        log_printf (puser, LDEBUG, "server_send_raw_data: Buffer limit reached (now %i)", new_size);
        
        char *cp;
        cp = _realloc (puser->write_buffer, new_size);
        if (cp != 0) {
            puser->write_buffer = cp;
            puser->write_size = new_size;
        } else {
			log_printf (puser, LERROR, "server_send_raw_data: _realloc failed.  Data in trouble.");
		}
    }
    memmove (&puser->write_buffer[puser->write_length], packet, size);
    puser->write_length += size;
}
