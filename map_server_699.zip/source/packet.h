/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/



/* Protocol definitions, intended for distribution! */
extern char * PACKET_END;

#define PACKET_AVAILABLE_PACKET_TYPES 0
#define PACKET_SELECT_PACKET_TYPES 1
#define PACKET_PING_REQUEST 2
#define PACKET_PING_RESPONSE 3
#define PACKET_IDLE_PING 4
#define PACKET_AUTHENTICATE 5
#define PACKET_CONNECT 6
#define PACKET_DISCONNECT 7
#define PACKET_CHAT_MESSAGE 8
#define PACKET_ANNOUNCE_PLAYER 9
#define PACKET_DENOUNCE_PLAYER 10
#define PACKET_PLAYER_ABILITIES 11
#define PACKET_MAP_LOADING 12
#define PACKET_RANDOM_GARBAGE 13
#define PACKET_MAP_SETUP 14
#define PACKET_MAP_PROPERTIES 15
#define PACKET_MAP_FILL 16
#define PACKET_MAP_DATA 17
#define PACKET_MAP_TOTAL_RESET 18
#define PACKET_MAP_TOTAL_DATA 19
#define PACKET_BUFFER_RESET 20
#define PACKET_BUFFER_APPEND 21
#define PACKET_BUFFER_IS_MAP_DATA 22
#define PACKET_BUFFER_IS_FILE_DATA 23
#define PACKET_MOVE_PLAYER 24
#define PACKET_MAP_MODIFY 25
#define PACKET_FILE_REQUEST 26
#define PACKET_TEXTURE_SETUP 27
#define PACKET_GROUP_SETUP 28
#define PACKET_BLOCK_SETUP 29
#define PACKET_MENU_REQUEST 30
#define PACKET_MENU_RESPONSE 31
#define PACKET_MENU_RESET 32
#define PACKET_MENU_TEXT 33
#define PACKET_MENU_LINK 34
#define PACKET_MENU_CHECK 35
#define PACKET_MENU_RADIO 36
#define PACKET_MENU_INPUT 37
#define PACKET_MENU_BUTTON 38
#define PACKET_MENU_ERASE 39
#define PACKET_MENU_SALTED_PASSWORD 40
#define PACKET_MENU_RESIZE 41
#define PACKET_SKY_BOX 42
#define PACKET_CLIENT_VERSION 43
#define PACKET_PORTAL_COOKIE 44
#define PACKET_PLAYER_PROPERTIES 45
#define PACKET_MENU_TEXTURE 46
#define PACKET_SERVER_NAME 47 
#define PACKET_PROJECTILE_CREATE 48
#define PACKET_PROJECTILE_COLLISION 49 
#define PACKET_TYPE_LIMIT 50

#define DISCONNECT_NULL 0
#define DISCONNECT_ERROR 1
#define DISCONNECT_REBOOT 2
#define DISCONNECT_FULL 3
#define DISCONNECT_IDLE 4
#define DISCONNECT_KICK 5
#define DISCONNECT_BAN 6
#define DISCONNECT_RANDOM 7
