--[[
By using the hook function "mme_user_format_chat_message", we 
can customize the appearance of chat messages.  In this case,
we print out the users' rank inside square brackets before
printing the name and chat message.

Note that we use chat_name for the users name instead of 'name', 
or just username, which is passed to the function.
chat_name contains either the users name or their nickname,
prodived that a nickname is set.

returning 1 is important here, in order to keep the map server
from sending the chat message, itself.  We are doing this 
ourselves by using the mme_user_send_message_broadcast function.
]]--

function mme_user_format_chat_message (username, message) 

	new_message = "|3[|" .. mme_rank[mme_user[username].rank_name].color .. mme_user[username].rank_name .. "|3] |" .. mme_user[username].color .. mme_user[username].chat_name .. "|9: " .. message
	mme_user_send_message_broadcast ("null", new_message)
	return (1)
end

print ("chat.lua : loaded")

