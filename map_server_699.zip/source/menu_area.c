/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"


struct d_menu_area_manager {
	int uid;
	char area[64][128];
	int num_areas;
	char new_name[128];
	int selected;
};

static int build_area_list (struct user *puser, struct d_menu_area_manager *d) {
	struct dirent *rdn;
	struct stat st;
	DIR *dn;
	char path[PATH_MAX];
	char temppath[PATH_MAX];
	int ret;
	char *cp;
	
	d->num_areas = 0;
	
	snprintf (path, PATH_MAX, "%s/%s/%i", PATH_AREAS, puser->map->file, puser->uid);
	dn = opendir (path);
    if (dn == 0) {
        log_printf (NULL, LERROR, "Unable to open directory [%s]: %s\n", strerror (errno), path);
		return (0);
    }
	
	while ((rdn = readdir (dn)) != NULL) {
		if (rdn->d_name[0] == '.') continue;	
		sprintf (temppath, "%s/%s", path, rdn->d_name);
		
		ret = lstat (temppath, &st);
		if (ret == -1) {
            log_printf (NULL, LNOTE, "stat failed for [%s]: %s", temppath, strerror (errno));
            continue;
        }

		if (S_ISDIR (st.st_mode)) continue;
		
		_strncpy (d->area[d->num_areas], rdn->d_name, 128);
		
		cp = strrchr (d->area[d->num_areas], '.');
		if (cp == 0) continue;
		
		if (strcmp (cp, ".bin") != 0) continue;
		
		*cp = 0;
		
		d->num_areas++;
	}
	closedir (dn);
	return (1);
}

int area_user_count (struct user *puser) {
	struct dirent *rdn;
	struct stat st;
	DIR *dn;
	char path[PATH_MAX];
	char temppath[PATH_MAX];
	int ret = 0;
    int count = 0;
	
	
	snprintf (path, PATH_MAX, "%s/%s/%i", PATH_AREAS, puser->map->file, puser->uid);
	dn = opendir (path);
    if (dn == 0) {
        log_printf (NULL, LERROR, "Unable to open directory [%s]: %s\n", strerror (errno), path);
		return (0);
    }
	
	while ((rdn = readdir (dn)) != NULL) {
		if (rdn->d_name[0] == '.') continue;	
		sprintf (temppath, "%s/%s", path, rdn->d_name);
		
		ret = lstat (temppath, &st);
		if (ret == -1) {
            log_printf (NULL, LNOTE, "stat failed for [%s]: %s", temppath, strerror (errno));
            continue;
        }

		if (S_ISDIR (st.st_mode)) continue;
		
        count ++;		
	}
	closedir (dn);
	return (count);
}


int menu_area_manager (struct user *puser, int message_id) {
	struct d_menu_area_manager *d;
    char temp[256];
	
	d = menu_get_current_stack_item_memory (puser);

	int a;
	
    switch (message_id) {
	case MENU_CREATE:
    
		d = menu_stack_push_init (puser, menu_area_manager, NULL, sizeof (struct d_menu_area_manager));
		
	case MENU_DRAW: {
		int index = 1;

        time_t t;
        time (&t);
		
		build_area_list (puser, d);        

        packet_send(puser, PACKET_MENU_RESET, 0, 78, 20, 3); 
        packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 0, "Area Manager");

//		packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 2, "Click on an area to get a list of options.");
		
		packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 2, "Available Areas");

		//if (d->num_areas < NUM_USER_AREAS) packet_send(puser, PACKET_MENU_BUTTON, index++, 17, 18, 3, 0, 0, 0, "Add a new area");
		
		if (d->num_areas < NUM_USER_AREAS) packet_send(puser, PACKET_MENU_LINK, index++, 1, 19, 3, 0, 0, "[ Add a new area ]");
		else {
            snprintf (temp, 128, "You have reached the maximum of %i areas.", NUM_USER_AREAS);
            packet_send(puser, PACKET_MENU_TEXT, index++, 1, 19, temp);
        }
		

		packet_send(puser, PACKET_MENU_TEXT, index++, 0, 18, "-------------------------------------------------------------------------------");		
		
		
//		packet_send(puser, PACKET_MENU_BUTTON, index++, 8, 16, 4, 0, 6, 0, "Load");		
//		packet_send(puser, PACKET_MENU_BUTTON, index++, 16, 16, 5, 0, 6, 0, "Rename");		
//		packet_send(puser, PACKET_MENU_BUTTON, index++, 24, 16, 6, 0, 6, 0, "Delete");		
//		packet_send(puser, PACKET_MENU_BUTTON, index++, 32, 16, 7, 0, 6, 0, "Copy");		


		
        for (a = 0; a < d->num_areas; a++) {
			
		
			//packet_send(puser, PACKET_MENU_CHECK, index++, 4, 4 + a, 9, a, 0, d->area[a]);
			packet_send(puser, PACKET_MENU_TEXT, index++, 3, 4 + a, d->area[a]);
			
			
			area_name_loaded (puser, temp);
			if (strcmp (temp, d->area[a]) != 0) {
				packet_send(puser, PACKET_MENU_LINK, index++, 36, 4 + a, 4, a, 0, "[ load ]");
				packet_send(puser, PACKET_MENU_LINK, index++, 46, 4 + a, 5, a, 0, "[rename]");
				if (d->num_areas > 1) packet_send(puser, PACKET_MENU_LINK, index++, 56, 4 + a, 6, a, 0, "[delete]");
			} else {
				packet_send(puser, PACKET_MENU_TEXT, index++, 36, 4 + a, "(this area is in use)");			
			}
			if (d->num_areas < NUM_USER_AREAS) packet_send(puser, PACKET_MENU_LINK, index++, 66, 4 + a, 7, a, 0, "[ copy ]");
			
			

        }
        
		break;}
		
		
	case MENU_COMMAND: {
		int menu_number = -1;
		int menu_name = -1;
		int menu_value = -1;
		int menu_flags = -1;
		unsigned char menu_char[65535]; 
		
		menu_command_parse (puser, &menu_number, &menu_name, &menu_value, &menu_flags, menu_char);

		log_printf (puser, LDEBUG, "area_manager menu response bytes=%i, menu=%i, name=%i, value=%i, flags=%i", 
				puser->menu_data_size, menu_number, menu_name, menu_value, menu_flags);	

    	if (menu_name == 3) {
		
			menu_create_area (puser, MENU_CREATE, d);
			
    	} else if (menu_name == 4) {
	
			log_printf (puser, LDEBUG, "Load area #%i", menu_value);
			snprintf (temp, 256, "Load \"%s\" instead of the currently loaded area?", d->area[menu_value]);
			menu_dialog_yesno (puser, MENU_CREATE, "Load Area", temp, 14);			
			d->selected = menu_value;
		
    	} else if (menu_name == 5) {
			d->selected = menu_value;
			log_printf (puser, LDEBUG, "Rename area #%i", menu_value);
			menu_rename_area (puser, MENU_CREATE ,d );

    	} else if (menu_name == 6) {
			d->selected = menu_value;
			log_printf (puser, LDEBUG, "Delete area #%i", menu_value);
			
			snprintf (temp, 256, "Permanently delete area \"%s\"?", d->area[menu_value]);
			menu_dialog_yesno (puser, MENU_CREATE, "Delete Area", temp, 16);			
			d->selected = menu_value;

    	} else if (menu_name == 7) {
			d->selected = menu_value;		
			log_printf (puser, LDEBUG, "Copy area #%i", menu_value);
            area_sync (puser->map);
			if (strlen (d->area[d->selected]) > 24) {
				menu_dialog (puser, MENU_CREATE, "Copy File", "Area names must be less than 25 characters if you intend to make a copy", "OK");			
				break;
			}
			snprintf (temp, 256, "Make a copy of area \"%s\"?", d->area[menu_value]);
			menu_dialog_yesno (puser, MENU_CREATE, "Copy Area", temp, 17);			

		} else if (menu_name == 14) {
			if (menu_value == 1) {
				log_printf (puser, LDEBUG, "Load area : Yes");
				
				area_swap (puser, d->area[d->selected]);
				menu_stack_pop (puser);
			} else {
				log_printf (puser, LDEBUG, "Load area : NO");
				menu_area_manager (puser,  MENU_DRAW);
			}
		
		
		} else if (menu_name == 16) {
			if (menu_value == 1) {
				log_printf (puser, LDEBUG, "Delete area : Yes");			
				area_delete (puser, d->area[d->selected]);
				
    		} else {
				log_printf (puser, LDEBUG, "Delete area : NO");
			}
			
//			menu_area_manager (puser,  MENU_DRAW);

		
		} else if (menu_name == 17) {
			if (menu_value == 1) {
				log_printf (puser, LDEBUG, "Copy area : Yes");			

				char old_name[PATH_MAX], new_name[PATH_MAX];

				snprintf (old_name, PATH_MAX, "%s/%s/%i/%s.bin", PATH_AREAS, puser->map->file, puser->uid, d->area[d->selected]);
				
				a = 1;
				while (1) {
			    	snprintf (new_name, PATH_MAX, "%s/%s/%i/%s (%i).bin", PATH_AREAS, puser->map->file, puser->uid, d->area[d->selected], a);
					if (access (new_name, F_OK) != 0) break;
					a++;
				}
				
				copy_file (old_name, new_name);

			
			} else {
				log_printf (puser, LDEBUG, "Copy area : NO");
			}
					
		} else {
			menu_stack_pop (puser);
		}
		
		break;}
	}
	return (1);
}

int menu_create_area (struct user *puser, int message_id, void *parent) {

	struct d_menu_area_manager *d;
	
	d = menu_get_current_stack_item_memory (puser);



	switch (message_id) {
	case MENU_CREATE:
		log_printf (puser, LDEBUG, "Menu_create_area");
		
		d = menu_stack_push_init (puser, menu_create_area, parent, 0);
		

	case MENU_DRAW:
        packet_send(puser, PACKET_MENU_RESET, 0, 40, 10, 3); 
        packet_send(puser, PACKET_MENU_TEXT, 1, TEXT_CENTER_COLUMN, 0, "Create Area");
        packet_send(puser, PACKET_MENU_TEXT, 2, 1, 2, "Enter a unique name for the new area.");
		packet_send(puser, PACKET_MENU_TEXT, 3, 1, 3, "When finished, click \"Create\".");		


        packet_send(puser, PACKET_MENU_INPUT, 4, 4, 5, 9, 0, 30, 30, 0, d->new_name);

		packet_send(puser, PACKET_MENU_BUTTON, 5, TEXT_CENTER_COLUMN, 7, 11, 0, 0, 0, "Create");

		break;
		
	case MENU_COMMAND: {


		int menu_number = -1;
		int menu_name = -1;
		int menu_value = -1;
		int menu_flags = -1;
		unsigned char menu_char[65535]; 
		
		menu_command_parse (puser, &menu_number, &menu_name, &menu_value, &menu_flags, menu_char);
		

		if (menu_name == 9) {
			_strncpy (d->new_name, (char *)menu_char, 32);
		} else if (menu_name == 11) {
		
			log_printf (puser, LDEBUG, "Name [%s]", d->new_name);
			_strlwr (d->new_name);
			char temp[256];
			char *cp = str_invalid (d->new_name, "/|\\\"';:<>{}[]*%");
			if (cp != 0) {

				sprintf (temp, "Area names cannot contain the (%c) character.", *cp);

				menu_dialog (puser, MENU_CREATE, "Create Area - Invalid Name", temp, "OK");

				break;
			}
			
			area_file_path_make (puser->map, temp, puser->idx, d->new_name);
			
			if (access (temp, F_OK) == 0) {
				sprintf (temp, "An area named \"%s\" already exists.", d->new_name);
            	menu_dialog (puser, MENU_CREATE, "Create Area - Error", temp, "OK");						

				break;
			}

			area_create_file (puser, d->new_name);
            area_swap (puser, d->new_name);
			menu_stack_clear (puser);
           	menu_dialog (puser, MENU_CREATE, "Create Area", "Your new area has been created and is now loading..", "OK");



		} else {
			menu_stack_pop (puser);
	
		
		}
		break;}	
	}

	
	return (1);		
}

int menu_rename_area (struct user *puser, int message_id, void *parent) {

	struct d_menu_area_manager *d;
	
	d = menu_get_current_stack_item_memory (puser);


	switch (message_id) {
	case MENU_CREATE:
		log_printf (puser, LDEBUG, "Menu_rename_area");

		d = menu_stack_push_init (puser, menu_rename_area, parent, 0);
		
		d->new_name[0] = 0;
		strcpy (d->new_name, d->area[d->selected]);

	case MENU_DRAW:
        packet_send(puser, PACKET_MENU_RESET, 0, 40, 10, 3); 
        packet_send(puser, PACKET_MENU_TEXT, 1, TEXT_CENTER_COLUMN, 0, "Rename Area");
        packet_send(puser, PACKET_MENU_TEXT, 2, 1, 2, "Enter a new name for this area.");
		packet_send(puser, PACKET_MENU_TEXT, 3, 1, 3, "When finished, click \"Rename\".");		
        packet_send(puser, PACKET_MENU_INPUT, 4, 4, 5, 9, 0, 30, 30, 0, d->new_name);
		packet_send(puser, PACKET_MENU_BUTTON, 5, TEXT_CENTER_COLUMN, 7, 11, 0, 0, 0, "Rename");

		break;
		
	case MENU_COMMAND: {


		int menu_number = -1;
		int menu_name = -1;
		int menu_value = -1;
		int menu_flags = -1;
		unsigned char menu_char[65535]; 
		
		menu_command_parse (puser, &menu_number, &menu_name, &menu_value, &menu_flags, menu_char);
		
		

		if (menu_name == 9 && puser->menu_data_size > 4) {
			_strncpy (d->new_name, (char *)menu_char, 32);
		} else if (menu_name == 11) {
		
			log_printf (puser, LDEBUG, "Name [%s]", d->new_name);
			_strlwr (d->new_name);
			char temp[256];
			char *cp = str_invalid (d->new_name, "/|\\\"';:<>{}[]*%");
			if (cp != 0) {

				sprintf (temp, "Area names cannot contain the (%c) character.", *cp);

				menu_dialog (puser, MENU_CREATE, "Create Area - Invalid Name", temp, "OK");

				break;
			}
			
			area_file_path_make (puser->map, temp, puser->idx, d->new_name);
			
			if (access (temp, F_OK) == 0) {
				sprintf (temp, "An area named \"%s\" already exists.", d->new_name);
            	menu_dialog (puser, MENU_CREATE, "Rename Area - Error", temp, "OK");						

				break;
			}
			
			
			char old_name[PATH_MAX], new_name[PATH_MAX];
	    	snprintf (old_name, PATH_MAX, "%s/%s/%i/%s.bin", PATH_AREAS, puser->map->file, puser->uid, d->area[d->selected]);
	    	snprintf (new_name, PATH_MAX, "%s/%s/%i/%s.bin", PATH_AREAS, puser->map->file, puser->uid, d->new_name);
			
			
			log_printf (puser, LDEBUG, "Area rename [%s] to [%s]", old_name, new_name);
			
			if (rename (old_name, new_name) == -1) {
				log_printf (puser, LWARNING, "Rename failed: %s", strerror (errno));
			
			}
			

			menu_stack_pop (puser);
			

		} else {
			menu_stack_pop (puser);
		
		}
		break;}	
	}

	
	return (1);		
}

