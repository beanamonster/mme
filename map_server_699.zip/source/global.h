/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/

#ifdef WIN32
    #define WINVER 0x0500
    #define _WIN32_WINNT 0x0500

	#include <windows.h>
	#include <commctrl.h>
#else 

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#ifndef __USE_GNU
#define __USE_GNU
#endif

    #include <sys/wait.h>
    #include <sys/select.h>
    #include <sys/socket.h> 
    #include <arpa/inet.h> 
    #include <netdb.h> 
    #include <netinet/tcp.h>
    #include <pthread.h>
#endif 


#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <limits.h>
#include <ctype.h>
#include <stdarg.h>
#include <errno.h> 
#include <unistd.h> 
#include <time.h>
#include <signal.h>
#include <dirent.h>
#include <fcntl.h>
#include <zlib.h>

#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>


#include "thread.h"
extern const unsigned int build_version;

#include "packet.h"
#include "announce.h"

#ifdef WIN32
    #define socket_error WSAGetLastError()
    #define error_code WSAGetLastError()
    //#define ECONNREFUSED WSAECONNREFUSED
    //#define EHOSTUNREACH WSAEHOSTUNREACH
    //#define ENETUNREACH WSAENETUNREACH
    //#define ETIMEDOUT WSAETIMEDOUT
    //#define ECONNRESET WSAECONNRESET
    //#define ECONNABORTED WSAECONNABORTED
    #define EWOULDBLOCK WSAEWOULDBLOCK
    #define lstat stat
    
#else
    #define socket_error errno
    #define closesocket close
#endif

/* Modes for log_printf */
#define LDEBUG 0
#define LNOTE 1
#define LWARNING 2
#define LERROR 3
#define LCHAT 0x10

#define DEFAULT_TCP_PORT 44434
#define NUM_USERS 255
#define USER_NOT_CONNECTED 0
#define USER_AUTHENTICATE 1
#define USER_CONNECTING 2
#define USER_CONNECTED 3
#define USER_DISCONNECT 4
#define USER_NEW_MAP 5

#define TEXT_CENTER_COLUMN 255
#define PACKET_SELECT_LENGTH 8192

#define NUM_AREA_SLOTS 64


/*
  BUFFER_SIZE needs to be the maximum packet length plus the size
  of the packet header, at minimum.  
  If DEFAULT_BUFFER_SIZE is too small, maximum-sized packets will not fit
  in the buffer, and will never be able to be processed.
  DEFAULT_BUFFER_SIZE could be bigger, but then you're most likely wasting 
  memory.
  Additionally, one could also read headers only, and then allocate
  the payload size as needed.  This is the most memory-effecient way,
  but adds some processing overhead due to many small packets needing to
  be read out and processed in sucessive socket reads.
*/
#define DEFAULT_BUFFER_SIZE 131080

#define MENU_NULL 0
#define MENU_CREATE 1
#define MENU_COMMAND 2
#define MENU_DRAW 3
#define MENU_CLOSE 4

struct short_xyz {
    short x;
    short y;
    short z;

}__attribute__((__packed__));
struct float_xyz {
    float x;
    float y;
    float z;
};

struct float_xyzuv {
    float x;
    float y;
    float z;
    float u;
    float v;
    
};
struct int_xyz {
    int x;
    int y;
    int z;
};

struct double_xyzuv {
    float x;
    float y;
    float z;
    float u;
    float v;
    
};

struct double_xyz {
    float x;
    float y;
    float z;
    float u;
    float v;
    
};
struct map_journal {
	int id;
	time_t stamp;
	unsigned short x;
	unsigned short y;
	unsigned short z;
	unsigned char new;
	unsigned char old;
} __attribute__((__packed__)) ;

struct rank {
    int id;
	char name[32];
   	char promote_to[32];
    char can_chat;
    char can_build;
    char motd_file[256];
    double cuboid_volume_limit_meters;
    double cuboid_size_limit_meters;
    char can_fly;
    char can_sonic_fly;
    char can_noclip;
    char *allowed_commands[256]; 
    char *allowed_menus[256];     
    unsigned char color;
    char transferable;
};
struct texture {
    int id;
    char file[256];
    unsigned char sha1[20];
    float x_pm;
    float y_pm;
    float alpha;
    unsigned int flags;
    int usage;
};

struct block {
    char name[64];
    char group[64];
    struct texture *texture_top;
    struct texture *texture_bottom;
    struct texture *texture_front;
    struct texture *texture_back;
    struct texture *texture_left;
    struct texture *texture_right;
    unsigned int flags;
	char hidden;
    char cuboidable;
    char damage;
    float explosiveness;
	int flow_depth;
    char min_rank[32];
};

struct block_group {
    char name[64];
    unsigned char blocks[257];
    int num_blocks;
};

#define CLIENT_TEXTURE_LIMIT 4096
#define SKYBOX_TEXTURE_IGNORE 2000
#define NUM_SKINS 255

#define NUM_PALETTES 16
struct palette {
    char active;
    //char config_file[256];
    char path[256];
    struct texture texture[CLIENT_TEXTURE_LIMIT];
    struct block block[256];
    struct block skybox[256];
    struct block_group block_group[256];
    struct skin {
        struct texture *texture;
        char name[32];
        char model_file[256];
        int model_id;
        char visible;
    } skin[NUM_SKINS];
    
    struct texture *skybox_top;
    struct texture *skybox_bottom;
    struct texture *skybox_left;
    struct texture *skybox_right;
    struct texture *skybox_front;
    struct texture *skybox_back;
    int skybox_flags;
    
    int num_textures;
    int num_block_groups;

} block_palette[NUM_PALETTES];

#define AREA_NUM_INVITED NUM_USERS
struct area {
    int active;
	int id;
	char user_name[25];
    struct user *invited[AREA_NUM_INVITED];
    char filename[256];  
	time_t last_load;
	int modify;
	unsigned int times_connected;	
} ;


#define NUM_USER_AREAS 10

#define NUM_MAPS 64
#define USER_CONSOLE &user[0]


struct map {
    int id;
    int active;
    struct int_xyz dimension;
    struct float_xyzuv spawn;
    int sealevel;
    char *data;
    size_t data_size;
    time_t last_save;
    int save_counter;
    char file[256];
	double last_movement_update;
	FILE *fn_journal;
    FILE *fn1;
    char build_rank_name[32];
    float scale;
    char map_journal;
    char block_palette_name[32];
    struct palette *palette;
    struct rank *rank;
    unsigned int invited[NUM_USERS];
    struct area area[NUM_AREA_SLOTS];
    int area_map;
	int area_quantity;
	unsigned char grass_block;
	unsigned char dirt_block;
	unsigned char border_block;
	short area_num_x;
	short area_num_y;
	short area_border_size;
	short area_x;
	short area_y;
	size_t area_data_size;
	short area_num_total;
	unsigned int area_in[NUM_USERS];
    char violence;
	struct finite_flow *flow;
	int flow_count;
	double finite_flow_stamp;
	int flow_at;
	int wind;
	int sea_z;
    int num_circuits;
    struct circuit {
        int funky;
        int x;
        int y;
        int z;
        int powered;
        int type;
        int state;
    
    } circuit;
	
} map_array[NUM_MAPS];

struct config {
    char name[64];
    unsigned char salt[20];
    int connection_limit;
    int connection_timeout;
	char external_address[280];
    unsigned char restart_dead_time;
    char local_connections;
    char display_rank_names;    
    char default_rank_name[32];
    char map_file[256];
    char announce_disabled;
    int minimum_client_version;
	int display_log;
	char online;
	int afk_timeout;
	char ansi;
	char pause_exit;
    int config_sync;
}  config;

#define NUM_RANKS 16

struct rank rank[NUM_RANKS];

struct undo_data {
	unsigned int action_count;
	short x;
	short y;
	short z;
	time_t stamp;
	unsigned char block;
};
	
#define NUM_FILE_REQUESTS 4096
struct file_request {
	char file[256];
	char sha1[20];
    char active;
} file_request[NUM_FILE_REQUESTS];

    
struct user {
    int idx;
    char name[25];
    char salt[21];
    struct float_xyzuv position;
    int uid;
	unsigned char color;
    char rank_name[32];
    int socket;
	int current_mode;
	int previous_mode;

    char skin_name[32];
    int skin_id;
    int banned;
    int connections; 
	char nick[32];	
	char no_nicknames;

    time_t last_io;
    time_t idle_stamp;
    time_t last_idle_ping;
	
	char ip_address[256];
	char error_message[256];

    void *write_event;

    struct float_xyzuv position_last;	
    struct map_journal journal_data;

    struct rank *rank;
    int write_init;
	char new;
    int who;
    
	char *write_buffer;
	int write_length;
	int write_size;

	char *read_buffer;
	int read_length;
	int read_size;
    
	char *data;
    int data_size;
    int data_length;
    int data_offset;

    char receivable_packets[8192];
    char sendable_packets[8192];
	char disconnect_message[128];
    char file_request_flag;
    //struct texture *texture_request[CLIENT_TEXTURE_LIMIT];
    struct file_request file_request[NUM_FILE_REQUESTS];
	int textures_sent;
	double process_stamp;

    int waiting_for_map;
    
	int ignore_list[NUM_USERS];
    char no_rainbows;
    struct area *area;
    int client_version;

    struct map *map;
    int menu_lines;
    int menu_columns;
    char *menu_data;
    int menu_data_size;
	int area_idx;
	int afk;
	int hitpoints;
	int defense;
	int strength;
	int max_hitpoints;	
	struct undo_data *undo;
	int num_undo;
	double last_map_error_stamp;
    double position_stamp;
    float current_speed;
    int dead;
	time_t last_login_stamp;
	char request_sha1[20][4096];
	unsigned int blocks_placed;
	unsigned int blocks_removed;
	int flow_block;
    int no_area_names;
    int paint;
} user[NUM_USERS];

mutex user_mutex_write[NUM_USERS];

struct packet_authenticate_data {
    char name[24];
    unsigned int number;
    int t;
    unsigned char salt[20];
}  __attribute__((__packed__));

struct map_file_header {
    unsigned int header_size;
    struct int_xyz dimension;
    int sealevel;
}__attribute__((__packed__));

struct map_header {
    int x;
    int y;
    int z;
    int sealevel;
}__attribute__((__packed__));

#define ABILITY_FLY 1
#define ABILITY_SONIC_SPEED 2
#define ABILITY_NOCLIP 4
#define MENU_CHECK_CHECKED 1

struct map_modify {
    short x;
    short y;
    short z;
    unsigned char type;
    unsigned char who;
} __attribute__((__packed__));

struct map_fill {
    short lower_x;
    short lower_y;
    short lower_z;
    short upper_x;
    short upper_y;
    short upper_z;
    unsigned char type;
    unsigned char who;
} __attribute__((__packed__));

int (*write_event)(struct user *, int);
int (*compress_callback)(int, int, int, int, int, int, int, char *);

extern FILE *g_log_file_handle;

extern char *PACKET_NULL;

#define NUM_HISTORY 20
struct user_connection_history {
	char name[25];
	time_t t;
} user_connection_history[NUM_HISTORY], user_connection_history_new[NUM_HISTORY];

#define NUM_NPC_TYPES 32

struct npc_type {
	char name[32];
	char skin[32];
	void *move;
	void *attack;
	void *die;
	void *hurt;
	
	float speed;
	int thing_type;
	int hitpoints;
	int defense;
	int strength;
	int attack_range;
	int attack_chance;
	int randomness;
	int hunger;
	int energy;
	int comfort;
	int sight;
	float decay;
	int (*proc) (void *);
} npc_type[NUM_NPC_TYPES];

#define NUM_NPCS 127

struct npc {
	char user_spawn[32];
	char active;
	struct npc_type *type;
    unsigned char id;
	int skin_id;
	//char name[25];
	//char target_name[25];
	int mode;
	struct float_xyzuv position;
	struct map *map;
	double stamp;
    double attack_stamp;
    struct float_xyzuv target_position;
	int hitpoints;
	int food;
	int water;
	int health;
	int hunger;
	int energy;
	int comfort;
	int fun;
	int social;
	int bladder;	
	char umask[8192];
	double decay_stamp;
	int (*proc) (void *, int);	
	int model_id;
} npc[NUM_NPCS];

#define PATH_MAPS "maps"
#define PATH_USERS "users"
#define PATH_LOGS "logs"
#define PATH_LUA "lua"
#define PATH_AREAS "areas"
#define PATH_MODELS "models"
#define PATH_PRIVATE_MAIL "private_mail"

#define BLOCK(kmap, xq, yq, zq) (kmap->data[(((short)zq) * kmap->dimension.y + ((short)yq)) * kmap->dimension.x + ((short)xq)])

#define MAP_LOADING_STATE_LOADING 0
#define MAP_LOADING_STATE_DECOMPRESSING 1
#define MAP_LOADING_STATE_DONE 2

typedef struct tagHOOK_LIST {
	int id;
	int (* command_ptr)(struct user *, char *, char *);
} HOOK_LIST;

/*kill_server keeps the server running while false.  If it gets
set to 1, the server saves the map and exits*/
int kill_server;

#define MNULL 0
#define MUSER 1
#define MSYSTEM 2
#define MERROR 4

#include "btr.h"
#include "prototypes.h"

#ifdef LINUX
void _strlwr (char *p) ;
#endif

char g_shutdown_message[256];
char g_shutdown_type[32];
int g_kill_server;
int g_stdin_open;
extern const char g_color_list[13][18];
double g_lag_max;
int g_force_announcement;
int g_argument_packets;
int g_bind_socket;
int g_debug_mode;
int g_print_to_stdout;
time_t g_server_shutdown_timeout;
time_t server_start;
int g_announce_child;

struct flow_properties {
	int active;
	int block;
	int fill_depth;
	struct map *map;
	double flow_stamp;
	int fs_idx;
    int who;
	struct short_xyz stack[4096];
} flow_array[32];

#define _malloc(moop_ms) easy_malloc(__FILE__, __LINE__, moop_ms)
#define _realloc(pointer, moop_ms) easy_realloc(__FILE__, __LINE__, pointer, moop_ms)
#define NOT_REAL(x) ( !( (x) > -1000000.0 && (x) < +1000000.0 ) )

#define MAP_CHECK_BOUNDS(varr, vex, vey, vez)(\
    ((vex >= 0 && vex < varr->dimension.x) &&\
    (vey >= 0 && vey < varr->dimension.y) &&\
    (vez >= 0 && vez < varr->dimension.z))

