/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"

FILE *g_log_file_handle = 0;

void log_swap () {
	struct stat st;
    char file_temp[PATH_MAX];
    sprintf (file_temp, "%s/log.txt", PATH_LOGS);
    
	if (stat (file_temp, &st) == -1) {
		return;
	}

	if (st.st_size < 100000 * 1024) {
		return;
	}    
	
	fprintf (stderr, "Swapping out log file\n");	
	
	if (g_log_file_handle != 0) {
		fclose (g_log_file_handle);
		g_log_file_handle = 0;
	}		

	char temp[512];
	int a;
	for (a = 1; ; a++) {
		snprintf (temp, 512, "%s/log_%i.txt", PATH_LOGS, a);
		if (access (temp, F_OK) != 0) break;
	}
		
	if (rename (file_temp, temp) == -1) {
		fprintf (stderr,  "Unable to rename %s to %s\n", file_temp, temp);
	}

	g_log_file_handle = fopen (file_temp, "ab");
	if (g_log_file_handle == 0) {
		g_log_file_handle = fopen (file_temp, "wb");
		fclose (g_log_file_handle);
		g_log_file_handle = fopen (file_temp, "ab");
	}
	
	return;
}

void log_printf (struct user *puser, int type, char *str, ... ) {
    va_list  arg;
    char buffer[4096];
    time_t t;
    char *cp;
    struct tm *e;
	int send_chat = 0;
	
	if (type & LCHAT) {
		send_chat = 1;
		type &= ~LCHAT;
	}
    
    if (g_debug_mode == 0 && type == LDEBUG) return;
	
	log_swap ();

    time (&t);

    e=localtime(&t);
    
    char *ctype = "unknown";
    if (type == LDEBUG) ctype = "DEBUG";
    else if (type == LNOTE) ctype = "NOTE";
    else if (type == LWARNING) ctype = "WARNING";
    else if (type == LERROR) ctype = "ERROR"; 

    snprintf (buffer, 4095u, "[%02i-%02i %02i:%02i:%02i] %-7s ",
                        e->tm_mon+1, e->tm_mday, e->tm_hour,
                        e->tm_min, e->tm_sec, ctype);
          
    cp=strrchr (buffer, ' ');
    cp++;

    if (puser != NULL) {
        char ip[1024];
		if (puser->name[0] == 0) sprintf (ip, "%-25s", puser->ip_address);
		else sprintf (ip, "%-25s", puser->name);
        strcat (cp, ip);
        cp += strlen (ip);
    }

    va_start(arg, str);
    vsnprintf(cp, (size_t) 4095u - strlen (buffer), str, arg);
    va_end(arg);

    if (g_log_file_handle != 0) fprintf (g_log_file_handle, "%s\r\n", buffer);

	if (g_print_to_stdout && (type >= config.display_log || g_debug_mode)) {
	    if (config.ansi) {
			switch (type) {
			case LDEBUG:  printf ("\e[1;30m%s\e[0m\n", buffer); break;
			case LNOTE:  printf ("\e[0;37m%s\e[0m\n", buffer); break;
			case LWARNING:  printf ("\e[1;37m%s\e[0m\n", buffer); break;
			case LERROR:  printf ("\e[1;31m%s\e[0m\n", buffer); break;
			default:
			printf ("\e[0;37m%s\e[0m\n", buffer); break;
			}
		} else {
            printf ("%s\n", buffer);
		}
	}
	
	if (send_chat && puser != NULL) user_message (puser, MSYSTEM, "%s", buffer);
}
