/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/

#include "global.h"
/*
	How this works:
	
	Each command is its own function (except help).
	These functions take a standard set of parameters, and are referenced
	by the command_list structure at the bottom of the file.

	When command_proc is called, it looks through the structure array for
	the given command, and then calls it via a function pointer provided
	by command_list.
	
	By using command_list, it is possible both display all valid commands,
	and also (possibly) validate that given commands are actually 
	supported by the server (Without maintaining two or more lists).
	
	To add a command, first make a function, then add it to the list.
	Example: (function)
        
		int command_idiot (struct user *puser, char *command, char *parameters) {
			// Return if the command isn't allowed for the users' rank
			if (!command_rank_test (puser, command)) return (0); 

    		user_message_broadcast (NULL, "%s is an idiot.", parameters);
			return (1);
		}

	Example: (add to list)
		{"idiot", command_idiot},

	..And you're done.
	
	The functions must be before the list itself.  Otherwise, you will
	need to stick a function prototype somewhere.

	You can also call these command functions from other places in the code, 
	provided you are okay with using sprintf to build a string, only to
	have it parsed out again.  
	Since most of the server management stuff is here anyway, I suppose you 
	could rely on this is as some sort of standardized ...thingie.

	Side note: If you add a command, don't forget to update the available 
	commands per rank (defined in commands in config.txt) so that the right
    people can use it.
*/

typedef struct tagCOMMAND_LIST {
	char name[64];
	int (* command_ptr)(struct user *, char *, char *);
} COMMAND_LIST;

static int parse_name_value (struct user *puser, char *parameters, char **o_name, char **o_value, char *fail) {
	char *value = NULL;
    int ret = 1;
	if (parameters == NULL) {
		if (fail != NULL) user_message (puser, MUSER | MERROR, "%s", fail);
        return (0);
	}
	value = strchr (parameters, ' ');
	if (value == NULL) {
		if (fail != NULL) user_message (puser, MUSER | MERROR, "%s", fail);
        ret = 0;
	} else {
	    *value = 0;
    	value ++;
    }
	if (o_name != NULL) *o_name = parameters;
	if (o_value != NULL) *o_value = value;
	return (ret);
}

static int command_rank_test (struct user *puser, char *command) {
	if (!rank_command_allowed (puser->rank, command)) {
		user_message (puser, MUSER | MERROR, "%s?  I don't know that one.",  command);
		return (0);
	}    
	return (1);
}
	
int command_tp (struct user *puser, char *command, char *parameters) {
    if (puser == &user[0]) {user_message (puser, MNULL, "This command is useless for console"); return (0); }
	if (!command_rank_test (puser, command)) return (0);
//	menu_tabs (puser, MENU_CREATE);

    struct user *duser = user_connected_find_by_name (parameters);
    if (duser == NULL) {
        user_message (puser, MUSER | MERROR, "%s?  I don't know who that is", parameters);
    } else {
        if (user_is_ignored (duser, puser->uid)) {
            user_message (puser, MUSER | MERROR, "%s is ignoring you.", duser->name);
        } else {
            puser->position = duser->position;
            user_spawn (puser, puser->position);
        }
    }


	return (1);
}
	
/*int command_paint (struct user *puser, char *command, char *parameters) {
    if (puser == &user[0]) {user_message (puser, MNULL, "This command is useless for console"); return (0); }
	if (!command_rank_test (puser, command)) return (0);
    user_message (puser, MNULL, "Place a block to paint, delete a block to cancel");
    puser->paint = 1;
	return (1);
}*/

int command_fly (struct user *puser, char *command, char *parameters) {
    if (puser == &user[0]) {user_message (puser, MNULL, "This command is useless for console"); return (0); }
	if (!command_rank_test (puser, command)) return (0);
	user_message (puser, MNULL, "|1Press |aZ|1 to fly.  Press |aZ|1 again to stop flying.  While flying, you can use |aQ|1 and |aE|1 to go up and down.");
	return (1);
}

int command_box (struct user *puser, char *command, char *parameters) {
    if (puser == &user[0]) {user_message (puser, MNULL, "This command is useless for console"); return (0); }
	if (!command_rank_test (puser, command)) return (0);
	user_message (puser, MNULL, "|3Click and hold the mouse button down on the start block.  Continue dragging until you have selected the area you want, and release the mouse button.");
	return (1);
}

int command_color (struct user *puser, char *command, char *parameters) {
    if (puser == &user[0]) {user_message (puser, MNULL, "This command is useless for console"); return (0); }
	if (!command_rank_test (puser, command)) return (0);
	user_message (puser, MNULL, "The color prefix is '||'");
	user_message (puser, MNULL, "Colors are |11|22|33|44|55|66|77|88|99|00|aa|bb|cc|dd|ee|ff");
	user_message (puser, MNULL, "|9Example: ||4Colors ||5are ||6FUN||9!  Becomes |4Colors |5are |6FUN|9!");
	return (1);
}

int command_he (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);

	if (parameters == NULL) {
        user_message (puser, MUSER, "No message to send!");
        return (0);
    }
    user_message_broadcast (puser, MUSER, "\e\x03Player \e%c%s\e\x03 %s", puser->color, puser->name, parameters);
	return (1);
}

int command_who (struct user *puser, char *command, char *parameters) {
    if (puser == &user[0]) {user_message (puser, MNULL, "This command is useless for console"); return (0); }
	if (!command_rank_test (puser, command)) return (0);
	
    if (!puser->map->map_journal) {
        user_message (puser, MSYSTEM, "Map journaling is disabled; who not available.");
    } else {
        puser->who = !puser->who;
        if (puser->who) {
            user_message (puser, MUSER, "Who enabled.");
            fflush (puser->map->fn_journal); 
            #ifdef LINUX
            fdatasync (fileno (puser->map->fn_journal));
            #endif
        }
        else user_message (puser, MUSER, "Who disabled.");
    }
	return (1);
}

int command_all (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	if (parameters == NULL) {
        user_message (puser, MUSER, "No message to send!");
        return (0);
    }

	user_message_broadcast (NULL, MUSER, "<<broadcast>> %s: %s", puser->name, parameters);
	return (1);
}

int command_ban (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	int id = 0;
	char *name, *reason;
	if (!parse_name_value (puser, parameters, &name, &reason, "usage: ban <name> reason ...")) return (0);

    if (user_id_by_name (puser->map, name, &id)) {
        user_ban (puser, id, reason);
    } else user_message (puser, MUSER, "%s does not appear to be a user; did you spell it correctly?", name); 
	return (1);
}

int command_ipban (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	int id = 0;
	char *name, *reason;
	if (!parse_name_value (puser, parameters, &name, &reason, "usage: ipban <name> reason ...")) return (0);
    if (user_id_by_name (puser->map, name, &id)) {
        user_ipban (puser, id, reason);
    } else user_message (puser, MUSER, "%s does not appear to be a user; did you spell it correctly?", name); 

	return (1);
}        

int command_kick (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	int id = 0;
	char *name, *reason;
	if (!parse_name_value (puser, parameters, &name, &reason, "usage: kick <name> reason ...")) return (0);
    if (user_id_by_name (puser->map, name, &id)) {
        user_kick (puser, id, reason);
    } else user_message (puser, MUSER, "%s does not appear to be a user; did you spell it correctly?", name); 
	return (1);
}        

int command_shutdown (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	char *type, *parsed_parameters;
	if (!parse_name_value (puser, parameters, &type, &parsed_parameters, "usage: shutdown <shutdown||restart> message ...")) return (0);
    command_server_shutdown (puser, type, parsed_parameters);        
	return (1);
}
	
int command_rank (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
    int id = 0;
	char *name, *parsed_parameters;
	if (!parse_name_value (puser, parameters, &name, &parsed_parameters, "usage: rank <name> <rank name>")) return (0);

    int rank_id =  rank_id_by_name (parsed_parameters);
    if (rank_id < 0) {
        user_message (puser, MUSER, "rank %s does not exist", parsed_parameters); 
        return (0);
    }

    if (user_id_by_name (puser->map, name, &id)) {
        user_rank_change (puser, id, rank_id);
    } else user_message (puser, MUSER, "%s does not appear to be a user; did you spell it correctly?", name); 
	return (1);
}

int command_rank_show (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
    
    user_message (puser, MUSER, "Your rank is %s", puser->rank->name); 
	return (1);
}
      
      
int command_unban (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	
	if (parameters == NULL) {
		user_message (puser, MUSER, "usage: unban <name>");
		return (0);
	}

    int uid;
    if (!user_id_by_name (puser->map, parameters, &uid)) {
        user_message (puser, MUSER, "%s does not appear to be a user; did you spell it correctly?", parameters);
        return (0);
    }
    struct user muser;
    muser.map = puser->map;
    if (!user_record_load (&muser, uid)) {
        user_message (puser, MSYSTEM | MERROR, "%s's record is missing.  I smell a conspiracy!", parameters);
        return (0);
    }

    if (muser.banned) {
        user_message (puser, MUSER, "%s has been unbanned", parameters);
        muser.banned = 0;
        user_record_save (&muser, uid);
    } else {
        user_message (puser, MUSER, "%s is not banned.", parameters);
    }

	return (1);
}

int command_server (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
    user_message (puser, MSYSTEM, "MME Map Server, build #%i", build_version);    
    user_message (puser, MSYSTEM, "Map (%s) Dimensions: %ix%ix%i", puser->map->file, puser->map->dimension.x, puser->map->dimension.y, puser->map->dimension.z);
    user_message (puser, MSYSTEM, "Map scale is %02.02f", puser->map->scale);
	return (1);
}

int command_lag (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	user_message (puser, MSYSTEM, "Peak lag: %f", g_lag_max);
	return (1);
}

int command_sphere (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	char *args[8];
	int num = csv_parse (parameters, ' ', args, 8);
    if (num != 5) {user_message (puser, MUSER, "usage: sphere x y z radius block"); return (0);}
    map_draw_sphere (puser, atoi (args[0]), atoi (args[1]), atoi (args[2]), atoi (args[3]), atoi (args[4]));
    user_message (puser, MUSER, "Drawing sphere");
	return (1);
}


int command_circle (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	char *args[8];
	int num = csv_parse (parameters, ' ', args, 8);
                
    if (num != 5) {user_message (puser, MUSER, "usage: circle x y z radius block"); return (0);}
	printf ("%s %s %s %s %s\n", args[0], args[1], args[2], args[3], args[4]);

    map_draw_circle (puser, atoi (args[0]), atoi (args[1]), atoi (args[2]), atoi (args[3]), atoi (args[4]));
    user_message (puser, MUSER, "Drawing circle");

	return (1);
}


int command_join (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);

    if (parameters == NULL) {user_message (puser, MUSER, "usage: join mapname"); return (0);}
    user_map_switch (puser, parameters);
	return (1);
}

int command_map_unload (struct user *puser, char *command, char *str) {
	if (!command_rank_test (puser, command)) return (0);
	
	if (map_count_active() <= 1) {
		user_message (puser,MUSER,  "I can't unload the only loaded map.");
		return (0);
	}
	struct map *pmap = map_struct_find_by_name (str);
	if (pmap == NULL) pmap = map_struct_find_by_filename (str);

	if (pmap != NULL) map_unload (pmap);
	else {
		user_message (puser, MUSER, "There is no map loaded with the filename [%s].", str);
		return (0);
	}
	return (1);
}


int command_map_load (struct user *puser, char *command, char *str) {
	if (!command_rank_test (puser, command)) return (0);	
	struct map *pmap = map_struct_find_by_filename (str);
	if (pmap == NULL) pmap = map_struct_find_empty ();
	if (pmap != NULL) {
		pmap->area_map = 0;	
		map_load_file (pmap, str);
	}
	
	if (pmap == NULL) {
		user_message (puser,MUSER,  "Map [%s] could not be loaded.", str);
		return (0);
	}
	return (1);
}

int command_map_load_area (struct user *puser, char *command, char *str) {
	if (!command_rank_test (puser, command)) return (0);	
	
	char path[PATH_MAX];
	snprintf (path, PATH_MAX, "%s/%s/properties", PATH_AREAS, str);

    if (access (path, F_OK) == -1) {
        user_message (puser,MUSER,  "Load map: Can't load %s; it doesn't exist.", path);
        return (0);
    }

	struct map *pmap = map_struct_find_by_filename (str);
	if (pmap == NULL) pmap = map_struct_find_empty ();
	if (pmap != NULL) {
		pmap->area_map = 1;
		map_load_file (pmap, str);
	}
	
	if (pmap == NULL) {
		user_message (puser,MUSER,  "Map [%s] could not be loaded.", str);
		return (0);
	}
	return (1);
}

int command_reload_ranks (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	
    rank_initialize();

    int a;
    for (a = 1; a < NUM_USERS; a++) {
        if (user[a].current_mode == USER_DISCONNECT || user[a].current_mode == USER_NOT_CONNECTED) continue;
        user[a].rank = rank_find_struct_by_name (user[a].rank_name);    
    }
    user_message (puser, MSYSTEM, "Ranks have been reloaded and applied.");
	return (1);
}

int command_list_maps (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
    int a;
	int maps = 0;

    for (a = 0; a < NUM_MAPS; a++) {
        if (!map_array[a].active) continue;
        user_message (puser, MNULL, "Map: %s", map_array[a].file);
		maps++;
    }
	
	if (maps == 0) user_message (puser, MSYSTEM, "There are no maps available.");

    return (1);
}

int command_reload (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
    
    
    map_server_initialize (1);
    int a;   
    for (a = 1; a < NUM_USERS; a++) {
        if (user[a].current_mode == USER_DISCONNECT || user[a].current_mode == USER_NOT_CONNECTED) continue;
        user[a].rank = rank_find_struct_by_name (user[a].rank_name);    
    }
    user_message (puser, MSYSTEM, "Ranks have been reloaded and applied.");

    for (a = 1; a < NUM_USERS; a++) {
        if (user[a].current_mode == USER_NOT_CONNECTED || user[a].current_mode == USER_DISCONNECT) continue;
    	texture_send_texture_info (&user[a]);
    	texture_send_block_groups (&user[a]);
    	texture_send_blocks (&user[a]);

		user[a].skin_id = skin_texture_find_id_by_name (puser->map->palette, user[a].skin_name);
		if (user[a].skin_id == -1) user[a].skin_name[0] = 0;
		if (user[a].skin_name[0] != 0) packet_broadcast (NULL, USER_CONNECTED, &user[a], PACKET_PLAYER_PROPERTIES, user[a].idx, user[a].skin_id);    			


	}
    user_message_broadcast (NULL, MSYSTEM,  "Textures, blocks, and skins have been reloaded.");	
	
	return (1);
}

int command_server_shutdown (struct user *puser, char *type, char *str) {
	if (!command_rank_test (puser, str)) return (0);
	
    if (str[0] == 0 || (strcmp (type, "shutdown") != 0 && strcmp (type, "restart") != 0 && strcmp (type, "cancel") != 0)) {
        user_message (puser, MUSER, "/shutdown <shudown||restart> <seconds> [message]");
        return (0);
    }
	if (strcmp (type, "cancel") == 0) {
		g_server_shutdown_timeout = -1;
		user_message_broadcast (NULL, MUSER, "%s has been canceled.", g_shutdown_type);
		
	} else {
		strcpy (g_shutdown_type, type);

		strim ("lr", str);
		char *cp = strchr (str, ' ');
		if (cp != NULL) {
			*cp = 0;
			cp++;
			strim ("l", cp);
			_strncpy (g_shutdown_message, cp, 256);
		}


		time (&g_server_shutdown_timeout);
		g_server_shutdown_timeout += atoi (str);
	}
	return (1);
}

int command_palette_load (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	if (parameters == NULL) {
		user_message (puser, MUSER, "usage: palette_load path");
		return (0);
	}
	
	struct palette *p = texture_find_palette_struct_by_name (parameters);
	
	if (p == NULL) p = texture_find_palette_empty ();
	if (p == NULL) {
		log_printf (puser, LERROR, "No space for more block palettes.");
		return (0);
	}

//    _strncpy (p->path, parameters, 256);
	
	block_initialize (p, parameters);
	return (1);
}

int command_map_create (struct user *puser, char *command, char *parameters) {
	char *args[32];
	int num = csv_parse (parameters, ' ', args, 32);

    struct map *pmap = map_struct_find_empty ();
    if (pmap == NULL) {
        log_printf (puser, LWARNING, "Map table is full.  Please unload a map first.");
        return (0);
    }
	if (num < 1) {
		user_message (puser, MUSER, "usage: /map_create <--dimensions XxYxZxSEALEVEL> <--filename filename>\
		[--scale [0.1-1.0]] [--default_rank_name name]  [--block_palette_name name]\
		[--map_journal [0||1]] [--dirt name] [--grass name] [--area_map <0|1>]");
		return (0);
	}
	int a;
	int first_block_palette = -1;
	for (a = 0; a < NUM_PALETTES; a++) {
		if (block_palette[a].active) break;
	}
	if (a == NUM_PALETTES) {
		user_message (puser, MUSER, "map_create: No block palettes are defined; map not created.");
		return (0);
	}
	first_block_palette = a;
	
    int dirt = texture_block_by_description (&block_palette[first_block_palette], "dirt");
    int grass = texture_block_by_description (&block_palette[first_block_palette], "grass");
	int sidewalk = texture_block_by_description (&block_palette[first_block_palette], "sidewalk");
	
	pmap->file[0] = 0;
	strcpy (pmap->build_rank_name, "guest");
	strcpy (pmap->block_palette_name, block_palette[first_block_palette].path);
 	pmap->scale = 0.1f;
	pmap->map_journal = 0;
	pmap->sealevel = 64;
	pmap->dimension.x = 1536;
	pmap->dimension.y = 1536;
	pmap->dimension.z = 192; 
	pmap->spawn.x = 768;
	pmap->spawn.y = 768;
	pmap->spawn.z = 100;
	pmap->area_map = 0;
	pmap->dirt_block = dirt;
	pmap->grass_block = grass;
	pmap->border_block = sidewalk;	
	
	pmap->area_num_x = 5;
	pmap->area_num_y = 5;
	pmap->area_border_size = 8;
	pmap->area_x = 400;
	pmap->area_y = 400;

	for (a = 0; a < num; a++) {
		if (args[a][0] == '-' && args[a][1] == '-' && a < num) {
			char *parameter = &args[a][2];
			char *value = args[a + 1];
			a++;
			
			if (strcasecmp (parameter, "filename") == 0) _strncpy (pmap->file, value, 32);
            else if (strcasecmp (parameter, "minimum_build_rank_name") == 0) _strncpy (pmap->build_rank_name, value, 32);
	        else if (strcasecmp (parameter, "area_map") == 0) pmap->area_map = config_logic_symbol (value);
            else if (strcasecmp (parameter, "block_palette_name") == 0) _strncpy (pmap->block_palette_name, value, 32);
            else if (strcasecmp (parameter, "scale") == 0) {
				float scale = atof (value);
				if (scale < 0.1) {
					log_printf (NULL, LWARNING, "command_map_create: map scale must be at least 0.1.  Defaulting to 0.1");
					scale = 0.1;
				}
				if (scale > 1.0) {
					log_printf (NULL, LWARNING, "command_map_create: map scale must be at no greater than 1.0.  Defaulting to 1.0");
					scale = 1.0;
				}
				pmap->scale = scale;
            }
            else if (strcasecmp (parameter, "map_journal") == 0) pmap->map_journal = config_logic_symbol (value);
			else if (strcasecmp (parameter, "dimensions") == 0) {
				char *args[5];
				csv_parse (value, 'x', args, 5);
				pmap->dimension.x = atoi (args[0]);
				pmap->dimension.y = atoi (args[1]);
				pmap->dimension.z = atoi (args[2]);				
				pmap->sealevel = atoi (args[3]);
			} else if (strcasecmp (parameter, "dirt") == 0) {
				int t = texture_block_by_description (&block_palette[first_block_palette], value);
				if (t <= 0) {
					user_message (puser, MUSER, "map_create (--dirt): \"%s\" does not exist in the palette.", value);					
					return (0);					
				}	
				dirt = t;
			} else if (strcasecmp (parameter, "grass") == 0) {
				int t = texture_block_by_description (&block_palette[first_block_palette], value);
				if (t <= 0) {
					user_message (puser, MUSER, "map_create (--grass) \"%s\" does not exist in the palette.", value);					
					return (0);					
				}	
				grass = t;
			} else if (strcasecmp (parameter, "border") == 0) {
				int t = texture_block_by_description (&block_palette[first_block_palette], value);
				if (t <= 0) {
					user_message (puser, MUSER, "map_create (--border) \"%s\" does not exist in the palette.", value);					
					return (0);					
				}	
				sidewalk = t;
			} else if (strcasecmp (parameter, "area_num_x") == 0) pmap->area_num_x = atoi (value);
			else if (strcasecmp (parameter, "area_num_y") == 0) pmap->area_num_y = atoi (value);
			else if (strcasecmp (parameter, "area_border_size") == 0) pmap->area_border_size = atoi (value);
			else if (strcasecmp (parameter, "area_x") == 0) pmap->area_x = atoi (value);
			else if (strcasecmp (parameter, "area_y") == 0) pmap->area_y = atoi (value);

		}
	}
	if (pmap->file[0] == 0) {
		user_message (puser, MUSER, "map_create requires --filename <name> to be specified.");
		return (0);
	}
	char path[PATH_MAX];
	if (pmap->area_map) {
		snprintf (path, PATH_MAX, "%s/%s",  PATH_AREAS, pmap->file);
	    easy_mkdir (path);    
		
		snprintf (path, PATH_MAX, "%s/%s/properties", PATH_AREAS, pmap->file);
		if (access (path, F_OK) == 0) {
			user_message (puser, MUSER, "Map file already exists.  Choose a different name.", path);
			pmap->file[0] = 0;
			return (0);
		}
		int dx = (pmap->area_border_size * pmap->area_num_x) + pmap->area_border_size + (pmap->area_num_x * pmap->area_x);
		int dy = (pmap->area_border_size * pmap->area_num_y) + pmap->area_border_size + (pmap->area_num_y * pmap->area_y);
		
	    dx /= 32; dx *= 32;
	    dy /= 32; dy *= 32;
		pmap->dimension.x = dx;
		pmap->dimension.y = dy;
		pmap->dimension.z /= 32; pmap->dimension.z *= 32;
		pmap->area_num_total = pmap->area_num_x * pmap->area_num_y;
		map_save (pmap);
	} else {
		snprintf (path, PATH_MAX, "%s/%s", PATH_MAPS, pmap->file);
		if (access (path, F_OK) == 0) {
			user_message (puser, MUSER, "Map file already exists.  Choose a different name.", path);
			pmap->file[0] = 0;
			return (0);
		}
    	map_generate (pmap, 255, dirt, grass);
	}
    map_save (pmap);
	user_message (puser, MUSER, "Map %s has been created.  Use /map_load \"%s\" to load it.", pmap->file, pmap->file);
	return (1);
}

void list_variables (struct user *puser) {
	user_message (puser, MUSER, "server.name %s\r\n", config.name);
	user_message (puser, MUSER, "server.external_address %s\r\n", config.external_address);
	user_message (puser, MUSER, "server.connection_limit %i\r\n", config.connection_limit);
	user_message (puser, MUSER, "server.connection_timeout %i\r\n", config.connection_timeout);
	user_message (puser, MUSER, "server.afk_timeout %i\r\n", config.afk_timeout);
	user_message (puser, MUSER, "server.minimum_client_version %i\r\n", config.minimum_client_version);
	user_message (puser, MUSER, "server.local_connections %i\r\n", config.local_connections);
	user_message (puser, MUSER, "server.announce_disabled %i\r\n", config.announce_disabled);
	user_message (puser, MUSER, "server.ansi %i\r\n", config.ansi);
	user_message (puser, MUSER, "server.pause_exit %i\r\n", config.pause_exit);
	
	int a;
	for (a = 0; a < NUM_RANKS; a++) {
		if (rank[a].name[0] == 0) continue;
		if (strcasecmp (rank[a].name, "owner") == 0) continue;
		if (strlen (rank[a].promote_to) > 0) user_message (puser, MUSER, "rank.%s.promote_to %s\r\n", rank[a].name, rank[a].promote_to);
		user_message (puser, MUSER, "rank.%s.can_chat %i\r\n", rank[a].name, rank[a].can_chat);
		user_message (puser, MUSER, "rank.%s.can_build %i\r\n", rank[a].name, rank[a].can_chat);
		user_message (puser, MUSER, "rank.%s.can_fly %i\r\n", rank[a].name, rank[a].can_fly);
		user_message (puser, MUSER, "rank.%s.can_sonic_fly %i\r\n", rank[a].name, rank[a].can_sonic_fly);
		user_message (puser, MUSER, "rank.%s.can_noclip %i\r\n", rank[a].name, rank[a].can_noclip);
		if (rank[a].color < 48) rank[a].color = 48;
		user_message (puser, MUSER, "rank.%s.color %c\r\n", rank[a].name, rank[a].color);
        char dump[4096];
        sprintf (dump, "rank.%s.allowed_commands ", rank[a].name);
		for (int b = 0; b < 256; b++) {
			if (rank[a].allowed_commands[b] != NULL) { 
                strcat (dump, rank[a].allowed_commands[b]);
                strcat (dump, ", ");
			}
		}
        user_message (puser, MUSER, dump);

        sprintf (dump, "rank.%s.allowed_menus ", rank[a].name);
		for (int b = 0; b < 256; b++) {
			if (rank[a].allowed_commands[b] != NULL) { 
                strcat (dump, rank[a].allowed_menus[b]);
                strcat (dump, ", ");
			}
		}
        user_message (puser, MUSER, dump);
	}
}

char * variable_get_value (struct user *puser, char *in, char *out, int out_length) {
    char command[256];
    int a;
    _strncpy (command, in, 256);

	char *parsed_command;
	parsed_command = strchr (command, '.');
	if (parsed_command != NULL) {
		*parsed_command = 0;
		parsed_command = parsed_command + 1;
	} else parsed_command = command;

	if (strcasecmp (command, "server") == 0) {
    	if (strcasecmp (parsed_command, "external_address") == 0) _strncpy (out, config.external_address, out_length);
    	else if (strcasecmp (parsed_command, "name") == 0) _strncpy (out,  config.name, out_length);
    	else if (strcasecmp (parsed_command, "connection_limit") == 0) snprintf (out, out_length, "%i", config.connection_limit);
    	else if (strcasecmp (parsed_command, "connection_timeout") == 0) snprintf (out, out_length, "%i",config.connection_timeout);
    	else if (strcasecmp (parsed_command, "restart_deadtime") == 0) snprintf (out, out_length, "%i",config.restart_dead_time);
    	else if (strcasecmp (parsed_command, "local_connections") == 0) snprintf (out, out_length, "%i",config.local_connections);
    	else if (strcasecmp (parsed_command, "announce_disabled") == 0) snprintf (out, out_length, "%i",config.announce_disabled);
    	else if (strcasecmp (parsed_command, "default_rank_name") == 0) _strncpy (out, config.default_rank_name, out_length);
    	else if (strcasecmp (parsed_command, "minimum_client_version") == 0) snprintf (out, out_length, "%i",config.minimum_client_version);
    	else if (strcasecmp (parsed_command, "online") == 0) snprintf (out, out_length, "%i", config.online);
    	else if (strcasecmp (parsed_command, "ansi") == 0) snprintf (out, out_length, "%i",config.ansi);
    	else if (strcasecmp (parsed_command, "pause_exit") == 0) snprintf (out, out_length, "%i",config.pause_exit);
    	else if (strcasecmp (parsed_command, "debug_mode") == 0) snprintf (out, out_length, "%i",g_debug_mode);
        else return (NULL);
	} else if (strcasecmp (command, "console") == 0) {
		if (strcasecmp (parsed_command, "nick") == 0) _strncpy (out, user[0].nick, out_length);
	} else if (strcasecmp (command, "map") == 0) {
		char * variable = strrchr (parsed_command, '.');
		if (variable != NULL) {
			*variable = 0;
			variable++;
		} else {
			user_message (puser, MUSER, "Map variables require the following format: map.the_map_name.the_variable");
			return (NULL);
		}
		struct map *pmap = map_struct_find_by_name (parsed_command);
		if (pmap == NULL) {
			user_message (puser, MUSER, "There is no map called '%s' loaded.", parsed_command);
			return (NULL);
		}
        else if (strcasecmp (variable, "minimum_build_rank_name") == 0) _strncpy (out, pmap->build_rank_name,out_length);
        else if (strcasecmp (variable, "map_journal") == 0) snprintf (out, out_length, "%i",pmap->map_journal);
        else if (strcasecmp (variable, "area_map") == 0) snprintf (out, out_length, "%i",pmap->area_map);
        else if (strcasecmp (variable, "block_palette_name") == 0) _strncpy (out, pmap->block_palette_name, out_length);
        else if (strcasecmp (variable, "spawn_x") == 0) snprintf (out, out_length, "%g", pmap->spawn.x);
        else if (strcasecmp (variable, "spawn_y") == 0) snprintf (out, out_length, "%g", pmap->spawn.y);
        else if (strcasecmp (variable, "spawn_z") == 0) snprintf (out, out_length, "%g", pmap->spawn.z);
        else if (strcasecmp (variable, "spawn_u") == 0) snprintf (out, out_length, "%g", pmap->spawn.u);
        else if (strcasecmp (variable, "spawn_v") == 0) snprintf (out, out_length, "%g", pmap->spawn.v);
        else if (strcasecmp (variable, "scale") == 0) snprintf (out, out_length, "%g", pmap->scale);
        else if (strcasecmp (variable, "area_num_x") == 0) snprintf (out, out_length, "%i",pmap->area_num_x);
        else if (strcasecmp (variable, "area_num_y") == 0) snprintf (out, out_length, "%i",pmap->area_num_y);
        else if (strcasecmp (variable, "area_border_size") == 0) snprintf (out, out_length, "%i",pmap->area_border_size);
        else if (strcasecmp (variable, "area_x") == 0) snprintf (out, out_length, "%i",pmap->area_x);
        else if (strcasecmp (variable, "area_y") == 0) snprintf (out, out_length, "%i",pmap->area_y);
        else if (strcasecmp (variable, "violence") == 0) snprintf (out, out_length, "%i",pmap->violence);
        else if (strcasecmp (variable, "sealevel") == 0) snprintf (out, out_length, "%i",pmap->sealevel);
        else return (NULL);
	} else if (strcasecmp (command, "npc_type") == 0) {
		char * variable = strrchr (parsed_command, '.');
		if (variable != NULL) {
			*variable = 0;
			variable++;
		} else {
			user_message (puser, MUSER, "npc_type variables require the following format: npc_type.the_type.the_variable");
			return (NULL);
		}
		struct npc_type * pnpc = (void *)npc_find_type_struct_by_name (parsed_command);
		if (pnpc == NULL) {
			user_message (puser, MUSER, "There is no npc type called '%s'.", parsed_command);
			return (NULL);
		}
        if (strcasecmp (variable, "skin") == 0) _strncpy (out, pnpc->skin, out_length);
        else if (strcasecmp (variable, "speed") == 0) snprintf (out, out_length, "%g", pnpc->speed);
        else if (strcasecmp (variable, "hitpoints") == 0) snprintf (out, out_length, "%i",pnpc->hitpoints);
        else if (strcasecmp (variable, "defense") == 0) snprintf (out, out_length, "%i",pnpc->defense);
        else if (strcasecmp (variable, "strength") == 0) snprintf (out, out_length, "%i",pnpc->strength);
        else if (strcasecmp (variable, "thing_type") == 0) snprintf (out, out_length, "%i",pnpc->thing_type);
        else if (strcasecmp (variable, "attack_range") == 0) snprintf (out, out_length, "%i",pnpc->attack_range);
		else if (strcasecmp (variable, "attack_chance") == 0) snprintf (out, out_length, "%i",pnpc->attack_chance);

		else if (strcasecmp (variable, "sight") == 0) snprintf (out, out_length, "%i",pnpc->sight);
		else if (strcasecmp (variable, "decay") == 0) snprintf (out, out_length, "%g",pnpc->decay);
		else if (strcasecmp (variable, "randomness") == 0) snprintf (out, out_length, "%i",pnpc->randomness);
        else {
			user_message (puser, MUSER, "%s is not a valid npc type variable.", variable);
            return (NULL);
		}
	} else if (strcasecmp (command, "rank") == 0) {
		char * variable = strrchr (parsed_command, '.');
		if (variable != NULL) {
			*variable = 0;
			variable++;
		} else {
			user_message (puser, MUSER, "rank variables require the following format: rank.the_rank_name.the_variable");
			return (NULL);
		}
		struct rank *prank = rank_find_struct_by_name (parsed_command);
		if (prank == NULL) {
			user_message (puser, MUSER, "There is no rank called '%s'.", parsed_command);
			return (NULL);
		}
		else if (strcasecmp (variable, "can_fly") == 0) snprintf (out, out_length, "%i",prank->can_fly);
		else if (strcasecmp (variable, "can_sonic_fly") == 0) snprintf (out, out_length, "%i",prank->can_sonic_fly);
		else if (strcasecmp (variable, "can_chat") == 0) snprintf (out, out_length, "%i",prank->can_chat);
		else if (strcasecmp (variable, "can_build") == 0) snprintf (out, out_length, "%i",prank->can_build);
		else if (strcasecmp (variable, "can_noclip") == 0) snprintf (out, out_length, "%i",prank->can_noclip);
		else if (strcasecmp (variable, "cuboid_volume_limit_meters") == 0) snprintf (out, out_length, "%g",prank->cuboid_volume_limit_meters);
		else if (strcasecmp (variable, "cuboid_size_limit_meters") == 0) snprintf (out, out_length, "%g",prank->cuboid_size_limit_meters);
		else if (strcasecmp (variable, "color") == 0) snprintf (out, out_length, "%i",prank->color);
		else if (strcasecmp (variable, "promote_to") == 0) _strncpy (out, prank->promote_to, out_length);
        else if (strcasecmp (variable, "allowed_commands") == 0) {
            out[0] = 0;
            for (a = 0; a < 256; a++) {
                if (prank->allowed_commands[a] == NULL) continue;
                if (strlen (out) + (strlen (prank->allowed_commands[a]) + 4) < out_length - 1) {
                    strcat (out, prank->allowed_commands[a]);
                    strcat (out, ", ");
                }
            }
        } else if (strcasecmp (variable, "allowed_menus") == 0) {
            out[0] = 0;
            for (a = 0; a < 256; a++) {
                if (prank->allowed_menus[a] == NULL) continue;
                if (strlen (out) + (strlen (prank->allowed_menus[a]) + 4) < out_length - 1) {
                    strcat (out, prank->allowed_menus[a]);
                    strcat (out, ", ");
                }
            }
        } else {
			user_message (puser, MUSER, "%s is not a valid rank variable.", variable);
            return (NULL);
		}
	} else {
        return (NULL);
	}
	return ((char *) out);
}


int command_set (struct user *puser, char *ignored, char *parameters) {
	char *command = NULL, *arguments = NULL;
	parse_name_value (puser, parameters, &command, &arguments, NULL);

    if (command == NULL) {
        user_message (puser, MUSER, "usage: set <name> <value>");
        return (0);
    }
    if (arguments == NULL && command != NULL) {
        char data[4096];
        char *result = variable_get_value (puser, command, data, 4096);
        if (result == NULL) {
            user_message (puser, MUSER, "%s: unknown variable", command);
            return (0);
        }
        
        user_message (puser, MUSER, "%s %s", command, result);
        return (1);
    } else {
    	if (puser != &user[0]) log_printf (puser, LNOTE, "command_set: %s %s", command, arguments);
	}

	char *parsed_command;
	parsed_command = strchr (command, '.');
	if (parsed_command != NULL) {
		*parsed_command = 0;
		parsed_command = parsed_command + 1;
	} else parsed_command = command;
    
	if (strcasecmp (command, "server") == 0) {
    	if (strcasecmp (parsed_command, "external_address") == 0) {_strncpy (config.external_address, arguments, 256); g_force_announcement = 1;}
    	else if (strcasecmp (parsed_command, "name") == 0) {_strncpy (config.name, arguments, 64); g_force_announcement = 1;}
    	else if (strcasecmp (parsed_command, "connection_limit") == 0) {config.connection_limit = atoi (arguments);  g_force_announcement = 1;}
    	else if (strcasecmp (parsed_command, "connection_timeout") == 0) config.connection_timeout = atoi (arguments);        
    	else if (strcasecmp (parsed_command, "restart_deadtime") == 0) config.restart_dead_time = atoi (arguments);
    	else if (strcasecmp (parsed_command, "local_connections") == 0) config.local_connections = config_logic_symbol (arguments);
    	else if (strcasecmp (parsed_command, "announce_disabled") == 0) config.announce_disabled = config_logic_symbol (arguments);            
    	else if (strcasecmp (parsed_command, "default_rank_name") == 0) _strncpy (config.default_rank_name, arguments, 32);
    	else if (strcasecmp (parsed_command, "minimum_client_version") == 0) config.minimum_client_version = atoi (arguments);
    	else if (strcasecmp (parsed_command, "online") == 0) config_server_online (config_logic_symbol (arguments));
    	else if (strcasecmp (parsed_command, "ansi") == 0) config.ansi = config_logic_symbol (arguments);
    	else if (strcasecmp (parsed_command, "pause_exit") == 0) config.pause_exit = config_logic_symbol (arguments);
    	else if (strcasecmp (parsed_command, "debug_mode") == 0) g_debug_mode = config_logic_symbol (arguments);
    	else if (strcasecmp (parsed_command, "afk_timeout") == 0) config.afk_timeout = atoi (arguments);
    	else if (strcasecmp (parsed_command, "config_sync") == 0) config.config_sync = atoi (arguments);
        else if (strcasecmp (parsed_command, "?") == 0) {
			user_message (puser, MUSER, "server.name %s", config.name);
			user_message (puser, MUSER, "server.external_address %s", config.external_address);
			user_message (puser, MUSER, "server.connection_limit %i", config.connection_limit);
			user_message (puser, MUSER, "server.connection_timeout %i", config.connection_timeout);
			user_message (puser, MUSER, "server.restart_deadtime %i", config.restart_dead_time);
			user_message (puser, MUSER, "server.local_connections %i", config.local_connections);
			user_message (puser, MUSER, "server.announce_disabled %i", config.announce_disabled);
			user_message (puser, MUSER, "server.default_rank_name %s", config.default_rank_name);
			user_message (puser, MUSER, "server.minimum_client_version %i", config.minimum_client_version);
			user_message (puser, MUSER, "server.online %i", config.online);
			user_message (puser, MUSER, "server.ansi %i", config.ansi);
			user_message (puser, MUSER, "server.pause_exit %i", config.pause_exit);
			user_message (puser, MUSER, "server.debug_mode %i", g_debug_mode);
            user_message (puser, MUSER, "server.config_sync %i", config.config_sync);
		
		}
		else user_message (puser, MUSER, "The /set command server.[%s] is not valid", parsed_command);
	} else if (strcasecmp (command, "console") == 0) {
		if (strcasecmp (parsed_command, "nick") == 0) _strncpy (user[0].nick, arguments, 32);
	} else if (strcasecmp (command, "map") == 0) {
		int save_update = 1;
		char * variable = strrchr (parsed_command, '.');
		if (variable != NULL) {
			*variable = 0;
			variable++;
		} else {
			user_message (puser, MUSER, "The /set map requires a map name as well as the variable: /set map.something.something value");
			return (0);
		}
		struct map *pmap = map_struct_find_by_name (parsed_command);
		if (pmap == NULL) {
			user_message (puser, MUSER, "There is no map called '%s' loaded.", parsed_command);
			return (0);
		}
		
        else if (strcasecmp (variable, "minimum_build_rank_name") == 0) _strncpy (pmap->build_rank_name, arguments, 32);
        else if (strcasecmp (variable, "map_journal") == 0) pmap->map_journal = config_logic_symbol (arguments);
        else if (strcasecmp (variable, "area_map") == 0) pmap->area_map = config_logic_symbol (arguments);
        else if (strcasecmp (variable, "block_palette_name") == 0) _strncpy (pmap->block_palette_name, arguments, 32);
        else if (strcasecmp (variable, "spawn_x") == 0) pmap->spawn.x = atof (arguments);
        else if (strcasecmp (variable, "spawn_y") == 0) pmap->spawn.y = atof (arguments);
        else if (strcasecmp (variable, "spawn_z") == 0) pmap->spawn.z = atof (arguments);
        else if (strcasecmp (variable, "spawn_u") == 0) pmap->spawn.u = atof (arguments);
        else if (strcasecmp (variable, "spawn_v") == 0) pmap->spawn.v = atof (arguments);
        else if (strcasecmp (variable, "scale") == 0) {
			float scale = atof (arguments);
			if (scale < 0.1) {
				log_printf (NULL, LWARNING, "command_map_create: map scale must be at least 0.1.  Defaulting to 0.1");
				scale = 0.1;
			}
			if (scale > 1.0) {
				log_printf (NULL, LWARNING, "command_map_create: map scale must be at no greater than 1.0.  Defaulting to 1.0");
				scale = 1.0;
			}
			puser->map->scale = scale;
			
			int c;
			for (c = 1; c < NUM_USERS; c++) {
				if (user[c].current_mode != USER_CONNECTED) continue;
				if (user[c].map != pmap) continue;
		        packet_send (puser, PACKET_MAP_PROPERTIES, &user[c].map->scale, &user[c].map->scale);
				user_message (&user[c], MUSER, "Map scale has been changed.");
			}
        }
        else if (strcasecmp (variable, "violence") == 0) pmap->violence = config_logic_symbol (arguments);
        else if (strcasecmp (variable, "sealevel") == 0) pmap->sealevel = atoi (arguments);
        else {
			user_message (puser, MUSER, "%s is not a valid map variable.", variable);
			save_update = 0;
		}
		
		pmap->save_counter += save_update;
		
	} else if (strcasecmp (command, "npc_type") == 0) {
		char * variable = strrchr (parsed_command, '.');
		if (variable != NULL) {
			*variable = 0;
			variable++;
		} else {
			user_message (puser, MUSER, "The /set npc_type requires a npc type name as well as the variable: /set npc_type.something.something value");
			return (0);
		}
		struct npc_type * pnpc = (void *)npc_find_type_struct_by_name (parsed_command);
		if (pnpc == NULL) {
			user_message (puser, MUSER, "There is no npc type called '%s'.", parsed_command);
			return (0);
		}
        if (strcasecmp (variable, "skin") == 0) _strncpy (pnpc->skin, arguments, 32);
        else if (strcasecmp (variable, "speed") == 0) pnpc->speed = atof (arguments);
        else if (strcasecmp (variable, "hitpoints") == 0) pnpc->hitpoints = atoi (arguments);
        else if (strcasecmp (variable, "defense") == 0) pnpc->defense = atoi (arguments);
        else if (strcasecmp (variable, "strength") == 0) pnpc->strength = atoi (arguments);
        else if (strcasecmp (variable, "thing_type") == 0) pnpc->thing_type = atoi (arguments);		
        else if (strcasecmp (variable, "attack_range") == 0) pnpc->attack_range = atoi (arguments);
		else if (strcasecmp (variable, "attack_chance") == 0) pnpc->attack_chance = atoi (arguments);

		else if (strcasecmp (variable, "sight") == 0) pnpc->sight = atoi (arguments);
		else if (strcasecmp (variable, "decay") == 0) pnpc->decay = atof (arguments);
		else if (strcasecmp (variable, "randomness") == 0) pnpc->randomness = atoi (arguments);
        else {
			user_message (puser, MUSER, "%s is not a valid npc type variable.", variable);
		}
	} else if (strcasecmp (command, "rank") == 0) {
		char * variable = strrchr (parsed_command, '.');
		if (variable != NULL) {
			*variable = 0;
			variable++;
		} else {
			user_message (puser, MUSER, "The /set rank requires a rank name as well as the variable: /set rank.something.something value");
			return (0);
		}
		struct rank *prank = rank_find_struct_by_name (parsed_command);
		if (prank == NULL) {
			user_message (puser, MUSER, "There is no rank called '%s'.", parsed_command);
			return (0);
		}
		
		else if (strcasecmp (variable, "can_fly") == 0) prank->can_fly = config_logic_symbol (arguments);
		else if (strcasecmp (variable, "can_sonic_fly") == 0) prank->can_sonic_fly = config_logic_symbol (arguments);
		else if (strcasecmp (variable, "can_chat") == 0) prank->can_chat = config_logic_symbol (arguments);
		else if (strcasecmp (variable, "can_build") == 0) prank->can_build = config_logic_symbol (arguments);		
		else if (strcasecmp (variable, "can_noclip") == 0) prank->can_noclip = config_logic_symbol (arguments);
		else if (strcasecmp (variable, "color") == 0) prank->color = atoi (arguments) + 48;
		else if (strcasecmp (variable, "promote_to") == 0) _strncpy (prank->promote_to, arguments, 32);
   		else if (strcasecmp (variable, "cuboid_volume_limit_meters") == 0) prank->cuboid_volume_limit_meters = atof (arguments);
   		else if (strcasecmp (variable, "cuboid_size_limit_meters") == 0) prank->cuboid_size_limit_meters = atof (arguments);
		else if (strcasecmp (variable, "allowed_command_add") == 0) 
			rank_command_allowed_add (prank, arguments);
		else if (strcasecmp (variable, "allowed_command_remove") == 0) 
			rank_command_allowed_remove (prank, arguments);

		
        else if (strcasecmp (variable, "allowed_commands") == 0) {
            char *args[256];
            int num = csv_parse (arguments, ',', args, 255);
            int a = 0;
            for (a = 0; a < num; a++) {
                if (strlen (args[a]) < 1) continue;
                prank->allowed_commands[a] = _malloc (strlen (args[a] + 2));
                strcpy (prank->allowed_commands[a], args[a]);
            }
            prank->allowed_commands[a] = NULL;
        }
        else if (strcasecmp (variable, "allowed_menus") == 0) {
            char *args[256];
            int num = csv_parse (arguments, ',', args, 255);
            int a = 0;
            for (a = 0; a < num; a++) {
                if (strlen (args[a]) < 1) continue;
                prank->allowed_menus[a] = _malloc (strlen (args[a] + 2));
                strcpy (prank->allowed_menus[a], args[a]);
            }
            prank->allowed_menus[a] = NULL;
        } else {
			user_message (puser, MUSER, "%s is not a valid rank variable.", variable);
		}
	} else {
		user_message (puser,MUSER,  "The /set command [%s].[%s] is not valid", command, parsed_command);	
		return (0);
	}
	return (1);
}

int command_say (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	if (parameters == NULL) {
		user_message (puser,MUSER,  "usage: say message");
		if (puser == &user[0]) user_message (puser, MUSER,  "You can use \"/set console.nick somename \" to set the console's nickname.  Heh heh.");
		return (0);
	}
	user_message_chat (puser, parameters);
	return (1);
}

int command_map_sync (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	map_disk_sync(0);
	return (1);
}

int command_zombie (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	npc_add (puser->map, "zombie", (int) puser->position.x, (int) puser->position.y, (int) puser->position.z);
	return (1);
}

int command_afk (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
    user_afk_toggle (puser, parameters);
	return (1);
}

int command_npc_create_type (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	if (parameters == NULL || parameters[0] == 0) {
		user_message (puser, MUSER, "npc_create_type: You must provide a name for the type");
		return (0);
	}
	if (npc_find_type_by_name (parameters) != -1) {
		user_message (puser,MUSER,  "npc_create_type: npc type %s is already in use.", parameters);
		return (0);
	}
	int idx = npc_find_type_empty();
	if (idx == -1) {
		user_message (puser, MUSER, "npc_create_type: npc type table is full.");
		return (0);
	}
	
	_strncpy (npc_type[idx].name, parameters, 32);
	return (1);
}

int command_npc_spawn_type (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	int x, y, z;
	
	char *args[5];
	int num = csv_parse (parameters, ' ', args, 5);
	if (num < 2) {
		user_message (puser,MUSER,  "npc_spawn_type: usage: <map> <name> [x y z]");
		return (0);
	}
    struct map *pmap;
    if (strcmp (args[0], ".") == 0) pmap = puser->map;
    else pmap = map_struct_find_by_filename (args[0]);

    if (pmap == NULL) {
        log_printf (NULL, LWARNING, "npc_spawn_type: Map %s does not appear to be loaded.  Not spawning NPC", args[0]);
        return (0);
    }

	if (num == 5) {
		x = atoi (args[2]);
		y = atoi (args[3]);
		z = atoi (args[4]);
	} else {
		x = puser->position.x;
	    y = puser->position.y;
		z = puser->position.z;
	}
	npc_add (pmap, args[1], x, y, z);
	return (1);
}

int command_rank_create (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	if (parameters == NULL || parameters[0] == 0) {
		user_message (puser, MUSER, "rank_create: You must provide a name for the rank");
		return (0);
	}

	if (rank_find_struct_by_name (parameters) != NULL) {
		return (1);
	}
		
	int idx = rank_id_find_empty();
	if (idx == -1) {
		user_message (puser, MUSER, "rank_create: rank table is full.");
		return (0);
	}
	
	_strncpy (rank[idx].name, parameters, 32);
	return (1);
}

int command_replace_block (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	
	char *args[4];
	int num = csv_parse (parameters, ' ', args, 4);
	if (num != 2) {
		user_message (puser, MUSER, "npc_replace_block: usage: <old> <new>");
		return (0);
	}
	
	unsigned char old_block = atoi (args[0]);
	unsigned char new_block = atoi (args[1]);
	
	if (old_block == 0) {
		old_block = texture_block_by_description (puser->map->palette, args[0]);
		if (old_block == 0) {
			user_message (puser, MUSER, "replace_block: old: %s is not a known block name, or number.", args[0]);
			return (0);
		}
	}
	
	if (new_block == 0) {
		new_block = texture_block_by_description (puser->map->palette, args[1]);
		if (new_block == 0) {
			user_message (puser,MUSER,  "replace_block: new: %s is not a known block name, or number.", args[1]);
			return (0);
		}
	}
	user_message (puser, MUSER, "Replace: %i->%i", old_block, new_block);
	int change = 0;
	for (int z = 0; z < puser->map->dimension.z; z++) {
		for (int x = 0; x < puser->map->dimension.x; x++) {
			for (int y = 0; y < puser->map->dimension.y; y++) {
				
				if ((unsigned char)BLOCK (puser->map, x, y, z) == old_block) {
					map_block_change (puser->map, x, y, z, new_block, puser->idx);
					change++;
				}
			}
		}
	}
	user_message (puser, MUSER, "replace_block: %i blocks replaced.", change);

	return (1);
}

int command_map_undo (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	int seconds;
	if (parameters != NULL)	seconds = atoi (parameters);
	else seconds = 1;
	if (seconds < 1) seconds = 1;
	map_undo_undo (puser, seconds);
	return (1);
}


int command_map_region_save (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	
	char *args[8];
	int num = csv_parse (parameters, ' ', args, 8);
	if (num != 7) {
		user_message (puser,MUSER,  "map_region_save: usage: <filename> <fromX> <fromY> <fromZ> <toX> <toY> <toZ>");
		return (0);
	}
	int ret = map_region_save (puser->map, args[0], atoi (args[1]), atoi (args[2]), atoi (args[3]), atoi (args[4]), atoi (args[5]), atoi (args[6]));
	
	if (ret) user_message (puser,MUSER,  "map_region_save (%s) complete.", args[0]);
	else user_message (puser, MUSER, "map_region_save (%s) failed.", args[0]);
	return (ret);
}	
	
int command_map_region_load (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	
	char *args[8];
	int num = csv_parse (parameters, ' ', args, 8);
	if (num != 7) {
		user_message (puser,MUSER,  "map_region_load: usage: <filename> <fromX> <fromY> <fromZ> <toX> <toY> <toZ>");
		return (0);
	}
	
	int ret = map_region_load (puser->map, args[0], atoi (args[1]), atoi (args[2]), atoi (args[3]), atoi (args[4]), atoi (args[5]), atoi (args[6]));
	
	if (ret) user_message (puser, MUSER, "map_region_load (%s) complete.", args[0]);
	else user_message (puser, MUSER, "map_region_load (%s) failed.", args[0]);
	
	return (ret);
}

int command_lua_exterminate (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	
	lua_exterminate();
	return (1);
}

int command_quit (struct user *puser, char *command, char *parameters) {
	if (puser != &user[0]) return (0);
	kill_server	= 1;
	return (1);
}

int command_list_connections (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);

    int a;
    for (a = 1; a < NUM_USERS; a++) {
        if (user[a].current_mode == USER_NOT_CONNECTED) continue;
        char *c = "Undefined state!";
        if (user[a].current_mode == USER_AUTHENTICATE) c = "Authenticating";
        else if (user[a].current_mode == USER_CONNECTING) c = "Connecting";
        else if (user[a].current_mode == USER_CONNECTED) c = "Connected";
        else if (user[a].current_mode == USER_DISCONNECT) c = "Disconnecting";
        else if (user[a].current_mode == USER_NEW_MAP) c = "Switching Map";

        user_message (puser, MUSER, "%i: User #%i, %s: (%s)", a, user[a].uid, user[a].name, c);
    }
	return (1);
}

int command_config_save (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	
	config_save () ;
	return (1);
}

int command_list_ranks (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	int a;

    // Do not include the owner rank.
	for (a = 0; a < NUM_RANKS -1; a++) {
		if (rank[a].name[0] != 0) user_message (puser, MUSER, "%s", rank[a].name);
	}

	return (1);
}


int command_list_palettes (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	int a;
    int count = 0;
    
    for ( a = 0; a < NUM_PALETTES; a++) {
        if (block_palette[a].active) {
			count++;
			user_message (puser, MUSER, "%s", block_palette[a].path);
		}
    }
    return (count);
}
int command_lua_hookfile_list (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);

    lua_hookfile_list(puser);

	return (1);
}


int command_lua_load_hookfile (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	if (parameters == NULL || parameters[0] == 0) {
		user_message (puser, MUSER, "lua_load_hookfile: You must provide a filename to load");
		return (0);
	}

    lua_hookfile_load (parameters);

	return (1);
}

int command_lua_unload_hookfile (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	if (parameters == NULL || parameters[0] == 0) {
		user_message (puser, MUSER, "lua_unload_hookfile: You must provide a filename to unload");
		return (0);
	}

    if (!lua_hookfile_remove (parameters)) {
        user_message (puser, MUSER, "lua_unload_hookfile: hookfile may not be loaded.");
    }

	return (1);
}

int command_flow_kill (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);

	map_flow_kill();
	return (1);
}

int command_flow (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	user_message (puser, MUSER, "Place the block which you want to flow.  Destroy-click to cancel.");
	puser->flow_block = atoi (parameters);

	return (1);
}

int command_npc_exterminate (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
	user_message (puser, MUSER, "Eterminating all NPCs.");
	int a;
	for (a = 0; a < NUM_NPCS; a++) npc_remove (a);



	return (1);
}



int command_map_backup (struct user *puser, char *command, char *str) {
	if (!command_rank_test (puser, command)) return (0);	
	
	if (str == NULL) {
		char temp[256];
		strcpy (temp, puser->map->file);
		str = temp;
	}
	struct map *pmap = map_struct_find_by_filename (str);
	if (pmap == NULL) {
		user_message (puser, MUSER, "The map %s is not loaded.", str);
	}
	
	if (pmap->area_map) {
		user_message (puser, MUSER, "Area maps can't be backed up due to their not-really-a-map nature.", str);
		return (1);
	}
	
	map_disk_sync (1);
	
	char file_new[PATH_MAX];
	char file_current[PATH_MAX];
	
	time_t t; time (&t);
    snprintf (file_new, PATH_MAX, "%s/%s", PATH_MAPS, pmap->file);
	
	char *cp = strrchr (file_new, '.');
	if (cp != NULL) {
		*cp = 0;
	} else {
		cp = &file_new[strlen (file_new)];
	}
	sprintf (cp, "_backup_%ld.map", (long) t);
	
    snprintf (file_current, PATH_MAX, "%s/%s", PATH_MAPS, pmap->file);
	if (copy_file (file_current, file_new)) {
		user_message (puser, MUSER, "Map backup %s has been created.", file_new);
	} else {
		user_message (puser, MUSER, "Unable to back up map %s", file_current);
	}
	return (1);
}

int command_goto (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);
    char *args[3];
    int num = csv_parse (parameters, ',', args, 3);
    if (num != 3) {
        user_message (puser, MUSER, "goto: requires 3 parameters separated by a comma.");
    } else {
        int x = atoi (args[0]);
        int y = atoi (args[1]);
        int z = atoi (args[2]);
        if (x < 0) x = 0;
        if (y < 0) y = 0;
        if (z < 0) z = 0;        
        if (x >= puser->map->dimension.x) x = puser->map->dimension.x - 1;
        if (y >= puser->map->dimension.y) y = puser->map->dimension.y - 1;
        if (z >= puser->map->dimension.z) z = puser->map->dimension.z - 1;

        user_spawn (puser, ((struct float_xyzuv){x, y, z, 0, 0}));
    
    }

	return (1);
}

int command_summon (struct user *puser, char *command, char *parameters) {
    if (puser == &user[0]) {user_message (puser, MNULL, "This command is useless for console"); return (0); }
	if (!command_rank_test (puser, command)) return (0);
//	menu_tabs (puser, MENU_CREATE);

    struct user *duser = user_connected_find_by_name (parameters);
    if (duser == NULL) {
        user_message (puser, MUSER | MERROR, "%s?  I don't know who that is", parameters);
    } else {
        if (user_is_ignored (duser, puser->uid)) {
            user_message (puser, MUSER | MERROR, "%s is ignoring you.", duser->name);
        } else {
            duser->position = puser->position;
            user_spawn (duser, duser->position);
        }
    }


	return (1);
}	

int command_config_reload (struct user *puser, char *command, char *parameters) {
	if (!command_rank_test (puser, command)) return (0);

	if (!console_exec_file ("config.txt")) {
        console_exec_file ("config.old");
        user_message (puser, MSYSTEM | MERROR, "console_exec_file: config.txt could not be opened.");
    }


	return (1);
}	


int command_up (struct user *puser, char *command, char *parameters) {
    if (puser == &user[0]) {user_message (puser, MNULL, "This command is useless for console"); return (0); }
	if (!command_rank_test (puser, command)) return (0);

    puser->position.z = puser->map->dimension.z;
    user_spawn (puser, puser->position);

	return (1);
}


static COMMAND_LIST command_list[] = {
	{"tp", command_tp},
	{"fly", command_fly},
	{"box", command_box},
	{"cuboid", command_box},
	{"z", command_box},		
	{"color", command_color},
	{"he", command_he},
	{"she", command_he},
	{"me", command_he},
	{"it", command_he},
	{"who", command_who},
	{"all", command_all},
	{"ban", command_ban},
	{"kick", command_kick},
	{"unban", command_unban},
	{"ipban", command_ipban},
	{"shutdown", command_shutdown},
	{"rank", command_rank},
	{"server", command_server},
	{"lag", command_lag},	
	{"sphere", command_sphere},	
	{"circle", command_circle},	
	{"join", command_join},	
	{"list_maps", command_list_maps},	
	{"reload", command_reload},	
	{"set", command_set},	
	{"map_create", command_map_create},
	{"map_load", command_map_load},
	{"map_unload", command_map_unload},
	{"say", command_say},	
	{"palette_load", command_palette_load},		
	{"map_load_area", command_map_load_area},			
	{"map_sync", command_map_sync},
	{"afk", command_afk},
	{"rank_create", command_rank_create},
	{"npc_create_type", command_npc_create_type},
	{"npc_spawn_type", command_npc_spawn_type},
	{"undo", command_map_undo},
	{"replace_block", command_replace_block},	
	{"map_region_save", command_map_region_save},		
	{"map_region_load", command_map_region_load},
	{"lua_exterminate", command_lua_exterminate},
	{"quit", command_quit},
	{"list_connections", command_list_connections},
	{"config_save", command_config_save},
	{"list_ranks", command_list_ranks},
	{"lua_load_hookfile", command_lua_load_hookfile},
	{"lua_unload_hookfile", command_lua_unload_hookfile},
	{"list_palettes", command_list_palettes},	
	{"flow_kill", command_flow_kill},		
	{"map_backup", command_map_backup},			
	{"flow_block", command_flow},				
	{"npc_exterminate", command_npc_exterminate},
	{"rank_show", command_rank_show},    
    {"goto", command_goto},    
    {"summon", command_summon},
    {"up", command_up},
    {"config_reload", command_config_reload},
//    {"paint", command_paint},
	//New crap goes here..
	//...
	
	{{0, 0}} // Terminator: Add stuff before this.
};

int command_proc (struct user *puser, char *cmd) {
	char command[4096];
	char *meat = strchr (cmd, ' ');
	if (meat != NULL) meat++;
	
	int length;
	if (meat != NULL) length = meat - cmd;
	else length = strlen (cmd) + 1;

	if (length > 63) length = 63;
	_strncpy (command, cmd, length);

    if (lua_hook_call ("mme_user_command", puser, command, meat)) return (1);
	
	if (strcasecmp (command, "help") == 0 && meat == NULL) {
		COMMAND_LIST *list = command_list;
		command[0] = 0;
		char *cp = command;
		while (list->name != 0 && list->command_ptr != 0) {
			if (rank_command_allowed (puser->rank, list->name)) {
				strcpy (cp, list->name);
				cp += (size_t) strlen (list->name);
				strcpy (cp, ", ");
				cp += 2;
			}
			list++;
		}
		user_message (puser, MUSER, "Available commands: %s", command);
		return (1);
	}

	COMMAND_LIST *list = command_list;
	while (list->name != 0 && list->command_ptr != 0) {
		if (strcasecmp (list->name, command) == 0) break;
		list++;
	}
    if (strcasecmp (command, "help") == 0) {
        if (!command_help_lookup (puser, meat)) {
            user_message (puser, MUSER, "I don't have help for that command (%s).", meat);
        }
        return (0);
    }
	
	if (list->name == 0 || list->command_ptr == 0) {
		user_message (puser, MUSER, "%s?  I don't know what that is.  Try /help",  command);	
		return (0);
	}
	
    if (puser != &user[0]) user_message (puser, MUSER, "|1Command:|2 %s", cmd);

	return (list->command_ptr (puser, command, meat));
}

int command_help_lookup (struct user *puser, char *command) {
	if (!command_rank_test (puser, command)) return (0);

    FILE *fn1 = fopen ("command_help.txt", "rb");
    if (fn1 == 0) {
        log_printf (puser, LERROR, "Help is unavailable: %s", strerror (errno));
        return (0);
    }
    int wr = 0;
    char buffer[1024];

    while (fgets (buffer, 1024, fn1)) {
        char *cp = strrchr (buffer, '\r'); if (cp != NULL) *cp = 0;
        cp = strrchr (buffer, '\n'); if (cp != NULL) *cp = 0;
        
        strim ("lr", buffer);

        if (buffer[0] == '[' && buffer[strlen (buffer) - 1] == ']') {
            if (wr == 1) break;
            buffer[strlen (buffer) - 1] = 0;
            strim ("lr", &buffer[1]);
            if (strcasecmp (&buffer[1], command) == 0) {
                wr = 1;
            }
        } else if (wr == 1) {
            int v = strlen (buffer);
            if (v > 0) user_message (puser, MUSER, "%s", buffer);
        }
    }
    fclose (fn1);
    
    return (wr);    
}

