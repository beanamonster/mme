-- Courtesy of http://lua-users.org/wiki/SplitJoin
function split(str, pat)
   local t = {}  -- NOTE: use {n = 0} in Lua-5.0
   local fpat = "(.-)" .. pat
   local last_end = 1
   local s, e, cap = str:find(fpat, 1)
   while s do
      if s ~= 1 or cap ~= "" then
	 table.insert(t,cap)
      end
      last_end = e+1
      s, e, cap = str:find(fpat, last_end)
   end
   if last_end <= #str then
      cap = str:sub(last_end)
      table.insert(t, cap)
   end
   return t
end

function get_balance (user) 
	amount = 0
	path = "lua/economy/" .. user .. ".money"
	file = io.open (path, "r")
	if (file ~= nil) then
		io.input (file)
		amount = io.read("*number")  
		io.close (file)
	end
	if (amount == nil) then 
		amount = 0
	end
	return (amount)
end


function increase_balance (user, value) 
	path = "lua/economy/" .. user .. ".money"
	amount = 0
	amount = get_balance (user)
	amount = amount + value
	
	file = io.open (path, "w")
	if (file ~= nil) then
		io.output (file)
		io.write(amount)  
		io.close (file)
	end
	if (amount == nil) then 
		amount = 0	
	end
	return (amount)
end

function decrease_balance (user, value) 
	path = "lua/economy/" .. user .. ".money"
	amount = 0
	amount = get_balance (user)
	amount = amount - value
	
	file = io.open (path, "w")
	if (file ~= nil) then
		io.output (file)
		io.write(amount .. "\n")  
		io.close (file)
	end
	if (amount == nil) then
		amount = 0	
	end
	return (amount)
end


function show_help (user) 
	mme_user_send_message (user, "/money [<give||balance> <value> <username>]")
	mme_user_send_message (user, "example: /money give 500 phaelonimaire")
	mme_user_send_message (user, "example: /money balance")
end


function mme_user_event_connected (user) 
	path = "lua/economy/" .. user .. ".money"
	file = io.open (path, "r")
	if (file ~= nil) then
		io.close (file)
		return (0)
	else 
		mme_user_send_message (user, "A money system has been added to the server.  You have been given $5 to start with.")
		mme_user_send_message (user, "Use the /money command to access your money! (type /money to get help)")
		increase_balance (user, 5) 
	end

	return (0)
end

function mme_user_command (user, command, parameters) 
	
	if (command == "money") then
		mme_user_send_message (user, "Command: ".. command .. " " .. parameters)
		amount = get_balance (user)

		result = nil
		if (parameters == nil or #parameters < 1) then
			show_help(user)
			return (1)
		end
		result = split(parameters ,'[ ]+')
		
		if (parameters == "help" or parameters == nil) then
		end 
		if (result[1] == "balance") then
			mme_user_send_message (user, "You have a balance of $" .. amount .. ".")
		end
		
		if (result[1] == "give") then
			if (result[2] == nil or result[3] == nil) then
				show_help(user)
				return (1)
			end
			
			value = tonumber (result[2])
			if (value == nil) then
				value = 0
			end
			
			if (value > amount) then
				mme_user_send_message (user, "You only have $" .. amount ..", sorry.")
				return (1)
			end
			
			if (value < 1) then
				mme_user_send_message (user, "You can't give nothing, or less than nothing.")
				return (1)
			end
			
			if (mme_user_valid (result[3]) == 0) then
				mme_user_send_message (user, result[3] .. " does not appear to be a valid user.")
				return (1)
			end
			
			
			decrease_balance (user, tonumber (value))
			increase_balance (result[3], tonumber (value))
			
			amount = get_balance (user)
			mme_user_send_message (user, "Your remaining balance is $" .. amount)
			
		else 
			if (result[1] == nil) then
				mme_user_send_message (user, "/money requires balance or give.")
				mme_user_send_message (user, " Example: '/money balance' will tell you your current balance")
				mme_user_send_message (user, " Example: '/money give 30 someguy' will give 'someguy' 30 monies")
			else 
				mme_user_send_message (user, result[1] .. " is not valid.  try /money balance or /money give.")
			end

		end
		
		
		return (1)
	else
		return (0)
	end
end
