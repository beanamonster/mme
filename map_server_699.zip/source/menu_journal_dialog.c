/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"

int menu_journal_dialog (struct user *puser, int message_id) {
	char temp[256];
	int index = 1;
	int row = 2;
    char str_time[256];
    char name[25];

    switch (message_id) {
    case MENU_CREATE:
        menu_stack_push_init (puser, menu_journal_dialog, NULL, 0);
    
    case MENU_DRAW:
	    index = 1;
	    row = 2;
        user_name_by_id (puser->map, name, puser->journal_data.id);

	    iso_time_str (puser->journal_data.stamp, str_time);		

        packet_send(puser, PACKET_MENU_RESET, 0, 50, 11, 3);
        packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 0, "Journal Data");
	    row = 2;
	    sprintf (temp, "Coordinate ....: %ix%ix%i", puser->journal_data.x, puser->journal_data.y, puser->journal_data.z);
        packet_send(puser, PACKET_MENU_TEXT, index++, 1, row++, temp);

	    if (puser->journal_data.id == 0) {
	        packet_send(puser, PACKET_MENU_TEXT, index++, 1, row++, "No data available");
	    } else {
		    sprintf (temp, "Name ..........: %s", name);
            packet_send(puser, PACKET_MENU_TEXT, index++, 1, row++, temp);

		    sprintf (temp, "Modified on ...: %s", str_time);		
            packet_send(puser, PACKET_MENU_TEXT, index++, 1, row++, temp);

		    sprintf (temp, "Current Block .: %i", puser->journal_data.new);
            packet_send(puser, PACKET_MENU_TEXT, index++, 1, row++, temp);

		    sprintf (temp, "Old Block .....: %i", puser->journal_data.old);
            packet_send(puser, PACKET_MENU_TEXT, index++, 1, row++, temp);

		    row++;

            packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, row++, 2, 0, 0, "[ Undo This player's changes ]");
            packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, row++, 3, 0, 0, "[ Undo This player's changes up to this time]");            
	    }

        packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, row++, 1, 0, 0, "[ Disable Journal Lookup ]");
        return (1);
        
    case MENU_COMMAND: {
		int menu_number = -1;
		int menu_name = -1;
		int menu_value = -1;
		int menu_flags = -1;
		unsigned char menu_char[65535]; 

        menu_command_parse (puser, &menu_number, &menu_name, &menu_value, &menu_flags, menu_char);
        switch (menu_name) {
        case 1:
		    user_send_player_abilities (puser, 1);
            //packet_send(puser, PACKET_PLAYER_ABILITIES, ABILITY_FLY | ABILITY_SONIC_SPEED | ABILITY_NOCLIP, config.box_volume_limit, puser->rank->box_size_limit);
		    puser->who = 0;
		    menu_dialog (puser,  MENU_CREATE, "Who Mode", "Who mode has been disabled.", "OK");
            break;
        case 2:
		    map_journal_undo (puser, puser->journal_data.id, 0);
		    break;	
        case 3:
		    map_journal_undo (puser, puser->journal_data.id, puser->journal_data.stamp);
		    break;	
        }

        menu_stack_clear (puser);
	    return (1);}
    }
    return (1);
}
