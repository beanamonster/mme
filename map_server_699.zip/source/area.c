/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.*/

#include "global.h"

struct area_enum {
	DIR *dn;
	char path[PATH_MAX];
	struct user *puser;
};

void area_initialize (struct map *pmap) {
    pmap->area->active = 0;
    easy_mkdir (PATH_AREAS);

    memset (&pmap->area, 0, sizeof (struct area) * pmap->area_num_total);

    char file_perminant[PATH_MAX];
    snprintf (file_perminant, PATH_MAX, "%s/%s", PATH_AREAS, pmap->file);

    easy_mkdir (file_perminant);    

	int a;
    char temp[PATH_MAX];
	
	char *data;
	area_create_raw (pmap, (unsigned char **)&data);
    snprintf (temp, PATH_MAX, "%s/area_list.txt", file_perminant);
	FILE * fn1 = fopen (temp, "rb");
    char *args[8];
    char buffer[1024];
	if (fn1 != 0) {
        while (fgets (buffer, 1024, fn1)) {
            char *cp = strrchr (buffer, '\r'); if (cp != NULL) *cp = 0;
            cp = strrchr (buffer, '\n'); if (cp != NULL) *cp = 0;
            int num = csv_parse (buffer, ',', args, 8);
            if (num != 5) continue;
            int idx = atoi (args[0]);
            if (idx < 0 || idx >= pmap->area_num_total) continue;
            
            _strncpy (pmap->area[idx].user_name, args[1], 25);
            pmap->area[idx].last_load = atoi (args[2]);
            _strncpy (pmap->area[idx].filename, args[3], 256);
            pmap->area[idx].id = atoi (args[4]);

		    if (!area_reload (pmap, idx)) {
			    area_map_merge (pmap, data, idx);		
		    }
        }
		fclose (fn1);
	}

	for (a = 0; a < pmap->area_num_total ; a++) {
		log_printf (NULL, LDEBUG, "Area %i [%s]", a, pmap->area[a].filename);

		if (!area_reload (pmap, a)) {
			area_map_merge (pmap, data, a);		
		}
	}


	_free (data);
    /*
    The active flag just here to make sure the area_list file doesn't get 
    written before it's loaded.
    */
    pmap->area->active = 1;
	log_printf (NULL, LDEBUG, "area template merged into map");
}


int area_find_empty (struct map *pmap) {
    log_printf (NULL, LDEBUG, "area_find_empty");
    int a;
	int oldest = -1;
	time_t t;
	time (&t);
		
    for (a = 0; a < pmap->area_num_total; a++) {
		if (pmap->area[a].id == 0) return (a);
		if (pmap->area[a].last_load == 0) return (a);
	}
	
	for (a = 0; a < pmap->area_num_total; a++) {
		if (user_online_find_by_id (pmap->area[a].id) != NULL) continue;
		if (oldest == -1 || pmap->area[a].last_load < t) {
			t = pmap->area[a].last_load;
			oldest = a;
		}
	}
	
	if (oldest != -1) return (oldest);
    return (-1);
}

void area_file_path_make (struct map *pmap, char *output, int id, char *name) {
	if (name[0] == 0 || name == NULL) {
		output[0] = 0;
		return;
	}

	sprintf (output, "%s/%s/%i", PATH_AREAS, pmap->file, id);
	easy_mkdir (output);

    sprintf (output, "%s/%s/%i/%s", PATH_AREAS, pmap->file, id, name);
	char *cp = strrchr (output, '.');
	if (cp == NULL) {
		strcat (output, ".bin");
	} else {
		if (strcasecmp (cp, ".bin") != 0) strcat (output, ".bin");
	}
}

int area_create_file (struct user *puser, char *name) {
	char *data;
    char path[PATH_MAX];
    
	area_create_raw (puser->map,(unsigned char **) &data);
   
    snprintf (path, PATH_MAX, "%s/%s/%i", PATH_AREAS, puser->map->file, puser->idx);
    easy_mkdir (path);    

	area_file_path_make (puser->map, path, puser->uid, name);
    
	log_printf (puser, LDEBUG, "Create area file [%s]", path);

	if (!area_save_file (path, (char *) data, puser->map)) {
        log_printf (puser, LERROR, "Unable to write area file %s: %s", path, strerror (errno));
        return (0);
	}

    _free (data);
	return (1);
}

int area_create_raw (struct map *pmap, unsigned char **return_data) {
    log_printf (NULL, LDEBUG, "area_create_raw");
    unsigned char *data;
	char path[PATH_MAX];
    
    snprintf (path, PATH_MAX, "%s/%s/template.bin", PATH_AREAS, pmap->file);
	
	if (!area_load_file (path, (char **)&data, pmap)) {
		log_printf  (NULL, LWARNING, "unable to open template file; generic map will be created");
	
    	data = _malloc (pmap->area_data_size);
    	memset (data, 255, pmap->area_data_size);
	
    	unsigned char *cp;
    	cp = data;
    	int z;
    	int layer_size = pmap->area_x * pmap->area_y;

    	for (z = 0; z < pmap->sealevel - 1; z++) {
        	memset (cp, pmap->dirt_block, layer_size);
        	cp += layer_size;
    	}
    	memset (cp, pmap->grass_block, layer_size);
	}	
	
	*return_data = data;
    return (1);
}

void area_release (struct user *puser) {
    log_printf (NULL, LDEBUG, "area_release");
    int a;

    for (a = 0; a < puser->map->area_num_total; a++) {
		if (puser->map->area[a].id == puser->uid) break;
    }
    if (a == puser->map->area_num_total) {
        log_printf (puser ,LDEBUG , "area_release: Can't find user's area to release.");
        return;
    }
    
    area_save (puser->map, a);
    
    //area[a].user = 0;
	puser->map->area[a].times_connected++;

    memset (&puser->map->area[a].invited, 0, sizeof (puser->map->area[a].invited));
}


void area_start (struct map *pmap, int num, short *x, short *y) {
    int r, c;
    c = num / 5;
    r = num - (c * 5);

    *x = (pmap->area_x * c) + (pmap->area_border_size * (c + 1));
    *y = (pmap->area_y * r) + (pmap->area_border_size * (r + 1));
}

void area_map_merge (struct map *pmap, char *data, int num) {
    short x, y, z, x_offset, y_offset;
    
    pmap->save_counter++;
    area_start (pmap, num, &x_offset, &y_offset);    


    for (z = 0; z < pmap->dimension.z; z++) {
        for (y = 0; y < pmap->area_y; y++) {
            for (x = 0; x < pmap->area_x; x++) {
                //We don't use map_modify() here, since it is intended for data coming from
                //players.  This function does all of the propogation work itself.

                pmap->data[(z * pmap->dimension.y + (y + y_offset)) * pmap->dimension.x + (x + x_offset)] = 
                    data[(z * pmap->area_y + y) * pmap->area_x + x];
            }
        }
    }
}

int area_load (struct user *puser, int num, char *area_name) {
    log_printf (NULL, LDEBUG, "area_load");
	int ret = 0;
    char temp[256];
	
    char *data;
    char *compressed_data;
	char *uncompressed_buffer;
	
	if (puser->map->area[num].id == puser->uid) {
		if (area_name == NULL) {
			log_printf (puser, LDEBUG, "area_load: no area_name specified");
			return (1);
		}
		area_file_path_make (puser->map, temp, puser->uid, area_name);
		
		if (strcmp (temp, puser->map->area[num].filename) == 0) {
			time (&puser->map->area[num].last_load);
			log_printf (puser, LDEBUG, "Area %s already loaded", area_name);
			return (1);
		} else log_printf (puser, LDEBUG, "area_load: not the same area %s: %s", puser->map->area[num].filename, temp);
	}
	
	if (area_name != NULL) {
		area_file_path_make (puser->map, puser->map->area[num].filename, puser->uid, area_name);

		if (!area_load_file (puser->map->area[num].filename, &data, puser->map)) {
			log_printf (puser, LERROR, "area_load: can't open %s",  puser->map->area[num].filename);
			area_name = NULL;

       		menu_dialog (puser, MENU_CREATE, "Area", "Your area cannot be loaded at the moment.\nTry again later.", "OK");
		} else {
			puser->map->area[num].modify = 0;
			puser->map->area[num].id = puser->uid;
			puser->map->area[num].times_connected = puser->connections;
			_strncpy (puser->map->area[num].user_name, puser->name, 24);	
			time (&puser->map->area[num].last_load);	
		}
	
	
	}


	if (area_name == NULL) {
	
		puser->map->area[num].modify = 0;
		puser->map->area[num].id = puser->uid;
		puser->map->area[num].times_connected = puser->connections;
		_strncpy (puser->map->area[num].user_name, puser->name, 24);	
		time (&puser->map->area[num].last_load);	

    	int a;
    	for (a = 0; a < AREA_NUM_INVITED; a++) puser->map->area[num].invited[a] = 0;
	
		while (area_find_newest_area (puser->map, puser->uid, temp)) {
			area_file_path_make (puser->map, puser->map->area[num].filename, puser->uid, temp);
			log_printf (puser, LDEBUG, "Attempting to load area map %s", puser->map->area[num].filename);
			if (area_load_file (puser->map->area[num].filename, &data, puser->map)) {
				ret = 1; 
				break;
			}
				
			sprintf (temp, "%s.broken", puser->map->area[num].filename);
			remove (temp);
			rename (puser->map->area[num].filename, temp);
			log_printf (puser, LERROR, "area_load: area file %s is broken and has been renamed.", puser->map->area[num].filename);			
		
		
		}
		
		if (ret == 0) {
			area_file_path_make (puser->map, puser->map->area[num].filename, puser->uid, "default");

			if (!area_create_file (puser, "default")) {
				log_printf (puser, LERROR, "Unable to create an area for uid %i: %s", puser->uid, puser->map->area[num].filename);
                area_record_clear(puser->map, num);
       			menu_dialog (puser, MENU_CREATE, "Area", "Your area cannot be loaded at the moment.\nTry again later.", "OK");
				return (0);				
			}
			
			if (!area_load_file (puser->map->area[num].filename, &data, puser->map)) {
				log_printf (puser, LERROR, "Unable to load the newly created area for uid %i: %s", puser->uid, temp);
                area_record_clear(puser->map, num);
       			menu_dialog (puser, MENU_CREATE, "Area", "Your area cannot be loaded at the moment.\nTry again later.", "OK");
				return (0);				
			}
		}
	
	} 	
    compressed_data = _malloc (puser->map->area_data_size + 4096);

    short x, y, z, x_offset, y_offset;
    
    area_start (puser->map, num, &x_offset, &y_offset);    

    log_printf (puser, LDEBUG, "Loading area for %s:%i, starting at %ix%i, #%i", puser->name, puser->uid, x_offset, y_offset, num);
	area_map_merge (puser->map, data, num);

	uncompressed_buffer = _malloc (65536);

	for (z = 0; z < puser->map->dimension.z; z+= 32) {
		for (x = 0 ; x < puser->map->area_x; x += 32) {
			for (y = 0; y < puser->map->area_y; y += 32) {	
				int lx, ly, lz;				

				lx = x + 32; if (x + lx > puser->map->area_x) lx = puser->map->area_x - x;
				ly = y + 32; if (y + ly > puser->map->area_y) ly = puser->map->area_y - y;
				lz = z + 32; if (z + lz > puser->map->dimension.z) lz = puser->map->dimension.z - z;
				
				if (lx > 32) lx = 32;
				if (ly > 32) ly = 32;
				if (lz > 32) lz = 32;
				
				area_region_copy (((struct int_xyz) {puser->map->area_x, puser->map->area_y, puser->map->dimension.z}), 
					 ((struct int_xyz) {lx, ly, lz}),
					 ((struct int_xyz) {x, y, z}), 
					 ((struct int_xyz) {x + lx, y + ly, z + lz}),
					 ((struct int_xyz) {0, 0, 0}),
					 data,
					 uncompressed_buffer);

				int uncompressed_data_size = lx * ly * lz;
				int compressed_data_size = uncompressed_data_size;
				
			    int ret=zlib_deflate (uncompressed_buffer, uncompressed_data_size, compressed_data, (int *)&compressed_data_size);
			    if (!ret)
				      log_printf (NULL, LERROR, "area_load: Zlib deflate error\n", ret);
					  
				log_printf (puser, LDEBUG, "Send area data for %ix%ix%i - %ix%ix%i (%ix%ix%i)", x + x_offset, y + y_offset, z, (x + x_offset) + (lx -1), (y + y_offset) + (ly - 1), z + (lz - 1), x, y, z);
					  
				if (puser->current_mode == USER_CONNECTED) {

	                packet_broadcast (puser->map, USER_CONNECTED, puser, PACKET_ANNOUNCE_PLAYER, puser->idx, 9, puser->name);
					packet_broadcast (puser->map, USER_CONNECTED, 0, PACKET_MAP_DATA, x + x_offset, y + y_offset, z, 
							(x + x_offset) + (lx -1), (y + y_offset) + (ly - 1), z + (lz - 1),
					        compressed_data_size, compressed_data);
				} else {
					packet_broadcast (puser->map, USER_CONNECTED,  puser, PACKET_MAP_DATA, x + x_offset, y + y_offset, z, 
							(x + x_offset) + (lx -1), (y + y_offset) + (ly - 1), z + (lz - 1),
					        compressed_data_size, compressed_data);
				}
			}
		}
	}

	log_printf (NULL, LDEBUG, "area_load finished");
	_free (uncompressed_buffer);
    _free (compressed_data);
    _free (data);
	
    return (1);
}

void area_list_save (struct map *pmap) {
    char file_perminant[PATH_MAX];
    if (!pmap->area->active) return;
    snprintf (file_perminant, PATH_MAX, "%s/%s/area_list.txt", PATH_AREAS, pmap->file);

	FILE *fn1 = fopen (file_perminant, "wb");
    if (fn1 == 0) {
        log_printf (NULL, LWARNING, "Unable to save area list: %s: %s", file_perminant, strerror (errno));
        return;
    }
    int a;
    for (a = 0; a < pmap->area_num_total; a++) {
        if (pmap->area[a].user_name[0] == 0) continue;
        fprintf (fn1, "%i, %s, %i, %s, %i\r\n", a, pmap->area[a].user_name, (int)pmap->area[a].last_load, pmap->area[a].filename, pmap->area[a].id);
    }

    fclose (fn1);    
}

int area_save (struct map *pmap, int num) {
    unsigned char *data;
    	
	if (pmap->area[num].modify == 0) {
		log_printf (NULL, LDEBUG, "area_save: no need: %s", pmap->area[num].filename);	
		return (1);
	}

    data = _malloc (pmap->area_data_size);
    
    short x, y, z, x_offset, y_offset;
    
    area_start (pmap, num, &x_offset, &y_offset);    

    for (z = 0; z < pmap->dimension.z; z++) {
        for (y = 0; y < pmap->area_y; y++) {
            for (x = 0; x < pmap->area_x; x++) {
                data[(z * pmap->area_y + y) * pmap->area_x + x] = 
                    pmap->data[(z * pmap->dimension.y + (y + y_offset)) * pmap->dimension.x + (x + x_offset)];
            }
        }
    }

	if (!area_save_file (pmap->area[num].filename, (char *)data, pmap)) {
        log_printf (NULL, LWARNING, "Unable to save area %s: %s", pmap->area[num].filename, strerror (errno));
        _free (data);
        return (0);
	}
	
    log_printf (NULL, LDEBUG, "area_save: saved: %s", pmap->area[num].filename);
	
	pmap->area[num].modify = 0;	
	
    _free (data);
    
    return (1);
}

int area_save_to (struct map *pmap, int num, struct user *puser) {
    unsigned char *data;
    
    char file_temp[PATH_MAX];
    
    data = _malloc (pmap->area_data_size);
    
    short x, y, z, x_offset, y_offset;
    
    area_start (pmap, num, &x_offset, &y_offset);    

    for (z = 0; z < pmap->dimension.z; z++) {
        for (y = 0; y < pmap->area_y; y++) {
            for (x = 0; x < pmap->area_x; x++) {
                data[(z * pmap->area_y + y) * pmap->area_x + x] = 
                    pmap->data[(z * pmap->dimension.y + (y + y_offset)) * pmap->dimension.x + (x + x_offset)];
            }
        }
    }

    char name_temp[128];
    _strncpy (name_temp, pmap->area[num].user_name, 5);
    strcat (name_temp, "_");
    char *cp = strrchr (pmap->area[num].filename, '/');
    if (cp == NULL) cp = pmap->area[num].filename;
    else cp++;
    strcat (name_temp, cp);
    name_temp[23] = 0;    
   	area_file_path_make (puser->map, file_temp, puser->uid, name_temp);
    if (access (file_temp, F_OK) == 0) {
        _free (data);
        return (2);
    }

    log_printf (puser, LDEBUG, "%s copied %s' area {%s} [%s]", puser->name, pmap->area[num].user_name, pmap->area[num].filename, file_temp);


	if (!area_save_file (file_temp, (char *)data, pmap)) {
        log_printf (NULL, LWARNING, "Unable to save area %s: %s", file_temp, strerror (errno));
        _free (data);
        return (0);
	}
	
    _free (data);
    
    return (1);
}

int area_is_reserved (struct map *pmap, int num) {
    if (pmap->area[num].user_name[0] == 0) return (1);
    return (0);
}


void area_player_locate (struct user *puser, int num) {
    short x, y;
    if (num == -1) return;

    area_start (puser->map, num, &x, &y);
    
    x += puser->map->area_x / 2;
    y += puser->map->area_y / 2;    
    
    log_printf (puser, LDEBUG, "Relocate to area at %ix%i", x, y);
	
	puser->position.x = x;
	puser->position.y = y;
	puser->position.z = puser->map->dimension.z;
    
    user_spawn (puser, puser->position);
    //packet_send(puser, PACKET_MOVE_PLAYER, (float )puser->position.x, (float)puser->position.y, (float)puser->map->dimension.z - 9, puser->position.u, puser->position.v, 0);
}

void area_load_player (struct user *puser) {
	int num;
	num = area_for_player (puser);	
	log_printf (puser, LDEBUG, "area_for_player = %i", num);
	if (num == -1) {
		num = area_find_empty (puser->map);
		log_printf (puser, LDEBUG, "area_find_empty = %i", num);
		if (num != -1) {
            area_record_clear(puser->map, num);
		}
		
		log_printf (puser, LDEBUG, "area_find_empty returned %i", num);
	} else {
		log_printf (puser, LDEBUG, "area_for_player returned %i", num);
		
	}
    if (num == -1) {
		log_printf (puser, LERROR, "Unable to find an empty area.");
       	menu_dialog (puser, MENU_CREATE, "Area", "Your area cannot be loaded right now - all available slots are in use.", "OK");			
		return;		
	}
	area_load (puser, num, NULL);
}


int area_for_player (struct user *puser) {
    int a;
    
    for (a = 0; a < puser->map->area_num_total; a++) {
		if (puser->map->area[a].id == puser->uid) return (a);
    }
    return (-1);
}

int area_in (struct map *pmap, short position_x, short position_y) {
    int num;
    short x, y, rx, ry;
    
    x = position_x / (pmap->area_x + pmap->area_border_size);
    y = position_y / (pmap->area_y + pmap->area_border_size);
	
	if (x >= 5 || y >= 5) {
		//log_printf (NULL, LNOTE, "outside area boundries! %x %x", x, y);
		return (-1);
	}

    rx = position_x - (x * (pmap->area_x + pmap->area_border_size));
    ry = position_y - (y * (pmap->area_y + pmap->area_border_size));
    
    if (rx < pmap->area_border_size || ry < pmap->area_border_size) num = -1;
    else num = (x * 5) + y;
    
    return (num);
}

int area_modify_test (struct user *puser, short x, short y, short z, char *err) {\
	if (!puser->map->area_map) return (1);
    int num;
    int a;
    num = area_in (puser->map, x, y);
	struct user *duser;
    
    if (num == -1) {
		log_printf (puser, LDEBUG, "area_modify_test: %ix%i can't be located as an area.", x, y);
        return (0);
    }
	
	log_printf (puser, LDEBUG, "area_modify_test: [area %i] compare %i to %i", num, puser->uid, puser->map->area[num].id);
    
	if (puser->map->area[num].id == puser->uid) return (1);
	duser = user_connected_find_by_id (puser->map->area[num].id);
        
    for (a = 0; a < AREA_NUM_INVITED; a++) {
        if (puser->map->area[num].invited[a] == (void *) puser) return (1);
    }

	if (puser->map->area[num].id == 0 || duser == NULL) {
		if (puser->map->area[num].user_name[0] == 0) 
	        strcpy (err, "The owner of this area is not around.  You can't build here.");
		else
			sprintf (err, "This area belongs to %s, and they are not around to invite you.", puser->map->area[num].user_name);

    } else {
		sprintf (err, "%s must invite you in order to build here.", duser->name);
	}
    return (0);
}

int area_invite_player (struct user *puser, int num) {
    int a;
    for (a = 0; a < AREA_NUM_INVITED; a++) {
        if (puser->map->area[num].invited[a] == 0) {
            puser->map->area[num].invited[a] = puser;
            return (1);
        }
    }
    return (0);
}

int area_uninvite_player (struct user *puser, int num) {
	int a;
	
    for (a = 0; a < AREA_NUM_INVITED; a++) {
        if (puser->map->area[num].invited[a] == puser) {
			puser->map->area[num].invited[a] = 0;
			return (1);
		}
    }
    return (0);
}


void area_uninvite_player_all (struct user *puser) {
	int a;
	
	for (a = 0; a < puser->map->area_num_total; a++) {
		area_uninvite_player (puser, a);
	}
}


int area_is_invited (struct map *pmap, char *name, int num) {
	int a;
	struct user *duser = user_connected_find_by_name (name);
	if (duser == NULL) return (0);
	
    for (a = 0; a < AREA_NUM_INVITED; a++) {
        if (pmap->area[num].invited[a] == duser) return (1);
    }
    return (0);
}


void area_sync (struct map *pmap) {
	int a;		

    for (a = 0; a < pmap->area_num_total; a++) {
		if (pmap->area[a].id == 0) continue;
		area_save (pmap, a);
	}
    area_list_save (pmap);    
	log_printf (NULL, LDEBUG, "Areas have been saved");
}


void area_swap (struct user *puser, char *name) {
	int num = area_for_player (puser);
	if (num < 0) {
		log_printf (puser, LERROR, "area_swap: no area found for player %s", puser->name);
		return;
	}
	area_release (puser);
    
    area_load (puser, num, name);
    area_list_save (puser->map);
}

void area_delete (struct user *puser, char *name) {
	char temp[512];
	area_file_path_make (puser->map, temp, puser->uid, name);
	log_printf (puser, LNOTE, "Area deleted: %s", temp);
	remove (temp);
}


void area_name_loaded (struct user *puser, char *name) {
	int num = area_for_player (puser);
	char temp[512];
	char *cp;
	
	cp = strrchr (puser->map->area[num].filename, '/');
	if (cp == 0) cp = puser->map->area[num].filename;
	else cp ++;
	
	strcpy (temp, cp);
	
	cp = strstr (temp, ".bin");
	if (cp != 0) *cp = 0;
	
	strcpy (name, temp);

}

void area_record_clear (struct map *pmap, int num) {
	pmap->area[num].id = 0;
	pmap->area[num].user_name[0] = 0;
	pmap->area[num].filename[0] = 0;
    pmap->area[num].last_load = 0;
	pmap->area[num].times_connected = 0;
}

int area_reload (struct map *pmap, int num) {
    log_printf (NULL, LDEBUG, "area_reload");
    char *data;

    memset (&pmap->area[num].invited, 0, sizeof (pmap->area[num].invited));

	if (!area_load_file (pmap->area[num].filename, &data, pmap)) {
        area_record_clear(pmap, num);
		return (0);
	}
  
    short x_offset, y_offset;
    
    area_start (pmap, num, &x_offset, &y_offset);    

    log_printf (NULL, LDEBUG, "Loading area for %s:%i, starting at %ix%i, #%i, %s", pmap->area[num].user_name, pmap->area[num].id, x_offset, y_offset, num, pmap->area[num].filename);	area_map_merge (pmap, data, num);
    _free (data);
	
    return (1);
}
/*
static int area_enumerate_open (struct area_enum *d, struct user *puser) {
	d->puser = puser;

	snprintf (d->path, PATH_MAX, "%s/%s/%i", PATH_AREAS, d->puser->map->file, d->puser->uid);

	easy_mkdir (d->path);

	d->dn = opendir (d->path);
    if (d->dn == 0) {
        log_printf (NULL, LERROR, "area_enumerate_open: Unable to open directory [%s]: %s\n", strerror (errno), d->path);
		return (0);
    }
	return (1);
}

static int area_enumerate (struct area_enum *d, char *file_out, int length) {
	struct dirent *rdn;
	
	while (1) {
		if ((rdn = readdir (d->dn)) == NULL) return (0);

		if (strcmp (rdn->d_name, ".") == 0) continue;
		if (strcmp (rdn->d_name, "..") == 0) continue;
		char *cp;
		cp = strrchr (rdn->d_name, '.');
		if (cp == NULL) continue;
		if (strcasecmp (cp, ".bin") != 0) continue;
		break;
	}	
	
	_strncpy (file_out, rdn->d_name, length);
	return (1);
}

static void area_enumerate_close (struct area_enum *d) {
	closedir (d->dn);
}*/

int area_blank (struct user *puser, int num) {
    log_printf (NULL, LDEBUG, "area_blank");
    char *data;
    char *compressed_data;
	char *uncompressed_buffer;
    
    area_record_clear (puser->map, num);
	
	area_create_raw (puser->map, (void *)&data); 

    compressed_data = _malloc (puser->map->area_data_size + 4096);

    short x, y, z, x_offset, y_offset;
    
    area_start (puser->map, num, &x_offset, &y_offset);    

    log_printf (puser, LDEBUG, "Loading blank area");
	area_map_merge (puser->map, data, num);

	uncompressed_buffer = _malloc (65536);

	for (z = 0; z < puser->map->dimension.z; z+= 32) {
		for (x = 0 ; x < puser->map->area_x; x += 32) {
			for (y = 0; y < puser->map->area_y; y += 32) {	
				int lx, ly, lz;				

				lx = x + 32; if (x + lx > puser->map->area_x) lx = puser->map->area_x - x;
				ly = y + 32; if (y + ly > puser->map->area_y) ly = puser->map->area_y - y;
				lz = z + 32; if (z + lz > puser->map->dimension.z) lz = puser->map->dimension.z - z;
				
				if (lx > 32) lx = 32;
				if (ly > 32) ly = 32;
				if (lz > 32) lz = 32;

				area_region_copy (((struct int_xyz) {puser->map->area_x, puser->map->area_y, puser->map->dimension.z}), 
					 ((struct int_xyz) {lx, ly, lz}),
					 ((struct int_xyz) {x, y, z}), 
					 ((struct int_xyz) {x + lx, y + ly, z + lz}),
					 ((struct int_xyz) {0, 0, 0}),
					 data,
					 uncompressed_buffer);

				int uncompressed_data_size = lx * ly * lz;
				int compressed_data_size = uncompressed_data_size;
				
			    int ret=zlib_deflate (uncompressed_buffer, uncompressed_data_size, compressed_data, (int *)&compressed_data_size);
			    if (!ret)
				      log_printf (NULL, LERROR, "area_load: Zlib deflate error\n", ret);
					  
				log_printf (puser, LDEBUG, "Send area data for %ix%ix%i - %ix%ix%i (%ix%ix%i)", x + x_offset, y + y_offset, z, (x + x_offset) + (lx -1), (y + y_offset) + (ly - 1), z + (lz - 1), x, y, z);
				
				packet_broadcast (puser->map, -1, NULL, PACKET_MAP_DATA, x + x_offset, y + y_offset, z, 
						(x + x_offset) + (lx -1), (y + y_offset) + (ly - 1), z + (lz - 1),
					    compressed_data_size, compressed_data);
			}
		}
	}

	log_printf (NULL, LDEBUG, "area_blank finished");
	_free (uncompressed_buffer);
    _free (compressed_data);
    _free (data);
	
    return (1);
}


void area_region_copy (struct int_xyz src_dimension, struct int_xyz dest_dimension, struct int_xyz src_start, struct int_xyz src_end, struct int_xyz dest_offset, char *src_buffer, char *dest_buffer) {
	struct int_xyz r_dimension;

	int x, y, z;
	r_dimension.x = src_end.x - src_start.x;
	r_dimension.y = src_end.y - src_start.y;
	r_dimension.z = src_end.z - src_start.z;
	
	log_printf (NULL, LDEBUG, "map_region_copy: src dimension %ix%ix%i", src_dimension.x, src_dimension.y, src_dimension.z);
	log_printf (NULL, LDEBUG, "map_region_copy: range dimension %ix%ix%i-%ix%ix%i",src_start.x, src_start.y, src_start.z, src_end.x, src_end.y, src_end.z);
	log_printf (NULL, LDEBUG, "map_region_copy: dest dimension %ix%ix%i", dest_dimension.x, dest_dimension.y, dest_dimension.z);
	log_printf (NULL, LDEBUG, "map_region_copy: copy dimension %ix%ix%i", r_dimension.x, r_dimension.y, r_dimension.z);
	
	
	for (x = 0; x < r_dimension.x; x++) {
		for (y = 0; y < r_dimension.y; y++) {	
			for (z = 0; z < r_dimension.z; z++) {	
				
				if (src_buffer[((z + src_start.z) * src_dimension.y + (y + src_start.y)) * src_dimension.x + (x + src_start.x)] == 0) continue;
				
				dest_buffer[((z + dest_offset.z) * dest_dimension.y + (y + dest_offset.y)) * dest_dimension.x + (x + dest_offset.x)] = 
					src_buffer[((z + src_start.z) * src_dimension.y + (y + src_start.y)) * src_dimension.x + (x + src_start.x)];
			}
		}
	}
}

int area_save_file (char *file_name, char *data, struct map *pmap) {
    FILE *fn1;

    char file_temp[PATH_MAX];
    snprintf (file_temp, PATH_MAX, "%s.temp", file_name);

	log_printf (NULL, LDEBUG, "area_save_file: %s: %ix%ix%i", file_name, pmap->area_x, pmap->area_y, pmap->dimension.z);

    fn1 = fopen (file_temp, "wb");
    if (fn1 == 0 ) {
        log_printf (NULL, LDEBUG, "area_save_file: Can't save map file [%s]: %s", file_temp, strerror (errno));
        return (0);
    }

    btr_file_write_serial (fn1, BTR_FLOAT, "scale", (void *) &pmap->scale, sizeof (float)); 
    btr_file_write_serial (fn1, BTR_SHORT, "dimension_x", (void *) &pmap->area_x, 0);       
    btr_file_write_serial (fn1, BTR_SHORT, "dimension_y", (void *) &pmap->area_y, 0);       
    btr_file_write_serial (fn1, BTR_SHORT, "dimension_z", (void *) &pmap->dimension.z, 0);       
    btr_file_write_serial (fn1, BTR_BYTE, "data", (void *) data, pmap->area_x * pmap->area_y * pmap->dimension.z);

    fclose (fn1);  

    file_replace (file_name, file_temp);                    

    return (1);
}

int area_load_file (char *file_name, char **data_out, struct map *pmap) {
    FILE *fn1;
	struct stat st;

    fn1 = fopen (file_name, "rb");
    if (fn1 == 0) {
        log_printf (NULL, LDEBUG, "area_load_file: can't open map file [%s]", file_name);
        return (0);
    }
    short dx = 0, dy = 0, dz = 0;
	char *data ;

	fstat (fileno(fn1), &st);
	// If the area file is the raw version, load it in.
	if (st.st_size == 400 * 400 * 96) {
		log_printf (NULL, LDEBUG, "Map is of ancient format.");
		dx = 400;
		dy = 400;
		dz = 96;
		data = _malloc (st.st_size);
		*data_out = data;
		fread (data, 1, st.st_size, fn1);
		fclose (fn1) ;
	} else {
        unsigned char id;
        char name[256];
        data = _malloc (BTR_MEMORY_BLOCK);
        size_t data_length;

        float fscale = 0.0f;
        *data_out = 0;

        while (btr_file_read_serial (fn1, &id, name, &data, &data_length)) {
            if (strcmp (name, "scale") == 0 && id == BTR_FLOAT) memmove (&fscale, data, sizeof (float));
            else if (strcmp (name, "dimension_x") == 0 && id == BTR_SHORT) memmove (&dx, data, sizeof (short));
            else if (strcmp (name, "dimension_y") == 0 && id == BTR_SHORT) memmove (&dy, data, sizeof (short));
            else if (strcmp (name, "dimension_z") == 0 && id == BTR_SHORT) memmove (&dz, data, sizeof (short));
            else if (strcmp (name, "data") == 0 && id == BTR_BYTE) {
                *data_out = data;
                data = _malloc (BTR_MEMORY_BLOCK);
            } else {
                log_printf (NULL, LDEBUG, "area_load_file: unknown variable %s has been skipped.", name);
            }
        }
        fclose (fn1);   
        _free (data);
	}

	log_printf (NULL, LDEBUG, "Area is %ix%ix%i, Map is %ix%ix%i", dx, dy, dz, pmap->dimension.x, pmap->dimension.y, pmap->dimension.z);

    if (dx == 0 || dy == 0 || dz == 0 ) {
        log_printf (NULL, LWARNING, "area_load_file: %s is not a valid map file", file_name);
        if (*data_out != 0) _free (*data_out);
        return (0);
    }

	if (dx != pmap->area_x || dy != pmap->area_y || dz != pmap->dimension.z) {
		area_map_transform (data_out, dx, dy, dz, pmap->area_x, pmap->area_y, pmap->dimension.z, pmap->sealevel, pmap->dirt_block, pmap->grass_block);
	}

    return (1);
}

int area_map_transform (char **data_in, short sx, short sy, short sz, short dx, short dy, short dz, short sealevel, unsigned char dirt_block, unsigned char grass_block) {
	size_t new_map_size = dx * dy * dz;
	int new_layer_size = dx * dy;
	int old_layer_size = sx * sy;
    
	char *new_map = _malloc (new_map_size);
	char *old_map = *data_in;

	int copy_layer_size;
	if (new_layer_size >= old_layer_size) copy_layer_size = old_layer_size;
	else copy_layer_size = new_layer_size;
	
	int layer_offset = new_layer_size - copy_layer_size;
	int a;
	int offset = 0;
	int old_offset = 0;
	for (a = 0; a < dz; a++) {
		if (a < sealevel - 1) memset (&new_map[offset], dirt_block, new_layer_size);
		else if (a == sealevel - 1) memset (&new_map[offset], grass_block, new_layer_size);
		else memset (&new_map[offset], 255, new_layer_size);
		
		if (a < sz) {
			memmove (&new_map[offset + layer_offset], &old_map[old_offset], copy_layer_size);
			old_offset += old_layer_size;
		}
		offset += new_layer_size;
	}

	_free (old_map);
	
	*data_in = new_map;

	return (1);
	
}

int area_find_newest_area (struct map *pmap, int uid, char *out) {

	char path[PATH_MAX];
	snprintf (path, PATH_MAX, "%s/%s/%i", PATH_AREAS, pmap->file, uid);
	DIR *dn;

	dn = opendir (path);
    if (dn == 0) {
        log_printf (NULL, LERROR, "area_find_newest_area: Unable to open directory [%s]: %s\n", strerror (errno), path);
		return (0);
    }
	out[0] = 0;
	size_t newest = 0;
	struct dirent *rdn;
	struct stat st;
	char temppath[PATH_MAX];
	while (1) {
		if ((rdn = readdir (dn)) == NULL) break;

		if (strcmp (rdn->d_name, ".") == 0) continue;
		if (strcmp (rdn->d_name, "..") == 0) continue;
		char *cp;
		cp = strrchr (rdn->d_name, '.');
		if (cp == NULL) continue;
		if (strcasecmp (cp, ".bin") != 0) continue;
		snprintf (temppath, PATH_MAX, "%s/%s/%i/%s", PATH_AREAS, pmap->file, uid, rdn->d_name);		

		if (stat (temppath, &st) == -1) {
			log_printf (NULL, LWARNING, "area_find_newest_area: can't stat %s", temppath);
			continue;
		}
		log_printf (NULL, LDEBUG, "area_find_newest_area: %s", rdn->d_name);
		
		if (st.st_mtime > newest || newest == 0) {
			strcpy (out, rdn->d_name);
			newest = st.st_mtime;
		}
		
	}	
	closedir (dn);
	log_printf (NULL, LDEBUG, "area_find_newest_area: using: [%s]", out);
	
	
	if (out[0] == 0) return (0);
	else return (1);
}
