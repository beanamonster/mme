
-- Courtesy of http://lua-users.org/wiki/SplitJoin
function split(str, pat)
   local t = {}  -- NOTE: use {n = 0} in Lua-5.0
   local fpat = "(.-)" .. pat
   local last_end = 1
   local s, e, cap = str:find(fpat, 1)
   while s do
      if s ~= 1 or cap ~= "" then
	 table.insert(t,cap)
      end
      last_end = e+1
      s, e, cap = str:find(fpat, last_end)
   end
   if last_end <= #str then
      cap = str:sub(last_end)
      table.insert(t, cap)
   end
   return t
end

function mme_user_command (user, command, parameters) 

	if (command == "tp" and mme_user_command_allowed (user, command) == 1) then	
		if (parameters == "") then
			mme_user_send_message (user, "usage: /tp username")
			return (0)
		end
		if (mme_user_is_connected (parameters) == 0) then
			mme_user_send_message (user, .. " is either not connected, or does not exist.  Did you spell it correctly?")
			return (0)
		end
		x = tonumber (mme_user_get (parameters, "position_x"))
		y = tonumber (mme_user_get (parameters, "position_y"))
		z = tonumber (mme_user_get (parameters, "position_z"))
		u = tonumber (mme_user_get (parameters, "position_u"))
		v = tonumber (mme_user_get (parameters, "position_v"))
		
		mme_user_send_move_player (user, x, y, z, u, v, 0)
	end
		
end
