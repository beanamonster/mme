/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"

struct d_menu_dialog {
	char *buffer;
	char *lines[256];
	int num_lines;
	char title[64];
	int max_line_length;
	char button[64];
};

int wrap_text (char *text, int column) {
	char *out = _malloc (strlen (text) * 2);
	char *op = out;
	char *cp = text;
	char *cp2;
	int length = strlen (text);
	int row = 0;

	while (cp < text + length) {
		int end = strlen (cp);
		if (end >= column) end = column;
		else {

			strcpy (op, cp);
			op += strlen (cp);
			break;
		}

		cp2 = NULL;		
		int a;
		for (a = end - 1; a > 0; a--) {
			if (cp[a] == ' ')  {
				cp2 = &cp[a];
				break;
			}
		}
				
		strncpy (op, cp, cp2 - cp);

		op += (cp2 - cp);
		*op = '\n';
		op++;
		
		cp = cp2 + 1;
		row++;
	}
	*op = 0;
	
	strcpy (text, out);
	_free (out);
	return (row + 1);

}


int text_newline_array (char *in, char *argv[], int max) {

	int num = csv_parse (in, '\n', argv, max);
	int a;
	for (a = 0; a < num; a++) {
    	int len = strlen (argv[a]);
		for (int b = 0; b < len; b++) if (argv[a][b] == '\r') argv[a][b] = ' ';
	}
	return (num);
}

int menu_dialog (struct user *puser, int message_id, char *title, char *text, char *button) {

	
	struct d_menu_dialog *d;
	d = menu_get_current_stack_item_memory (puser);

	
	int a, len;

	switch (message_id) {
	case MENU_CREATE:{
		d = menu_stack_push_init (puser, menu_dialog, NULL, sizeof (struct d_menu_dialog));
		
		
		d->buffer = _malloc (strlen (text) * 2);
		strcpy (d->buffer, text);

		if (strchr (d->buffer, '\n') == NULL) {
			wrap_text (d->buffer, 64) ;
		}
		
		
		
		_strncpy (d->title, title, 63);
		_strncpy (d->button, button, 63);
		
		d->num_lines = csv_parse (d->buffer, '\n', d->lines, 250);
		
		d->max_line_length = 0;		

        for (a = 0; a < d->num_lines; a++) {
            len = strlen (d->lines[a]);
            if (len > d->max_line_length) d->max_line_length = len;
			for (int b = 0; b < len; b++) if (d->lines[a][b] == '\r') d->lines[a][b] = ' ';
        }
		
		
		
	case MENU_DRAW: 

		
        packet_send(puser, PACKET_MENU_RESET, 0, d->max_line_length + 2, 4 + d->num_lines, 3);
        packet_send(puser, PACKET_MENU_TEXT, 1, TEXT_CENTER_COLUMN, 0, d->title);
        packet_send(puser, PACKET_MENU_LINK, 3, TEXT_CENTER_COLUMN, d->num_lines + 3, 0, 0, 0, d->button);

        for (a = 0; a < d->num_lines; a++) {
			if (strlen (d->lines[a]) > 0)
	            packet_send(puser, PACKET_MENU_TEXT, a + 4, 1, a + 2, d->lines[a]);

		}
  		break;}

	case MENU_COMMAND:


		_free (d->buffer);
	
		menu_stack_pop (puser);
    
    }
    

	return (1);
}





struct d_menu_area_dialog {
	int num;

};


int menu_area_dialog (struct user *puser, int message_id, int area_number) {
	struct d_menu_area_dialog *d;
	d = menu_get_current_stack_item_memory (puser);

	char temp[1024];
	int index = 1;
	int a;

	switch (message_id) {
	case MENU_CREATE:{
		log_printf (puser, LDEBUG, "init menu_area_dialog");

		d = menu_stack_push_init (puser, menu_area_dialog, NULL, sizeof (struct d_menu_area_dialog));	

		d->num = area_number;
		}
		
	case MENU_DRAW: 
	
		a = 0;

 		if (rank_menu_allowed (puser->rank, "area_reload") && d->num >= 0) a = 4;

        packet_send(puser, PACKET_MENU_RESET, 0, 60, 9 + a, 3);
		packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 0, "Area");
		
		if (d->num == -1) {
		
			packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 2, "You may not build here.");
		} else if (d->num == -2) {
			packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 2, "Your fill box contained an unbuildable region");
		
		} else {
            if (puser->map->area[d->num].user_name[0] == 0) 
    			sprintf (temp, "This area is reserved.");
            else
    			sprintf (temp, "This area belongs to %s.", puser->map->area[d->num].user_name);
	        packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 2, temp);
			if (puser->map->area[d->num].user_name[0] != 0) {
				sprintf (temp, "%s must invite you to build here.", puser->map->area[d->num].user_name);
		        packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 3, temp);
			}
		}
        int row = 5;
		

		if (rank_menu_allowed (puser->rank, "area_reload") && d->num >= 0) {
		
			packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, row, 2, 0, 0, "[ Invite Yourself ]");row++;
			packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, row, 2, 1, 0, "[ Unload Area ]");row++;
			packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, row, 2, 2, 0, "[ Load different Area ]");row++;	
            		
		}
		
		
//    	if (!area_is_reserved (puser->map, d->num)	)
//            packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, row, 2, 4, 0, "I want a copy of this area"); row++;
		
    	packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, row, 2, 3, 0, "[ Go to my area! ]"); row++;
        packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, 7 + a, 1, 0, 0, "[ OK ]");


		break;
	case MENU_COMMAND:{
		int menu_number = -1;
		int menu_name = -1;
		int menu_value = -1;
		int menu_flags = -1;
		unsigned char menu_char[65535]; 
		
		menu_command_parse (puser, &menu_number, &menu_name, &menu_value, &menu_flags, menu_char);
		
		
		log_printf (puser, LDEBUG, "menu_area_dialog: %i %i", menu_name, menu_value);
		
		if (menu_name == 1 && menu_value == 0) {
			menu_stack_pop (puser);
			
		} else if (menu_name == -1 && menu_value == -1) {
			menu_stack_pop (puser);	
			
		} else if (menu_name == 2 && menu_value == 0) {
			area_invite_player (puser, d->num);
			menu_stack_pop (puser);	
			menu_dialog (puser, MENU_CREATE, "Invited", "You have invited yourself.", "OK");			
		} else if (menu_name == 2 && menu_value == 1) {
			if (user_attached_find_by_name (puser->map->area[d->num].user_name)) {
				menu_stack_pop (puser);	
				menu_dialog (puser, MENU_CREATE, "Unload Area", "You can't unload an area of someone who\nis still connected.", "OK");
			} else {
	        	area_blank (puser, d->num);
				menu_stack_pop (puser);	
        	}
	
			
		

		} else if (menu_name == 2 && menu_value == 2) {

			if (user_attached_find_by_name (puser->map->area[d->num].user_name)) {
				menu_stack_pop (puser);	
				menu_dialog (puser, MENU_CREATE, "Unload Area", "You can't unload an area of someone who\nis still connected.", "OK");
				return (1);
			}
		
		
			if (menu_number != 255) {
				menu_edit_box (puser, MENU_CREATE, "Load player", "\x00", 24, 2, 2);
			} else {
			
			
				int id = 0;
				struct user duser;
				memmove (&duser, puser, sizeof (struct user));
				
				
				if (menu_char[0] == '#') {
					id = atoi ((char *)menu_char + 1);
				} else {
                    if (user_id_by_name (puser->map, (char *)menu_char, &id) == 0) id = 0;
				}

				if (id != 0) {
                    if (!user_record_load (&duser, id)) id = 0;
				}

				if (id == 0) {
					menu_stack_pop (puser);	
					menu_dialog (puser, MENU_CREATE, "Load Area", "I don't know who that is!", "OK");			


				} else {
					if (area_for_player (&duser) != -1) {
						sprintf (temp, "%s's area is already loaded.", duser.name);
						menu_dialog (puser, MENU_CREATE, "Load Area", temp, "OK");			
						return (1);
				
					}
				
					area_save (puser->map, d->num);
					memset (&puser->map->area[d->num].invited, 0, sizeof (size_t) * 256);
					
					area_record_clear (puser->map, d->num);
					
					puser->map->area[d->num].id = id;
                    duser.map = puser->map;
					duser.uid = id;
					
					
					if (!area_find_newest_area (puser->map, duser.uid, temp)) {
						sprintf (temp, "%s's area could not be loaded.", duser.name);
						menu_stack_pop (puser);	
						menu_dialog (puser, MENU_CREATE, "Load Area", temp, "OK");			
					
					} else {
						menu_stack_pop (puser);					
						area_load (&duser, d->num, temp);					
					}
				}
			
			
			}
        } else if (menu_name == 2 && menu_value == 3) {
			area_player_locate (puser, area_for_player (puser));
        } else if (menu_name == 2 && menu_value == 4) {
			menu_stack_pop (puser);
            if (area_user_count (puser) >= NUM_USER_AREAS) {
                menu_dialog (puser, MENU_CREATE, "Areas", "You have reached the limit of saved areas.\nYou must delete a saved area, first.", "OK");
                return (1);                
            }
            if (area_is_reserved (puser->map, d->num)) {
                menu_dialog (puser, MENU_CREATE, "Areas", "This area is not available to copy", "OK");
                return (1);                
            }
            int ret = area_save_to (puser->map, d->num, puser);
            if (ret == 1) {
                menu_dialog (puser, MENU_CREATE, "Areas", "This area has been copied to \"My Areas\"\nTo access it, press F2, and click on \"My Areas\"", "OK");
            } else if (ret == 2) {
                menu_dialog (puser, MENU_CREATE, "Areas", "You already have an area of the same name which may match this one.\nUse \"My Areas\" to delete, copy, or rename it.", "OK");
            } else {
                menu_dialog (puser, MENU_CREATE, "Areas", "The area could not be copied.  Try again later", "OK");
            }
            return (1);            
		} else {
			log_printf (puser, LDEBUG, "menu_undo: unknown %i %i", menu_name, menu_value);
			menu_area_dialog (puser,  MENU_DRAW, 0);
		}
		
		
		break;}

    }
    

	return (1);
}



struct d_menu_yesno {
	int response;
	char title[64];
	char text[512];
} d_menu_yesno;



int menu_dialog_yesno (struct user *puser, int message_id, char *title, char *text, int response) {
	struct d_menu_yesno *d;
	
	d = menu_get_current_stack_item_memory (puser);

	switch (message_id) {
	case MENU_CREATE:
	
		d = menu_stack_push_init (puser, menu_dialog_yesno, NULL, sizeof (struct d_menu_yesno));

		d->response = response;
		_strncpy (d->title, title, 511);
		_strncpy (d->text, text, 511);
		


		
	case MENU_DRAW:{    
        char *args[256], *buffer;
        int a, num_lines;
        int len = strlen (d->text);
        buffer = _malloc (len + 2);
        strcpy (buffer, d->text);
        buffer[len]=0;
        int max_line_length = 0;


        num_lines = csv_parse (buffer, '\n', args, 256);
        if (num_lines > 20) num_lines = 20;

        for (a = 0; a < num_lines; a++) {
            len = strlen (args[a]);
            if (len > max_line_length) max_line_length = len;
        }


	
		
        packet_send(puser, PACKET_MENU_RESET, 0, max_line_length + 2, 5 + num_lines, 2);
        packet_send(puser, PACKET_MENU_TEXT, 1, TEXT_CENTER_COLUMN, 0, d->title);
      //  packet_send(puser, PACKET_MENU_LINK, 3, TEXT_CENTER_COLUMN, num_lines + 3, 0, 0, 0, button);
	  
	  	int center = max_line_length / 2;
	  
	  
		packet_send(puser, PACKET_MENU_BUTTON, 3, center - 5, num_lines + 3, 1, 1, 3, 0, "Yes");	  
		packet_send(puser, PACKET_MENU_BUTTON, 4, center + 4, num_lines + 3, 1, 0, 3, 0, "No");	  
	  

        for (a = 0; a < num_lines; a++) {
			if (strlen (args[a]) > 0)
	            packet_send(puser, PACKET_MENU_TEXT, a + 5, 1, a + 2, args[a]);

		}
  		break;}

		
				
	case MENU_COMMAND: {
		int menu_number = -1;
		int menu_name = -1;
		int menu_value = -1;
		int menu_flags = -1;
		unsigned char menu_char[65535]; 
		
		menu_command_parse (puser, &menu_number, &menu_name, &menu_value, &menu_flags, menu_char);

		menu_stack_pop (puser);
	
		unsigned char data[8];
		
		data[0] = 0;
		data[1] = d->response;
		data[2] = menu_value;
		
		puser->menu_data = (void *)data;
		puser->menu_data_size = 3;
		
		menu_proc (puser, MENU_COMMAND);
		
		return (0);
	}
	
	}

	
	return (1);		
}



int menu_killed_dialog (struct user *puser, int message_id) {
	switch (message_id) {
	case MENU_CREATE:
		menu_stack_push (puser, menu_killed_dialog);
    	packet_broadcast (puser->map, USER_CONNECTED, puser, PACKET_DENOUNCE_PLAYER, puser->idx);
        puser->dead = 1;
		
	case MENU_DRAW: 
        packet_send(puser, PACKET_MENU_RESET, 0, 40, 8, 3);
        packet_send(puser, PACKET_MENU_TEXT, 1, TEXT_CENTER_COLUMN, 0, "Dead!");
        packet_send(puser, PACKET_MENU_TEXT, 2, TEXT_CENTER_COLUMN, 2, "You died.  Click OK to respan.");
        packet_send(puser, PACKET_MENU_LINK, 3, TEXT_CENTER_COLUMN, 3, 0, 0, 0, "[ OK ]");
  		break;

	case MENU_COMMAND:
        puser->dead = 0;
		puser->hitpoints = puser->max_hitpoints;
        if (puser->map->area_map) {
            area_player_locate (puser, area_for_player (puser));
        } else {
            user_spawn (puser, puser->map->spawn);    
        }

/*
        packet_broadcast (&map_array[m], USER_CONNECTED, &user[a], PACKET_MOVE_PLAYER, puser->position.x, puser->position.y, puser->position.z, 
                    puser->position.u, puser->position.v, puser->idx);
*/
        packet_broadcast (puser->map, USER_CONNECTED, puser, PACKET_ANNOUNCE_PLAYER, puser->idx, 9, puser->name);
        packet_broadcast (puser->map, USER_CONNECTED, puser, PACKET_PLAYER_PROPERTIES, puser->idx, puser->skin_id);

		menu_stack_pop (puser);
    }
    return (1);
}

