--[[
This file is called by the map server when it starts up.
We use this file to load other lua files which contain hooks.
Hooks (in our case) are lua functions which are called by
the map server when specific events occur.  (Sending chat
messages, placing blocks, moving, etc)
These scripts are executed once, and then remain in the
map server memory and are searched for specifically named
functions during the servers' operation.

You can put your hook functions in this file if you want,
but it helps to break them down into different files so
that you don't end up with a big hairy mess.

Lua uses the double-dash (--) as a comment indicator.
If a line starts with --, the line will be ignored.  Also,
you can comment out a whole block by using the dashes with
brackets, as illustrated by this multi-line comment.
]]--


-- mme_hookfile_load ("chat.lua")
-- mme_hookfile_load ("tnt.lua")
-- mme_hookfile_load ("trip.lua")
-- mme_hookfile_load ("economy.lua")
-- mme_hookfile_load ("more_commands.lua")
-- mme_hookfile_load ("zombie.lua")
--mme_hookfile_load ("spawn_protect.lua")



-- The following will be printed out on the console:
print ("startup.lua: done")

