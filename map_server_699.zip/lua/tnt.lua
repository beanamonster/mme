--[[
Every time a PACKET_MAP_MODIFY packet is received by the map server, the
'mme_user_receive_packet_map_modify' hook is called.  By hooking this 
function we can see when a user attempts to place a single block, before
the map server tries to update the map.
When a user places block 158 (TNT in the default texture set) we
use the mme_map_draw_sphere() function to draw a sphere, and tell the
map server that it doesn't need to do anything with the placed block
by returning 1.
If the placed block isn't id 158, we then return 0, telling the map server
to finish processing the block.
]]--

tnt = {}
function mme_user_event_connected (user) 
	tnt[user] = 0
	return (0)
end


function mme_user_receive_packet_map_modify (username, x, y, z, type, unused) 
	if (tnt[username] == nil) then tnt[username] = 0 end
	if (type == 158) then
		--if (tnt[username] > 0) then
			tnt[username] = tnt[username] - 1
			mme_map_draw_sphere (mme_user[username].map_file, x, y, z, 8, 255)
		--else
		--	mme_user_send_packet_map_modify (username, x, y, z, 255)
		--	mme_user_send_message (username, "You don't have any TNT blocks.  You'll have to make some.")			
		--end
		return (1)
	elseif (type == 148 and z > 3) then
		-- fire 
		if (mme_map_get_block (mme_user[username].map_file, x, y, z - 1) == 153 and mme_map_get_block (mme_user[username].map_file,x, y, z - 2) == 15 and mme_map_get_block (mme_user[username].map_file,x, y, z - 3) == 62) then
			mme_map_modify_block (username, x, y, z, 255)
			mme_map_modify_block (username, x, y, z -1 , 255)
			mme_map_modify_block (username, x, y, z -2 , 255)
			mme_map_modify_block (username, x, y, z -3 , 255)
--			mme_map_modify_block (username, x, y, z - 3, 158)
			tnt[username] = tnt[username] + 1
			-- mulch1, tree trunk, sand, fire
			
			mme_user_send_message (username, "You now have " .. tnt[username] .. " TNT blocks in your inventory.")	
			return (1)
		end
	
	
	end
	return (0)
end

print ("tnt.lua : loaded")

