#include <unistd.h>

struct btr_header {
	unsigned char id;
	unsigned char name_length;
	unsigned long long payload_length;
} __attribute__((__packed__));

#define BTR_BYTE 1
#define BTR_SHORT 2
#define BTR_INT 4
#define BTR_FLOAT 5
#define BTR_LONG 8
#define BTR_DOUBLE 9
#define BTR_STRING 10
#define BTR_MEMORY_BLOCK 4096
