--[[
Every time a PACKET_MOVE_PLAYER packet is received by the map server, the
'mme_user_event_position_changed' hook is called.  This is an example of
how to display text when a user is at a specific x, y, z location.
The 'mme_user_event_position_changed' hook's return value isn't important,
but needs to be specified.

Since the coordinates are floating point numbers (they contain decimal
places) we use the lua function math.floor to round then down to the
nearest whole number, or block position.
]]--


function mme_user_event_position_changed (user, old_x, old_y, old_z, old_u, old_v, new_x, new_y, new_z, new_u, new_v)

	ox = math.floor (old_x)
	oy = math.floor (old_y)
	oz = math.floor (old_z)	

	nx = math.floor (new_x)
	ny = math.floor (new_y)
	nz = math.floor (new_z)	

	
	if ((ox ~= 100 or oy ~= 100) and nx == 100 and ny == 100) then
		mme_user_send_message (user, "100x100!")	
	end
	

		
	return (0)
end

print ("trip.lua: loaded")

