/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"

static int ip_banned (char *test_ip) ;

int user_authenticate (struct user *puser, struct packet_authenticate_data *auth, int size) {
    //User defaults should be placed here.  When a user is loaded, 
    //their settings will be merged into the defaults.

    _strncpy (puser->rank_name, config.default_rank_name, 32);
	puser->color = 4;
	puser->file_request_flag	 = 0;
    puser->rank = rank_find_struct_by_name (puser->rank_name);
    puser->map = NULL;
    
	int num_users = 0;

	int a;
	for (a = 1; a < NUM_USERS; a++) {
		if (user[a].current_mode != USER_DISCONNECT && user[a].current_mode != USER_NOT_CONNECTED) num_users ++;
	}
	
	if (num_users + 1 > config.connection_limit) {
		user_disconnect (puser, DISCONNECT_FULL, 0, "This server is full.  Come back later.");
		log_printf (puser, LNOTE, "Server full (%i/%i)", num_users,config.connection_limit );
		return (0);
	}
	
    if (size != sizeof (struct packet_authenticate_data)) {
        if (!config.local_connections) {
            user_disconnect (puser, DISCONNECT_ERROR, 0, "You must connect through the MME Server Portal.");
            log_printf (puser, LNOTE, "Auth packet not the right size: %i/%i", size, sizeof (struct packet_authenticate_data));
            return (0);
        }
        log_printf (puser, LNOTE, "User authentication skipped...");        
        
        sprintf (puser->name, "+player_%i", puser->idx);
        puser->uid = 0;
        puser->map = &map_array[0];
        goto end;
    }

    if (puser->client_version < config.minimum_client_version) {
        user_disconnect (puser, DISCONNECT_NULL, 0, "Download the latest client and try again!");  
        log_printf (puser, LNOTE, "Client %i falls below our threshold.", puser->client_version);
        return (0);
    }
    
    log_printf (puser, LDEBUG, "User authentication starts...");

    unsigned char auth_data[64];
	unsigned char auth_token[20];

	memset (auth_data, 0, 64);
	memmove (auth_data, config.salt, 20);
	memmove (((char *)auth_data + 20), auth, sizeof (struct packet_authenticate_data) - 20);

	sha1 ((char *)auth_token, (char *)auth_data, sizeof (struct packet_authenticate_data));
	
	time_t t;	
	time (&t);
	
	if (t - auth->t > 3600 && !config.local_connections) {
        user_disconnect (puser, DISCONNECT_ERROR, 0, "Your session has expired.  Please log in again.");	
	    log_printf (puser, LNOTE, "%s has an out-of-date key", auth->name);	
        return (0);
	}

	if (memcmp (auth_token, auth->salt, 20) != 0) {
        if (!config.local_connections) {
            log_printf (puser, LNOTE, "%s has an invalid key", auth->name);	
            user_disconnect (puser, DISCONNECT_NULL, 1, "Your authentication key is invalid.  Please log in again.");
            return (0);
        } else if (auth->number != 0) {
            auth->number = 0 - (puser->idx);
        }
	}
    
    if (auth->number == 0) {
		if (!config.local_connections) user_disconnect (puser, DISCONNECT_NULL, 0, "Your connection data is invalid.");
        log_printf (puser, LNOTE, "%s has a zero user id",  auth->name);
		auth->number = 0;
        //return (0);
    }

	if (strcasecmp (puser->name, "console") == 0) {
        user_disconnect (puser, DISCONNECT_NULL, 0, "Console is a reserved name.  Goodbye.");
        log_printf (puser, LNOTE, "Tried to connect with name: %s",  auth->name);
        return (0);
	}
    
    _strncpy (puser->name, auth->name, 25);
    puser->uid = auth->number;

    puser->map = &map_array[0];
	
	if (puser->map == NULL) {
		log_printf (puser, LWARNING, "Can't find a map for %s", puser->name);
		return (0);
	}

    if (ip_banned(puser->ip_address)) {
//    if (in_list (puser->ip_address, "ip_banned.txt")) {
        user_disconnect (puser, DISCONNECT_BAN, 0, "You have been banned from this server.");
        log_printf (puser, LNOTE, "IP %s is banned",  puser->ip_address);
        return (0);
    }
    
	char temp_name[26];
	_strncpy (temp_name, auth->name, 26);
    for (a = 1; a < NUM_USERS; a++) {
        if (user[a].current_mode == USER_NOT_CONNECTED || user[a].current_mode == USER_DISCONNECT) continue;
		if (puser == &user[a]) continue;
		if (strcasecmp (temp_name, user[a].name) != 0) continue;
		if (user[a].uid != auth->number || config.local_connections) continue;
		

        log_printf (puser, LNOTE, "%s is already connected", puser->name);
        user_record_save (&user[a], user[a].uid);
        user[a].current_mode = USER_CONNECTED;
		user_disconnect (&user[a], DISCONNECT_NULL, 0, "You have logged in from somewhere else.");
    }
    
    int reason;        
    if (!user_login(puser, puser->map, &reason)) {
        if (reason == DISCONNECT_BAN)
            user_disconnect (puser, DISCONNECT_BAN, 0, "You are banned.");

        else if (reason == DISCONNECT_KICK) {
            user_disconnect (puser, DISCONNECT_BAN, 0, "You look way too familiar...");
            // Setting these to zero prevents the user record from being created.
            puser->name[0] = 0;
            puser->uid = 0;
        } else 
            user_disconnect (puser, DISCONNECT_ERROR, 0, "You may not connect at this time.");
    
        return (0);
    }
	end:;
	
	char temp[256];
	snprintf (temp, 256, "%s -- %s", puser->name, config.name);
    
    packet_send (puser, PACKET_SERVER_NAME, temp);
    
	user_mode_set (puser, USER_CONNECTING);    

    // If the user's map is violent, allow the projectile packets
   /* if (puser->map->violence) {
	
        set_default_receivable_packets (puser->receivable_packets);
	    packet_set_available (puser->receivable_packets, PACKET_PROJECTILE_COLLISION);
	    packet_set_available (puser->receivable_packets, PACKET_PROJECTILE_CREATE);

		set_default_sendable_packets (puser->sendable_packets);
	    packet_set_available (puser->sendable_packets, PACKET_PROJECTILE_COLLISION);				
	    packet_set_available (puser->sendable_packets, PACKET_PROJECTILE_CREATE);		
        packet_send(puser, PACKET_AVAILABLE_PACKET_TYPES, puser->sendable_packets);		


    }*/
    return (1);
}

int user_login (struct user *puser, struct map *pmap, int *reason) {
    int a;
    if (pmap != NULL) puser->map = pmap;
	

     
    if (!user_record_load (puser, puser->uid)) {
        puser->new = 1;
        
        if (user_ip_is_banned (puser->map, puser->ip_address)) {
            log_printf (puser, LNOTE, "Login refused for %s: IP address matches previously-banned user.", puser->name);
            *reason = DISCONNECT_KICK;
            return (0);
        }
        
        log_printf (puser, LNOTE, "Registering new user %s (#%i) from %s", puser->name, puser->uid, puser->ip_address);
        user_record_save (puser, puser->uid);
    } else {
    
        if (puser != &user[0] && puser->uid != 0) log_printf (puser, LNOTE, "User %s (#%i) connected from %s", puser->name, puser->uid, puser->ip_address);
    }
    
    if (puser->name[0] == 0) {
        log_printf (puser, LERROR, "Connected user does not have a name");
        *reason = DISCONNECT_ERROR;
        return (0);
    }
        
    if (puser->banned) {
        *reason = DISCONNECT_BAN;
        log_printf (puser, LNOTE, "%s is banned",  puser->name);
        return (0);
    }

    if (in_list (puser->name, "owner.txt")) {
        log_printf (puser, LNOTE, "Owner connected; %s (#%i)", puser->name, puser->uid);
        puser->rank = rank_struct_by_highest ();
        _strncpy (puser->rank_name, puser->rank->name, 32);
    }


    puser->rank = rank_find_struct_by_name (puser->rank_name);
    if (puser->rank == NULL) {
        puser->rank = rank_find_struct_by_name (config.default_rank_name);    

        if (puser->rank == NULL) puser->rank = &rank[0];
        
        _strncpy (puser->rank_name, puser->rank->name, 32);
    }

    // Make sure the player's skin is valid

    for (a = 0; a < NUM_SKINS; a++ ) {
        if (puser->map->palette->skin[a].name[0] == 0) continue;
        if (strcasecmp (puser->map->palette->skin[a].name, puser->skin_name) == 0) break;
    }

    if (a == NUM_SKINS) { // No?  He gets no skin.
        puser->skin_name[0] = 0;
        puser->skin_id = -1;
    }

    puser->skin_id = skin_texture_find_id_by_name (puser->map->palette, puser->skin_name);
    if (puser->skin_id == -1) puser->skin_name[0] = 0;
 
    return (1);
}


void user_mode_set (struct user *puser, int mode) {
	puser->previous_mode = puser->current_mode;
	puser->current_mode = mode;
	if (puser->previous_mode == 4 && puser->current_mode == 4) log_printf (puser, LERROR, "User mode going from 4 to 4");
	log_printf (puser, LDEBUG, "User mode going from %i to %i", puser->previous_mode, puser->current_mode);	
}


void user_disconnect (struct user *puser, unsigned char reason, unsigned char delay, char *str) {
	if (puser->current_mode == USER_DISCONNECT) return;
    packet_send(puser, PACKET_DISCONNECT, reason, delay, str);

	user_mode_set (puser, USER_DISCONNECT);
}


void user_announce_player (struct user *puser, char *message) {

	if (puser->map->area_map) area_player_locate (puser, area_for_player (puser));
	else user_spawn (puser, puser->map->spawn);    

    if (message != NULL) user_message_broadcast (puser, MSYSTEM, "%s", message);    
    
    // Set the position of the other users
	user_send_player_updates(1);
    
    // Announce other connected users to current user
    for (int a = 1; a < NUM_USERS; a++) {
        if (user[a].current_mode != USER_CONNECTED ||  &user[a] == puser ) continue;

        packet_send (puser, PACKET_MOVE_PLAYER, user[a].position.x, user[a].position.y, user[a].position.z, 
                user[a].position.u, user[a].position.v, user[a].idx);
	    packet_send (puser, PACKET_ANNOUNCE_PLAYER, user[a].idx, 9, user[a].name);					
	    if (user[a].skin_name[0] != 0) texture_skin_change (puser, puser->idx, user[a].skin_name);
	}
    
    
    lua_hook_call ("mme_user_event_player_announced", puser);
    npc_announce (puser);
}


void user_message (struct user *puser, int type, char *str, ... ) {
    va_list  arg;
    char *buffer;
    buffer = _malloc (65536);
    int number = puser->idx;
    va_start(arg, str);
    vsnprintf(&buffer[2], 65533, str, arg);
    va_end(arg);
	
	if (type & MUSER) { if (type & MERROR) buffer[1] = 14; else buffer[1] = 4;}
	else if (type & MSYSTEM) { number = 0; if (type & MERROR) buffer[1] = 11; else buffer[1] = 8;}
	else buffer[1] = 9;	
	buffer[0] = '\e';

	str_colorize (buffer);
    
    
    if (puser->socket == 1) {
         mme_to_ascii (buffer); 
		 printf ("->%s\n", buffer);
    }
	else packet_send (puser, PACKET_CHAT_MESSAGE, number, buffer);

    _free (buffer);
}


void color_strip (char *str) {
    char *buffer = _malloc (strlen (str) + 1);
    strcpy (buffer, str);
    int a, b;
    
    b = 0;
    for (a = 0; a < strlen (buffer); a++) {
        if (buffer[a] == '\e') {a++; continue;}
        str[b] = buffer[a];
        b++;
    }
    strcpy (str, buffer);
    _free (buffer);

}

void mme_to_ascii (char *str) {
    char *buffer = _malloc (strlen (str) + 1);
    strcpy (buffer, str);
    int a, b;
    
    b = 0;
    for (a = 0; a < strlen (buffer); a++) {
        if (buffer[a] == '\e') {a++; continue;}
        if (buffer[a] < 32 || (unsigned char)buffer[a] > 127) {continue;}
        str[b] = buffer[a];
        b++;
    }
    str[b] = 0;
    _free (buffer);

}


void user_message_broadcast (struct user *puser, int type, char *str, ... ) {
    va_list  arg;
    char *buffer, *cp, *cp2;
    buffer = _malloc (65536);
    int number = 1;
    va_start(arg, str);
    vsnprintf(&buffer[2], 65534, str, arg);
    va_end(arg);
	
	if (type & MUSER) { if (type & MERROR) buffer[1] = 14; else buffer[1] = 4;}
	else if (type & MSYSTEM) {number = 0; if (type & MERROR) buffer[1] = 11; else buffer[1] = 8;}
	else buffer[1] = 9;	
	buffer[0] = '\e';
	
	str_colorize (buffer);
    
    if (puser == NULL) {
	    packet_broadcast (NULL, USER_CONNECTED, NULL, PACKET_CHAT_MESSAGE, number, buffer);
    	mme_to_ascii (buffer);
    	printf ("=>[%s]\n", buffer);
        _free (buffer);
        return;
    
    }
    int a;    
    
    char *no_rainbow = _malloc (strlen (buffer) + 2);
    strcpy (no_rainbow, buffer);

    char butt[3] = {0x1b, 0x0b, 0};
    
    cp2 = strchr (no_rainbow, ':');

    while (1) {
        if (cp2 == NULL) break;
        cp = strstr (no_rainbow, butt);
        if (cp == NULL || cp > cp2) break;
        cp[1] = 9;
    }

	for (a = 1; a < NUM_USERS; a++) {
		if (user[a].current_mode != USER_CONNECTED) continue;
        if (user[a].map != NULL && puser->map != NULL && user[a].map != puser->map) continue;

		if (user_is_ignored (&user[a], puser->uid) || user_is_ignored (puser, user[a].uid)) {
			log_printf (puser, LDEBUG, "Chat: %s is ignoring %s", user[a].name, puser->name);
			continue;
		}

        if (user[a].no_rainbows) packet_send (&user[a], PACKET_CHAT_MESSAGE, number, no_rainbow);
		else packet_send (&user[a], PACKET_CHAT_MESSAGE, puser->idx, buffer);
	}
    mme_to_ascii (buffer);
    printf ("=>[%s]\n", buffer);
    
    _free (no_rainbow);
    _free (buffer);
}



void user_send_player_updates(int force) {

    int m;
    for (m = 0; m < NUM_MAPS; m++) {
        if (!map_array[m].active) continue;
    
        if (easy_time() < map_array[m].last_movement_update) return;
        int a;

        for (a = 1; a < NUM_USERS; a++) {
            if (user[a].current_mode != USER_CONNECTED) continue;
            if (user[a].map != &map_array[m]) continue;
						
		    if (force == 0 && memcmp (&user[a].position, &user[a].position_last, sizeof (user[a].position)) == 0) continue;
		    memmove (&user[a].position_last, &user[a].position, sizeof (user[a].position));		

		    log_printf (NULL, LDEBUG, "send player update for %i", a);
            

            packet_broadcast (&map_array[m], USER_CONNECTED, &user[a], PACKET_MOVE_PLAYER, user[a].position.x, user[a].position.y, user[a].position.z, 
                    user[a].position.u, user[a].position.v, user[a].idx);

        }
        map_array[m].last_movement_update = easy_time() + 0.125;
    }
}

void user_show_message_file (struct user *puser, char *file) {
    FILE *fn1;

    char buffer[256], *cp;
    
    fn1 = fopen (file, "rb");
    if (fn1 == 0) {
        log_printf (puser, LWARNING, "unable to show message file [%s]", file);
        return;
    }
    
    
    while (fgets (buffer, 255, fn1)) {
        cp = strchr (buffer, '\r'); if (cp != 0) *cp = 0;
        cp = strchr (buffer, '\n'); if (cp != 0) *cp = 0;    
    
        packet_send (puser, PACKET_CHAT_MESSAGE, puser->idx, buffer);
    
    }
    fclose (fn1);
}

void user_show_message_file_dialog (struct user *puser, char *file) {
    FILE *fn1;

    char *buffer;
    
    fn1 = fopen (file, "rb");
    if (fn1 == 0) {
        log_printf (puser, LWARNING, "unable to show message file [%s]", file);
        return;
    }
    
    struct stat st;
    
    fstat (fileno(fn1), &st);
    buffer = _malloc (st.st_size + 1);
    
    fread (buffer, st.st_size, 1, fn1);
    fclose (fn1);
    
    buffer[st.st_size] = 0;
  
    menu_dialog (puser, MENU_CREATE, "file", buffer, "OK");  
///    menu_dialog (puser, file, buffer);
    _free (buffer);
    
}


void user_set_write_event (struct user *puser, void *location) {
    puser->write_event = location;
    puser->write_init = 1;    
}


unsigned int user_meters_to_blocks (double d, double scale) {
	if (d == -0.1f) return (-1);
	else if (d < 0) return ((int)nearbyint (0 - d));
	
	return (nearbyint (d / scale));
}


int user_send_player_abilities (struct user *puser, int init) {
    if (init) {
        log_printf (puser, LDEBUG,  "Send Player Abilities"); 
        int abilities = 0;
        if (puser->rank->can_fly) abilities |= ABILITY_FLY;
        if (puser->rank->can_noclip) abilities |= ABILITY_NOCLIP;
        if (puser->rank->can_sonic_fly) abilities |= ABILITY_SONIC_SPEED;
		
		unsigned int cuboid_volume_limit;
	    unsigned short cuboid_size_limit;
		
		if (puser->map->area_map) {
			cuboid_volume_limit = -1;
			cuboid_size_limit = -1;
		} else {
		    cuboid_volume_limit = user_meters_to_blocks (puser->rank->cuboid_volume_limit_meters, puser->map->scale);
	    	cuboid_size_limit = user_meters_to_blocks (puser->rank->cuboid_size_limit_meters, puser->map->scale);
		}
		
		           
        packet_send(puser, PACKET_PLAYER_ABILITIES, abilities,  cuboid_volume_limit, cuboid_size_limit);
		
        return (0);
    } else 
	    user_set_write_event (puser, user_send_complete);
    return (0);
}

int user_send_map (struct user *puser, int init) {
    if (init) {
		if (puser->map->area_map) area_load_player (puser);
		map_compress_send (puser, 1);
		return (0);
    }
	
	if (map_compress_send (puser, 0) == 1) {
   		packet_send(puser, PACKET_MAP_LOADING, 255, "Decompressing map");
		user_set_write_event (puser, user_send_block_data);
        return (1);
	}	

    return (0);
}            
          
int user_send_block_data (struct user *puser, int init) {           
    texture_send_texture_info (puser);
    texture_send_block_groups (puser);
    texture_send_blocks (puser);
    texture_send_skybox_info (puser);
    user_set_write_event (puser, user_send_player_abilities);
    return (1);
}

int user_send_complete (struct user *puser, int init) {
    if (init) {
        // This must always happen, otherwise the textures will not be applied.
        packet_send(puser, PACKET_MAP_LOADING, 0, 0); 
    }
    
    
	
	packet_send (puser, PACKET_PING_REQUEST, (char *)"\x55", 1);
    user_set_write_event (puser, NULL); 
	return (1);
}

struct user * user_connected_find_by_name (char *name) {
    int a;
    
    for (a = 0; a < NUM_USERS; a++) {
        if (user[a].current_mode != USER_CONNECTED) continue;
        if (strcasecmp (name, user[a].name) == 0) return ((void *) &user[a]);
    }
    return (NULL);
}

struct user * user_attached_find_by_name (char *name) {
    int a;
    
    for (a = 0; a < NUM_USERS; a++) {
        if (user[a].current_mode == USER_NOT_CONNECTED || user[a].current_mode == USER_DISCONNECT) continue;
        if (strcasecmp (name, user[a].name) == 0) return ((void *) &user[a]);
    }
    return (NULL);
}

struct user * user_connected_find_by_id (int id) {
    int a;
    
    for (a = 0; a < NUM_USERS; a++) {
        if (user[a].current_mode != USER_CONNECTED) continue;
        if (id == user[a].uid) return ((void *) &user[a]);
    }
    return (NULL);
}

void user_chat_private (struct user *puser, char *message) {
	int length = strlen (message);
	int id;
	char *cp = strchr (message, ' ');
	if (cp == 0) {
		user_message (puser, MUSER, "Message not sent.  Private messages require a name and a message, separated by a space.");
		return;
	}
	*cp = 0; cp++;
	strim ("lr", cp);

	struct user *duser = user_connected_find_by_name (message);
	if (duser == NULL) {
		if (!user_id_by_name (puser->map, message, &id)) {
			user_message (puser, MUSER, "%s does not exist.", message);
			return;
		}
		
		char temp[1024];
		sprintf (temp, "%s/%i", PATH_PRIVATE_MAIL, id);
		FILE *fn1 = fopen (temp, "ab");
		if (fn1 == 0) {
			log_printf (puser, LERROR, "Unable to save message file %s: %s", temp, strerror (errno));
			user_message (puser, MUSER, "%s is not connected, and your message could not be saved.", message);
			return;
		}
		
		time_t t;
		time (&t);
		fprintf (fn1, "%i\x01%s\x01%s\n", (unsigned int)t, puser->name, cp);
		fclose (fn1);

		user_message (puser, MUSER, "%s does not appear to be connected; message will be delivered when they connect.  Message was \"\e\x02%s\e\x09\"", message, cp);
			
	} else {

		char *buffer;
		buffer = _malloc (length + 32);

		if (user_is_ignored (duser, puser->uid) || user_is_ignored (puser, duser->uid)) {
			user_message (puser, MUSER, "%s is ignoring you.  Private messages will not be delivered.", duser->name);
		} else {
			snprintf (buffer, length + 32, "\e\x04(pm) %s:\e\x08 %s", puser->name, cp);
			packet_send (duser, PACKET_CHAT_MESSAGE, duser->idx, buffer);
			packet_send (puser, PACKET_CHAT_MESSAGE, duser->idx, buffer);
		}
		_free (buffer);
	}

}

void str_colorize (char *str) { 
	char *cp = 0;
	char *cp2 =0 ;
	char colors[16] = "1234567890abcdef";
	char *cp3 = 0;
	char *output = 0;
	
	output = _malloc (strlen (str) + 1);
	output[0] = 0;
	char *ocp;
	ocp = output;
	
	int length = strlen (str);
	cp = str;

	while (cp < str + length) {
		cp2 = strchr (cp, '|');
		if (cp2 == 0) cp2 = cp + strlen (cp);
		
        //This can't be _strncpy, or strncpy.
        //Since strncpy may or may not stick in the null byte, use memmove
        memmove (ocp, cp, cp2 - cp);
		ocp += cp2 - cp;
		cp3 = strchr (colors, cp2[1]);		

		if (cp2[1] == '|') {
			*ocp = '|';
			ocp ++;
			cp2++;
			
		} else if (cp3 != 0 && cp2[1] != 0 ) {
			ocp[1] = (cp3 - colors) + 1;
			ocp[0] = '\e';
			ocp += 2;
			cp2++;
		}

		cp = cp2 + 1;
		*ocp = 0;		
	}
	*cp2 = 0;
	
	strcpy (str, output);
	_free (output);
	
}


void user_spawn (struct user * puser, struct float_xyzuv spawn) {

    
    /* In order to move the player model without the client animating the position change,
    we must denounce the player, change its position, and then re-announce.*/
    
    packet_broadcast (puser->map, USER_CONNECTED, puser, PACKET_DENOUNCE_PLAYER, puser->idx);            

    // Tell the user's client to move its viewpoint    
    packet_send(puser, PACKET_MOVE_PLAYER, (float)spawn.x, (float)spawn.y,  (float)spawn.z, (float)spawn.u, (float)spawn.v, 0);

    /*packet_send (puser, PACKET_MOVE_PLAYER, spawn.x, spawn.y, spawn.z, 
                spawn.u, spawn.v, puser->idx);*/
                
    //Send announcement of player to other connected users
    packet_broadcast (puser->map, USER_CONNECTED, puser, PACKET_ANNOUNCE_PLAYER, puser->idx, 9, puser->name);

    // Re-sending the player properties isn't needed, but doesn't hurt.
    texture_skin_change_broadcast (puser->map, puser, puser->idx, puser->skin_name);
	event_player_position_changed (puser, spawn);
}


void add_to_list (char *name, char *filename) {
    FILE *fn1;
    fn1 = fopen (filename, "ab");
    if (fn1 == 0) {
        fn1 = fopen (filename, "wb");
        if (fn1 == 0) {
            log_printf (NULL, LERROR, "Can't add [%s] to [%s]: %s", name, filename, strerror (errno));
            return;
        }
    }
    fprintf (fn1, "%s\r\n", name);
    fclose (fn1);
}

int remove_from_list (char *name, char *filename) {
    FILE *fn1, *fn2;
    int ret = 0;
    
    fn1 = fopen (filename, "rb");
    if (fn1 == 0) {
        log_printf (NULL, LWARNING, "remove_from_list: unable to remove %s from the list; %s", name, strerror (errno));
        return (0);
    }
    
    fn2 = fopen ("tempfile", "wb");
    if (fn2 == 0) {
        log_printf (NULL, LWARNING, "remove_from_list: cannot create temp file; %s", strerror (errno));
        return (0);
    }
    char temp[128], *cp;
    while (fgets (temp, 128, fn1)) {
        cp = strchr (temp, '\r'); if (cp != 0) *cp = 0;
        cp = strchr (temp, '\n'); if (cp != 0) *cp = 0;
        
        strim ("lr", temp);
        
        if (strcasecmp (name, temp) == 0) {ret = 1; continue;}
        
        fprintf (fn2, "%s\r\n", temp);
    }
    
    fclose (fn1);
    fclose (fn2);
    
    if (remove (filename) == -1) {
        log_printf (NULL, LERROR, "remove_from_list: %s cannot be deleted: %s", strerror (errno));
    }
    
    if (rename ("tempfile", filename) == -1) {
        log_printf (NULL, LERROR, "remove_from_list: %s cannot be renamed: %s", strerror (errno));
    }

    return (ret);    

}

int in_list (char *name, char *filename) {
    FILE *fn1;
    char temp[128], *cp;
    int ret = 0;
    
    fn1 = fopen (filename, "rb");
    if (fn1 == 0) {
        log_printf (NULL, LNOTE, "There is no list file called [%s]", filename);
        return (0);
    }
    
    while (fgets (temp, 127, fn1)) {
        cp = strchr (temp, '\r'); if (cp !=0) *cp = 0;
        cp = strchr (temp, '\n'); if (cp !=0) *cp = 0;
        strim ("lr", temp);

        if (temp[0] == '#') continue;
        if (strcasecmp (temp, name) == 0) {
            ret = 1; 
            goto end;
        }
    }
    end:
    
    fclose (fn1);
    return (ret);
}

void user_deallocate (struct user *puser) {
	double t = easy_time();
	while (puser->waiting_for_map) {
		double v = easy_time() - t;
		if (v > 0.1) log_printf (puser, LWARNING , "user_deallocate: Time dialation of %f\n", v);
	}

	_free (puser->write_buffer);
	_free (puser->read_buffer);
	_free (puser->data);
	_free (puser->undo);
	map_compress_deallocate (puser);

}

void user_connection_setup () {
    int a;
	struct user *puser;
    
    for (a = 1; a < NUM_USERS; a++) {
        if (user[a].current_mode == USER_NOT_CONNECTED) break;
    }
    
    if (a == NUM_USERS) {
        // server is full.
        log_printf (NULL, LNOTE, "Server is full.");
        return ;
    }
    /*
        Initialize some parameters to ensure new connections don't have old data,
        or priveladges/limitations from the previous user.
    */
    
	puser = &user[a];

	memset (puser, 0, sizeof (struct user));
	puser->idx = a;	
    
	//Data cleared, populate for new user
    puser->socket =  socket_accept (puser->ip_address, 255, g_bind_socket);
    
	user_mode_set (puser, USER_CONNECTING);
   
	puser->write_size = DEFAULT_BUFFER_SIZE;
	puser->write_buffer = _malloc (puser->write_size);
    memset (puser->write_buffer, 0, puser->write_size + 1);
	
	puser->read_size = DEFAULT_BUFFER_SIZE;
	puser->read_buffer = _malloc (puser->read_size);
    memset (puser->read_buffer, 0, puser->read_size + 1);	


	puser->data_size = DEFAULT_BUFFER_SIZE;
	puser->data = _malloc (puser->data_size + 1);
    memset (puser->data, 0, puser->data_size);
	
	puser->undo = _malloc (sizeof (struct undo_data) * 32767);

    puser->write_event = NULL;
   
    time (&puser->last_io);
    
    for (a = 0; a < NUM_USERS; a++) {
        puser->ignore_list[a] = -1;
    }
    menu_stack_clear (puser);
	
	puser->max_hitpoints = puser->hitpoints = 100; 
	puser->strength = 1;
	puser->defense = 1;
	
	set_default_sendable_packets (puser->sendable_packets);
	set_default_receivable_packets (puser->receivable_packets);
	packet_send(puser, PACKET_AVAILABLE_PACKET_TYPES, puser->sendable_packets);
	
    log_printf (puser, LNOTE, "Connection established %i", puser->idx);
    return ;
}

int user_record_load (struct user *puser, int id) {
	if (id < 1) return (1);
    FILE *fn1;
	
	if (puser->map == NULL) {
		log_printf (puser, LERROR, "user_record_load: user map pointer is empty.");
		return (0);
    }
    char file_temp[PATH_MAX];
    snprintf (file_temp, PATH_MAX, "%s/%s", PATH_USERS, "user.txt");
     
    fn1 = fopen (file_temp, "rb");
    if (fn1 == 0) return (0);
    
    char buffer[1024];
    char *args[16];
    int found = 0;

    while (fgets (buffer, 1024, fn1)) {
        char *cp = strrchr (buffer, '\r'); if (cp != NULL) *cp = 0;
        cp = strrchr (buffer, '\n'); if (cp != NULL) *cp = 0;
        int num = csv_parse (buffer, ',', args, 16);
        if (num < 2) {
            log_printf (NULL, LDEBUG, "invalid number of arguments");
            continue;
        }

        if (atoi (args[0]) != id) continue;
        found = 1;

        strncpy (puser->name, args[1], 25);
        strncpy (puser->rank_name, args[2], 32);        
        if (num > 3) puser->color = atoi (args[3]);
        if (num > 5) {
            puser->no_rainbows = atoi (args[5]);
        }
        if (num > 6) {
            _strncpy (puser->skin_name, args[6], 32);
        }
        
        if (num > 7) {
            puser->banned = atoi (args[7]);
		}
        if (num > 9) {
            puser->last_login_stamp = atol (args[9]);
        }
        if (num > 10) {
            puser->blocks_placed = atoi (args[10]);
        }
        if (num > 11) {
            puser->blocks_removed = atoi (args[11]);
        }
        if (num > 12) {
            puser->no_area_names = atoi (args[12]);
        }
		
       
        break;
    }
    fclose (fn1);
    
    if (found == 0) return (0);
    
    puser->uid = id;

    puser->rank = rank_find_struct_by_name (puser->rank_name);
    if (puser->rank == NULL) {
        log_printf (puser, LNOTE, "User's rank %s not found; going with default.", puser->rank_name);
        puser->rank = rank_find_struct_by_name (config.default_rank_name);
    }
    if (puser->rank == NULL) {
        puser->rank = &rank[0];
        log_printf (puser, LNOTE, "Default rank not found.  Going with the lowest possible.");
    }
    
    if (puser->color < 1 || puser->color > 0x10)  puser->color = 3;
    
    return (1);

}

int user_record_save (struct user *puser, int id) {
	if (id < 1) return (1);
    char found = 0;  
    char *buffer = NULL;
    char *cp, *cp2, *cp3;
    int length;
    char temp_record[1024];
    if (puser->name[0] == 0 || puser->uid < 1) return (1);
    
    char file_perminant[PATH_MAX];
    char file_temp[PATH_MAX];
    snprintf (file_perminant, PATH_MAX, "%s/%s", PATH_USERS, "user.txt");
    snprintf (file_temp, PATH_MAX, "%s/.%s", PATH_USERS, "user.txt");    

    
    FILE *fn1;
    fn1 = fopen (file_perminant, "rb");
    if (fn1 != NULL) {
        struct stat st;
        fstat (fileno (fn1), &st);

        // This is much faster than trying to read through the actual file record by record...
        buffer = _malloc (st.st_size + 1);
        
        fread (buffer, 1, st.st_size, fn1);
        
        buffer[st.st_size] = 0;
        fclose (fn1);

    }
    
    fn1 = fopen (file_temp, "wb");
    if (fn1 == 0) {
        if (buffer != NULL) _free (buffer);
        log_printf (puser, LERROR, "unable to open %s for writing: %s", file_temp, strerror (errno));
        return (0);
    }

    if (buffer != NULL) {
        length = strlen (buffer);
        cp = buffer;
        while (cp < buffer + length) {

            cp2 = strchr (cp, '\n');
            if (cp2 == NULL) cp2 = cp + strlen (cp);

            //find the first field separator
            
            _strncpy (temp_record, cp, cp2 - cp);
            cp = strrchr (temp_record, '\r'); if (cp != NULL) *cp = 0;
            cp = strrchr (temp_record, '\n'); if (cp != NULL) *cp = 0;

            
            cp3 = strchr (temp_record, ',');
            // no field seperator? 
            if (cp3 == NULL) {cp = cp2 + 1; continue;}
            
            // chomp out the first field so we can atoi it.
            *cp3 = 0;
            
            // Not our record?  rewrite it and move on
            if (atoi (temp_record) != id) {
                *cp3 = (unsigned char) ',';
                //strcat (temp_record, "\r\n");
                fprintf (fn1, "%s\r\n", temp_record);
            } else {
                // Here it is, update it and move along.
                fprintf (fn1, "%i, %s, %s, %i, %ix%ix%ix%ix%i, %i, %s, %i, %s, %i, %u, %u, %i\r\n", 
                        id, puser->name, puser->rank_name, puser->color, 
                        0, 0, 0,
                         0, 0, puser->no_rainbows, puser->skin_name, puser->banned, puser->ip_address, (int)puser->last_login_stamp, puser->blocks_placed, puser->blocks_removed, puser->no_area_names);
                found = 1;
            }
            cp = cp2 + 1;
        }
        _free (buffer);   
    }
    
    if (found == 0) {
        //The record wasn't found, so just add it to the end.
        fseek (fn1, 0, SEEK_END);
        fprintf (fn1, "%i, %s, %s, %i, %ix%ix%ix%ix%i, %i, %s, %i, %s, %i, %u, %u, %i\r\n", 
                        id, puser->name, puser->rank_name, puser->color, 
                        0, 0, 0,
                         0, 0, puser->no_rainbows, puser->skin_name, puser->banned, puser->ip_address, (int)puser->last_login_stamp, puser->blocks_placed, puser->blocks_removed, puser->no_area_names);
    
    }
    
    fclose (fn1); 
    
    file_replace (file_perminant, file_temp);
   
    return (1);
}

/*
    Administrative actions taken against other users need to be
    triple-checked as to make sure it isn't the result of some spoofing attempt.
*/
void user_kick (struct user *puser, int uid, char *reason) {

    struct user *duser = user_connected_find_by_id (uid);
    if (duser == NULL) {
        user_message (puser, MUSER, "That user does not appear to be connected.");
        return;
    }
    if (rank_id_by_name (puser->rank->name) <= rank_id_by_name (duser->rank->name)) return;
    
    /*if (duser->map != puser->map) {
        user_message (puser, MUSER, "You can't kick someone who is on a different map.");
        return;
    }*/


    snprintf (duser->disconnect_message, 128, "%s has been kicked: %s", duser->name, reason);
    log_printf (duser, LNOTE, "%s (by %s)", duser->disconnect_message, puser->name);

    char temp[256];
    sprintf (temp, "Kicked: %s", reason);
    user_disconnect (duser, DISCONNECT_KICK, 0, temp);
    user_message (puser, MUSER, "You have kicked %s.", duser->name);
    
    return;    
}

void user_ipban (struct user *puser, int uid, char *reason) {

    struct user *duser = user_connected_find_by_id (uid);
    if (duser == NULL) {
        user_message (puser, MUSER, "That user does not appear to be connected.");
        return;
    }
    if (rank_id_by_name (puser->rank->name) <= rank_id_by_name (duser->rank->name)) return;

    log_printf (puser, LNOTE, "%s banned ip %s: %s", puser->name, duser->ip_address, reason);
    snprintf (duser->disconnect_message, 128, "%s has been IP banned: %s", duser->name, reason);
    char temp[256];
    sprintf (temp, "Banned! %s", reason);
    user_disconnect (duser, DISCONNECT_BAN, 0, temp);
    user_message (puser, MUSER, "You have banned IP %s", duser->ip_address);
    add_to_list (duser->ip_address, "ip_banned.txt");
    int a;
    for (a = 1; a < NUM_USERS; a++) {
		if (user[a].current_mode == USER_DISCONNECT || user[a].current_mode == USER_NOT_CONNECTED) continue;
        if (&user[a] == duser) continue;
	
        if (strcmp (duser->ip_address, user[a].ip_address) == 0) {
            user_disconnect (&user[a], DISCONNECT_BAN, 0, "You have been banned!");
        }
    
	}
    return;    
}

void user_ban (struct user *puser, int uid, char *reason) {
	if (uid < 1) return;
/*
    struct user *duser = user_connected_find_by_id (uid);
    if (rank_id_by_name (puser->rank->name) <= rank_id_by_name (duser->rank->name)) return;
  */
    struct user *duser = user_connected_find_by_id (uid);
    if (duser == NULL) {
        struct user u;
        duser = &u;
		duser->map = puser->map;
        if (!user_record_load (duser, uid)) {
            user_message (puser, MUSER | MERROR, "Unable to change rank");
            return;
        }
    }
    
    /*if (duser->map != puser->map) {
        user_message (puser, MUSER, "You can't ban someone who is on a different map.");
        return;
    }*/

    log_printf (puser, LNOTE, "%s banned %s: %s", puser->name, duser->name, reason);
    snprintf (duser->disconnect_message, 128, "%s has been banned!  %s", duser->name, reason);
    char temp[256];
    sprintf (temp, "Banned!  %s", reason);
    user_disconnect (duser, DISCONNECT_BAN, 0, temp);

    duser->banned = 1;
    user_message (puser, MUSER, "%s has been banned", duser->name);
    user_record_save (duser, duser->uid);
    return;    
}

void user_rank_change (struct user *puser, int uid, int rank_id) {
	if (uid < 1) return;
    int rerank_max;

    struct user *duser = user_connected_find_by_id (uid);
    if (duser == NULL) {
        struct user u;
        duser = &u;
		duser->map = puser->map;
        if (!user_record_load (duser, uid)) {
            user_message (puser, MUSER | MERROR, "Unable to change rank");
            return;
        }
    }
    
    if (uid == puser->uid) {
        user_message (puser, MUSER | MERROR, "You cannot change your own rank.");
        return;
    }

    if (!rank_struct_promote_limits (puser->rank, &rerank_max)) {
        user_message (puser, MUSER, "Your rank does not allow promoting.");
        return;
    }
    printf ("%i:%i\n", rank_id_by_name (puser->rank->name) , rank_id_by_name (duser->rank->name));

    if (rank_id_by_name (puser->rank->name) <= rank_id_by_name (duser->rank->name)) {
        user_message (puser, MUSER, "Your rank prevents you from promoting someone to that rank.");
        return;
    }

    _strncpy (duser->rank_name, rank[rank_id].name, 25);
    duser->rank = &rank[rank_id];

    user_message (duser, MUSER, "Your rank has been changed to %s.", duser->rank_name);
    user_message (puser, MUSER, "%s's rank has been changed to %s.", duser->name, duser->rank_name);

    log_printf (puser, LNOTE, "%s changed %s's rank to %s", puser->name, duser->name, duser->rank->name);

    user_record_save (duser, duser->uid);
    
    user_send_player_abilities (duser, 1);
}

int user_name_by_id (struct map *pmap, char *name, int id) {
	if (id < 1) return (0);
	struct user duser;
	
	if (id == 0) return (0);
    duser.map = pmap;
	
    if (!user_record_load (&duser, id)) {
		log_printf (NULL, LWARNING, "User record for id %i not available", id);
		sprintf (name, "ID %i", id);
		
		return (1);
	}
	log_printf (NULL, LDEBUG, "user_name_by_id: id %i is %s", id, duser.name);
	_strncpy (name, duser.name, 24);
	return (1);
}

int user_id_by_name (struct map *pmap, char *name, int *id) {
    struct user *p;
    *id = 0;
    p = user_connected_find_by_name (name);
    if (p != NULL) {
        *id = p->uid;
        return (1);
    }
	if (pmap == NULL) pmap = &map_array[0];
    
    char file_temp[PATH_MAX];
    snprintf (file_temp, PATH_MAX, "%s/%s", PATH_USERS, "user.txt");

    FILE *fn1;
    fn1 = fopen (file_temp, "rb");
    if (fn1 == 0) return (0);
    
    char buffer[1024];
    char *args[16];

    while (fgets (buffer, 1024, fn1)) {
        char *cp = strrchr (buffer, '\r'); if (cp != NULL) *cp = 0;
        cp = strrchr (buffer, '\n'); if (cp != NULL) *cp = 0;
        int num = csv_parse (buffer, ',', args, 16);
        if (num < 2) {
            log_printf (NULL, LDEBUG, "user_id_by_name: invalid number of arguments");
            continue;
        }
        
        if (strcasecmp (args[1], name) != 0) continue;
        *id = atoi (args[0]);
        break;
    }
    fclose (fn1);
    
    if (*id != 0) return (1);
    return (0);
}

int user_id_by_name_partial (struct map *pmap, char *name, int *id) {
    struct user *p;
    *id = 0;
    p = user_connected_find_by_name (name);
    if (p != NULL) {
        *id = p->uid;
        return (1);
    }
    _strlwr (name);
    char file_temp[PATH_MAX];
    snprintf (file_temp, PATH_MAX, "%s/%s", PATH_USERS, "user.txt");

    FILE *fn1;
    fn1 = fopen (file_temp, "rb");
    if (fn1 == 0) return (0);
    
    char buffer[1024];
    char *args[16];

    while (fgets (buffer, 1024, fn1)) {
        char *cp = strrchr (buffer, '\r'); if (cp != NULL) *cp = 0;
        cp = strrchr (buffer, '\n'); if (cp != NULL) *cp = 0;
        int num = csv_parse (buffer, ',', args, 16);
        if (num < 2) {
            log_printf (NULL, LDEBUG, "user_id_by_name: invalid number of arguments");
            continue;
        }
        _strlwr (args[1]);
        if (strstr (args[1], name) == 0) continue;
        *id = atoi (args[0]);
        break;
    }
    fclose (fn1);
    
    if (*id != 0) return (1);
    return (0);
}

int user_ip_is_banned (struct map *pmap, char *ip_address) {
    int ret = 0;    

    char file_temp[PATH_MAX];
    snprintf (file_temp, PATH_MAX, "%s/%s", PATH_USERS, "user.txt");

    FILE *fn1;
    fn1 = fopen (file_temp, "rb");
    if (fn1 == 0) return (0);
    
    char buffer[1024];
    char *args[16];

    while (fgets (buffer, 1024, fn1)) {
        char *cp = strrchr (buffer, '\r'); if (cp != NULL) *cp = 0;
        cp = strrchr (buffer, '\n'); if (cp != NULL) *cp = 0;
        int num = csv_parse (buffer, ',', args, 16);
        if (num < 8) {
            log_printf (NULL, LDEBUG, "user_id_by_name: invalid number of arguments");
            continue;
        }
        if (strcasecmp (args[8], ip_address) == 0 && atoi (args[7]) == 1) {
            ret = 1;
            break;
        }
    }
    fclose (fn1);

    return (ret);
}

int user_is_ignored (struct user *ignorer, int annoyance_uid) {
	int a;
   // struct user * v = user_connected_find_by_id (annoyance_uid);
	for (a = 1; a < NUM_USERS; a++) {
		if (ignorer->ignore_list[a] == annoyance_uid) return (1);
		//if (v != NULL) if (v->ignore_list[a] == ignorer->uid) return (1);        

	}
	return (0);
}

void user_ignore_add (struct user *ignorer, int annoyance_uid) {
	int a;
	for (a = 1; a < NUM_USERS; a++) {
		if (ignorer->ignore_list[a] == -1) {
			ignorer->ignore_list[a] = annoyance_uid;
            struct user *duser = user_connected_find_by_id (annoyance_uid);
            if (duser != NULL) {
                packet_send (ignorer, PACKET_DENOUNCE_PLAYER, duser->idx);
//                packet_send (duser, PACKET_DENOUNCE_PLAYER, puser->idx);
            }
            
			break;
		}
	}
}

void user_ignore_remove (struct user *ignorer, int annoyance_uid) {
	int a;
	for (a = 1; a < NUM_USERS; a++) {
		if (ignorer->ignore_list[a] == annoyance_uid) {
			ignorer->ignore_list[a] = -1;
	
            struct user *duser = user_connected_find_by_id (annoyance_uid);
            if (duser != NULL) {
	            packet_send (ignorer, PACKET_ANNOUNCE_PLAYER, duser->idx, 9, duser->name);
                packet_send (duser, PACKET_ANNOUNCE_PLAYER, ignorer->idx, 9, ignorer->name);
            }
			break;
		}
	}
}

void user_map_switch (struct user *puser, char *name) {
    struct user updated_user;
    memmove (&updated_user, puser, sizeof (updated_user));
//    int old_violence = puser->map->violence;
    
    updated_user.map = map_struct_find_by_name (name);
    if (updated_user.map == NULL) {
        user_message (puser, MUSER, "no map named %s exists.", name);
        return;
    }
    
    if (puser->map != NULL) {
    	packet_broadcast (puser->map, USER_CONNECTED, puser, PACKET_DENOUNCE_PLAYER, puser->idx);    
		user_message_broadcast (puser, MSYSTEM, "%s is switching from map %s to %s.", puser->name,  puser->map->file, updated_user.map->file);
	}
    
    memmove (puser, &updated_user, sizeof (updated_user));

    puser->skin_id = skin_texture_find_id_by_name (puser->map->palette, puser->skin_name);    
	user_mode_set (puser, USER_NEW_MAP);    
    user_set_write_event (puser, user_send_map);    

    lua_hook_call ("mme_user_event_map_switch", puser);
	return;
}


void user_connection_history_initialize() {
	FILE *fn1;
	
	memset (&user_connection_history, 0, sizeof (user_connection_history));
	
	fn1 = fopen ("connection_history.bin", "rb");
	if (fn1 == 0) return;

	fread (&user_connection_history, sizeof (user_connection_history), 1, fn1);
	
	fclose (fn1);
	return;
}


void user_connection_history_update (char *name) {
	int a;
	if (name == NULL) {
		memset (&user_connection_history, 0, sizeof (user_connection_history));
		return;
	}
	
	int b;
	
	b = 1;
	
	_strncpy (user_connection_history_new[0].name, name, 24);
	time (&user_connection_history_new[0].t);
	
	for ( a = 0; a < NUM_HISTORY && b < NUM_HISTORY; a++) {
		if (user_connection_history[a].name[0] == 0) continue;
		if (strcasecmp (user_connection_history[a].name, name) == 0) continue;
		
		memmove (&user_connection_history_new[b], &user_connection_history[a], sizeof (struct user_connection_history));
	
		b++;
	}

	memmove (&user_connection_history, &user_connection_history_new, sizeof (user_connection_history));


	FILE *fn1 = fopen ("connection_history.bin", "wb");
	if (fn1 == 0) {
		log_printf (NULL, LERROR, "Cannot open connection_history.bin for writing: %s", strerror (errno));
		return;
	}
	fwrite (&user_connection_history, sizeof (user_connection_history), 1, fn1);
	fclose (fn1);
	return;
}


struct user * user_online_find_by_id (int id) {
    int a;
    
    for (a = 0; a < NUM_USERS; a++) {
        if (user[a].current_mode == USER_NOT_CONNECTED) continue;
        if (id == user[a].uid) return ((void *) &user[a]);
    }
    return (NULL);
}

// Not thread safe.
char *user_name (struct user *puser, int no_nicknames) {
	static char name[32];
	
	if (puser == &user[0] && puser->nick[0] != 0) return (puser->nick);	
	
	if (puser->nick[0] == 0 || no_nicknames) return (puser->name);
	snprintf (name, 32, "\x02%s", puser->nick);
	return (name);
}


void user_message_chat (struct user *puser, char *message) {

	if (!lua_hook_call ("mme_user_format_chat_message", puser, message)) {
       	user_message_broadcast (puser, MNULL, "\e%c%s\e\x09:\e\x09 %s", puser->color, user_name (puser, 0), message);
	}
	return;
}

int user_test_ignore (struct user *source_user, struct user *destination_user) {

	if (!rank_command_allowed (source_user->rank, "ignore")) return (0);
	if (rank_command_allowed (destination_user->rank, "kick") ||
			rank_command_allowed (destination_user->rank, "ban") ||
			rank_command_allowed (destination_user->rank, "ipban") ||
			rank_command_allowed (destination_user->rank, "rank")) {
			
		return (0);
	}
	return (1);
}

void user_afk_toggle (struct user *puser, char *message) {
    if (puser->afk) user_afk_clear (puser, message);
    else user_afk_set (puser, message);
}


void user_afk_set (struct user *puser, char * message) {
    if (!puser->afk) event_user_is_afk (puser, message);
    puser->afk = 1;
	return;
}

void user_afk_clear (struct user *puser, char *message) {
    if (puser->afk) event_user_not_afk (puser, message);
    puser->afk = 0;
	return;
}

struct iptable {
	char ip[64];
	char name[25];
};

void user_iptable_update (struct user *puser) {
	FILE *fn1;
	struct stat st;
	struct iptable *iptable;
	unsigned int num_iptables = 0;
	if (puser->uid == 0) return ;
	
	iptable = _malloc (sizeof (struct iptable));

	fn1 = fopen ("iplist.dat", "rb");
	if (fn1 != 0) {
		fstat (fileno (fn1), &st);
		// This looks crazy, but ensures that a corrupt file doesn't cause a
		// buffer overflow.
		num_iptables = (st.st_size / sizeof (struct iptable));
		size_t alloc_size = st.st_size * (num_iptables + 2);
		
		iptable = _realloc (iptable, alloc_size);
	
		fread (iptable, sizeof (struct iptable) * num_iptables, 1, fn1);
		fclose (fn1);	
	}
	int a;
	
	for (a = 0; a < num_iptables; a++) {
		if (strcmp (iptable[a].name, puser->name) == 0 && strcmp (iptable[a].ip, puser->ip_address) == 0) break;
	}	

	if (a == num_iptables) {
		_strncpy (iptable[a].name, puser->name, 25);
		_strncpy (iptable[a].ip, puser->ip_address, 64);
		num_iptables++;
		
		fn1 = fopen ("iplist.dat", "r+b");
		if (fn1 == 0) {
			fn1 = fopen ("iplist.dat", "wb");
			if (fn1 == 0) log_printf (puser, LWARNING, "user_iptable_update: Unable to open iplist.dat for writing: %s", strerror (errno));
		}
		if (fn1 != 0) {
			fwrite (iptable, num_iptables, sizeof (struct iptable), fn1);
		
			fclose (fn1);
		}
		
	}
	
	_free (iptable);
	return;
}	

int user_ip_lookup (struct user *puser, char **out) {
	if (puser->uid == 0) return (0);
	FILE *fn1;
	struct stat st;
	struct iptable *iptable;
	unsigned int num_iptables = 0;
	

	fn1 = fopen ("iplist.dat", "rb");
	if (fn1 != 0) {
		fstat (fileno (fn1), &st);
		// This looks crazy, but ensures that a corrupt file doesn't cause a
		// buffer overflow.
		num_iptables = (st.st_size / sizeof (struct iptable));
		size_t alloc_size = st.st_size * (num_iptables + 2);
		
		iptable = _malloc (alloc_size);
	
		fread (iptable, sizeof (struct iptable) * num_iptables, 1, fn1);
		fclose (fn1);	
	} else {
		return (0);
	}


	// This is also somewhat crazy, but gets around using realloc.
	// Why no realloc?  Appending without strcat by using a pointer
	// and not having realloc() change our memory address in the middle
	// of it.  ...And not having a limited length for the name list.
	// Yeah, that's a good reason, too.
	// If you want to be special, make an array of pointers to the 
	// matches so that you don't have to strcmp() everything again. 
	int a;
	int count = 0;
	for (a = 0; a < num_iptables; a++) {
		if (strcmp (iptable[a].ip, puser->ip_address) == 0 && strcmp (iptable[a].name, puser->name) != 0) count++;
	}
	*out = NULL;
	
	if (count > 0) {
		char *list = _malloc (32 * count);
		char *cp = list;

		for (a = 0; a < num_iptables; a++) {
			if (strcmp (iptable[a].ip, puser->ip_address) == 0 && strcmp (iptable[a].name, puser->name) != 0 ) {
				strcpy (cp, iptable[a].name);
				int len = strlen (iptable[a].name);
				cp[len + 0] = ',';
				cp[len + 1] = ' ';
				cp[len + 2] = 0;
				
				cp += len + 2;
			}
		}

		int len = strlen (list);
		list[len - 2] = 0;  // Eat that comma/space off the end.  
		*out = list;
	}

	_free (iptable);

	return (count);
}
	
void user_damage (struct user *shooter, struct user *victim, int damage) {
//    printf ("%s shot %s\n", shooter->name, victim->name);


    user_message (victim, MUSER, "You have taken %i points of damage! (%i/100 remain)", damage, victim->hitpoints);
    victim->hitpoints -= damage;
	if (victim->hitpoints < 1) 
	    user_message_broadcast (NULL, MSYSTEM, "%s has killed %s", shooter->name, victim->name);    	
}

void user_dead_test (struct user *puser) {
    if (puser->hitpoints <= 0 && !puser->dead) {
        puser->hitpoints = 0;
        puser->dead = 1;
        menu_killed_dialog (puser, MENU_CREATE);			
    }
}	
/*

void user_renegotiate_packets (struct user *puser, 
set_default_receivable_packets (puser->receivable_packets);    
	    packet_set_available (puser->receivable_packets, PACKET_PROJECTILE_COLLISION);
	    packet_set_available (puser->receivable_packets, PACKET_PROJECTILE_CREATE);
        packet_send(puser, PACKET_SELECT_PACKET_TYPES, puser->receivable_packets);
    } else if (old_violence && !puser->map->violence) {
        set_default_receivable_packets (puser->receivable_packets);
        packet_send(puser, PACKET_SELECT_PACKET_TYPES, puser->receivable_packets);
*/


void user_mail_display (struct user *puser) {
	FILE *fn1;
	char temp[1024];
	char buffer[68700];

	sprintf (temp, "%s/%i", PATH_PRIVATE_MAIL, puser->uid);
	char *args[4], *cp;
	
	fn1 = fopen (temp, "rb");
	if (fn1 == 0) {
		return;
	}
	
	while (fgets (buffer, 65536, fn1)) {
		cp = strchr (buffer, '\r'); if (cp != 0) *cp = 0;
		cp = strchr (buffer, '\n'); if (cp != 0) *cp = 0;		
	
		csv_parse (buffer, '\x01', args, 3);
		time_t v = atol (args[0]);
		

		if (v > puser->last_login_stamp) {
			char the_time_ago[128];
			time_t t;
			time (&t);
			
			time_ago (v, t, the_time_ago);
		
			user_message (puser, MUSER, "\e\x04(pm:\e\x08%s\e\x04) %s:\e\x02 %s", the_time_ago, args[1], args[2]);
		
		}
	}
	fclose (fn1);

}


static int ip_banned (char *test_ip) {
    FILE *fn1;
    char temp[128], *cp;
    int ret = 0;
    
    fn1 = fopen ("ip_banned.txt", "rb");
    if (fn1 == 0) {
        log_printf (NULL, LNOTE, "Can't open ip_banned.txt: %s", strerror (errno));
        return (0);
    }
    
    while (fgets (temp, 127, fn1)) {
        cp = strchr (temp, '\r'); if (cp !=0) *cp = 0;
        cp = strchr (temp, '\n'); if (cp !=0) *cp = 0;
        strim ("lr", temp);

        if (temp[0] == '#') continue;
        if (strcasecmp (temp, test_ip) == 0) {ret = 1; break;}
        //if (socket_ipv4_address_match (temp, test_ip)) {ret = 1; break;}
    }
    fclose (fn1);
    return (ret);
}
