/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"

struct d_menu_skin_manager {
	int name;
	int value;
	int skin[255];
	int skin_count;
	int offset;
};

int menu_skin_manager (struct user *puser, int message_id) {
   	int a, b;
	struct d_menu_skin_manager *d;
	int line;
	int index = 1;
	
	d = menu_get_current_stack_item_memory (puser);

	switch (message_id) {
	case MENU_CREATE:
		d = menu_stack_push_init (puser, menu_skin_manager, NULL, sizeof (struct d_menu_skin_manager));
		d->offset = 0;
		d->skin_count = 0;
		for (a = 0; a < NUM_SKINS; a++) {
			if (!puser->map->palette->skin[a].visible ) continue;
			d->skin[d->skin_count] = a;
			d->skin_count ++;
		}

	case MENU_DRAW:
		index = 1;
		unsigned char flag;
        packet_send(puser, PACKET_MENU_RESET, 0, 60, 20, 3); 
        packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 0, "Skin Manager");
        packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 2, "Pick a skin from the list");		
		line = 4;
		
		if (d->skin_count - d->offset < 15) b = d->skin_count - d->offset;
		else b = 15;
		
		for (a = 0; a < b; a++) {
			int v = d->skin[a + d->offset];
        	if (!puser->map->palette->skin[v].visible ) continue;
			flag = (1 << 1);
			if (puser->map->palette->skin[v].texture->id == puser->skin_id && puser->skin_id != 0) {
				flag |= (1 << 0);
			} else if (v == 0 &&  (puser->skin_id == 0 || puser->skin_id == -1))
							flag |= (1 << 0);
			
			packet_send(puser, PACKET_MENU_RADIO, index++, 3, line++, 3, a, flag, puser->map->palette->skin[v].name);    
		}
		flag = (1 << 1);
		
		if (puser->skin_name[0] == 0 || puser->skin_id == 0) {
			packet_send(puser, PACKET_MENU_TEXT, index++, 30, 5, "\e\x01No preview available");			
		} else if (!packet_is_sendable (PACKET_PLAYER_PROPERTIES, puser->sendable_packets)) {
			packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 1, "\e\x0bYou must upgrade your client to see skins!");			
	    } else if (!packet_is_sendable (PACKET_MENU_TEXTURE, puser->sendable_packets)) {
			packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 1, "\e\x0bUpgrade your client to preview skins!");	
		} else {
			packet_send(puser, PACKET_MENU_TEXTURE, index++, 40, 5, 15, 15, puser->skin_id, 0, 128, 64, 255);
		}
		
		if (d->skin_count >= 15) {
			packet_send(puser, PACKET_MENU_LINK, index++, 34, 19, 1, 2, 0, "[ next ]");
			packet_send(puser, PACKET_MENU_LINK, index++, 12, 19, 1, 1, 0, "[ previous ]");
		}
		break;
		
	case MENU_COMMAND: {
		int menu_number = -1;
		int menu_name = -1;
		int menu_value = -1;
		int menu_flags = -1;
		unsigned char menu_char[65535]; 
		
		menu_command_parse (puser, &menu_number, &menu_name, &menu_value, &menu_flags, menu_char);
		
		if (menu_name == 1) {
			if (menu_value == 1 && d->offset > 0) d->offset -= 15;
			if (menu_value == 2 && d->offset < d->skin_count - 15) d->offset += 15;
			menu_proc (puser, MENU_DRAW);
		} else if (menu_name == 3) {
			if (menu_value == 0) {
				puser->skin_id = 0;
				puser->skin_name[0] = 0;
		    	packet_broadcast (puser->map, USER_CONNECTED, puser, PACKET_PLAYER_PROPERTIES, puser->idx, -1);				
			} else {
				if (menu_value < NUM_SKINS &&  puser->map->palette->skin[menu_value].visible) {
					_strncpy (puser->skin_name, puser->map->palette->skin[menu_value].name, 32);
					puser->skin_id = puser->map->palette->skin[menu_value].texture->id;
			    	packet_broadcast (puser->map, USER_CONNECTED, puser, PACKET_PLAYER_PROPERTIES, puser->idx, puser->skin_id);
				}
			}
			menu_proc (puser, MENU_DRAW);
		} else {
			menu_stack_pop (puser);
		}
		break;}	
	}
	return (1);		
}
