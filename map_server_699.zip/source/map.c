/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"

void finite_flow_add (int x, int y, int z) ;

struct d_map_compress_send {
	z_stream strm;
	char compressed_data[65536];
	size_t size; 
	size_t uncompressed_size;
	size_t uncompressed_offset;
	size_t block_size;
	int zlib_active;
	int percent;
} d_map_compress_send[NUM_USERS];


void finite_list_add (struct map *pmap, int x, int y, int z) ;
int map_check_bounds (struct map *pmap, int x, int y, int z) {
  if (x < 0 || x >= pmap->dimension.x) return(0);
  if (y < 0 || y >= pmap->dimension.y) return(0);
  if (z < 0 || z >= pmap->dimension.z) return(0);
  return (1);
}

unsigned char * map_get_block_pointer (struct map *pmap, int x, int y, int z) {
	if (!map_check_bounds (pmap, x, y, z)) return (0);  
    return ( (unsigned char *)&BLOCK (pmap, x, y, z));
}

int map_modify (struct map *pmap, struct short_xyz c, int t) {
    if (!map_check_bounds (pmap, c.x, c.y, c.z)) return (0);  
	map_set_modified (pmap, c.x, c.y);

	BLOCK(pmap, c.x, c.y, c.z) = t;
    return (1);
}

int map_modify_fill (struct user *puser, struct short_xyz start, struct short_xyz finish, int t) {
	map_set_modified (puser->map, start.x, start.y);

	int x, y, z;
	
	for (z = start.z; z <= finish.z; z++) {
		for (x = start.x; x <= finish.x; x++) {
			for (y = start.y; y <= finish.y; y++) {
				map_undo_log (puser, x, y, z, (unsigned char)BLOCK (puser->map, x, y, z));
				BLOCK (puser->map, x, y, z) = t;
				if (t == 255) puser->blocks_removed++; else puser->blocks_placed++;
			}
		}
	}	
	return (1);
}

int map_get(struct map *pmap, struct short_xyz c) {
    if (!map_check_bounds (pmap, c.x, c.y, c.z)) return 256 + (c.z < pmap->sealevel);
    return ((unsigned char)BLOCK (pmap, c.x, c.y, c.z));
}


int map_load_file (struct map *pmap, char *file_name) {
	FILE *fn1;
	struct stat st;

   	char file_temp[PATH_MAX];	
	
	if (pmap->area_map) {
		snprintf (file_temp, PATH_MAX, "%s/%s/properties", PATH_AREAS, file_name);
	} else {
    	snprintf (file_temp, PATH_MAX, "%s/%s", PATH_MAPS, file_name);
	}

	if (stat (file_temp, &st)!=0) {
		//log_printf (NULL, LERROR, "can't stat map file [%s]", file_temp);
		return (0);
	}

	fn1=fopen (file_temp, "rb");
	if (fn1==0) {
		//log_printf (NULL, LERROR, "can't open map file [%s]", file_temp);
		return (0);
	}
	
    _strncpy (pmap->file, file_name, 256);

	unsigned char id;
	char name[256];
	char *data = _malloc (BTR_MEMORY_BLOCK);
	size_t data_length = 0;
	
	pmap->build_rank_name[0] = 0;
	pmap->block_palette_name[0] = 0;
	if (pmap->data != 0) _free (pmap->data);
	pmap->data = NULL;
	pmap->scale = 666.0;
	fread (name, 4, 1, fn1);
	if (name[0] == 'B' && name[1] == 'T' && name[2] == 'R' && name[3] == 0) {
		while (btr_file_read_serial (fn1, &id, name, &data, &data_length)) {
			if (strcmp (name, "minimum_build_rank_name") == 0 && id == BTR_STRING) _strncpy (pmap->build_rank_name, data, 32);
			else if (strcmp (name, "block_palette_name") == 0 && id == BTR_STRING) _strncpy (pmap->block_palette_name, data, 32);
			else if (strcmp (name, "scale") == 0 && id == BTR_FLOAT) memmove (&pmap->scale, data, sizeof (float));
			else if (strcmp (name, "dimension_x") == 0 && id == BTR_SHORT) memmove (&pmap->dimension.x, data, sizeof (short));
			else if (strcmp (name, "dimension_y") == 0 && id == BTR_SHORT) memmove (&pmap->dimension.y, data, sizeof (short));
			else if (strcmp (name, "dimension_z") == 0 && id == BTR_SHORT) memmove (&pmap->dimension.z, data, sizeof (short));
			else if (strcmp (name, "sealevel") == 0 && id == BTR_SHORT) memmove (&pmap->sealevel, data, sizeof (short));
			else if (strcmp (name, "dirt_block") == 0 && id == BTR_SHORT) memmove (&pmap->dirt_block, data, sizeof (short));		
			else if (strcmp (name, "grass_block") == 0 && id == BTR_SHORT) memmove (&pmap->grass_block, data, sizeof (short));
			else if (strcmp (name, "violence") == 0 && id == BTR_BYTE) memmove (&pmap->violence, data, 1);
			else if (strcmp (name, "area_num_x") == 0 && id == BTR_SHORT) memmove (&pmap->area_num_x, data, sizeof (short));
			else if (strcmp (name, "area_num_y") == 0 && id == BTR_SHORT) memmove (&pmap->area_num_y, data, sizeof (short));
			else if (strcmp (name, "area_border_size") == 0 && id == BTR_SHORT) memmove (&pmap->area_border_size, data, sizeof (short));
			else if (strcmp (name, "area_x") == 0 && id == BTR_SHORT) memmove (&pmap->area_x, data, sizeof (short));
			else if (strcmp (name, "area_y") == 0 && id == BTR_SHORT) memmove (&pmap->area_y, data, sizeof (short));
			else if (!pmap->area_map && strcmp (name, "spawn") == 0 && id == BTR_FLOAT) memmove (&pmap->spawn, data, sizeof (struct float_xyzuv));
			else if (!pmap->area_map && strcmp (name, "map_journal") == 0 && id == BTR_BYTE) memmove (&pmap->map_journal, data, 1);
			else if (!pmap->area_map && strcmp (name, "data") == 0 && id == BTR_BYTE) {
				if (pmap->data != NULL) _free (pmap->data);
				pmap->data = data;
				data = _malloc (4096);
			} else {
				log_printf (NULL, LDEBUG, "map_load_file: unknown variable %s has been skipped.", name);
			}
		}
	} else {
		log_printf (NULL, LWARNING, "Old map format: Will be converted when saved.");
		fseek (fn1, 0, SEEK_SET);
		
		struct map_file_header header;
		fread (&header, sizeof (struct map_file_header), 1, fn1);
		pmap->dimension.x = header.dimension.x;
		pmap->dimension.y = header.dimension.y;
		pmap->dimension.z = header.dimension.z;
		if (pmap->dimension.x < 0 || pmap->dimension.x > 32767 ||
		pmap->dimension.y < 0 || pmap->dimension.y > 32767 ||
		pmap->dimension.z < 0 || pmap->dimension.z > 32767) {
			log_printf (NULL, LERROR, "Map %s dimensions are funky. [%ix%ix%i]", pmap->file, pmap->dimension.x, pmap->dimension.y, pmap->dimension.z);
			return (0);
		}
		
		log_printf (NULL, LDEBUG, "Map dimensions: [%ix%ix%i]", pmap->dimension.x, pmap->dimension.y, pmap->dimension.z);

		pmap->data_size= (size_t) pmap->dimension.x * pmap->dimension.y * pmap->dimension.z;
		
		pmap->data = _malloc (pmap->data_size);
		if (fread (pmap->data, 1, pmap->data_size, fn1) != pmap->data_size) {
            log_printf (NULL, LWARNING, "map_load_file: %s's size does not match the map dimensions.", pmap->file);
        }
	}
	
	fclose (fn1);	
	_free (data);
	
	pmap->area_data_size = (size_t) (pmap->area_x * pmap->area_y * pmap->dimension.z);
	pmap->area_num_total = pmap->area_num_x * pmap->area_num_y;
	
	if (pmap->dirt_block < 1 || pmap->dirt_block >= 255) pmap->dirt_block = 1;
	if (pmap->grass_block < 1 || pmap->grass_block >= 255) pmap->grass_block = 1;
	if (pmap->border_block < 1 || pmap->border_block >= 255) pmap->border_block = 1;
	
	if (pmap->area_map) {
		map_generate (pmap, 255, pmap->dirt_block, pmap->border_block);
	} else {
		if (pmap->data == NULL) {
			log_printf (NULL, LERROR, "Map has no data!");
			return (0);
		}
	}
	
    if (pmap->build_rank_name[0] == 0) {
        log_printf (NULL, LDEBUG, "Map %s does not have a minimum build rank", pmap->file);
        strcpy (pmap->build_rank_name, config.default_rank_name);
    }
    pmap->rank = rank_find_struct_by_name (pmap->build_rank_name);    
	
	if (pmap->block_palette_name[0] == 0) {
		strcpy (pmap->block_palette_name, "textures");
		log_printf (NULL, LWARNING, "Map [%s] did not specify a block palette.  Assigning 'textures'", pmap->file);
	}
	
	pmap->palette = texture_palette_load (pmap->block_palette_name);
	if (pmap->palette == NULL) {
        log_printf (NULL, LERROR, "No textures.");
        exit(0);
        
    }
    _strncpy (pmap->palette->path, pmap->block_palette_name, 256);
	
	pmap->data_size= (size_t) pmap->dimension.x * pmap->dimension.y * pmap->dimension.z;
	
	if (pmap->spawn.x == 0 && pmap->spawn.y == 0 && pmap->spawn.z == 0) {

		pmap->spawn.x=pmap->dimension.x / 2;
		pmap->spawn.y=pmap->dimension.y / 2;
		pmap->spawn.z=pmap->dimension.z - 16;
		log_printf (NULL, LDEBUG, "Map %s did not have valid spawn coordinates.  Fixed.", pmap->file);
	}
    
	if (!pmap->area_map) {
    	unsigned int damaged = 0;
    	int a;
    	for (a = 0; a < pmap->data_size; a++) {
        	if ((unsigned char)pmap->data[a] == 0) {
            	pmap->data[a] = 255;
            	damaged ++;
        	}
    	}

    	if (damaged > 0) log_printf (NULL, LERROR, "Map %s file had %u invalid blocks; they were converted to air.", file_name, damaged);
	}
	log_printf (NULL, LDEBUG, "Map [%s] is %ix%ix%i", pmap->file, pmap->dimension.x, pmap->dimension.y, pmap->dimension.z);	

    map_journal_open (pmap);
    	
	if (pmap->area_map) area_initialize (pmap);
	
	if (pmap->scale < 0.1 || pmap->scale > 1.0) {
		log_printf (NULL, LWARNING, "Map [%s] did not specify a scale; defaulting to 0.1", pmap->file);
		pmap->scale = 0.1;
	}
//	finite_flow_init (pmap);


    pmap->active = 1;
	return (1);
}

int map_generate (struct map *pmap, int air, int dirt, int grass) {
	if (!pmap->area_map) log_printf (NULL, LNOTE, "Creating map file '%s' [%ix%ix%i]", pmap->file, pmap->dimension.x, pmap->dimension.y, pmap->dimension.z );
    else log_printf (NULL, LNOTE, "Allocating area map '%s' [%ix%ix%i]", pmap->file, pmap->dimension.x, pmap->dimension.y, pmap->dimension.z );
	pmap->data_size= (size_t) pmap->dimension.x * pmap->dimension.y * pmap->dimension.z;

	pmap->data = _malloc (pmap->data_size);

	memset (pmap->data, air, pmap->data_size);

	char *cp;
	cp = pmap->data;
	int z;
	size_t layer_size =(size_t) pmap->dimension.x * pmap->dimension.y;

	for (z = 0; z < pmap->sealevel - 1; z++) {
		memset (cp, dirt, layer_size);
		cp += layer_size;
	}

	memset (cp, grass, layer_size);

	map_set_modified (pmap, 0, 0);

	map_save (pmap);

	time (&pmap->last_save);

	return (1);
}

void map_initialize() {

	memset (&d_map_compress_send, 0, sizeof (d_map_compress_send));
    memset (&map_array, 0, sizeof (map_array));
	memset (&flow_array, 0, sizeof (flow_array));
    int a;
    for (a = 0; a < NUM_MAPS; a++) {
        map_array[a].id = a;
        map_array[a].scale = 0.1;
    }
}

void map_compress_send_thread (struct user *puser) {
    map_compress_send_internal (puser, 1);
    while (!map_compress_send_internal (puser, 0)) {
        #ifdef WIN32
            Sleep (1);
        #else 
            usleep (1);
        #endif
    }
    puser->waiting_for_map = 0;
}

int map_compress_send (struct user *puser, int init) {
	if (init) {
    
        puser->waiting_for_map = 1;
        thread_create (map_compress_send_thread, puser);
        return (0);
    }
    if (puser->waiting_for_map == 0) return (1);
    else return (0);
    
}
void map_compress_deallocate (struct user *puser) {
	struct d_map_compress_send *d;
	d = &d_map_compress_send[puser->idx];

	if (d->zlib_active) {
		d->zlib_active = 0;
		deflateEnd(&d->strm);
		log_printf (puser, LERROR, "Deallocated!");
	}
}

static char *str_map_loading = "Loading the map..";

int map_compress_send_internal (struct user *puser, int init) {
	struct d_map_compress_send *d;
	int zret;
	int ret = 0;

	if (puser->idx < 0) {
        log_printf (puser, LERROR, "negative player id given to map_compress_send");
		easy_die (NULL, 1);
	}
	
	d = &d_map_compress_send[puser->idx];

	if (init) {
		#ifdef WIN32
		SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_LOWEST);
		#else
		struct sched_param my_param;
		my_param.sched_priority = sched_get_priority_min(SCHED_OTHER);
		pthread_setschedparam(pthread_self(), SCHED_OTHER, &my_param);
		#endif
		
		d->percent = 0;
        if (d->zlib_active) {
			d->zlib_active = 0;
            deflateEnd(&d->strm);
        }
        
		d->zlib_active = 1;
		
        packet_send(puser, PACKET_MAP_LOADING, 0, str_map_loading);
	
		log_printf (puser, LDEBUG, "compress: Begin initialization; map [%s] is %ix%ix%i ", puser->map->file, puser->map->dimension.x, puser->map->dimension.y, puser->map->dimension.z);

		d->strm.zalloc = Z_NULL;
		d->strm.zfree = Z_NULL;
		d->strm.opaque = Z_NULL;

		d->uncompressed_size = (size_t)puser->map->dimension.x * puser->map->dimension.y * puser->map->dimension.z;
		
		d->block_size = 16384;
		log_printf (puser, LDEBUG, "compressed block size = %zu, total data size = %zu", d->block_size, d->uncompressed_size);
		
		if (d->uncompressed_size == 0) {    
            log_printf (puser, LERROR, "uncompressed size calculation error");
       		easy_die (NULL, 1);
        }

		d->uncompressed_offset = 0;

		zret = deflateInit(&d->strm, Z_DEFAULT_COMPRESSION);
		if (zret != Z_OK) {
			log_printf (puser, LERROR, "Zlib compression failure");

			user_mode_set (puser, USER_DISCONNECT);
			ret = -1; goto end;
		}

		packet_send (puser, PACKET_MAP_TOTAL_RESET);
        packet_send (puser, PACKET_MAP_SETUP, puser->map->dimension.x, puser->map->dimension.y, puser->map->dimension.z, puser->map->sealevel);		
        
    	if (puser->map->area_map) area_player_locate (puser, area_for_player (puser));
    	else user_spawn (puser, puser->map->spawn);    


        
        packet_send (puser, PACKET_MAP_PROPERTIES, 0, puser->map->scale);
            
		ret = 0; goto end;
	}

	
	redo:;
    
	float f;	
	f = d->uncompressed_offset * 255.0;
	f /= d->uncompressed_size;

	if ((int)f - d->percent >= 1) {
        packet_send(puser, PACKET_MAP_LOADING, (unsigned char) d->percent, str_map_loading);
		d->percent = f;
	}
	
	unsigned int next_block_size = d->block_size;
	if (d->block_size + d->uncompressed_offset > d->uncompressed_size)
		next_block_size =(size_t) d->uncompressed_size - d->uncompressed_offset;
	
	d->strm.avail_in = next_block_size;
	d->strm.next_in = (unsigned char *)&puser->map->data[d->uncompressed_offset];
	
	int finish;
	if (d->uncompressed_offset >= d->uncompressed_size) {
		finish = Z_FINISH;
		log_printf (puser, LDEBUG, "* finish");
	} else {
		finish = Z_NO_FLUSH;
	}
	
	int data_sent = 0;
	do  {
        if (puser->current_mode == USER_NOT_CONNECTED || puser->current_mode == USER_DISCONNECT ) {
			log_printf (puser, LDEBUG, "user died!");
			d->strm.avail_out = 0;
			zret = Z_STREAM_END;
            break;
        }
			
		d->strm.avail_out = d->block_size;
		d->strm.next_out = (unsigned char *)d->compressed_data;

		zret = deflate(&d->strm, finish);
		if (zret == Z_STREAM_ERROR) {
			log_printf (puser, LERROR, "compress: stream error");
			ret = -1; goto end;
		}

		int have = d->block_size - d->strm.avail_out;
	
		if (have != 0) {
			log_printf (puser, LDEBUG, "Send Map data %i", have);
    		packet_send (puser, PACKET_MAP_TOTAL_DATA, d->compressed_data, have);
			data_sent += have;
		}
	
	
	} while ( d->strm.avail_out == 0);
	
	if (zret == Z_STREAM_END) {
		log_printf (puser, LDEBUG, "Stream end");
		ret = 1; goto end;
	}
	d->uncompressed_offset+= next_block_size;
	if (data_sent == 0) goto redo;
	end:
	
	if (ret == 1 || ret == -1) {
		if (d->zlib_active) deflateEnd(&d->strm);
		d->zlib_active = 0;
		if (ret == -1) ret = 1;			
	}
	
	return (ret);
}

int client_modify_test (struct user *puser, const struct map_modify *pmodify, char *err) {
	int ret = 1;

    if ((puser->map->palette->block[pmodify->type].name[0] == 0 && pmodify->type != 255) || pmodify->type == 0) {
        log_printf (puser, LWARNING, "Attempted to place invalid block: %i", pmodify->type);
        _strncpy (err, "You are not permitted to place that block.", 64);
        ret = 0;
    } else if (!map_check_bounds (puser->map, pmodify->x, pmodify->y, pmodify->z)) {
        ret = 0;
        _strncpy (err, "You cannot place blocks outside of the map boundries.", 64);

    } else if (!rank_compare_by_name_ge (puser->rank->name, puser->map->palette->block[pmodify->type].min_rank)) {
        _strncpy (err, "You are not permitted to place that block.", 64);
        ret = 0;
        


    } else if (lua_hook_call ("mme_user_map_modify_allow", puser, pmodify->x, pmodify->y, pmodify->z, pmodify->type, pmodify->who)) {  
        ret = 0;
	}
	
	if (puser->map->area_map) {
		if (!area_modify_test (puser, pmodify->x, pmodify->y, pmodify->z, err)) ret = 0;
	} else {
		if (puser->rank->id < puser->map->rank->id) {
       		strcpy (err, "You do not have sufficient rank to build here.");
	        ret = 0;
		}
    }
	
	if (ret != 0) {
	    if ((unsigned char)BLOCK (puser->map, pmodify->x, pmodify->y, pmodify->z) == pmodify->type) ret = 2;
	}
    return (ret);

}

int modify_client_map (struct user *puser, struct map_modify *pmodify, int damage_flag) {
	int old;

    strcpy (puser->error_message, "You are not allowed to build here.");
    
	if (puser->map->area_map) 
		strcpy (puser->error_message, "You are not allowed to build here.\nPress F2 and click on \"Go to my area\" to go to your area.");

    if (pmodify->x < 0 || pmodify->x >= puser->map->dimension.x) return (0);
    if (pmodify->y < 0 || pmodify->y >= puser->map->dimension.y) return (0);
    if (pmodify->z < 0 || pmodify->z >= puser->map->dimension.z) return (0);

	old =(unsigned char) BLOCK (puser->map, pmodify->x, pmodify->y, pmodify->z);
    if (pmodify->type == 0) {
		pmodify->type = old;
	}
    
	if (puser->who && puser->map->map_journal && !damage_flag && !puser->map->area_map) {
        packet_send (puser, PACKET_MAP_MODIFY, pmodify->x, pmodify->y, pmodify->z, old, 0);
		map_journal_get (puser->map, pmodify->x, pmodify->y, pmodify->z, &puser->journal_data);
		menu_journal_dialog (puser, MENU_CREATE);
		return (1);
	}    
	
	if (puser->flow_block && !damage_flag) {	
		if (pmodify->type != 255) map_flow_start (puser, pmodify->x, pmodify->y, pmodify->z, pmodify->type, puser->flow_block, puser->uid);
		else user_message (puser, MUSER, "Flow canceled.");
		puser->flow_block = 0;		
		return (1);	
	}
    
    if (!client_modify_test (puser, pmodify, puser->error_message)) {
		old = (unsigned char)BLOCK (puser->map, pmodify->x, pmodify->y, pmodify->z);
        
        packet_send (puser, PACKET_MAP_MODIFY, pmodify->x, pmodify->y, pmodify->z, old, 0);
        	
		if (easy_time() - puser->last_map_error_stamp >= 1 && !damage_flag) {
		
        	if (puser->map->area_map) 
            	menu_area_dialog (puser, MENU_CREATE, area_in (puser->map, pmodify->x, pmodify->y));
        	else 
            	menu_dialog (puser, MENU_CREATE, "Block Placement", puser->error_message, "OK");

        }
        puser->last_map_error_stamp = easy_time();      
			
		return (1);
    }
    
    if (puser->map->area_map) {
		int a;
		a = area_in (puser->map, pmodify->x, pmodify->y);
		if (a != -1) puser->map->area[a].modify ++;
	}    
	if (pmodify->type == 255) puser->blocks_removed++; else puser->blocks_placed++;

	map_set_modified (puser->map, pmodify->x, pmodify->y);

  	map_journal_update (puser->map, puser->uid, pmodify->x, pmodify->y, pmodify->z, pmodify->type, old) ;

	BLOCK (puser->map, pmodify->x, pmodify->y, pmodify->z) = pmodify->type;

    packet_broadcast (puser->map, -1, NULL, PACKET_MAP_MODIFY, pmodify->x, pmodify->y, pmodify->z, pmodify->type, 0);

	map_undo_log (puser, pmodify->x, pmodify->y, pmodify->z, old);	
    
//    if (pmodify->type == 10) finite_flow_add (pmodify->x, pmodify->y, pmodify->z);

    return (1);
}



void map_disk_sync ( int dump) {
    struct map *pmap;
    int m;
    for (m = 0; m < NUM_MAPS; m++) {
        pmap = &map_array[m];
        if (!pmap->active) continue;
        if (pmap->save_counter == 0) continue;

        log_printf (NULL, LDEBUG, "save map %s", pmap->file);
        map_save (pmap);
        pmap->save_counter = 0;

        if (pmap->fn_journal) {
            fflush (pmap->fn_journal); 
            #ifdef LINUX
            fdatasync (fileno (pmap->fn_journal));
            #endif
        }
    }         
    return;
}

int map_area_save (struct map *pmap) {
	FILE *fn1;

	if (pmap->file[0] == 0) {
        log_printf (NULL, LERROR, "map_save: map filename missing");
        return (1);
    }
	
    char file_temp[PATH_MAX];
    char file_perminant[PATH_MAX];
    
    snprintf (file_temp, PATH_MAX, "%s/%s/.properties", PATH_AREAS, pmap->file);
    snprintf (file_perminant, PATH_MAX, "%s/%s/properties", PATH_AREAS, pmap->file);
 
	fn1 = fopen (file_temp, "wb");
	if (fn1 == 0 ) {
		log_printf (NULL, LERROR, "Can't save map file [%s]: %s", pmap->file, strerror (errno));
		return (0);
	}
	
	fwrite ("BTR\x00", 4, 1, fn1);

	btr_file_write_serial (fn1, BTR_STRING, "minimum_build_rank_name", pmap->build_rank_name, 0);	
	btr_file_write_serial (fn1, BTR_STRING, "block_palette_name", pmap->block_palette_name, 0);	
	btr_file_write_serial (fn1, BTR_FLOAT, "scale", (void *) &pmap->scale, sizeof (float));	
	btr_file_write_serial (fn1, BTR_FLOAT, "spawn", (void *) &pmap->spawn, sizeof (struct float_xyzuv));	
	btr_file_write_serial (fn1, BTR_SHORT, "dimension_x", (void *) &pmap->dimension.x, 0);	
	btr_file_write_serial (fn1, BTR_SHORT, "dimension_y", (void *) &pmap->dimension.y, 0);	
	btr_file_write_serial (fn1, BTR_SHORT, "dimension_z", (void *) &pmap->dimension.z, 0);	
	btr_file_write_serial (fn1, BTR_SHORT, "sealevel", (void *) &pmap->sealevel, 0);	
	btr_file_write_serial (fn1, BTR_SHORT, "dirt_block", (void *) &pmap->dirt_block, 0);	
	btr_file_write_serial (fn1, BTR_SHORT, "grass_block", (void *) &pmap->grass_block, 0);	
	btr_file_write_serial (fn1, BTR_SHORT, "area_num_x", (void *) &pmap->area_num_x, 0);	
	btr_file_write_serial (fn1, BTR_SHORT, "area_num_y", (void *) &pmap->area_num_y, 0);	
	btr_file_write_serial (fn1, BTR_SHORT, "area_border_size", (void *) &pmap->area_border_size, 0);		
	btr_file_write_serial (fn1, BTR_SHORT, "area_x", (void *) &pmap->area_x, 0);	
	btr_file_write_serial (fn1, BTR_SHORT, "area_y", (void *) &pmap->area_y, 0);	
    btr_file_write_serial (fn1, BTR_BYTE, "violence", (void *) &pmap->violence, 0);

	fclose (fn1);  
    
    file_replace (file_perminant, file_temp);
	
	return (1);
}

int map_save (struct map *pmap) {
    if (pmap->area_map) {
        area_sync (pmap);
		return (map_area_save (pmap));
    }

	FILE *fn1;
	
	pmap->data_size = pmap->dimension.x * pmap->dimension.y * pmap->dimension.z;

	if (pmap->file[0] == 0) {
        log_printf (NULL, LERROR, "map_save: map filename missing");
        return (1);
    }
    
    char file_temp[PATH_MAX];
    char file_perminant[PATH_MAX];
    
    snprintf (file_temp, PATH_MAX, "%s/.%s", PATH_MAPS, pmap->file);
    snprintf (file_perminant, PATH_MAX, "%s/%s", PATH_MAPS, pmap->file);
 
	fn1 = fopen (file_temp, "wb");
	if (fn1 == 0 ) {
		log_printf (NULL, LERROR, "Can't save map file [%s]: %s", pmap->file, strerror (errno));
		return (0);
	}
	
	if (!pmap->area_map && pmap->data == NULL) {
		log_printf (NULL, LERROR, "Map has no data!");
		return (0);
	}

	fwrite ("BTR\x00", 4, 1, fn1);	
	btr_file_write_serial (fn1, BTR_STRING, "minimum_build_rank_name", pmap->build_rank_name, 0);	
	btr_file_write_serial (fn1, BTR_STRING, "block_palette_name", pmap->block_palette_name, 0);	
	btr_file_write_serial (fn1, BTR_FLOAT, "scale", (void *) &pmap->scale, sizeof (float));	
	btr_file_write_serial (fn1, BTR_FLOAT, "spawn", (void *) &pmap->spawn, sizeof (pmap->spawn));	
	btr_file_write_serial (fn1, BTR_SHORT, "dimension_x", (void *) &pmap->dimension.x, 0);	
	btr_file_write_serial (fn1, BTR_SHORT, "dimension_y", (void *) &pmap->dimension.y, 0);	
	btr_file_write_serial (fn1, BTR_SHORT, "dimension_z", (void *) &pmap->dimension.z, 0);	
	btr_file_write_serial (fn1, BTR_SHORT, "sealevel", (void *) &pmap->sealevel, 0);	
	btr_file_write_serial (fn1, BTR_BYTE, "map_journal", (void *) &pmap->map_journal, 1);		
	btr_file_write_serial (fn1, BTR_BYTE, "data", (void *) pmap->data, pmap->data_size);
	btr_file_write_serial (fn1, BTR_SHORT, "dirt_block", (void *) &pmap->dirt_block, 0);	
	btr_file_write_serial (fn1, BTR_SHORT, "grass_block", (void *) &pmap->grass_block, 0);	
    btr_file_write_serial (fn1, BTR_BYTE, "violence", (void *) &pmap->violence, 0);
	fclose (fn1);  
    
    file_replace (file_perminant, file_temp);
	
	return (1);
}

void file_replace (char *perminant, char *temporary) {
    char backup[PATH_MAX];
    snprintf (backup, PATH_MAX, "%s.old", perminant);
    remove (backup);
    rename (perminant, backup);
    rename (temporary, perminant);
	remove (backup);
}
/*
int map_partial_save (struct map *pmap) {

    char file_temp[PATH_MAX];
    char file_perminant[PATH_MAX];

    
    if (pmap->fn1 == 0) {
	    struct map_file_header header;
        pmap->pwritten = 0;
        

	    if (pmap->file[0] == 0) {
            log_printf (NULL, LERROR, "map_save: map filename missing");
            return (1);
        }
        
        snprintf (file_temp, PATH_MAX, file_temp, "%s/.%s", PATH_MAPS, pmap->file);
        snprintf (file_perminant, PATH_MAX, file_temp, "%s/%s", PATH_MAPS, pmap->file);



        header.dimension.x = pmap->dimension.x;
        header.dimension.y = pmap->dimension.y;
        header.dimension.z = pmap->dimension.z;
        header.sealevel = pmap->sealevel;

        header.header_size = sizeof (struct map_file_header);

	    pmap->fn1 = fopen (file_temp, "wb");
	    if (pmap->fn1 == 0 ) {
		    log_printf (NULL, LERROR, "Can't save map file [%s]: %s", pmap->file, strerror (errno));
		    return (1);
	    }
        log_printf (NULL, LNOTE, "Map save started");
    
    	fwrite (&header, sizeof (struct map_file_header), 1, pmap->fn1);    
    

        return (0);    
    }
        

    if (pmap->data_size - pmap->pwritten == 0) {
    
        fclose (pmap->fn1);
        
        file_replace (file_perminant, file_temp);

        log_printf (NULL, LNOTE, "Map save complete");
        pmap->save_counter = 0;
        return (1);
    }


    int write_length = (1024*1024)/2;
    if (write_length > pmap->data_size - pmap->pwritten) write_length = pmap->data_size - pmap->pwritten;

	fwrite (pmap->data + pmap->pwritten, write_length, 1, pmap->fn1);
    pmap->pwritten += write_length;

	return (0);
  

}

*/

int map_fix_fill_coordinates (struct user *puser, struct map_fill *pmodify) {
    struct short_xyz start, finish;

	if (pmodify->lower_x < 0) pmodify->lower_x = 0;
	if (pmodify->lower_y < 0) pmodify->lower_y = 0;
	if (pmodify->lower_z < 0) pmodify->lower_z = 0;	
	if (pmodify->upper_x < 0) pmodify->upper_x = 0;
	if (pmodify->upper_y < 0) pmodify->upper_y = 0;
	if (pmodify->upper_z < 0) pmodify->upper_z = 0;

	if (pmodify->lower_x >= puser->map->dimension.x) pmodify->lower_x = puser->map->dimension.x - 1;
	if (pmodify->lower_y >= puser->map->dimension.y) pmodify->lower_y = puser->map->dimension.y - 1;
	if (pmodify->lower_z >= puser->map->dimension.z) pmodify->lower_z = puser->map->dimension.z - 1;	
	if (pmodify->upper_x >= puser->map->dimension.x) pmodify->upper_x = puser->map->dimension.x - 1;
	if (pmodify->upper_y >= puser->map->dimension.y) pmodify->upper_y = puser->map->dimension.y - 1;
	if (pmodify->upper_z >= puser->map->dimension.z) pmodify->upper_z = puser->map->dimension.z - 1;

    if (pmodify->lower_x > pmodify->upper_x) {start.x = pmodify->upper_x; finish.x=pmodify->lower_x;}
    else {start.x = pmodify->lower_x; finish.x=pmodify->upper_x;}

    if (pmodify->lower_y > pmodify->upper_y) {start.y = pmodify->upper_y; finish.y=pmodify->lower_y;}
    else {start.y = pmodify->lower_y; finish.y=pmodify->upper_y;}

    if (pmodify->lower_z > pmodify->upper_z) {start.z = pmodify->upper_z; finish.z=pmodify->lower_z;}
    else {start.z = pmodify->lower_z; finish.z=pmodify->upper_z;}
    
    int size_x  = finish.x - start.x, size_y = finish.y - start.y, size_z = finish.z - start.z;

	unsigned int cuboid_volume_limit;
	unsigned short cuboid_size_limit;

	if (puser->map->area_map) {
			cuboid_volume_limit = -1;
			cuboid_size_limit = -1;
	} else {
		cuboid_volume_limit = user_meters_to_blocks (puser->rank->cuboid_volume_limit_meters, puser->map->scale);
	    cuboid_size_limit = user_meters_to_blocks (puser->rank->cuboid_size_limit_meters, puser->map->scale);
	}
    
    if (size_x > cuboid_size_limit || size_y > cuboid_size_limit || size_z > cuboid_size_limit) {
        _strncpy (puser->error_message, "Your cuboid is dimensionally larger than the specified limit", 64);
        goto fail;
    }
    
    if (size_x * size_y * size_z > cuboid_volume_limit) {
        _strncpy (puser->error_message, "Your cuboid volume is larger than the specified limit", 64);
        goto fail;
    }
    
    if (puser->who) goto fail;

	_strncpy (puser->error_message, "You can't build here.", 64);

	if ((start.x < 0 || start.x >= puser->map->dimension.x) ||
		(start.y < 0 || start.y >= puser->map->dimension.y) ||
		(start.z < 0 || start.z >= puser->map->dimension.z)) {
		log_printf (puser, LNOTE, "map_fix_fill_coordinates: region contained invalid coordinates: %ix%ix%i - %ix%ix%i", start.x, start.y, start.z, finish.x, finish.y, finish.z);
		goto fail;
	}
    
    if (!puser->map->palette->block[pmodify->type].cuboidable) {
        snprintf (puser->error_message, 64, "You can't cuboid with %s blocks.", puser->map->palette->block[pmodify->type].name);
        goto fail;
   	}
	
	pmodify->lower_x = start.x;
	pmodify->lower_y = start.y;
	pmodify->lower_z = start.z;
	pmodify->upper_x = finish.x;
	pmodify->upper_y = finish.y;
	pmodify->upper_z = finish.z;
	
	return (1);
	fail:;
	return (0);
}


int map_client_fill (struct user *puser, struct map_fill *pmodify, int size) {
    struct short_xyz start, finish;
    struct map_modify sm;
    
    if (size < sizeof (struct map_fill) - 1) {
        log_printf (puser, LERROR, "map_fill: packet size is too small: %i/%i", sizeof (struct map_fill) - 1);
        return(0);
    }
	
	if (pmodify->lower_x < 0) pmodify->lower_x = 0;
	if (pmodify->lower_y < 0) pmodify->lower_y = 0;
	if (pmodify->lower_z < 0) pmodify->lower_z = 0;	
	if (pmodify->upper_x < 0) pmodify->upper_x = 0;
	if (pmodify->upper_y < 0) pmodify->upper_y = 0;
	if (pmodify->upper_z < 0) pmodify->upper_z = 0;

	if (pmodify->lower_x >= puser->map->dimension.x) pmodify->lower_x = puser->map->dimension.x - 1;
	if (pmodify->lower_y >= puser->map->dimension.y) pmodify->lower_y = puser->map->dimension.y - 1;
	if (pmodify->lower_z >= puser->map->dimension.z) pmodify->lower_z = puser->map->dimension.z - 1;	
	if (pmodify->upper_x >= puser->map->dimension.x) pmodify->upper_x = puser->map->dimension.x - 1;
	if (pmodify->upper_y >= puser->map->dimension.y) pmodify->upper_y = puser->map->dimension.y - 1;
	if (pmodify->upper_z >= puser->map->dimension.z) pmodify->upper_z = puser->map->dimension.z - 1;

    if (pmodify->lower_x > pmodify->upper_x) {start.x = pmodify->upper_x; finish.x=pmodify->lower_x;}
    else {start.x = pmodify->lower_x; finish.x=pmodify->upper_x;}

    if (pmodify->lower_y > pmodify->upper_y) {start.y = pmodify->upper_y; finish.y=pmodify->lower_y;}
    else {start.y = pmodify->lower_y; finish.y=pmodify->upper_y;}

    if (pmodify->lower_z > pmodify->upper_z) {start.z = pmodify->upper_z; finish.z=pmodify->lower_z;}
    else {start.z = pmodify->lower_z; finish.z=pmodify->upper_z;}
    
    int size_x  = finish.x - start.x, size_y = finish.y - start.y, size_z = finish.z - start.z;

	unsigned int cuboid_volume_limit;
	unsigned short cuboid_size_limit;

	if (puser->map->area_map) {
			cuboid_volume_limit = -1;
			cuboid_size_limit = -1;
	} else {
		cuboid_volume_limit = user_meters_to_blocks (puser->rank->cuboid_volume_limit_meters, puser->map->scale);
	    cuboid_size_limit = user_meters_to_blocks (puser->rank->cuboid_size_limit_meters, puser->map->scale);
	}
    
    if (size_x > cuboid_size_limit || size_y > cuboid_size_limit || size_z > cuboid_size_limit) {
        _strncpy (puser->error_message, "Your cuboid is dimensionally larger than the specified limit", 64);
        goto fail;
    }
    
    if (size_x * size_y * size_z > cuboid_volume_limit) {
        _strncpy (puser->error_message, "Your cuboid volume is larger than the specified limit", 64);
        goto fail;
    }
    
    if (puser->who) goto fail;

	_strncpy (puser->error_message, "You can't build here.", 64);

	if ((start.x < 0 || start.x >= puser->map->dimension.x) ||
		(start.y < 0 || start.y >= puser->map->dimension.y) ||
		(start.z < 0 || start.z >= puser->map->dimension.z)) {
		log_printf (puser, LNOTE, "PACKET_MAP_FILL contained invalid coordinates: %ix%ix%i - %ix%ix%i", start.x, start.y, start.z, finish.x, finish.y, finish.z);
		goto fail;
	}
    
    if (!puser->map->palette->block[pmodify->type].cuboidable) {
        snprintf (puser->error_message, 64, "You can't cuboid with %s blocks.", puser->map->palette->block[pmodify->type].name);
        goto fail;
    }
    
    sm.type=pmodify->type;
    for (sm.x=start.x; sm.x<=finish.x; sm.x++) {
        for (sm.y=start.y; sm.y<=finish.y; sm.y++) {
            for (sm.z=start.z; sm.z<=finish.z; sm.z++) {
                if (!client_modify_test (puser, &sm, puser->error_message)) {
					log_printf (puser, LDEBUG, "permission fail");
					goto fail;
				}

            }
        }
    }
    
   	map_journal_update_fill (puser->map, puser->uid, start, finish, pmodify->type) ;
	map_modify_fill (puser, start, finish, pmodify->type);
	
/*    for (sm.x=start.x; sm.x<=finish.x; sm.x++) {
        for (sm.y=start.y; sm.y<=finish.y; sm.y++) {
            for (sm.z=start.z; sm.z<=finish.z; sm.z++) {
                finite_flow_add (puser->map, sm.x, sm.y, sm.z);
            }
        }
    }*/
		
	
	
    packet_broadcast (puser->map, -1, NULL, PACKET_MAP_FILL, pmodify->lower_x, pmodify->lower_y, pmodify->lower_z, pmodify->upper_x, 
                pmodify->upper_y, pmodify->upper_z, pmodify->type, puser->idx);
	
	return (1);	
	fail:

    if (easy_time() - puser->last_map_error_stamp >= 1) {
	
    	if (!puser->who)
        	menu_dialog (puser, MENU_CREATE, "Block Placement", puser->error_message, "OK");

    }
    puser->last_map_error_stamp = easy_time();
		
	map_region_send (puser, start, finish, 0);

	return (1);  
}

int zlib_deflate (char *in, int in_size, char *out, int *out_size) {
    int ret;
    z_stream strm;

    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;
    ret = deflateInit(&strm, Z_DEFAULT_COMPRESSION);
    if (ret != Z_OK)
        return (0);

    strm.avail_in = in_size;
    strm.next_in = (unsigned char *)in;

    strm.avail_out = *out_size;
    strm.next_out = (unsigned char *)out;

    ret = deflate(&strm,Z_FINISH);

    (void)deflateEnd(&strm);

    *out_size=strm.total_out;

    return (1);
}

int zlib_inflate (char *in, int in_size, char *out, int *out_size) {
    z_stream strm;
    int ret;

    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;
    strm.avail_in = 0;
    strm.next_in = Z_NULL;
    ret = inflateInit(&strm);
    if (ret != Z_OK)
        return 0;

    strm.avail_in = in_size;
    strm.next_in = (unsigned char *)in;

    strm.avail_out = *out_size;
    strm.next_out = (unsigned char *)out;
    ret = inflate(&strm, Z_NO_FLUSH);
    log_printf (NULL, LDEBUG, "inflate ret = %i", ret);
    inflateEnd(&strm);

    *out_size=strm.total_out;

    return (1);
}

void map_region_copy (struct map *pmap, struct int_xyz src_dimension, struct int_xyz dest_dimension, struct int_xyz src_start, struct int_xyz src_end, struct int_xyz dest_offset, unsigned char *src_buffer, unsigned char *dest_buffer) {
	struct int_xyz r_dimension;

	int x, y, z;
	r_dimension.x = src_end.x - src_start.x;
	r_dimension.y = src_end.y - src_start.y;
	r_dimension.z = src_end.z - src_start.z;
	
	for (x = 0; x < r_dimension.x; x++) {
		for (y = 0; y < r_dimension.y; y++) {	
			for (z = 0; z < r_dimension.z; z++) {	
				
				if (src_buffer[((z + src_start.z) * src_dimension.y + (y + src_start.y)) * src_dimension.x + (x + src_start.x)] == 0) continue;
				
				dest_buffer[((z + dest_offset.z) * dest_dimension.y + (y + dest_offset.y)) * dest_dimension.x + (x + dest_offset.x)] = 
					src_buffer[((z + src_start.z) * src_dimension.y + (y + src_start.y)) * src_dimension.x + (x + src_start.x)];
			}
		}
	}
}

void map_draw_circle (struct user *puser, short cx, short cy, short cz, int radius, unsigned char block) {
    int x = 0;
    int y = radius;
    int last = 0;
    int d = 3 - 2*radius;
    struct map_modify m;
    m.z = cz;
    m.type = block;
    while( !last ) {
        if(abs(y-x) <= 1)
            last = 1;

        m.x = cx + x; m.y = cy + y; modify_client_map (puser, &m, 0);
        m.x = cx + x; m.y = cy - y; modify_client_map (puser, &m, 0);
        m.x = cx - x; m.y = cy + y; modify_client_map (puser, &m, 0);    
        m.x = cx - x; m.y = cy - y; modify_client_map (puser, &m, 0);    

        m.x = cx + y; m.y = cy + x; modify_client_map (puser, &m, 0);
        m.x = cx + y; m.y = cy - x; modify_client_map (puser, &m, 0);
        m.x = cx - y; m.y = cy + x; modify_client_map (puser, &m, 0);    
        m.x = cx - y; m.y = cy - x; modify_client_map (puser, &m, 0);    

        if(d < 0) {
            d += 4*x + 6; 
        } else {
            d += 4*(x-y) + 10;
            y--;
        }
    x++; 
    }
}

void map_draw_sphere (struct user *puser, short x, short y, short z, short radius, short block) {
    short i, j, k;
    int r = radius;
    for (i = x - r; i < x + r; i++) {
        for (j = y - r; j < y + r; j++) {
            for (k = z - r; k < z + r; k++) {
                int w;
                w = nearbyint (sqrt (pow(i - x, 2) + pow(j - y, 2) + pow (k - z, 2)));

                if ( w < r ) {
                    struct map_modify m;
                    m.x = i; m.y = j; m.z = k; m.type = block; m.who= puser->idx;

				   if (client_modify_test (puser, &m, puser->error_message)) {
						int old = (unsigned char)BLOCK (puser->map, m.x, m.y, m.z);
						BLOCK (puser->map, m.x, m.y, m.z) =  block;
    					if (block == 255) puser->blocks_removed++; else puser->blocks_placed++;
						
						map_set_modified (puser->map, m.x, m.y);
					  	map_journal_update (puser->map, puser->uid, m.x, m.y, m.z, block, old) ;
						
					    //packet_broadcast (puser->map, -1, NULL, PACKET_MAP_MODIFY, m.x, m.y, m.z, block, 0);
				   }
                }
            }
        }
    }
	struct short_xyz start, finish;
	start.x = x - radius - 1;
	start.y = y - radius - 1;
	start.z = z - radius - 1;
	finish.x = x + radius + 1;
	finish.y = y + radius + 1;
	finish.z = z + radius + 1;
	
	
	map_region_send (puser, start, finish, 1);
}

void map_close_all () {
    for (int a = 0; a < NUM_MAPS; a++) {
        if (!map_array[a].active) continue;
       
		map_save (&map_array[a]);    
        if (map_array[a].fn_journal != 0) map_journal_close (&map_array[a]);    
    }
	return;
}

struct map *map_struct_find_by_filename (char *str) {
    int a;

    for (a = 0; a < NUM_MAPS; a++) {
        if (!map_array[a].active) continue;
        if (strcasecmp (str, map_array[a].file) == 0) return (&map_array[a]);
    }

    return (NULL);
}

struct map *map_struct_find_by_name (char *str) {
    int a;

    for (a = 0; a < NUM_MAPS; a++) {
        if (map_array[a].file[0] == 0) continue;
        if (strcasecmp (str, map_array[a].file) == 0) {
			return (&map_array[a]);
		}
    }

    return (NULL);
}

struct map *map_struct_find_empty () {
    int a;

    for (a = 0; a < NUM_MAPS; a++) {
		if (map_array[a].active) continue;
		return (&map_array[a]);
	}
	
    return (NULL);
}

void map_unload (struct map *pmap) {
    int a;
    for (a = 1; a < NUM_USERS; a++) {
        if (user[a].current_mode == USER_NOT_CONNECTED || user[a].current_mode == USER_DISCONNECT) continue;
        if (user[a].map == pmap) {
			struct map *new_map = map_struct_find_appropriate (&user[a], pmap);
			if (new_map != NULL) user_map_switch (&user[a], new_map->file);
        }
    }
    map_journal_close (pmap);

	pmap->save_counter = 1;    
    map_save (pmap);

    _free (pmap->data);
    
	pmap->file[0] = 0;
	pmap->active = 0;
	pmap->data = NULL;
	
    return;
}

void map_update_compressed_data (struct user *puser, unsigned char *data, int size) {
	int ret = 0;
    size_t uncompressed_data_size;
    unsigned char *uncompressed_data = NULL;
    
	log_printf (puser, LDEBUG, "Process PACKET_MAP_DATA");
	if (puser->who) {
		log_printf (puser, LDEBUG, "PACKET_MAP_DATA ignored; who enabled");
		return;
	}
	ret = 0;

	if (size < 12) {
		log_printf (puser, LWARNING, "PACKET_MAP_DATA: invalid packet size of %i bytes", size);
        return;
	}

	struct short_xyz start = {0, 0, 0};
	struct short_xyz finish = {0, 0, 0};	
	
	start.x = ((short *) data)[0];
	start.y = ((short *) data)[1];
	start.z = ((short *) data)[2];				

	finish.x = ((short *) data)[3];
	finish.y = ((short *) data)[4];
	finish.z = ((short *) data)[5];

    if ((start.x < 0 || start.x >= puser->map->dimension.x)  ||
            (start.y < 0 || start.y >= puser->map->dimension.y)  ||
            (start.z < 0 || start.z >= puser->map->dimension.z)|| 
            (finish.x < 0 || finish.x >= puser->map->dimension.x)  ||
            (finish.y < 0 || finish.y >= puser->map->dimension.y)  ||
            (finish.z < 0 || finish.z >= puser->map->dimension.z)  ) {
    
        log_printf (puser, LWARNING, "PACKET_MAP_DATA: coordinates  [%ix%ix%i]-[%ix%ix%i]", start.x, start.y, start.z, finish.x, finish.y, finish.z);
        goto end;
    }    
	
	struct short_xyz src_dimension;
	
	src_dimension.x = ((finish.x - start.x) + 1);
	src_dimension.y = ((finish.y - start.y) + 1);
	src_dimension.z = ((finish.z - start.z) + 1);
	
	log_printf (puser, LDEBUG , "PACKET_MAP_DATA  (untainted) [%ix%ix%i]-[%ix%ix%i]", start.x, start.y, start.z, finish.x, finish.y, finish.z);	
	
	uncompressed_data_size = src_dimension.x * src_dimension.y * src_dimension.z;

	uncompressed_data = _malloc (uncompressed_data_size + 1);

	int uncompressed_data_length = uncompressed_data_size;

	if (!zlib_inflate ((char *)data + 12, size - 12, (char *)uncompressed_data, &uncompressed_data_length)) {
		_free (uncompressed_data);
		log_printf (puser, LWARNING, "PACKET_MAP_DATA: zlib could not decompress data");
		user_message (puser, MSYSTEM | MERROR, "PACKET_MAP_DATA not processed: zlib could not decompress data.", puser->error_message);
		ret = -1;
		goto end;
	}

	if (start.x > finish.x || start.y > finish.y || start.z > finish.z) {
		log_printf (puser, LWARNING, "PACKET_MAP_DATA: unsorted coordinates: %ix%ix%i - %ix%ix%i", start.x, start.y, start.z, finish.x, finish.y, finish.z);
		user_message (puser, MSYSTEM | MERROR, "PACKET_MAP_DATA not processed: your coordinates aren't sorted.");
		ret = 0;
		goto end;
	}
	
	if ((start.x < 0 || start.y < 0 || start.z < 0) ||
		(start.x >= puser->map->dimension.x || start.y >= puser->map->dimension.y || start.z >= puser->map->dimension.z) ||
		(finish.x < 0 || finish.y < 0 || finish.z < 0) ||
		(finish.x >= puser->map->dimension.x || finish.y >= puser->map->dimension.y || finish.z >= puser->map->dimension.z)) {
		log_printf (puser, LWARNING, "PACKET_MAP_DATA: outside of map boundries : %ix%ix%i - %ix%ix%i", start.x, start.y, start.z, finish.x, finish.y, finish.z);
		user_message (puser, MSYSTEM | MERROR, "PACKET_MAP_DATA not processed: your coordinates go outside of the map.");			
		ret = 0;
		goto end;
	}

	int x, y, z;

	strcpy (puser->error_message, "Fill area contains an unbuildable region.");

	for (x = start.x; x < finish.x + 1; x++) {
		for (y = start.y; y < finish.y + 1; y++) {		
			for (z = start.z; z < finish.z + 1; z++) {		
	            if (client_modify_test (puser, &((struct map_modify) {x, y, z, 255}), puser->error_message) < 1) {
					log_printf (puser, LWARNING, "PACKET_MAP_DATA: %s", puser->error_message);
					user_message (puser, MSYSTEM | MERROR, "PACKET_MAP_DATA not processed: %s", puser->error_message);
					ret = 0;
					goto end;

				}
			}
		}
	}

	map_set_modified (puser->map, start.x, start.y);
	
	map_region_copy_data (
		((struct short_xyz) {src_dimension.x, src_dimension.y, src_dimension.z}), 
		((struct short_xyz) {puser->map->dimension.x, puser->map->dimension.y, puser->map->dimension.z}),
		((struct short_xyz) {0, 0, 0}),
		((struct short_xyz) {src_dimension.x, src_dimension.y, src_dimension.z}), 
			start, 
			uncompressed_data, (unsigned char *)puser->map->data);

	ret = 1;		
	
	end:
	log_printf (puser, LDEBUG, "PACKET_MAP_DATA result: %i", ret);

	if (ret == 0) {
		map_compressed_region_send (puser,
			((struct short_xyz) {(short)start.x, (short)start.y, (short)start.z}), 
			((struct short_xyz) {(short)finish.x +1,(short) finish.y  +1,(short) finish.z +1}));

		menu_dialog (puser, MENU_CREATE, "Note", puser->error_message, "OK");
	} else {
	    packet_broadcast (puser->map, -1, puser, PACKET_MAP_DATA, start.x, start.y, start.z, finish.x, finish.y, finish.z, size - 12, data + 12);
	}
	
	if (uncompressed_data != NULL) _free (uncompressed_data);
	return;
}


int map_compressed_region_send (struct user *puser, struct short_xyz start, struct short_xyz finish) {
	int x, y, z;
    struct short_xyz dimension;
    
    dimension.x = (finish.x - start.x) + 1;
    dimension.y = (finish.y - start.y) + 1;
    dimension.z = (finish.z - start.z) + 1;	
    
	log_printf (puser, LDEBUG ,  "region send %ix%ix%i", dimension.x, dimension.y, dimension.z);
	int dest_data_size = dimension.x * dimension.y * dimension.z;
	char *uncompressed_buffer = _malloc (dest_data_size);
	char *compressed_data = _malloc (dest_data_size);
    int x_offset = 0, y_offset = 0, z_offset = 0;
    x_offset = start.x;
    y_offset = start.y;
    z_offset = start.z;
    
	for (z = 0; z < dimension.z; z+= 32) {
		for (x = 0 ; x < dimension.x; x += 32) {
			for (y = 0; y < dimension.y; y += 32) {	
				int lx, ly, lz;				

				lx = x + 32; if (x + lx > dimension.x) lx = dimension.x - x;
				ly = y + 32; if (y + ly > dimension.y) ly = dimension.y - y;
				lz = z + 32; if (z + lz > dimension.z) lz = dimension.z - z;
				
				if (lx > 32) lx = 32;
				if (ly > 32) ly = 32;
				if (lz > 32) lz = 32;
				
				map_region_copy_data (((struct short_xyz) {puser->map->dimension.x, puser->map->dimension.y, puser->map->dimension.z}), 
					 ((struct short_xyz) {lx, ly, lz}),
					 ((struct short_xyz) {start.x + x, start.y + y, start.z + z}), 
					 ((struct short_xyz) {start.x + x + lx, start.y + y + ly, start.z + lz}),
					 ((struct short_xyz) {0, 0, 0}),
					 (unsigned char *)puser->map->data,
					 (unsigned char *)uncompressed_buffer);

				int uncompressed_data_size = lx * ly * lz;
				int compressed_data_size = uncompressed_data_size;
				
			    int ret=zlib_deflate (uncompressed_buffer, uncompressed_data_size, compressed_data, (int *)&compressed_data_size);
			    if (!ret)
				      log_printf (NULL, LERROR, "area_load: Zlib deflate error\n", ret);
					  
				log_printf (puser, LDEBUG, "Send area data for %ix%ix%i - %ix%ix%i (%ix%ix%i)", x + x_offset, y + y_offset, z, (x + x_offset) + (lx -1), (y + y_offset) + (ly - 1), z + (lz - 1), x, y, z);

				packet_send (puser, PACKET_MAP_DATA, x + x_offset, y + y_offset, z + z_offset, 
						(x + x_offset) + (lx -1), (y + y_offset) + (ly - 1), (z + z_offset) + (lz - 1),
					    compressed_data_size, compressed_data);
			}
		}
	}    
	_free (uncompressed_buffer);
	_free (compressed_data);
	return (1);
}

void map_region_copy_data (struct short_xyz src_dimension, struct short_xyz dest_dimension, struct short_xyz src_start, struct short_xyz src_end, struct short_xyz dest_offset, unsigned char *src_buffer, unsigned char *dest_buffer) {
	struct short_xyz r_dimension;

	int x, y, z;
	r_dimension.x = src_end.x - src_start.x;
	r_dimension.y = src_end.y - src_start.y;
	r_dimension.z = src_end.z - src_start.z;

	log_printf (NULL, LDEBUG, "map_region_copy: src dimension %ix%ix%i", src_dimension.x, src_dimension.y, src_dimension.z);
	log_printf (NULL, LDEBUG, "map_region_copy: range dimension %ix%ix%i-%ix%ix%i",src_start.x, src_start.y, src_start.z, src_end.x, src_end.y, src_end.z);
	log_printf (NULL, LDEBUG, "map_region_copy: dest dimension %ix%ix%i", dest_dimension.x, dest_dimension.y, dest_dimension.z);
	log_printf (NULL, LDEBUG, "map_region_copy: copy dimension %ix%ix%i", r_dimension.x, r_dimension.y, r_dimension.z);

	for (x = 0; x < r_dimension.x; x++) {
		for (y = 0; y < r_dimension.y; y++) {	
			for (z = 0; z < r_dimension.z; z++) {	
				if (src_buffer[((z + src_start.z) * src_dimension.y + (y + src_start.y)) * src_dimension.x + (x + src_start.x)] == 0) continue;
				dest_buffer[((z + dest_offset.z) * dest_dimension.y + (y + dest_offset.y)) * dest_dimension.x + (x + dest_offset.x)] = 
					src_buffer[((z + src_start.z) * src_dimension.y + (y + src_start.y)) * src_dimension.x + (x + src_start.x)];
			}
		}
	}
}

struct map * map_struct_find_appropriate (struct user *puser, struct map *ignoremap) {
	int a;
	struct user duser;
	memmove (&duser, puser, sizeof (struct user));
	
	for (a = 0; a < NUM_MAPS; a++) {
		if (!map_array[a].active) continue;
		if (&map_array[a] == ignoremap) continue;
		int reason = 0;
		// this is an ugly way to do this.

    	if (!user_login(&duser, &map_array[a], &reason)) {
        	if (reason == DISCONNECT_BAN) continue;
        	else if (reason == DISCONNECT_KICK) continue;
       	}
		break;
	}
	
	if (a == NUM_MAPS) {
		user_disconnect (puser, DISCONNECT_ERROR, 0, "I am unable to find an approprate map for you.");
		return (NULL);
	}
	
	return (&map_array[a]);
}

int map_count_active () {
	int maps = 0;
	int a;
    for (a = 0; a < NUM_MAPS; a++) {
        if (!map_array[a].active) continue;
		maps++;
    }
    return (maps);
}


void map_undo_log (struct user *puser, short x, short y, short z, unsigned char block) {
	if (block == 0) {
		log_printf (puser, LWARNING, "map_undo_log: Zero block at %ix%ix%i", x, y, z);
		return;
	}

	puser->undo = _realloc (puser->undo, sizeof (struct undo_data) * (puser->num_undo + 64));
	puser->undo[puser->num_undo].x = x;
	puser->undo[puser->num_undo].y = y;
	puser->undo[puser->num_undo].z = z;
	puser->undo[puser->num_undo].block = block;
	time (&puser->undo[puser->num_undo].stamp);
	puser->num_undo++;
}


void map_undo_undo (struct user *puser, int seconds) {
	int a;
	time_t start_stamp;
	if (seconds < 2) seconds = 2;
	
	if (puser->num_undo < 1) {
		user_message (puser, MUSER, "Undo: nothing to undo!");
		return;
	}
	
	start_stamp = puser->undo[puser->num_undo - 1].stamp;	
	
	time_t stop_stamp = (start_stamp - seconds);
	time_t t; time (&t);
	
	int undid = 0;
	for (a = puser->num_undo - 1; a >= 0; a--) {
		if (puser->undo[a].stamp < stop_stamp) {
			if (undid > 15) continue;
		}

		undid ++;   
    	struct map_modify m;
    	m.x = puser->undo[a].x; 
		m.y = puser->undo[a].y; 
		m.z = puser->undo[a].z ;
		m.type = (unsigned char )puser->undo[a].block; 
		m.who = puser->idx;

	   if (client_modify_test (puser, &m, puser->error_message) && 	puser->undo[a].block != 0) {
	   		map_block_change (puser->map, m.x, m.y, m.z, puser->undo[a].block, puser->uid);
		}
		puser->undo[a].block = 0;
	}

	int b = 0;
	for (a = 0; a < puser->num_undo; a++) {
		if (puser->undo[a].block == 0) continue;
		if (a == b) continue;
		memmove (&puser->undo[b], &puser->undo[a], sizeof (struct undo_data));
		b++;
		puser->undo[a].block = 0;
	}

	user_message (puser, MUSER, "Undo: Reverted %i/%i blocks.", undid, puser->num_undo);
	puser->num_undo = b;
}


void map_block_change (struct map *pmap, int x, int y, int z, unsigned char block, int who) {
	if (x < 0 || x >= pmap->dimension.x ||
	(y < 0 || y >= pmap->dimension.y) ||
	(z < 0 || z >= pmap->dimension.z)) {
		log_printf (NULL, LWARNING, "map_block_change: %ix%ix%i is outside of map", x, y, z);
		return;
	}
	int old = (unsigned char)BLOCK(pmap, x, y, z);
	
	if (old == block || block == 0) return;
	
	BLOCK (pmap, x, y, z) = block;

	map_set_modified (pmap, x, y);
	map_journal_update (pmap, who, x, y, z, block, old) ;

	packet_broadcast (pmap, -1, NULL, PACKET_MAP_MODIFY, x, y, z, block, who);
	return;
}



int map_region_save (struct map *pmap, char *filename, int fx, int fy, int fz, int tx, int ty, int tz) {
	struct map new_map;
	int v;
	memset (&new_map, 0, sizeof (new_map));
	
	if (fx > tx) {v = fx; fx = tx; tx = v;}
	if (fy > ty) {v = fy; fy = ty; ty = v;}
	if (fz > tz) {v = fz; fz = tz; tz = v;}	
	new_map.dimension.x = tx - fx;
	new_map.dimension.y = ty - fy;
	new_map.dimension.z = tz - fz;
	new_map.sealevel = pmap->sealevel;
	new_map.scale = pmap->scale;
	new_map.data_size = (size_t) new_map.dimension.x * new_map.dimension.y * new_map.dimension.z;
	new_map.data = _malloc (new_map.data_size);
	_strncpy (new_map.file, filename, 256);
	_strncpy (new_map.block_palette_name, pmap->block_palette_name, 256);
	new_map.dirt_block = pmap->dirt_block;
	new_map.grass_block = pmap->grass_block;
	int x, y, z;
	struct map *vm = &new_map;
	for (z = fz; z < tz; z++) {
		for (x = fx; x < tx; x++) {
			for (y = fy; y < ty; y++) {		
				int nx = x - fx;
				int ny = y - fy;
				int nz = z - fz;	
			//	printf ("Block %ix%ix%i\n", nx, ny, nz);
				
				BLOCK (vm, nx, ny, nz) = (unsigned char) BLOCK (pmap, x, y, z);
			}
		}
	}

	map_save (&new_map);
	_free (new_map.data);

	return (1);
}

int map_region_load (struct map *pmap, char *filename, int fx, int fy, int fz, int tx, int ty, int tz) {
	struct map new_map;
	int v;
	memset (&new_map, 0, sizeof (new_map));
	
	if (fx > tx) {v = fx; fx = tx; tx = v;}
	if (fy > ty) {v = fy; fy = ty; ty = v;}
	if (fz > tz) {v = fz; fz = tz; tz = v;}	
	
	if (!map_load_file (&new_map, filename)) {
		log_printf (NULL, LWARNING, "map_region_load: Unable to load map.");
		return (0);
	}
	struct map *vm = &new_map;	

	int x, y, z;
	for (z = fz; z < tz; z++) {
		for (x = fx; x < tx; x++) {
			for (y = fy; y < ty; y++) {		
				int nx = x - fx;
				int ny = y - fy;
				int nz = z - fz;				
				if (x >= pmap->dimension.x || y >= pmap->dimension.y  || z >= pmap->dimension.z ) continue;
				if (nx >= vm->dimension.x  || ny >= vm->dimension.y  || nz >= vm->dimension.z ) continue;
				if (x < 0 || y < 0 || z < 0) continue;
				if (nx < 0 || ny < 0 || nz < 0) continue;
				
				//BLOCK (pmap, x, y, z) = (unsigned char) BLOCK (vm, nx, ny, nz);
				//packet_broadcast (pmap, -1, NULL, PACKET_MAP_MODIFY, x, y, z, (unsigned char)BLOCK (pmap, x, y, z), 0);
				//pmap->save_counter++;
				
				map_block_change (pmap, x, y, z, (unsigned char)BLOCK (pmap, x, y, z), 0);
				
			}
		}
	}
	
	map_unload (&new_map);
	return (1);
}


struct map * map_create (char *file, int x, int y, int z, int sealevel) {
    struct map *pmap = map_struct_find_empty ();
    if (pmap == NULL) {
        log_printf (NULL, LWARNING, "Map table is full.  Please unload a map first.");
        return (NULL);
    }
    pmap->palette = &block_palette[0];
	
    int dirt = texture_block_by_description (pmap->palette , "dirt");
    int grass = texture_block_by_description (pmap->palette , "grass");
	int sidewalk = texture_block_by_description (pmap->palette , "sidewalk");
	
    _strncpy (pmap->file, file, 255);
	strcpy (pmap->build_rank_name, "guest");
	strcpy (pmap->block_palette_name, pmap->palette->path);
 	pmap->scale = 0.1f;
	pmap->map_journal = 0;
	pmap->sealevel = sealevel;
	pmap->dimension.x = x;
	pmap->dimension.y = y;
	pmap->dimension.z = z; 
	pmap->spawn.x = x / 2;
	pmap->spawn.y = y / 2;
	pmap->spawn.z = sealevel + 24;
	pmap->area_map = 0;
	pmap->dirt_block = dirt;
	pmap->grass_block = grass;
	pmap->border_block = sidewalk;	
   	map_generate (pmap, 255, dirt, grass);
    return ((void *)pmap);
}


void map_explosion (struct user *puser, int x, int y, int z) {
    int i, j, k;
    int type = (unsigned char) BLOCK (puser->map, x, y, z);    
    if (!client_modify_test (puser, &(struct map_modify) {x, y, z, type, puser->uid}, puser->error_message)) return;

    int r = nearbyint (user_meters_to_blocks (
        puser->map->palette->block[type].explosiveness,
        puser->map->scale));

    BLOCK(puser->map, x, y, z) = 255;
    packet_broadcast (puser->map, -1, NULL, PACKET_MAP_MODIFY, x, y, z, 255, 0);    
	
//	start = (struct int_xyz){x, y, z};
    
    for (i = x - r; i < x + r; i++) {
        for (j = y - r; j < y + r; j++) {
            for (k = z - r; k < z + r; k++) {
				if (i < 0 || j < 0 || k < 0) continue;
				if (i >= puser->map->dimension.x) continue;
				if (j >= puser->map->dimension.y) continue;
				if (k >= puser->map->dimension.z) continue;
			
                int w;
                w = nearbyint(sqrt ((pow(i - x, 2) + pow(j - y, 2) + pow (k - z, 2))));

                if ( w < r ) {
                    int old = (unsigned char)BLOCK (puser->map, i, j, k);
                    if (old == 255) continue;
                    type = 255;
                    if (client_modify_test (puser, &(struct map_modify) {i, j, k, type, puser->uid}, puser->error_message)) {
 
                        if (puser->map->palette->block[old].explosiveness > 0.0)
                            map_explosion (puser, i, j, k);
						else BLOCK (puser->map, i, j, k) = type;
						if (type == 255) puser->blocks_removed++; else puser->blocks_placed++;

					  	map_journal_update (puser->map, puser->uid, i, j, k, type, old) ;
						
					    packet_broadcast (puser->map, -1, NULL, PACKET_MAP_MODIFY, i, j, k, (unsigned char)type, 0);
                    }
                }
            }
        }
    }
	map_set_modified (puser->map, x, y);
}

void map_set_modified (struct map *pmap, int x, int y) {
	if (!pmap->area_map) {
		pmap->save_counter = 1;
	} else {
		int a;
		a = area_in (pmap, x, y);
		if (a != -1) pmap->area[a].modify = 1;
	}
}



/*
struct d_region_stream {
    struct int_xyz dimension;
	int x_chunk_width;
	int y_chunk_width;
	int z_chunk_width;
	char *data;
	char *compressed_data;
	int x;
	int y;
	int z;
	struct map *pmap;
	struct int_xyz start;
	struct int_xyz finish;

};


void map_region_stream_open (struct map *pmap, struct int_xyz start, struct int_xyz finish, struct d_region_stream *d) {
	memset (d, 0, sizeof (struct d_region_stream));
	d->x_chunk_width = 32;
	d->y_chunk_width = 32;
	d->z_chunk_width = 32;

	d->dimension.x = (finish.x - start.x);
	d->dimension.y = (finish.y - start.y);
	d->dimension.z = (finish.z - start.z);
	
	memmove (d->finish, finish, sizeof (struct int_xzy));
	memmove (d->start, start, sizeof (struct int_xzy));	

	d->data = _malloc (65536);
	d->compressed_data = _malloc (65536);	

}

int map_region_make_compressed_stream (struct map *pmap, struct int_xyz start, struct int_xyz finish, char *blob) {
	int x, y, z;
    struct int_xyz dimension;
	char *cp = blob;
	
	dimension.x = (finish.x - start.x);
	dimension.y = (finish.y - start.y);
	dimension.z = (finish.z - start.z);
	
	int x_chunk_width = 32;
	int y_chunk_width = 32;
	int z_chunk_width = 32;
	

	if (dimension.x * dimension.y * dimension.z < 65520) {
		x_chunk_width = dimension.x;
		y_chunk_width = dimension.y;
		z_chunk_width = dimension.z;
	}

	char *data = _malloc (65536);
	char *compressed_data = _malloc (65536);	
	for (z = start.z; z <= finish.z; z += 32) {
		for (x = start.x; x <= finish.x; x += 32) {
			for (y = start.y; y <= finish.y; y += 32) {	
				int lx, ly, lz;

				lx = x + x_chunk_width;
				ly = y + y_chunk_width;
				lz = z + z_chunk_width;

				if (lx > finish.x) lx = x + (finish.x - x);
				if (ly > finish.y) ly = y + (finish.y - y);
				if (lz > finish.z) lz = z + (finish.z - z);

				dimension.x = (lx - x);
				dimension.y = (ly - y);				
				dimension.z = (lz - z);

				int bx, by, bz;
				for (bz = 0; bz < dimension.z; bz++) {
					for (bx = 0; bx < dimension.x; bx++) {
						for (by = 0; by < dimension.y; by++) {
							data[(bz * dimension.y + by) * dimension.x + bx] = 
								(unsigned char)BLOCK (pmap, (x + bx), (y + by), (z + bz));
						}
					}
				}

				int uncompressed_data_size = dimension.x * dimension.y * dimension.z;
				int compressed_data_size = uncompressed_data_size;

			    int ret = zlib_deflate (data, uncompressed_data_size, compressed_data, (int *)&compressed_data_size);
			    if (!ret)
				      log_printf (NULL, LERROR, "map_region_make_compressed: Zlib deflate error\n", ret);

				int out_x = (x + dimension.x) - 1;
				int out_y = (y + dimension.y) - 1;
				int out_z = (z + dimension.z) - 1;
				
				((unsigned short) cp[0]) = PACKET_MAP_DATA;
				((unsigned short) cp[2]) = compressed_data_size + 12;
				((unsigned short) cp[4]) = (short) x;
				((unsigned short) cp[6]) = (short) y;
				((unsigned short) cp[8]) = (short) z;
				((unsigned short) cp[10]) = (short) out_x;
				((unsigned short) cp[12]) = (short) out_y;
				((unsigned short) cp[14]) = (short) out_z;
				cp += 16;
				memmove (cp, compressed_data, compressed_data_size);
				cp += compressed_data_size;
			}
		}
	}
	_free (data);
	_free (compressed_data);

	return ((size_t)cp - blob);
}

*/

int map_region_send (struct user *puser, struct short_xyz start, struct short_xyz finish, int broadcast) {
	int x, y, z;
    struct short_xyz dimension;

	finish.x ++;
	finish.y ++;
	finish.z ++;
	
	dimension.x = (finish.x - start.x);
	dimension.y = (finish.y - start.y);
	dimension.z = (finish.z - start.z);
	
	int x_chunk_width = 32;
	int y_chunk_width = 32;
	int z_chunk_width = 32;
	
	if (start.x < 0) start.x = 0;
	if (start.y < 0) start.y = 0;
	if (start.z < 0) start.z = 0;

	if (start.x >= puser->map->dimension.x) start.x = puser->map->dimension.x - 1;
	if (start.y >= puser->map->dimension.y) start.y = puser->map->dimension.y - 1;
	if (start.z >= puser->map->dimension.z) start.z = puser->map->dimension.z - 1;

	if (finish.x < 0) finish.x = 0;
	if (finish.y < 0) finish.y = 0;
	if (finish.z < 0) finish.z = 0;

	if (finish.x >= puser->map->dimension.x) finish.x = puser->map->dimension.x - 1;
	if (finish.y >= puser->map->dimension.y) finish.y = puser->map->dimension.y - 1;
	if (finish.z >= puser->map->dimension.z) finish.z = puser->map->dimension.z - 1;


	if (start.x > finish.x) {short v = start.x; start.x = finish.x; finish.x = v;}
	if (start.y > finish.y) {short v = start.y; start.y = finish.y; finish.y = v;}
	if (start.z > finish.z) {short v = start.z; start.z = finish.z; finish.z = v;}	

	
    
	//printf ("%ix%ix%i - %ix%ix%i\n", start.x, start.y, start.z, finish.x, finish.y, finish.z);
	
	if (dimension.x * dimension.y * dimension.z < 65520) {
		x_chunk_width = dimension.x;
		y_chunk_width = dimension.y;
		z_chunk_width = dimension.z;
	}
    
    int dim = abs (start.x - finish.x) * abs(start.y - finish.y) * abs (start.z - finish.z);
	
	
	if (packet_is_sendable(PACKET_MAP_DATA, puser->sendable_packets) && dim > 32) {

		char *data = _malloc (65536);
		char *compressed_data = _malloc (65536);	
		for (z = start.z; z <= finish.z; z += 32) {
			for (x = start.x; x <= finish.x; x += 32) {
				for (y = start.y; y <= finish.y; y += 32) {	
					int lx, ly, lz;

					lx = x + x_chunk_width;
					ly = y + y_chunk_width;
					lz = z + z_chunk_width;

					if (lx > finish.x) lx = x + (finish.x - x);
					if (ly > finish.y) ly = y + (finish.y - y);
					if (lz > finish.z) lz = z + (finish.z - z);

					dimension.x = (lx - x);
					dimension.y = (ly - y);				
					dimension.z = (lz - z);

					int bx, by, bz;

					for (bz = 0; bz < dimension.z; bz++) {
						for (bx = 0; bx < dimension.x; bx++) {
							for (by = 0; by < dimension.y; by++) {
								data[(bz * dimension.y + by) * dimension.x + bx] = 
									(unsigned char)BLOCK (puser->map, (x + bx), (y + by), (z + bz));
							}
						}
					}

					int uncompressed_data_size = dimension.x * dimension.y * dimension.z;
					int compressed_data_size = uncompressed_data_size;

			    	int ret = zlib_deflate (data, uncompressed_data_size, compressed_data, (int *)&compressed_data_size);
			    	if (!ret)
				    	  log_printf (NULL, LERROR, "area_load: Zlib deflate error\n", ret);


					log_printf (puser, LDEBUG, "Send data for %ix%ix%i - %ix%ix%i (%ix%ix%i)", x, y, z, dimension.x, dimension.y, dimension.z);

					short out_x = (x + dimension.x) - 1;
					short out_y = (y + dimension.y) - 1;
					short out_z = (z + dimension.z) - 1;

					if (!broadcast)
						packet_send (puser, PACKET_MAP_DATA, x, y, z, 
							out_x, out_y, out_z,
					    	compressed_data_size, compressed_data);
					else 
					    packet_broadcast (puser->map, -1, NULL, PACKET_MAP_DATA, x, y, z, 
							out_x, out_y, out_z,
					    	compressed_data_size, compressed_data);
				}
			}
		}
		_free (data);
		_free (compressed_data);
		

	} else {
		printf ("PACKET_MAP_DATA not available\n");
		struct short_xyz c;

		for (c.x = start.x; c.x <= finish.x; c.x++) {
    		for (c.y = start.y; c.y <= finish.y; c.y++) {
        		for (c.z = start.z; c.z <= finish.z; c.z++) {
            		packet_send (puser, PACKET_MAP_MODIFY, c.x, c.y, c.z, map_get(puser->map, c), 0);
        		}
    		}
		}
	}
	
	return (1);
}


static int flow_push (struct flow_properties *d, int x, int y, int z, int who) {
	if (d->fs_idx > 4095) {
		return (0);
	}
//	int z_down = z - d->fill_depth;
	
	if (x < 0 || y < 0 || z < 0) return (0);
	if (x >= d->map->dimension.x || y >= d->map->dimension.y || z >= d->map->dimension.z) return (0);

	
	
	//if (z_down >= 0 && (unsigned char)BLOCK (d->map, x, y, z_down) == d->block) return (0);
	

	d->stack[d->fs_idx].x = x;
	d->stack[d->fs_idx].y = y;
	d->stack[d->fs_idx].z = z;
//    d->stack[d->fs_idx].who = who;
	d->fs_idx++;
	return (1);	
}
static int flow_pop (struct flow_properties *d, struct short_xyz *f) {
	if (d->fs_idx == 0) {
		d->active = 0;
		return (0);
	}

	memmove (f, &d->stack[0], sizeof (struct short_xyz));
	memmove (&d->stack[0], &d->stack[1], 4095 * sizeof (struct short_xyz));
	d->fs_idx --;
	return (1);
}

static void flood (struct flow_properties *d, int x, int y , int z, int who) {

	if ((unsigned char)BLOCK (d->map, x, y, z ) == 255 &&
		(unsigned char)BLOCK (d->map, x, y, z - 1 ) != 255
	
	) {
		map_block_change (d->map, x, y, z, d->block, who);
		flow_push (d, x, y, z, who);
	} else if (z > 0 &&(unsigned char)BLOCK (d->map, x, y, z ) == 255 &&
		(unsigned char)BLOCK (d->map, x, y, z -1) == 255) {
		map_block_change (d->map, x, y, z - 1, d->block, who);
		flow_push (d, x, y, z - 1, who);
	}

}

void map_flow_kill () {
	struct flow_properties *d;
	for (d = &flow_array[0]; d < &flow_array[32]; d++) {
		d->fs_idx = 0;
	}
}



static int map_flow (struct flow_properties *d, int x, int y, int z, int who) {
	
	 
	if (z == 0) return (0);
	if (x < 0 || y < 0 || z < 0) return (0);
	if (x >= d->map->dimension.x || y >= d->map->dimension.y || z >= d->map->dimension.z) return (0);
	
	if ((unsigned char)BLOCK (d->map, x, y, z - 1) == 255) {
		
		map_block_change (d->map, x, y, z - 1, d->block, who);

		flow_push (d, x, y, z - 1, who);
		return (1);
	} else if ((unsigned char)BLOCK (d->map, x, y, z - 1) != 255) {

		flood (d, x+1, y, z, who);
		flood (d, x-1, y, z, who);
		flood (d, x, y+1, z, who);
		flood (d, x, y-1, z, who);
		return (1);
	}
	return (0);
}


void map_flow_proc () {
	struct flow_properties *d;
	for (d = &flow_array[0]; d < &flow_array[32]; d++) {
	
		if (easy_time() < d->flow_stamp) {
			continue;
		}
		if (!d->active) continue;
		struct short_xyz stack;	
		int a;
		for (a = 0; a < 128; a++) {
			redo:;
			if (!flow_pop (d, &stack)) continue;

			if (!map_flow (d, stack.x, stack.y, stack.z, d->who)) goto redo;
			d->flow_stamp = easy_time() + 0.02;		
		}
	
	}
}

struct flow_properties *map_flow_find_empty () {
	struct flow_properties *d;
	for (d = &flow_array[0]; d < &flow_array[32]; d++) {
		if (!d->active) return (d);
	}
	return (NULL);
}

void map_flow_start (struct user *puser, int x, int y, int z, int block, int depth, int who) {
	struct flow_properties *d = map_flow_find_empty();
	if (d == NULL)  {
		log_printf (puser, LWARNING, "map_flow_start: flow table full");
		return ;
	}
	d->active = 1;
	d->block = block;
	d->fill_depth = depth;
	d->map = puser->map;
	d->fs_idx = 0;
	d->flow_stamp = 0;
    d->who = who;

	//d->start_x = x; d->start_y = y; d->start_z = z;
	map_flow (d, x, y, z, who);
}
