/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"

struct mb {
	long int stamp;
	char from[32];
	char subject[64];
	char message[4096];
};

struct mb *message_board;
int num_message_board;


struct d_menu_player_data {
    int mode;
    char user[256][64];
    char selected_user[64];
    char tf;
	int offset;    
};

static void sub_connected_players (struct user *puser, struct d_menu_player_data *d);
static void sub_was_on (struct user *puser, struct d_menu_player_data *d);
static void sub_user_settings (struct user *puser, struct d_menu_player_data *d);
static void sub_maps (struct user *puser, struct d_menu_player_data *d);
static int menu_connected_player_menu (struct user *puser, int message_id, struct d_menu_player_data *d);
static void sub_server_config (struct user *puser, struct d_menu_player_data *d) ;

//struct menu_player_data player_data[NUM_USERS];

int menu_connected_players (struct user *puser, int message_id) {
	int index;


	struct d_menu_player_data *d;

	d = (void *) menu_get_current_stack_item_memory (puser);

	switch (message_id) {
	case MENU_CREATE:
		log_printf (puser, LDEBUG, "menu_connected_players");

    	d = menu_stack_push_init (puser, menu_connected_players, NULL, sizeof (struct d_menu_player_data));
        d->mode = 2;
		
	case MENU_DRAW:
		index = 1;

        packet_send(puser, PACKET_MENU_RESET, 0, 80, 24, 3); 
	
        packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 0, "Server Menu");

        if (puser->map->area_map) {
            packet_send(puser, PACKET_MENU_LINK, index++, 0, 0, 0, 1, 0, "Go to my area");
        } else {
    		packet_send(puser, PACKET_MENU_LINK, index++, 0, 0, 0, 1, 0, "Respawn");
        }
        	
        
        
        
        unsigned char fl_on_now = 0, fl_was_on = 0, fl_my_settings = 0, fl_maps = 0, fl_server_config = 0;
        
        switch (d->mode) {
        case 2: 
            sub_connected_players (puser, d);
            fl_on_now = 1; 
            break;
        case 3: 
            sub_was_on (puser, d);
            fl_was_on = 1; 
            break;        
        case 4: 
            sub_user_settings (puser, d);
            fl_my_settings = 1;             
            break;
        case 5: 
            sub_maps (puser, d);
            fl_maps = 1;             
            break;
        case 6: 
            sub_server_config (puser, d);
            fl_server_config = 1;             
            break;
/*        case 8: 
            sub_message_board (puser, d);
            fl_message_board = 1;             
            break;*/
        }
		int column_offset = 0;

        packet_send(puser, PACKET_MENU_BUTTON, index++, column_offset, 2, 0, 2, 0, fl_on_now, "On Now"); column_offset += 8;
		packet_send(puser, PACKET_MENU_BUTTON, index++, column_offset, 2, 0, 3, 0, fl_was_on, "Was On.."); column_offset += 10;
        if (rank_menu_allowed (puser->rank, "my_settings")) {
			packet_send(puser, PACKET_MENU_BUTTON, index++, column_offset, 2, 0, 4, 0, fl_my_settings, "My Settings");
			column_offset += 13;
		}
        
        int num_maps = 0;
        int a;
        for (a = 0; a < NUM_MAPS; a++) {
            if (!map_array[a].active) continue;
            num_maps++;
        }
        
        if (rank_menu_allowed (puser->rank, "maps") && num_maps > 1) {
	        packet_send(puser, PACKET_MENU_BUTTON, index++, column_offset, 2, 0, 5, 0, fl_maps, "Maps");
			column_offset += 6;
		}
        if (rank_menu_allowed (puser->rank, "server_config")) {
            packet_send(puser, PACKET_MENU_BUTTON, index++, column_offset, 2, 0, 6, 0, fl_server_config, "Server Config");
			column_offset += 15;
		}
    	if (puser->map->area_map) {
			packet_send(puser, PACKET_MENU_BUTTON, index++, column_offset, 2, 0, 7, 0, 0, "My Areas");
			column_offset += 10;
            
			packet_send(puser, PACKET_MENU_BUTTON, index++, column_offset, 2, 0, 8, 0, 0, "Area Index");
			column_offset += 10;
            
		}		
        
        break;
        

	case MENU_COMMAND: {

		int menu_number = -1;
		int menu_name = -1;
		int menu_value = -1;
		int menu_flags = -1;
		unsigned char menu_char[65535]= {0}; 
		
		menu_command_parse (puser, &menu_number, &menu_name, &menu_value, &menu_flags, menu_char);

		log_printf (puser, LDEBUG, "[connected players] menu response bytes=%i, menu=%i, name=%i, value=%i, flags=%i", 
				puser->menu_data_size, menu_number, menu_name, menu_value, menu_flags);	
                
        if (menu_name == 0) {
            if (menu_value == 1) {
                if (puser->map->area_map) {
                    area_player_locate (puser, area_for_player (puser));
                } else {
                    user_spawn (puser, puser->map->spawn);    
                }
                    
    			menu_stack_pop (puser);

            } else if (menu_value == 2) {
                d->mode = 2;
                menu_connected_players (puser, MENU_DRAW);

            } else if (menu_value == 3) {
                d->mode = 3;
                menu_connected_players (puser, MENU_DRAW);
                
            } else if (menu_value == 4) {
                d->mode = 4;
                menu_connected_players (puser, MENU_DRAW);

            } else if (menu_value == 5) {
                d->mode = 5;
                menu_connected_players (puser, MENU_DRAW);

            } else if (menu_value == 6) {
                d->mode = 6;
                menu_connected_players (puser, MENU_DRAW);

			} else if (puser->map->area_map && menu_value == 7) {
       			menu_stack_clear (puser);

                menu_area_manager (puser, MENU_CREATE);
            } else if (menu_value == 8) {
                d->mode = 8;
       			menu_stack_clear (puser);

                menu_area_list (puser, MENU_CREATE);
				
            }
                
                    
        } else if (menu_name == 1) {
            strcpy (d->selected_user, d->user[menu_value]);
            menu_connected_player_menu (puser, MENU_CREATE, d);
        /*
            menu_stack_pop (puser);
            struct user *duser = user_connected_find_by_name (d->user[menu_value]);
            if (duser == NULL) {
                sprintf (temp, "%s appears to have disconnected.", d->user[menu_value]);
                menu_dialog (puser, MENU_CREATE, "User Disconnected", temp, "OK");
                break;
            }
        

            packet_send(puser, PACKET_MOVE_PLAYER, duser->position.x, duser->position.y, duser->position.z, duser->position.u, duser->position.v, 0);
        */
        
        
        
        } else if (menu_name == 4) {

            if (menu_value == 1) {

				if (menu_number != 255) {
					menu_edit_box (puser, MENU_CREATE, "Enter a nickname for chat", puser->nick, 24, 4, 1);
				} else {
					if (menu_char[0] == 0) {
						puser->nick[0] = 0;
						event_nick_change (puser);
						break;
					}

                	str_color_strip ((char *)menu_char);

					for (a = 0; a < strlen ((char *)menu_char); a++) {
						if (strchr ("~`@#%%&*()[]{}<>|", menu_char[a]) != 0) menu_char[a] = ' ';
					}

					strim ("lr", (char *)menu_char);

					if (strlen ((char *)menu_char) < 2) {
						menu_dialog (puser, MENU_CREATE, "Nickname", "Nickname is too short.", "OK");
						break;
					}


					int found = 0;
					
					if (user_id_by_name_partial (puser->map, (char *)menu_char, &found)) {
						menu_dialog (puser, MENU_CREATE, "Nickname", "Nickname is too close to a players name.", "OK");
						break;
					}

					_strncpy (puser->nick, (char *)menu_char, 25);
					menu_connected_players (puser, MENU_DRAW);
				}
				break;

				
            } else if (menu_value == 2) {
				puser->nick[0] = 0;
				menu_connected_players (puser, MENU_DRAW);
				
            } else if (menu_value == 3) {
                if (menu_number != 255) {
                    menu_color_choose (puser, MENU_CREATE, 4, 3);
                } else {
                    puser->color = menu_char[0];
                }
				
            } else if (menu_value == 4) {
                puser->no_rainbows = !puser->no_rainbows;
                menu_connected_players (puser, MENU_DRAW);
				
            } else if (menu_value == 5) {	
	            menu_skin_manager (puser, MENU_CREATE);
				
            } else if (menu_value == 6) {
                puser->no_nicknames = !puser->no_nicknames;
                menu_connected_players (puser, MENU_DRAW);

            } else if (menu_value == 8) {
                puser->no_area_names = !puser->no_area_names;
                menu_connected_players (puser, MENU_DRAW);

            }
        
        } else if (menu_name == 5) {
            menu_stack_clear (puser);
            user_map_switch (puser, map_array[menu_value].file);        

        } else if (menu_name == 6) {
            if (menu_value == 0) {
                menu_stack_clear (puser);
                command_reload (puser, "reload", "reload") ;
            } else if (menu_value == 1) {
			    if (menu_number != 255) {
				    menu_edit_box (puser, MENU_CREATE, "Shutdown in how many seconds?", "now", 5, 6, 1);
			    } else {
                    menu_stack_clear (puser);
                    command_server_shutdown (puser, "shutdown", (char *)menu_char);
			    }
			}
				/*
            } else if (menu_value == 2) {
				menu_management_server (puser, MENU_CREATE);
            } else if (menu_value == 3) {				
				
					menu_rank_manager (puser, MENU_CREATE);
            }*/

        } else if (menu_name == 8) {		
			if (menu_value == 1 && menu_flags == 0) {
			
				menu_connected_players (puser, MENU_DRAW);
				
			} else if (menu_value == 3) {
				d->offset ++;
				menu_connected_players (puser, MENU_DRAW);
			} else if (menu_value == 4) {
				d->offset --;
				menu_connected_players (puser, MENU_DRAW);
			}
            
                    
        } else if (menu_name == -1 && menu_value == -1) {
            menu_stack_clear (puser);

		} else {
            menu_connected_players (puser, MENU_DRAW);
			log_printf (puser, LDEBUG, "menu response not handled: %i %i", menu_name, menu_value);
		}
        
			

		break; }

	
	}
	
	return (1);
	
}

static void sub_connected_players (struct user *puser, struct d_menu_player_data *d) {
    int a;

    char temp[128];


    time_t t;
    time (&t);
    int col = 0, row = 4;
    int num = 0;
    int index = 10;
		
       
        	
        for (a = 1; a < NUM_USERS; a++) {
            if (user[a].current_mode != USER_CONNECTED) continue;
			if (&user[a] == puser) continue;
       		//if (user_is_ignored (&user[a], puser->uid)) continue;            

            _strncpy (d->user[num], user[a].name, 25);
            

            if (puser->map != user[a].map)           
                sprintf (temp, "(%s)", d->user[num]);
            else if (user[a].afk) 
                sprintf (temp, "%s(AFK)", d->user[num]);
            else 
                sprintf (temp, "%s", d->user[num]);
            if (rank_menu_allowed (puser->rank, "connected_players") && !user_is_ignored (&user[a], puser->uid))            
                packet_send(puser, PACKET_MENU_LINK, 20+num, col * 26, row, 1, (unsigned char) num, 0, temp);
            else 
				packet_send(puser, PACKET_MENU_TEXT, 20+num, col * 26, row, temp);	
                
			col++;
			if (col > 2) {
				col = 0;
				row ++;
				if (row > 20) break;
			}
			
            num++;
        }
        

    if (num == 0) {
        packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 11, "* No one here but you *");
        packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 12, "Why not convince your friends to play?");    
    }

}


static void sub_was_on (struct user *puser, struct d_menu_player_data *d) {
    time_t t;
    time (&t); 
    int a, b = 4;
    int index = 10;
    char temp[256];

    for (a = 0; a < NUM_HISTORY; a++) {
	    if (user_connection_history[a].name[0] == 0) continue;

	    if (user_connected_find_by_name (user_connection_history[a].name) != 0) continue;


	    sprintf (temp, "%-30s", user_connection_history[a].name);

	    time_ago (user_connection_history[a].t, t, temp + 27);


    //			the_date (temp + 27, user_connection_history[a].t) ;

	    packet_send(puser, PACKET_MENU_TEXT, index++, 2, b, temp);
	    b++;
    }


}


extern const char color_list[13][18];
static void sub_user_settings (struct user *puser, struct d_menu_player_data *d) {
	char temp[1024];


	int index = 10;
	
	
    
	sprintf (temp, "Your rank is currently \e%c%s", puser->rank->color, puser->rank->name);

	packet_send(puser, PACKET_MENU_TEXT, index++, 1, 4, temp);
	

	char *cp = 0;
	if (puser->nick[0] == 0) cp = "<not set>";
	else cp = puser->nick;
	sprintf (temp, "Nickname: \e%c%s", puser->color, cp);

	packet_send(puser, PACKET_MENU_TEXT, index++, 1, 5, temp);

    packet_send(puser, PACKET_MENU_LINK, index++, 50, 5, 4, 1, 0, "[ change ]");
	
	if (puser->nick[0] != 0) packet_send(puser, PACKET_MENU_LINK, index++, 40, 5, 4, 2, 0, "[ reset ]");
	
	
	sprintf (temp, "Chat Color: \e%c%s", puser->color, color_list[puser->color]);

	packet_send(puser, PACKET_MENU_TEXT, index++, 1, 7, temp);

    packet_send(puser, PACKET_MENU_LINK, index++, 50, 7, 4, 3, 0, "[ change ]");
    
    
    
    if (puser->no_rainbows)
        strcpy (temp, "\e\x0bRainbow\e\x09 names:\e\x02 DISABLED");
    else 
        strcpy (temp, "\e\x0bRainbow\e\x09 names:\e\x05 ENABLED");
        
    packet_send(puser, PACKET_MENU_TEXT, index++, 1, 11, temp);

    packet_send(puser, PACKET_MENU_LINK, index++, 50, 11, 4, 4, 0, "[ toggle ]");

	cp = "<client default>";
	if (puser->skin_name[0] != 0) cp = puser->skin_name;
	sprintf (temp, "Current Skin: \e\x05%s", cp);
    packet_send(puser, PACKET_MENU_TEXT, index++, 1, 13, temp);    
	
    packet_send(puser, PACKET_MENU_LINK, index++, 50, 13, 4, 5, 0, "[ change ]");	
	

   if (puser->no_nicknames)
        strcpy (temp, "Display nicknames:\e\x02 DISABLED");
    else 
        strcpy (temp, "Display nicknames:\e\x05 ENABLED");

    packet_send(puser, PACKET_MENU_TEXT, index++, 1, 15, temp);

    packet_send(puser, PACKET_MENU_LINK, index++, 50, 15, 4, 6, 0, "[ toggle ]");
  
    if (puser->map->area_map) {
        if (puser->no_area_names) 
            strcpy (temp, "\e\x09Show area 'welcome' messages:\e\x02 DISABLED");
        else 
            strcpy (temp, "\e\x09Show area 'welcome' messages:\e\x05 ENABLED");
        
        packet_send(puser, PACKET_MENU_TEXT, index++, 1, 17, temp);
    
        packet_send(puser, PACKET_MENU_LINK, index++, 50, 17, 4, 8, 0, "[ toggle ]");
    }
    return;
}

static void sub_server_config (struct user *puser, struct d_menu_player_data *d) {

	int index = 10;
   	if (rank_command_allowed (puser->rank, "reload"))
        packet_send(puser, PACKET_MENU_LINK, index++, 1, 5, 6, 0, 0, "[ Reload Server Configuration ]");

   	if (rank_command_allowed (puser->rank, "shutdown"))
        packet_send(puser, PACKET_MENU_LINK, index++, 1, 6, 6, 1, 0, "[ Shutdown server ]");
    
        packet_send(puser, PACKET_MENU_LINK, index++, 1, 7, 6, 2, 0, "[ Server Configuration ]");

		packet_send(puser, PACKET_MENU_LINK, index++, 1, 8, 6, 3, 0, "[ Rank manager ]");

    return;
}



static void sub_maps (struct user *puser, struct d_menu_player_data *d) {
	char temp[1024];
	int index;
	index = 10;
    
    packet_send(puser, PACKET_MENU_TEXT, index++, 0, 4, "#Users    Map Name                         Dimensions");    

    int a;
    int num = 0;
    for (a = 0; a < NUM_MAPS; a++) {
        if (!map_array[a].active) continue;
        int p = 0;
        int c;
        for (c = 1; c < NUM_USERS; c++) {
            if (user[c].current_mode != USER_CONNECTED) continue;
	        if (&user[c] == puser) continue;

            if (user[c].map == &map_array[a]) p ++;
        }
        
		if (puser->map == &map_array[a]) sprintf (temp, "You +%i", p);
		else sprintf (temp, "%i", p);
        packet_send(puser, PACKET_MENU_TEXT, index++, 0, 5 + num, temp);
        
		if (puser->map == &map_array[a]) 
	        packet_send(puser, PACKET_MENU_TEXT, index++, 10, 5 + num, map_array[a].file);
        else 
			packet_send(puser, PACKET_MENU_LINK, index++, 10, 5 + num , 5, (unsigned char) a, 0, map_array[a].file);
        
        sprintf (temp, "%ix%ix%i", map_array[a].dimension.x, map_array[a].dimension.y, map_array[a].dimension.z);
        packet_send(puser, PACKET_MENU_TEXT, index++, 43, 5 + num, temp);
        
        
        
        num++;
	
    }
    return;
}

static int menu_connected_player_menu (struct user *puser, int message_id, struct d_menu_player_data *pd) {
    char temp[512];

	int index;
    struct d_menu_player_data *d;
	struct user *duser ;
	d = (void *) menu_get_current_stack_item_memory (puser);
	
   	if (message_id != MENU_CREATE) {
		duser = user_connected_find_by_name (d->selected_user);
		if (duser == 0 || duser == NULL) {
			menu_stack_pop (puser);
           	menu_dialog (puser, MENU_CREATE, "Player unavailable", "The player has disconnected or is no longer available.", "OK");
		
			return (MENU_CLOSE);
		}
	}
    switch (message_id) {
	case MENU_CREATE:
		duser = user_connected_find_by_name (d->selected_user);		
		if (duser == 0 || duser == NULL) {
			menu_stack_pop (puser);
           	menu_dialog (puser, MENU_CREATE, "Player unavailable", "The player has disconnected or is no longer available.", "OK");
		
			return (MENU_CLOSE);
		}
        
       	d = menu_stack_push_init (puser, menu_connected_player_menu, pd, 0);
	case MENU_DRAW:
		index = 1;
        snprintf (temp, 256, "<< %s >>", d->selected_user);

		int lines = 0;
      	duser = user_connected_find_by_name (d->selected_user);		
		
		if (duser == NULL) {
			menu_stack_pop (puser);
           	menu_dialog (puser, MENU_CREATE, "Player unavailable", "The player has disconnected or is no longer available.", "OK");
			return (MENU_CLOSE);
		}
		
        if (puser->map->area_map) lines += 2;
		if (rank_command_allowed (puser->rank, "kick") && rank_compare_by_name (puser->rank_name, duser->rank_name)) lines++;
		if (rank_command_allowed (puser->rank, "who")) lines++;
		if (rank_command_allowed (puser->rank, "teleport")) lines++;        
		if (user_test_ignore (puser, duser)) lines++;        
		if (rank_command_allowed (puser->rank, "ban") && rank_compare_by_name (puser->rank_name, duser->rank_name)) lines++;
		if (duser != NULL && rank_compare_by_name (puser->rank_name, duser->rank_name)) lines++;		
		
		//Draw the menu
        packet_send(puser, PACKET_MENU_RESET, 0, 40, lines+4, 3); 
        packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 0, temp);
		lines = 2;
		
    	if (user_test_ignore (puser, duser)) {
		    if (user_is_ignored (puser, duser->uid))
			    packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, lines++, 4, 1, 0, "Stop Ignoring");
		    else
			    packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, lines++, 4, 0, 0, "Ignore");
		}
        if (rank_command_allowed (puser->rank, "teleport")) {
            if (puser->map == duser->map)
                packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, lines++, 5, 0, 0, "Teleport to");
            else {
                packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, lines++, 5, 0, 0, "Switch to same map as");
            }
        }
        if (puser->map->area_map) {
		    packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, lines++, 8, 0, 0, "Teleport to area");			
            if (area_is_invited (puser->map, d->selected_user, area_for_player (puser))) {
                packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, lines++, 7, 0, 0, "Uninvite");
            } else {
                packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, lines++, 6, 0, 0, "Invite to build");
            }
        }
		if (rank_compare_by_name (puser->rank_name, duser->rank_name)) {
	        if (rank_command_allowed (puser->rank, "kick")) packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, lines++, 3, 0, 0, "Kick");
    	    if (rank_command_allowed (puser->rank, "ban")) packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, lines++, 9, 0, 0, "Ban");
            int max;
            if (rank_struct_promote_limits (puser->rank, &max)) {
                if (rank_id_by_name (puser->rank->name) > rank_id_by_name (duser->rank->name)) {
                    sprintf (temp, "Change Rank (Currently %s)", duser->rank_name);
                    packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, lines++, 10, 0, 0, temp);
                }
            }
		}
		break;
	case MENU_COMMAND: {
		duser = user_connected_find_by_name (d->selected_user);		
        if (duser == NULL) {
            menu_stack_pop (puser);
            return(0);
        }
		int menu_number = -1;
		int menu_name = -1;
		int menu_value = -1;
		int menu_flags = -1;
		char menu_char[65536];
		menu_command_parse (puser, &menu_number, &menu_name, &menu_value, &menu_flags, (unsigned char *)menu_char);

		log_printf (puser, LDEBUG, "menu response bytes=%i, menu=%i, name=%i, value=%i, flags=%i", 
				puser->menu_data_size, menu_number, menu_name, menu_value, menu_flags);	

        log_printf (puser, LDEBUG, "Player menu for %s", d->selected_user);
        struct user *duser = user_connected_find_by_name (d->selected_user);
        if (duser == NULL && duser == puser) {
			menu_stack_pop (puser);
            sprintf (temp, "%s is no longer available.", d->selected_user);
            menu_dialog (puser, MENU_CREATE, "Player unvavailable", temp, "OK");
            break;
        }
    	if (menu_name == 3  && rank_command_allowed (puser->rank, "kick")) {
			if (menu_number != 255) {
				menu_edit_box (puser, MENU_CREATE, "Kick Reason", "Inappropriate behavior", 80, 3, 0);
			} else {
    			user_kick (puser, duser->uid, menu_char);
                menu_stack_clear (puser);

			}
    	} else if (menu_name == 4) {
			if (menu_value == 0) {
                menu_stack_clear (puser);
				user_ignore_add (puser, duser->uid);
				sprintf (temp, "All messages from %s will be ignored.", duser->name);
            	menu_dialog (puser, MENU_CREATE, "Ignore", temp, "OK");
				user_message (duser, MUSER, "Player %s has chosen to ignore you.", puser->name);
                if (puser->map->area_map) area_uninvite_player (duser, area_for_player (puser));
			} else {
                menu_stack_clear (puser);
				user_ignore_remove (puser, duser->uid);
				sprintf (temp, "Messages from %s will be displayed once again.", duser->name);
            	menu_dialog (puser, MENU_CREATE, "Ignore", temp, "OK");
				user_message (duser, MUSER, "Player %s is no longer ignoring you.", puser->name);
			}
    	} else if (menu_name == 5) {
            menu_stack_clear (puser);
            if (puser->map == duser->map)
            	packet_send(puser, PACKET_MOVE_PLAYER, duser->position.x, duser->position.y, duser->position.z, duser->position.u, duser->position.v, 0);
			else 
                user_map_switch (puser, duser->map->file);
    	} else if (menu_name == 6) {
            menu_stack_clear (puser);
            if (area_invite_player (duser, area_for_player (puser))) {
            	sprintf (temp, "%s has been invited to your area.", d->selected_user);
            	menu_dialog (puser, MENU_CREATE, "Invitation", temp, "OK");
            	user_message (duser, MUSER, "Player %s has invited you to build in their area.", puser->name);
            	break;
        	} else {
              	sprintf (temp, "%s could not be invited  Maybe they disconnected?", d->selected_user);
            	menu_dialog (puser, MENU_CREATE, "Invitation", temp, "OK");
        	}
        } else if (menu_name == 7) {
            menu_stack_clear (puser);
        	if (area_uninvite_player (duser, area_for_player (puser))) {
            	sprintf (temp, "%s has been uninvited.", d->selected_user);
            	menu_dialog (puser, MENU_CREATE, "Invitation Removal", temp, "OK");
				
				sprintf (temp, "You may no longer build in %s's area.", puser->name);
            	menu_dialog (duser, MENU_CREATE, "Invitation Revoked", temp, "OK");
        	}
    	} else if (menu_name == 8) {
            menu_stack_clear (puser);
			if (puser->map->area_map) area_player_locate (puser, area_for_player (duser));
			else packet_send(puser, PACKET_MOVE_PLAYER, 
				(float) puser->map->dimension.x / 2, (float) puser->map->dimension.y / 2, 
				(float)puser->map->sealevel+8, puser->position.u, puser->position.v, 0);
    	} else if (menu_name == 9 && rank_command_allowed (puser->rank, "ban")) {
			if (menu_number != 255) {
				menu_edit_box (puser, MENU_CREATE, "Ban Reason", "Inappropriate behavior", 80, 9, 0);
			} else {
                menu_stack_clear (puser);
    			user_ban (puser, duser->uid, menu_char);
			}
        } else if (menu_name == 10) {
            if (menu_value == 0) {
                int max;
                if (!rank_struct_promote_limits (puser->rank, &max)) return(0);
                menu_rank_choose (puser, MENU_CREATE, max + 1, 10, 1);		
            
            } else {
                log_printf (puser, LNOTE, "Rank change?");
                user_rank_change (puser, duser->uid, (unsigned char) menu_char[0]);            
                menu_stack_pop (puser);
            }
            
		} else if (menu_name == -1 && menu_value == -1) {
			menu_stack_pop (puser);

		} else {
			log_printf (puser, LDEBUG, "menu response not handled: %i %i", menu_name, menu_value);
		}
		
		break;}
	}
	return (1);
}

struct d_menu_rank_choose {
	int max_rank;
	int menu_name;
	int menu_value;
	
} d_menu_rank_choose;

int menu_rank_choose (struct user *puser, int message_id, int max_rank, int s_menu_name, int s_menu_value) {
	struct d_menu_rank_choose *d;
	int a, b;
	int index = 1;
	int lines = 0;
	
	d = menu_get_current_stack_item_memory (puser);

	switch (message_id) {
	case MENU_CREATE:
		log_printf (puser, LDEBUG, "rank choose menu");
		d = menu_stack_push_init (puser, menu_rank_choose, NULL, sizeof (struct d_menu_rank_choose));
		d->max_rank = max_rank;
		d->menu_name = s_menu_name;
		d->menu_value = s_menu_value;

	case MENU_DRAW: 
		for (a = 0; a < d->max_rank; a++) {
			if (rank[a].name[0] == 0) continue;
			lines++;
		}
		
        packet_send(puser, PACKET_MENU_RESET, 0, 35, lines+3, 3); 
        packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 0, "Choose Rank");
		
		b = 0;
		for (a = 0; a < d->max_rank; a++) {
			if (rank[a].name[0] == 0) continue;
			packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, b + 2, 2, a, 0, rank[a].name);
			b++;

		}
		break;
		
	case MENU_COMMAND: {
		int menu_number = -1;
		int menu_name = -1;
		int menu_value = -1;
		int menu_flags = -1;
		unsigned char menu_char[65535]; 
		
		//int text_length =  
        menu_command_parse (puser, &menu_number, &menu_name, &menu_value, &menu_flags, menu_char);
		if (menu_name == 2) {
			menu_stack_pop (puser);
            if (menu_value >= d->max_rank) {
                menu_proc (puser, MENU_DRAW);
                return(1);
            }
			unsigned char data[512];
			data[0] = 0;
			data[1] = d->menu_name;
			data[2] = d->menu_value;
			data[3] = 0;
			data[4] = menu_value;
			puser->menu_data = (char *)data;
			puser->menu_data_size = 5;

			menu_proc (puser, MENU_COMMAND);
			return (1);
		} else if (menu_name == -1 && menu_value == -1) {
			menu_stack_pop (puser);
		}
		break;}	
	}
	return (1);		
}

struct d_menu_color_choose {
	int name;
	int value;
};

int menu_color_choose (struct user *puser, int message_id, int name, int value) {
	struct d_menu_color_choose *d;
	int index = 1;
	d = menu_get_current_stack_item_memory (puser);
	switch (message_id) {
	case MENU_CREATE:
		d = menu_stack_push_init (puser, menu_color_choose, NULL, sizeof (struct d_menu_color_choose));
		d->name = name;
		d->value = value;
	case MENU_DRAW:
		index = 1;
		
        packet_send(puser, PACKET_MENU_RESET, 0, 25, 20, 3); 
        packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 0, "Choose a color");
		packet_send(puser, PACKET_MENU_TEXT, index++, 2, 3, "\e\x01 brown"); packet_send(puser, PACKET_MENU_LINK, index++, 11, 3, 2, 1, 0, "[ select ]");
		packet_send(puser, PACKET_MENU_TEXT, index++, 2, 4, "\e\x02 red");   packet_send(puser, PACKET_MENU_LINK, index++, 11, 4, 2, 2, 0, "[ select ]");		
		packet_send(puser, PACKET_MENU_TEXT, index++, 2, 5, "\e\x03 orange");packet_send(puser, PACKET_MENU_LINK, index++, 11, 5, 2, 3, 0, "[ select ]");		
		packet_send(puser, PACKET_MENU_TEXT, index++, 2, 6, "\e\x04 yellow");packet_send(puser, PACKET_MENU_LINK, index++, 11, 6, 2, 4, 0, "[ select ]");
		packet_send(puser, PACKET_MENU_TEXT, index++, 2, 7, "\e\x05 green"); packet_send(puser, PACKET_MENU_LINK, index++, 11, 7, 2, 5, 0, "[ select ]");
		packet_send(puser, PACKET_MENU_TEXT, index++, 2, 8, "\e\x06 blue");  packet_send(puser, PACKET_MENU_LINK, index++, 11, 8, 2, 6, 0, "[ select ]");
		packet_send(puser, PACKET_MENU_TEXT, index++, 2, 9, "\e\x07 purple");packet_send(puser, PACKET_MENU_LINK, index++, 11, 9, 2, 7, 0, "[ select ]");
		packet_send(puser, PACKET_MENU_TEXT, index++, 2, 10, "\e\x08 gray"); packet_send(puser, PACKET_MENU_LINK, index++, 11, 10, 2, 8, 0, "[ select ]");
		packet_send(puser, PACKET_MENU_TEXT, index++, 2, 11, "\e\x09 white");packet_send(puser, PACKET_MENU_LINK, index++, 11, 11, 2, 9, 0, "[ select ]");
		packet_send(puser, PACKET_MENU_TEXT, index++, 2, 12, "\e\x0a black"); packet_send(puser, PACKET_MENU_LINK, index++, 11, 12, 2, 10, 0, "[ select ]");		
		packet_send(puser, PACKET_MENU_TEXT, index++, 2, 13, "\e\x0b rainbow"); packet_send(puser, PACKET_MENU_LINK, index++, 11, 13, 2, 11, 0, "[ select ]");        
		packet_send(puser, PACKET_MENU_TEXT, index++, 2, 14, "\e\x0c pink"); packet_send(puser, PACKET_MENU_LINK, index++, 11, 14, 2, 12, 0, "[ select ]");
		packet_send(puser, PACKET_MENU_TEXT, index++, 2, 15, "\e\x0d silver"); packet_send(puser, PACKET_MENU_LINK, index++, 11, 15, 2, 13, 0, "[ select ]");
		packet_send(puser, PACKET_MENU_TEXT, index++, 2, 16, "\e\x0e gold"); packet_send(puser, PACKET_MENU_LINK, index++, 11, 16, 2, 14, 0, "[ select ]");
		packet_send(puser, PACKET_MENU_TEXT, index++, 2, 17, "\e\x0f ruby"); packet_send(puser, PACKET_MENU_LINK, index++, 11, 17, 2, 15, 0, "[ select ]");                
		packet_send(puser, PACKET_MENU_TEXT, index++, 2, 18, "\e\x10 emerald"); packet_send(puser, PACKET_MENU_LINK, index++, 11, 18, 2, 16, 0, "[ select ]");        
		break;
		
	case MENU_COMMAND: {
		int menu_number = -1;
		int menu_name = -1;
		int menu_value = -1;
		int menu_flags = -1;
		unsigned char menu_char[65535]; 
		menu_command_parse (puser, &menu_number, &menu_name, &menu_value, &menu_flags, menu_char);
		if (menu_name == 2) {
			menu_stack_pop (puser);
			unsigned char data[512];
			data[0] = 255;
			data[1] = d->name;
			data[2] = d->value;
			data[3] = 0;
			data[4] = menu_value;

			puser->menu_data = (char *)data;
			puser->menu_data_size = 5;

			menu_proc (puser, MENU_COMMAND);
		} else {
			menu_stack_pop (puser);
		}
		break;}	
	}
	return (1);		
}
