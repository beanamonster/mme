#include "global.h"

//http://stackoverflow.com/questions/3151779/how-its-better-to-invoke-gdb-from-program-to-print-its-stacktrace/4611112#4611112

#include <execinfo.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ucontext.h>
#include <unistd.h>


/* get REG_EIP from ucontext.h */

// replaced REG_EIP with REG_RIP for x86_64
#define __USE_GNU
#include <ucontext.h>

void bt_sighandler(int sig, siginfo_t *info, void *secret) {
  void *trace[16];
  char **messages = (char **)NULL;
  int i, trace_size = 0;
  ucontext_t *uc = (ucontext_t *)secret;

  /* Do something useful with siginfo_t */
 /* if (sig == SIGSEGV)
    printf("Got signal %d, faulty address is %p, " "from %p\n", sig, info->si_addr,  uc->uc_mcontext.gregs[REG_RIP]);
  else
    printf("Got signal %d#92;\n", sig);*/

  trace_size = backtrace(trace, 16);
  /* overwrite sigaction with caller's address */
  trace[1] = (void *) uc->uc_mcontext.gregs[REG_RIP];

  messages = backtrace_symbols(trace, trace_size);
  /* skip first stack frame (points here) */

  for (i=1; i<trace_size; ++i) {
    /* find first occurence of '(' or ' ' in message[i] and assume
     * everything before that is the file name. (Don't go beyond 0 though
     * (string terminator)*/
    size_t p = 0;
    while(messages[i][p] != '(' && messages[i][p] != ' ' && messages[i][p] != 0)
        ++p;

    char syscom[256];
    snprintf(syscom, 255, "addr2line %p -e %.*s", trace[i] , p, messages[i] );
           //last parameter is the filename of the symbol
    FILE *pp = popen (syscom, "r");
    char temp[1024];
    strcpy (temp, "(addr2line broken?)");
    if (pp != 0) {
        fgets (temp, 1024, pp);
        char *cp = strrchr (temp, '\r'); if (cp != 0) *cp = 0;
        cp = strrchr (temp, '\n'); if (cp != 0) *cp = 0;
        pclose (pp);
    }
    if (g_stdin_open) printf ("[%s (%s)]\n", messages[i], temp);
    if (g_log_file_handle != 0) fprintf (g_log_file_handle, "[%s (%s)]\n", messages[i], temp); 
    

  }
  if (g_log_file_handle != 0) fclose (g_log_file_handle);
  exit(0);
}

void backtrace_initalize () {

  /* Install our signal handler */
  struct sigaction sa;

  sa.sa_sigaction = (void *)bt_sighandler;
  sigemptyset (&sa.sa_mask);
  sa.sa_flags = SA_RESTART | SA_SIGINFO;

  sigaction(SIGSEGV, &sa, NULL);
  //sigaction(SIGUSR1, &sa, NULL);
  /* ... add any other signal here */
}

void crash() {
  char *p = NULL;
  memcpy (p, "tttttt", 6);
}
