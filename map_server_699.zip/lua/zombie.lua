
mme_npc_create_type ("zombie")
mme_npc_type_set ("zombie", "speed", 1.0)
mme_npc_type_set ("zombie", "skin", "zombie")
mme_npc_type_set ("zombie", "hitpoints", 20)
mme_npc_type_set ("zombie", "thing_type", 0)
mme_npc_type_set ("zombie", "sight", 200)
mme_npc_type_set ("zombie", "name", "\x0e\x11Zombie")

function mme_user_command (user, command, parameters) 
	
	if (command == "zombie") then
		if (mme_user_command_allowed (user, command) == 0) then	
			mme_user_send_message (user, "The /zombie command is not available!")
			return (0)
		end

		id = mme_npc_spawn_type (mme_user[user].map_file, "zombie", mme_user[user].position_x, mme_user[user].position_y, mme_user[user].position_z);
		
		mme_npc_set (id, "user_spawned", user);
		
		mme_user_send_message (user, "zombie: A zombie has been spawned.")
		return (1)
		
	elseif (command == "eibmoz") then

		count = 0
		for key,value in pairs(mme_npc) do 
			if (mme_npc[key].user_spawned == user) then 
				mme_npc_remove (key) 
				count = count + 1
			end
		end
		
		if (count == 0) then
			mme_user_send_message (user, "eibmoz: You have not spawned any zombies.")	
		elseif (count == 1) then
			mme_user_send_message (user, "eibmoz: Your zombie has been terminated.")			
		else 
			mme_user_send_message (user, "eibmoz: All " .. count .. " of your zombies have been terminated.")	
		end
		return (1)
	end
	return (0)

end


function mme_user_disconnect (user) 
	for key,value in pairs(mme_npc) do 
		if (mme_npc[key].user_spawned == user) then mme_npc_remove (key) end
		print(key,value) 
	end

	return (0)
end





print ("zombie.lua: loaded")


