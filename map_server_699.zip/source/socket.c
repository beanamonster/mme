/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"

;/*Notes about crazy windows sockets:

  * For sockets, windows uses WSAGetLastError() instead of errno

  * Closing a windows socket requires closesocket, not close.
  * Always use closesocket; In linux, closesocket is #defined as close.

*/

void socket_initialize() {

    #ifdef LINUX
        signal(SIGPIPE, SIG_IGN);
    #endif
    #ifdef WIN32
        WSADATA wsa;
        WSAStartup(0x0202, &wsa);
    #endif
};

void socket_set_nonblocking (int sock) {
    int mode;
    #ifdef LINUX
        mode = fcntl(sock, F_GETFL, 0);
        mode |= O_NONBLOCK;
        fcntl (sock, F_SETFL, mode);
    #else
        mode = 1;
        ioctlsocket(sock, FIONBIO, (void *) &mode);
    #endif
}




int socket_bind (char *ip, int port) {
    int sock;
    struct sockaddr_in server;
	server.sin_family=AF_INET;
    server.sin_port=htons(port);
    server.sin_addr.s_addr = (inet_addr (ip));
    sock = socket(AF_INET, SOCK_STREAM, 0);
    
    log_printf (NULL, LDEBUG, "Listen on %s:%i", ip, port);
    
	int b=1;
	setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (void *)&b, sizeof(b) );
    
    if (bind(sock, (struct  sockaddr  *) &server, sizeof(server)) == -1) {
        fprintf (stderr, "Unable to bind to address: %s\n", strerror(errno));
        return (-1);
    }
    
    if (listen(sock, 1)==-1) {
        fprintf (stderr, "Unable to listen on socket: : %s\n", strerror(errno));
        return (-1);
    }

    socket_set_nonblocking (sock);
    return (sock);
}

int socket_accept (char *ip, int length_ip, int parent_socket) {
    struct sockaddr_in client;
    int sock;
    int cs = sizeof (struct sockaddr_in);
    sock = accept(parent_socket, (struct  sockaddr  *) &client, (void *)&cs);
    if (sock == -1) {
        log_printf (NULL, LERROR, "accept failed while establishing connection: %s", strerror (errno));
        return (-1);
    }


    #ifdef LINUX
    int b=1; // disable nagle
    setsockopt(sock, SOL_TCP, TCP_NODELAY, (void *)&b, sizeof(b) );
    #endif
  
    // set socket to non-blocking
    socket_set_nonblocking (sock);    
	
    
    #ifdef LINUX
    	inet_ntop (AF_INET, &client.sin_addr, ip, length_ip);
    #else 
        _strncpy (ip, inet_ntoa (client.sin_addr), length_ip);
    #endif
    

    return (sock);

}

int socket_connect (char *address_in, int port, void * the_sockaddr) {
	int a, sock=0, b ;
  struct sockaddr_in target;
	struct hostent *phe;

  char address[1024];
  int ret=-1;
  char *cp;

  
  _strncpy (address, address_in, 1024);  address[1023] = 0;
  cp=strrchr (address, ':');
  if (cp!=0) {
  	*cp=0;
    cp++;
    port=atoi (cp);
  	log_printf (NULL, LDEBUG, "socket_connect: %s:%i", address, port);
  }
  

	target.sin_family=AF_INET;
  target.sin_port=htons(port);

  phe=(struct hostent *)gethostbyname(address);
  if (phe==0) {
    log_printf (NULL, LDEBUG, "gethostbyname() failed (%i)\n", errno);
    goto end;
  }

  if (phe->h_addr==0) {
   log_printf (NULL, LDEBUG, "gethostbyname has no IP for %s: %s\n", address,  strerror (errno));
    goto end;
  }

  target.sin_addr.s_addr = ((struct in_addr *)phe->h_addr)->s_addr;



//  iptochar (&target.sin_addr.s_addr, ip);

  sock=socket(AF_INET, SOCK_STREAM, 0);


  #ifdef WIN32
	b=1;
  setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, (void *)&b, sizeof(b));
  #else
	b=1;
	setsockopt(sock, SOL_TCP, TCP_NODELAY, (void *)&b, sizeof(b) );
  #endif
  
  
	/* connect() sucks.
  	connect() has no means of setting a timeout.  This means that it's somewhere
    between 70 seconds and forever, depending on the OS.  
    The only way to fix this is to do connect() in non-blocking mode, which is
    what is below.
    
 		Since firewalls are often black holes when it comes to unforwarded ports,
    we wait for 7 seconds and then give up.
    
    Is seven seconds long enough?  I have no idea.
  */
  
  #ifdef WIN32
  int mode=1;
  ioctlsocket (sock, FIONBIO, (void *)&mode);
  #else
  int mode = fcntl(sock, F_GETFL, 0);
  mode |= O_NONBLOCK;
  fcntl (sock, F_SETFL, mode);
	#endif
  
  time_t t_start, t_now;

  time (&t_start);
  while ((a=connect(sock ,(struct  sockaddr  *) &target, sizeof(target)))!=0) {
  	#ifdef WIN32
    /*Various versions of windows will return various messages here, so
    	the only way to make this work is to make sure we check the ones we
      absolutely know are bad.*/
    
		if (socket_error==WSAEADDRNOTAVAIL ||
          socket_error==WSAEAFNOSUPPORT ||
          socket_error==WSAECONNREFUSED ||
          socket_error==WSAEFAULT ||
          //socket_error==WSAEINVAL ||
          socket_error==WSAENETUNREACH ||
          socket_error==WSAEHOSTUNREACH 
          ) break;
    else if (socket_error==WSAEISCONN) {a=0; break;}
    //if (socket_error!=WSAEINPROGRESS && socket_error!=WSAEALREADY && socket_error!=WSAEWOULDBLOCK) break;
    Sleep (1);
		#else 
    if (errno!=EINPROGRESS && errno!=EALREADY) break;    
    usleep (1);
    #endif
  	
    time (&t_now);
		if (t_now-t_start>7) {a=-1; break;}    

  }

  if (a==-1) {
    log_printf (NULL, LDEBUG, "Connection to %s failed. %i %s\n", address, socket_error, strerror (socket_error));
    goto end;
  }

  #ifdef WIN32
  mode=0;
  ioctlsocket (sock, FIONBIO, (void *)&mode);
  #else
  mode = fcntl(sock, F_GETFL, 0);
  mode &= ~O_NONBLOCK;
  fcntl (sock, F_SETFL, mode);
	#endif
  
  ret=sock;
	if (the_sockaddr!=0) memmove (the_sockaddr, &target, sizeof (target));

end:


  if (ret==-1 && sock>2) closesocket (sock);


	return (ret);
}


int socket_recv_all (int sock, void *vp, unsigned int size, int timeout) {
	char *cp;
	int a, sz;
	fd_set rfds;
	struct timeval tv;
	int retval;
	  
    if (timeout==0) timeout=20;

	if (sock<0) {
		return (-1);
	}

	retval=0;

	cp=vp;
	sz=size;

	while (sz>0) {
	  FD_ZERO(&rfds);
	  FD_SET(sock, &rfds);

		tv.tv_sec = timeout;
		tv.tv_usec = 0;

        retval = select(sock+1, &rfds, 0, 0, &tv);

		if (retval==0) {
			return(-1);
		} else if (retval==-1) {
			return (-1);
		} else {
			a=recv (sock, cp, sz, 0);
			if (a<1) {
				return (-1);
			}
			cp+=a;
			sz-=a;
			if (sz<=0) break;
		}
	}
	

	return (1);
}




int socket_send_all (int sock, void *vp, unsigned int size, int timeout) {
  char *cp;
  int a, sz;
  fd_set rfds;
  struct timeval tv;
  int retval;

  
  if (timeout==0) timeout=20;

  if (sock<0) return (-1);

  cp=vp;
  sz=size;

  while (sz>0) {

    FD_ZERO(&rfds);

    FD_SET(sock, &rfds);

    tv.tv_sec = timeout;
    tv.tv_usec = 0;

    retval = select(sock+1, 0, &rfds, 0, &tv);

    if (retval==0) {
      return (-1);
    } else if (retval==-1) {
      return (-1);
    } else {
      a=send (sock, cp, sz, 0);
      if (a<1) {
        return (-1);
      }
      cp+=a;
      sz-=a;
      if (sz<=0) break;
    }
  }


  return (1);
}

char *socket_inet_ntop (int ignore, unsigned char *addr, char *out, int length) {
	snprintf (out, length, "%i.%i.%i.%i", addr[0], addr[1], addr[2], addr[3]);

	return (out);
}

#ifdef WIN32
	typedef int socklen_t;
#endif 

int socket_ip_local_get (int sock, char *buffer, int bufflen) {

    struct sockaddr_in name;
    socklen_t namelen = sizeof(name);
    int err = getsockname(sock, (struct sockaddr*) &name, &namelen);
	if (err == -1) {
		log_printf (NULL, LWARNING, "socket_ip_local_get: %s", strerror (errno));
		return (0);
	}

    socket_inet_ntop(0, (unsigned char *)&name.sin_addr, buffer, bufflen);
	return (1);
}


void get_interface_thing () {
    struct sockaddr_in target;

    int sock = socket_connect ("ping.multiplayermapeditor.com", 44436, &target);
    
    if (sock == -1) {
        log_printf (NULL, LWARNING, "Unable to connect to the server list");
    }

	char local_address[256] = {"\x00"};
	socket_ip_local_get (sock, local_address, 64);
	closesocket (sock);
	if (local_address[0] == 0) 
		log_printf (NULL, LERROR, "Could not determine the local interface address!  Make sure the map server is allowed to make outgoing connections.");
	else 
		log_printf (NULL, LNOTE, "Using local interface IP %s", local_address);

}


int socket_listener_bind () {

	int port = DEFAULT_TCP_PORT;
	char *cp  = strrchr (config.external_address, ':');
	if (cp != 0) {
		cp++;
		port = atoi (cp);
	}
	g_bind_socket = -1;

    g_bind_socket = socket_bind("0.0.0.0", port);
    if (g_bind_socket == -1) {
        log_printf (NULL, LERROR, "The port %i may be in use by another program, or perhaps\nyou have another server running?\n", port);
    } else {
	    user_message (&user[0], MNULL, "Waiting for connections on port %i", port);  
	}
	if (g_bind_socket != -1) return (1);
	return (0);
}

void socket_listener_unbind () {
	if (g_bind_socket != -1) closesocket (g_bind_socket);
	g_bind_socket = -1;
}
/*

int socket_ipv4_address_match (char *pagainst_addr, char *ptest_addr) {
    int slash_number = 32;
    char against[32];
    strcpy (against, pagainst_addr);
    char *cp = strchr (against, '/');
    if (cp != 0) {
        slash_number = atoi (&cp[1]);
        *cp = 0;
    }
    
    int test_address, against_address;
    inet_pton(AF_INET, against, (void *)&against_address);  against_address = ntohl (against_address);
    inet_pton(AF_INET, ptest_addr, (void *)&test_address);  test_address = ntohl (test_address);

    int mask = (1 << (32 - slash_number)) - 1;
   
    if ((test_address | mask) == (against_address | mask)) return (1);

    return (0);

}
*/
