/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"

static time_t waittime[NUM_USERS];
static time_t lasttime[NUM_USERS];
/*
    You know what's fun?  Function pointers.
    What's more fun than function pointers?  Arrays of them.
    What's more fun than that?  A pointer to an array of them.
*/
typedef struct tagMENU_LIST {
	char name[64];
    void *command_ptr;
} MENU_LIST;

struct d_menu_management {
    int mode;
    char user[256][25];
    char selected_user[25];
    char tf;
	int offset;
    MENU_LIST *subptr;
	int menu_number;
	int menu_name;
	int menu_value;
	int menu_flags;
	char menu_char[65535]; 
    int menu_text_length;
    struct config config;
    struct map *org_map;
    struct map map;
};
static int sub_status (struct user *puser, int message_id, struct d_menu_management *d);
static int sub_server (struct user *puser, int message_id, struct d_menu_management *d);
static int sub_maps (struct user *puser, int message_id, struct d_menu_management *d);
static int sub_users (struct user *puser, int message_id, struct d_menu_management *d);
static int sub_ranks (struct user *puser, int message_id, struct d_menu_management *d);

static MENU_LIST submenu_list[] = {
	{"status", sub_status},
	{"server", sub_server},
	{"maps", sub_maps},
	{"users", sub_users},
	{"ranks", sub_ranks},
	{{0, 0}} // Terminator: Add stuff before this.
};

int menu_management_timeout (struct user *puser, int init) {
	if (init) {
		time (&waittime[puser->idx]);
		waittime[puser->idx] += 10;
		menu_management_entry (puser, MENU_CREATE);
		return (0);
	}

	time_t t;
	time (&t);
    if (t != lasttime[puser->idx]) {
        menu_management_entry (puser, MENU_DRAW);
        lasttime[puser->idx] = t;
    }
    
	if (t >= waittime[puser->idx]) {
        menu_stack_clear (puser);
		user_set_write_event (puser, user_send_map);
		return (1);	
	}
	return (0);
}

int menu_management_entry (struct user *puser, int message_id) {
//	char temp[256];
	int index = 1;
//	int row = 2;
//    char str_time[256];
//    char name[25];

    switch (message_id) {
    case MENU_CREATE:
        menu_stack_push_init (puser, menu_management_entry, NULL, 0);
    
    case MENU_DRAW:
        packet_send(puser, PACKET_MENU_RESET, 0, 50, 6, 3);
        packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 0, "Management Interface");
        packet_send(puser, PACKET_MENU_LINK, index++, TEXT_CENTER_COLUMN, 2, 2, 0, 0, "Click here to start the management interface");
        char message[128];
        time_t t;
        time (&t);

        sprintf (message, "Map will load in %i seconds, otherwise.", (int)(waittime[puser->idx] - t));
		packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 4, message);
        return (1);
        
    case MENU_COMMAND: {    
		int menu_number = -1;
		int menu_name = -1;
		int menu_value = -1;
		int menu_flags = -1;
		unsigned char menu_char[65535]= {0}; 
		
        menu_command_parse (puser, &menu_number, &menu_name, &menu_value, &menu_flags, menu_char);
        switch (menu_name) {
        case 2:
            menu_stack_clear (puser);
            user_set_write_event (puser, NULL);
            menu_management (puser, MENU_CREATE);
            break;
        default:
            menu_stack_clear (puser);
    		user_set_write_event (puser, user_send_map);
            break;
        }

	    return (1);}
    }
    return (1);
}

//#define POINTER_TO_INDEX(base, offset, type) (size_t) ((offset - base) / sizeof (type))

int menu_management (struct user *puser, int message_id) {
	int index = 1;
	struct d_menu_management *d;
    int (*telephone)(struct user *, int, struct d_menu_management *);
	d = (void *) menu_get_current_stack_item_memory (puser);

	switch (message_id) {
	case MENU_CREATE:
		log_printf (puser, LDEBUG, "menu_management");

    	d = menu_stack_push_init (puser, menu_management, NULL, sizeof (struct d_menu_management));
        d->subptr = &submenu_list[0];
        memmove (&d->config, &config, sizeof (config));
        memmove (&d->map, &map_array[0], sizeof (struct map));
        d->org_map = &map_array[0];

		
	case MENU_DRAW:{
        packet_send(puser, PACKET_MENU_RESET, 0, 80, 24, 3);
		packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 0, "Server Management");
        
		index = 1;
        int column_offset = 0;
        // Go through the static list above and make buttons for the different parts.
        MENU_LIST *p;
        for (p = &submenu_list[0]; (p->name != 0 && p->command_ptr != 0); p++) {
            
            if (p == d->subptr) {
                packet_send(puser, PACKET_MENU_TEXT, index, column_offset, 2, p->name);
            } else {
                packet_send(puser, PACKET_MENU_LINK, index, column_offset, 2, 0, index - 1, 0, p->name);
            }
            
            column_offset += 10;            
            index++;
        }
        telephone = d->subptr->command_ptr;
        telephone (puser, MENU_DRAW, d);
        break;}
        

	case MENU_COMMAND: {
        d->menu_number = -1; d->menu_name = -1; d->menu_value = -1; d->menu_flags = -1; d->menu_char[0] = 0;
		d->menu_text_length = menu_command_parse (puser, &d->menu_number, &d->menu_name, &d->menu_value, &d->menu_flags, (unsigned char *)d->menu_char);
        if (d->menu_name == 0) {
    		log_printf (puser, LDEBUG, "[management] menu response bytes=%i, menu=%i, name=%i, value=%i, flags=%i", 
				puser->menu_data_size, d->menu_number, d->menu_name, d->menu_value, d->menu_flags);	

            if (d->menu_value >= 0 && d->menu_value < (sizeof (submenu_list) / sizeof (MENU_LIST)) - 1) {
                d->subptr = &submenu_list[d->menu_value];
		    } else {
                menu_stack_clear (puser);
			    log_printf (puser, LDEBUG, "menu response not handled: %i %i", d->menu_name, d->menu_value);
		    }
            telephone = d->subptr->command_ptr;
            menu_management (puser, MENU_DRAW);
        } else {
            telephone = d->subptr->command_ptr;
            telephone (puser, MENU_COMMAND, d);
        }			
		break; }
	}
	return (1);
	
}
static int sub_status (struct user *puser, int message_id, struct d_menu_management *d) {
//	int index = 10;
//	int row = 4;

	switch (message_id) {
	case MENU_DRAW: 	

  		break;

	case MENU_COMMAND:{
        if (d->menu_name != 1) break;

        menu_management (puser, MENU_DRAW);
	
	    break;}
    
    }
	return (1);
}

static int sub_maps (struct user *puser, int message_id, struct d_menu_management *d) {
	int index = 10;
	int row = 4;
//    int brow = 4;
    int a;
    char temp[256];
	switch (message_id) {
	case MENU_DRAW: 	
        if (d->map.area_map) snprintf (temp, 255, "(area map) %s", d->map.file);
        else _strncpy (temp, d->map.file, 32);
		packet_send(puser, PACKET_MENU_TEXT, index++, 35, row, temp);
        row++;
        
        snprintf (temp, 255, "Dimensions: %ix%ix%i (sealevel %i)", d->map.dimension.x, d->map.dimension.y, d->map.dimension.z, d->map.sealevel);
   		packet_send(puser, PACKET_MENU_TEXT, index++, 35, row, temp);
        row+=2;
        
        packet_send(puser, PACKET_MENU_TEXT, index++, 35, row, "Build Rank");
		snprintf (temp, 255, "<%s>", d->map.build_rank_name);
        packet_send(puser, PACKET_MENU_LINK, index++, 50, row, 1, 0, 0, temp);
		row += 2;

		packet_send(puser, PACKET_MENU_TEXT, index++, 35, row, "Block Palette");
        packet_send(puser, PACKET_MENU_INPUT, index++, 50, row, 1, 1, 25, 32, 0, d->map.block_palette_name);
		row += 2;		

		packet_send(puser, PACKET_MENU_TEXT, index++, 35, row, "Spawn Position");
        snprintf (temp, 255, "%02.02f", d->map.spawn.x);    
        packet_send(puser, PACKET_MENU_INPUT, index++, 50, row, 1, 2, 4, 4, 0, temp);
        snprintf (temp, 255, "%02.02f", d->map.spawn.y);    
        packet_send(puser, PACKET_MENU_INPUT, index++, 56, row, 1, 3, 4, 4, 0, temp);
        snprintf (temp, 255, "%02.02f", d->map.spawn.z);    
        packet_send(puser, PACKET_MENU_INPUT, index++, 62, row, 1, 4, 4, 4, 0, temp);
        snprintf (temp, 255, "%02.02f", d->map.spawn.u);    
        packet_send(puser, PACKET_MENU_INPUT, index++, 68, row, 1, 5, 4, 4, 0, temp);
        snprintf (temp, 255, "%02.02f", d->map.spawn.v);    
        packet_send(puser, PACKET_MENU_INPUT, index++, 74, row, 1, 6, 4, 4, 0, temp);

		row += 2;		

		packet_send(puser, PACKET_MENU_TEXT, index++, 35, row, "Map Scale");
        snprintf (temp, 255, "%02.02f", d->map.scale);
        packet_send(puser, PACKET_MENU_INPUT, index++, 50, row, 1, 7, 4, 4, 0, temp);
		row += 2;		

        packet_send(puser, PACKET_MENU_CHECK, index++, 36, row, 1, 8, menu_set_check (d->map.map_journal), "Block Journaling (/who)");
    	row += 2;

		packet_send(puser, PACKET_MENU_BUTTON, index++, 36, row, 1, 9, 0, 0, "Apply");

		packet_send(puser, PACKET_MENU_BUTTON, index++, 55, row, 1, 10, 0, 0, "Create New Map");

        row = 4;
        for (a = 0; a < NUM_MAPS; a++) {
            if (!map_array[a].active) continue;
            if (strcmp (map_array[a].file, d->map.file) == 0) {
                packet_send(puser, PACKET_MENU_TEXT, index++, 0, row, map_array[a].file);
            } else {
                packet_send(puser, PACKET_MENU_LINK, index++, 0, row, 1, a + 20, 0, map_array[a].file);
            }
            row++;
        }
        
  		break;

	case MENU_COMMAND:{
        if (d->menu_name != 1) break;
        if (d->menu_value == 1 && d->menu_text_length > 0) {
            d->menu_char[d->menu_text_length] = 0;
            strim ("lr", d->menu_char);
            if (strlen (d->menu_char) > 1) {
                _strncpy (d->map.block_palette_name, d->menu_char, 64);
            }
        } else if (d->menu_value == 2) {
            d->menu_char[d->menu_text_length] = 0;
            d->map.spawn.x = atof (d->menu_char);
        } else if (d->menu_value == 3) {
            d->menu_char[d->menu_text_length] = 0;
            d->map.spawn.y = atof (d->menu_char);
        } else if (d->menu_value == 4) {
            d->menu_char[d->menu_text_length] = 0;
            d->map.spawn.z = atof (d->menu_char);
        } else if (d->menu_value == 5) {
            d->menu_char[d->menu_text_length] = 0;
            d->map.spawn.u = atof (d->menu_char);
        } else if (d->menu_value == 6) {
            d->menu_char[d->menu_text_length] = 0;
            d->map.spawn.y = atof (d->menu_char);
        } else if (d->menu_value == 7) {
            d->menu_char[d->menu_text_length] = 0;
            float scale = atof (d->menu_char);
            if (scale >= 0.1 && scale <= 1.0) {
                d->map.scale = scale;
            }
        } else if (d->menu_value == 8) {
            d->map.map_journal = d->menu_flags;
        } else if (d->menu_value == 9) {
            memmove (d->org_map, &d->map, sizeof (struct map));
            d->org_map->save_counter ++;
            
        }
        menu_management (puser, MENU_DRAW);
	
	    break;}
    
    }
	return (1);
}
static int sub_users (struct user *puser, int message_id, struct d_menu_management *d) {
//	int index = 10;
//	int row = 4;

	switch (message_id) {
	case MENU_DRAW: 	

  		break;

	case MENU_COMMAND:{
        if (d->menu_name != 1) break;

        menu_management (puser, MENU_DRAW);
	
	    break;}
    
    }
	return (1);
}
static int sub_ranks (struct user *puser, int message_id, struct d_menu_management *d) {
//	int index = 10;
//	int row = 4;

	switch (message_id) {
	case MENU_DRAW: 	

  		break;

	case MENU_COMMAND:{
        if (d->menu_name != 1) break;

        menu_management (puser, MENU_DRAW);
	
	    break;}
    
    }
	return (1);
}

static int sub_server (struct user *puser, int message_id, struct d_menu_management *d) {
	int index = 10;
//	int a, len;
	char temp[256];
	int row = 4;

	switch (message_id) {
	case MENU_DRAW: 	
		packet_send(puser, PACKET_MENU_TEXT, index++, 1, row, "Server name");
        packet_send(puser, PACKET_MENU_INPUT, index++, 20, row, 1, 0, 32, 32, 0, d->config.name);
		row += 2;
		
		packet_send(puser, PACKET_MENU_TEXT, index++, 1, row, "External Address");
        packet_send(puser, PACKET_MENU_INPUT, index++, 20, row, 1, 1, 32, 255, 0, d->config.external_address);
		row += 2;		
		
		packet_send(puser, PACKET_MENU_TEXT, index++, 1, row, "Connection limit");
		snprintf (temp, 256, "%i", d->config.connection_limit);
        packet_send(puser, PACKET_MENU_INPUT, index++, 20, row, 1, 2, 3, 3, 0, temp);
		row += 2;

		packet_send(puser, PACKET_MENU_TEXT, index++, 1, row, "Connection timeout");
		snprintf (temp, 256, "%i", d->config.connection_timeout);
        packet_send(puser, PACKET_MENU_INPUT, index++, 20, row, 1, 3, 5, 5, 0, temp);
    	row += 2;

		packet_send(puser, PACKET_MENU_TEXT, index++, 1, row, "AFK timeout");
		snprintf (temp, 256, "%i", d->config.afk_timeout);
        packet_send(puser, PACKET_MENU_INPUT, index++, 20, row, 1, 4, 5, 5, 0, temp);
    	row += 2;


        packet_send(puser, PACKET_MENU_TEXT, index++, 1, row, "New user rank");
		snprintf (temp, 255, "<%s>", d->config.default_rank_name);
        packet_send(puser, PACKET_MENU_LINK, index++, 20, row, 1, 5, 0, temp);
		row += 2;
        
		packet_send(puser, PACKET_MENU_TEXT, index++, 1, row, "Min client version");
		snprintf (temp, 256, "%i", d->config.minimum_client_version);
        packet_send(puser, PACKET_MENU_INPUT, index++, 20, row, 1, 7, 5, 5, 0, temp);
		row += 2;


        packet_send(puser, PACKET_MENU_CHECK, index++, 1, row, 1, 8, menu_set_check (d->config.local_connections), "Unauthorized Connections Allowed");
    	row += 1;

        packet_send(puser, PACKET_MENU_CHECK, index++, 1, row, 1, 9, menu_set_check (d->config.announce_disabled), "Disable Server List Announcement");
    	row += 2;

		packet_send(puser, PACKET_MENU_BUTTON, index++, 1, row, 1, 10, 0, 0, "Apply");
  		break;

	case MENU_COMMAND:{
        if (d->menu_name != 1) break;
        if (d->menu_value == 0 && d->menu_text_length > 0) {
            d->menu_char[d->menu_text_length] = 0;
            strim ("lr", d->menu_char);
            if (strlen (d->menu_char) > 1) {
                _strncpy (d->config.name, d->menu_char, 64);
            }
        } else if (d->menu_value == 1 && d->menu_text_length > 0) {
            d->menu_char[d->menu_text_length] = 0;
            strim ("lr", d->menu_char);
            if (strlen (d->menu_char) > 1) {
                _strncpy (d->config.external_address, d->menu_char, 64);
            }
        } else if (d->menu_value == 2) {
            d->menu_char[d->menu_text_length] = 0;
            int v = atoi (d->menu_char);
            if (v > 0 || v < 256) d->config.connection_limit = v;
        } else if (d->menu_value == 3) {
            d->menu_char[d->menu_text_length] = 0;
            d->config.connection_timeout = atoi (d->menu_char);
        } else if (d->menu_value == 4) {
            d->menu_char[d->menu_text_length] = 0;
            d->config.afk_timeout = atoi (d->menu_char);
        } else if (d->menu_value == 5) {
            int max;
            rank_struct_promote_limits (user[0].rank, &max);
            menu_rank_choose (puser, MENU_CREATE, max + 1, 1, 6);		
            
        } else if (d->menu_value == 6) {
            int max;
            rank_struct_promote_limits (user[0].rank, &max);

            log_printf (puser, LNOTE, "Rank change?");
            int v = d->menu_char[0];
            if (v >= 0 && v <= max) 
                _strncpy (d->config.default_rank_name, rank[v].name, 32);

        } else if (d->menu_value == 7) {
            d->menu_char[d->menu_text_length] = 0;
            d->config.minimum_client_version = atoi (d->menu_char);
        } else if (d->menu_value == 8) {
            d->config.local_connections = d->menu_flags;
        } else if (d->menu_value == 9) {
            d->config.announce_disabled = d->menu_flags;
        } else if (d->menu_value == 10) {
            memmove (&config, &d->config, sizeof (config));
    		g_force_announcement = 1;
        }

        menu_management (puser, MENU_DRAW);

	
	    break;}
    
    }
    

	return (1);
}
