/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/

#define ANNOUNCE_SEND_INTERVAL 60
#define ANNOUNCE_PURGE_INTERVAL 320
#define ANNOUNCE_SEND_MINIMUM 30

struct server_xmit_data {
    unsigned short size;
    char name[64];
    char salt[20];
    char address[256];
    int connections_current;
    int connections_max;
    unsigned char server_type;
    char local_address[64];
}  __attribute__((__packed__));

struct server_acknowledge_packet {
    unsigned char result;
} __attribute__((__packed__)) ;

#define ANNOUNCE_OK 0
#define ANNOUNCE_NAME_TOO_SHORT 1
#define ANNOUNCE_BAD_ADDRESS 2
#define ANNOUNCE_BAD_PORT 3
#define ANNOUNCE_I_HATE_YOU 4
#define ANNOUNCE_TOO_EARLY 5
#define ANNOUNCE_BAD_MATH 6
#define ANNOUNCE_INVALID_LENGTH 7
#define ANNOUNCE_LIST_FULL 8

#define SERVER_TYPE_PUBLIC 0
#define SERVER_TYPE_PRIVATE 1
