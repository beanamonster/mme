/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"

void event_proc (struct user *puser) {
    if (puser->write_length < 61) {
        if (puser->write_event != NULL) {
            write_event = puser->write_event;
            write_event (puser, puser->write_init);
            if (puser->write_event == write_event) puser->write_init = 0;
        }
        
        if (puser->file_request_flag) {
            request_send_proc (puser);
        }
    }
}


void event_authentication_complete (struct user *puser) {
    log_printf (puser, LNOTE, "%s (#%i): Authentication complete", puser->name, puser->uid);
}

void event_map_loading_complete (struct user *puser) {
    log_printf (puser, LDEBUG, "Map send complete");

    if (puser->current_mode == USER_CONNECTING) {
		user_iptable_update (puser);
	    if (puser->new) {
            if (!lua_hook_call ("mme_user_event_new", puser) && access ("rules.txt", F_OK) == 0) user_show_message_file_dialog (puser, "rules.txt");
        }

	    if (puser->textures_sent) {
            if (!lua_hook_call ("mme_user_event_textures_sent", puser)) {                

			}
	    }
                
        if (!lua_hook_call ("mme_user_event_connected", puser)) {
            log_printf (puser, LNOTE, "%s has arrived", puser->name);
            if (access ("motd.txt", F_OK) == 0)
                user_show_message_file_dialog (puser, "motd.txt");
                
            if (access (puser->rank->motd_file, F_OK) == 0)
                user_show_message_file_dialog (puser, puser->rank->motd_file);
				
			char *list;
			
			int count = user_ip_lookup (puser, &list);
			if (count == 0) {
				user_message_broadcast (puser, MSYSTEM, "Player %s has arrived.", puser->name);
			} else {
				user_message_broadcast (puser, MSYSTEM, "Player %s has arrived. (Same IP address as %s)" , puser->name, list);
				_free (list);
			}
        }
    } else if (puser->current_mode == USER_NEW_MAP) {
        if (!lua_hook_call ("mme_user_event_map_switch", puser)) {
            user_message_broadcast (puser, MSYSTEM, "Player %s has joined map %s", puser->name, puser->map->file);
        }
    }
    user_connection_history_update (puser->name);		
  	user_mode_set (puser, USER_CONNECTED);
    user_announce_player (puser, NULL);    
	user_mail_display (puser) ;
	time (&puser->last_login_stamp);
    
    g_force_announcement = 1;
}

void event_user_disconnect (struct user *puser) {
	if (puser->previous_mode != USER_CONNECTED) return;
	if (puser->map == NULL) return;

    if ((puser->current_mode == USER_CONNECTED || puser->current_mode == USER_DISCONNECT)) {
        if (puser->map->area_map) {
		    area_release (puser);
		    area_uninvite_player_all (puser);
	    }
    }
//    paint_user_kill (puser);

	log_printf (puser, LDEBUG, "event_user_disconnect %i -> %i", puser->previous_mode, puser->current_mode);

    packet_broadcast (puser->map, USER_CONNECTED, puser, PACKET_DENOUNCE_PLAYER, puser->idx);	

    if (puser->previous_mode == USER_CONNECTED || puser->current_mode == USER_CONNECTED) {
        if (puser->disconnect_message[0] == 0)         
            sprintf (puser->disconnect_message, "Player %s has departed.", puser->name);

        if (!lua_hook_call ("mme_user_event_disconnect", puser)) {
            user_message_broadcast (puser, MSYSTEM, "%s", puser->disconnect_message);
        }

        log_printf (puser, LNOTE, "%s", puser->disconnect_message);
    }
	
    user_record_save (puser, puser->uid);
    
    g_force_announcement = 0;
}

void event_player_position_changed (struct user *puser, struct float_xyzuv new_position) {
    if (lua_hook_call ("mme_user_event_position_changed", puser, puser->position.x, puser->position.y, puser->position.z, puser->position.u, puser->position.v, 
        new_position.x, new_position.y, new_position.z, new_position.u, new_position.v)) {
    }        
    int a;
    float speed  = 0;
    double stamp = easy_time() - puser->position_stamp;
    
    speed = easy_distance_from (puser->position, new_position);

    if (stamp > 0)
        speed = ( speed / puser->map->scale) / stamp;
    else speed = 0;
    puser->position_stamp = easy_time();
    if (speed != puser->current_speed && speed > 0) {
        puser->current_speed = speed;
    }

	if (puser->map->area_map && puser->current_mode == USER_CONNECTED && !puser->no_area_names) {
		a = area_in (puser->map, puser->position.x, puser->position.y);
		if (a != puser->map->area_in[puser->idx] && puser->position.z < puser->map->dimension.z ) {
			if (a != -1) {
				if (puser->map->area[a].user_name[0] != 0) {
					user_message (puser, MSYSTEM, "Welcome to %s's area.", puser->map->area[a].user_name);
				}
			}
			puser->map->area_in[puser->idx] = a;
		}
	}
}

void event_nick_change (struct user *puser) {
	if (puser->nick[0] == 0) return;
    user_message_broadcast (puser, MSYSTEM, "Player \e%c%s\e\x03 has changed their nickname to \e%c%s", puser->color, puser->name, puser->color, puser->nick);	
}


void event_user_is_afk (struct user *puser, char *message) {
    if (message != NULL)
        user_message_broadcast (puser, MSYSTEM, "Player \e\%c%s\e\x08 is AFK: \e\x09%s", puser->color, user_name (puser, 0), message);
    else 
        user_message_broadcast (puser, MSYSTEM, "Player \e\%c%s \e\x08is AFK", puser->color, user_name (puser, 0));
}


void event_user_not_afk (struct user *puser, char *message) {
    if (message != NULL)
        user_message_broadcast (puser, MSYSTEM, "Player \e\%c%s\e\x08 is no longer AFK: \e\x09%s", puser->color, user_name (puser, 0), message);
    else 
        user_message_broadcast (puser, MSYSTEM, "Player \e\%c%s \e\x08is no longer AFK", puser->color, user_name (puser, 0));
}
