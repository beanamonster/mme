/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"

void rank_initialize () {
	memset (&rank, 0, sizeof (rank));
	
	// This is a special rank which provides unrestricted access.
	strcpy (rank[NUM_RANKS - 1].name, "owner");
	rank[NUM_RANKS - 1].can_chat = 1;
    rank[NUM_RANKS - 1].can_fly = 1;
    rank[NUM_RANKS - 1].can_sonic_fly = 1;
    rank[NUM_RANKS - 1].can_noclip = 1;
    rank[NUM_RANKS - 1].cuboid_volume_limit_meters = -0.1f;
    rank[NUM_RANKS - 1].cuboid_size_limit_meters = -0.1f;
    rank[NUM_RANKS - 1].transferable = 0;    	
    rank[NUM_RANKS - 1].color = 1;

	int a;
	for (a = 0; a < NUM_RANKS; a++) {
        rank[a].id = a;
    }
}

void rank_use_internal_defaults () {
	strcpy (rank[0].name, "twit");
	rank[0].can_chat = 1;
    rank[0].can_fly = 1;
    rank[0].can_sonic_fly = 1;
    rank[0].can_noclip = 1;
	rank[0].color = '1';
    rank[0].cuboid_volume_limit_meters = 1;
    rank[0].cuboid_size_limit_meters = 0;
	rank_command_allowed_add (&rank[0], "ignore");
	rank_command_allowed_add (&rank[0], "teleport");
	rank_command_allowed_add (&rank[0], "tp");
	rank_command_allowed_add (&rank[0], "server");
	rank_command_allowed_add (&rank[0], "undo");
	rank_menu_allowed_add (&rank[0], "my_settings");
	rank_menu_allowed_add (&rank[0], "maps");
	rank_menu_allowed_add (&rank[0], "connected_players");
	
	strcpy (rank[1].name, "guest");
	rank[1].can_chat = 1;
    rank[1].can_fly = 1;
    rank[1].can_sonic_fly = 1;
    rank[1].can_noclip = 1;
    rank[1].cuboid_volume_limit_meters = 9.144;
    rank[1].cuboid_size_limit_meters = 9.144;
	rank[1].color = '2';
	rank_command_allowed_add (&rank[1], "ignore");
	rank_command_allowed_add (&rank[1], "teleport");
	rank_command_allowed_add (&rank[1], "tp");
	rank_command_allowed_add (&rank[1], "server");
	rank_command_allowed_add (&rank[1], "undo");

	rank_menu_allowed_add (&rank[1], "my_settings");
	rank_menu_allowed_add (&rank[1], "maps");
	rank_menu_allowed_add (&rank[1], "connected_players");
	
	strcpy (rank[2].name, "member");
	rank[2].can_chat = 1;
    rank[2].can_fly = 1;
    rank[2].can_sonic_fly = 1;
    rank[2].can_noclip = 1;
    rank[2].cuboid_volume_limit_meters = 914.4;
    rank[2].cuboid_size_limit_meters = 914.4;
	rank[2].color = '3';
	rank_command_allowed_add (&rank[2], "ignore");
	rank_command_allowed_add (&rank[2], "teleport");
	rank_command_allowed_add (&rank[2], "tp");
	rank_command_allowed_add (&rank[2], "server");
	rank_command_allowed_add (&rank[2], "undo");
	
	rank_menu_allowed_add (&rank[2], "my_settings");
	rank_menu_allowed_add (&rank[2], "maps");
	rank_menu_allowed_add (&rank[2], "connected_players");
	
			
	strcpy (rank[3].name, "operator");
	strcpy (rank[3].promote_to, "member");
	rank[3].can_chat = 1;
    rank[3].can_fly = 1;
    rank[3].can_sonic_fly = 1;
    rank[3].can_noclip = 1;
    rank[3].cuboid_volume_limit_meters = 1524;
    rank[3].cuboid_size_limit_meters = 4572;
	rank[3].color = '4';
	rank_command_allowed_add (&rank[3], "ignore");
	rank_command_allowed_add (&rank[3], "teleport");
	rank_command_allowed_add (&rank[3], "tp");
	rank_command_allowed_add (&rank[3], "kick");
	rank_command_allowed_add (&rank[3], "ban");
	rank_command_allowed_add (&rank[3], "unban");
	rank_command_allowed_add (&rank[3], "rank");
	rank_command_allowed_add (&rank[3], "server");
	rank_command_allowed_add (&rank[3], "undo");
	
	rank_menu_allowed_add (&rank[3], "my_settings");
	rank_menu_allowed_add (&rank[3], "maps");
	rank_menu_allowed_add (&rank[3], "connected_players");
	
	strcpy (rank[4].name, "admin");
	strcpy (rank[4].promote_to, "operator");
	rank[4].can_chat = 1;
    rank[4].can_fly = 1;
    rank[4].can_sonic_fly = 1;
    rank[4].can_noclip = 1;
    rank[4].cuboid_volume_limit_meters = 1524;
    rank[4].cuboid_size_limit_meters = 4572;
	rank[4].color = '5';
	rank_command_allowed_add (&rank[4], "ignore");
	rank_command_allowed_add (&rank[4], "teleport");
	rank_command_allowed_add (&rank[4], "tp");
	rank_command_allowed_add (&rank[4], "kick");
	rank_command_allowed_add (&rank[4], "ban");
	rank_command_allowed_add (&rank[4], "unban");
	rank_command_allowed_add (&rank[4], "rank");
	rank_command_allowed_add (&rank[4], "server");
	rank_command_allowed_add (&rank[4], "undo");
	
	rank_menu_allowed_add (&rank[4], "my_settings");
	rank_menu_allowed_add (&rank[4], "maps");
	rank_menu_allowed_add (&rank[4], "connected_players");	
}


extern const char color_list[13][18];

void rank_command_allowed_add (struct rank *prank, char *str) {
	int a;
	for (a = 0; a < 256; a++) {
		if (prank->allowed_commands[a] == NULL) {
			prank->allowed_commands[a] = _malloc (4096);
			strcpy (prank->allowed_commands[a], str);
			break;
		}
	}
	if (a == 256) {
		log_printf (NULL, LERROR, "rank_command_allowed_add: No space left for allowed commands. (adding %s)", str);
	}
}


void rank_command_allowed_remove (struct rank *prank, char *str) {
	int a;
	for (a = 0; a < 256; a++) {
		if (prank->allowed_commands[a] == NULL) continue;
		if (strcasecmp (str, prank->allowed_commands[a]) == 0) {
			_free (prank->allowed_commands[a]);
			prank->allowed_commands[a] = NULL;
		}
		break;
	}
}

void rank_menu_allowed_add (struct rank *prank, char *str) {
	int a;
	for (a = 0; a < 256; a++) {
		if (prank->allowed_menus[a] == NULL) {
			prank->allowed_menus[a] = _malloc (4096);
			strcpy (prank->allowed_menus[a], str);
			break;
		}
	}
	
	if (a == 256) {
		log_printf (NULL, LERROR, "rank_menu_allowed_add: No space left for allowed commands. (adding %s)", str);
	}
}


void rank_menu_allowed_remove (struct rank *prank, char *str) {
	int a;
	for (a = 0; a < 256; a++) {
		if (prank->allowed_menus[a] == NULL) continue;
		if (strcasecmp (str, prank->allowed_menus[a]) == 0) {
			_free (prank->allowed_menus[a]);
			prank->allowed_menus[a] = NULL;
		}
		break;
	}
}

int rank_command_allowed (struct rank *prank, char *cmd) {
    int a;
	
	if (prank == &rank[NUM_RANKS - 1]) return (1);
    
    for (a = 0; a <256; a++) {
        if (prank->allowed_commands[a] == NULL) break;
        if (strcasecmp (prank->allowed_commands[a], cmd) == 0) return (1);
    }

    return (0);
}

int rank_menu_allowed (struct rank *prank, char *cmd) {
    int a;
	if (prank == &rank[NUM_RANKS - 1]) return (1);	
    
    for (a = 0; a < 256; a++) {
        if (prank->allowed_menus[a] == NULL) break;
        if (strcasecmp (prank->allowed_menus[a], cmd) == 0) return (1);
    }

    return (0);
}

struct rank * rank_struct_by_lowest () {
	int a;
	
	for (a = 0; a < NUM_RANKS; a++) {
		if (rank[a].name[0] == 0) continue;
		return (&rank[a]);
	}
    return (NULL);
}

int rank_id_by_highest () {
	int a;
	int ret = 0;
	
	for (a = 0; a < NUM_RANKS; a++) {
		if (rank[a].name[0] == 0) continue;
		ret = a;
	}
	return (ret);
}

struct rank * rank_struct_by_highest () {
	int a;
	int ret = 0;
	
	for (a = 0; a < NUM_RANKS; a++) {
		if (rank[a].name[0] == 0) continue;
		ret = a;
	}
	return (&rank[ret]);
}

int rank_id_find_empty() {
	int a;
	for (a = 0; a < NUM_RANKS - 1; a++) {
		if (rank[a].name[0] == 0) return (a);
	}
	return (-1);
}

int rank_id_by_name (char *str) {
	int a;
	if (strcasecmp (str, "console") == 0) {
		log_printf (NULL, LWARNING, "rank_id_by_name: search for \"console\" rank will always return -1");
		return (-1);
	}
	
    if (str == NULL || str == 0) return (-1);
	
	for (a = 0; a < NUM_RANKS; a++) {
		if (rank[a].name[0] == 0) continue;
		if (strcasecmp (str, rank[a].name) == 0) return (a);
	}
//	log_printf (NULL, LNOTE, "rank_id_by_name: rank [%s] does not exist, using lowest rank", str);
	return (-1);

}

struct rank * rank_find_struct_by_name (char *str) {
	int a;

	if (strcasecmp (str, "console") == 0) {
		log_printf (NULL, LWARNING, "rank_find_struct_by_name: search for \"console\" rank will always return NULL");
		return (NULL);
	}
	
	for (a = 0; a < NUM_RANKS; a++) {
		if (rank[a].name[0] == 0) continue;
		if (strcasecmp (str, rank[a].name) == 0) return (&rank[a]);
	}
    
//    log_printf (NULL, LERROR, "rank_find_struct_by_name: Can't find rank %s", str);
	return (NULL);
}


int rank_compare_by_name (char *str1, char *str2) {

	if (strcasecmp (str1, "console") == 0) {
		return (1);
	}
	
	if (rank_id_by_name (str1) > rank_id_by_name (str2)) return (1);

	return (0);
}

int rank_compare_by_name_ge (char *str1, char *str2) {

	if (strcasecmp (str1, "console") == 0) {
		return (1);
	}
	
	if (rank_id_by_name (str1) >= rank_id_by_name (str2)) return (1);

	return (0);
}
int rank_struct_promote_limits (struct rank *prank, int *max) {
	if (prank == &rank[NUM_RANKS - 1]) {
		*max = rank_id_by_highest ();
		return (1);	
	}

    if (prank->promote_to[0] == 0) return (0);
        
    *max = rank_id_by_name (prank->promote_to);
    log_printf (NULL, LDEBUG, "Rank %s can promote to %s(%i)", prank->name, prank->promote_to, *max);
   
    return (1);
}

int rank_count_active () {
	int a;
    int count = 0;
    // Do not include the onwer rank.
	for (a = 0; a < NUM_RANKS -1; a++) {
		if (rank[a].name[0] != 0) count ++;
	}
	return (count);
}
