/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/

#include "global.h"

/*
 BTR format
	("Just fucking save it.")
	Serial, name-value format for binary data.
	header:
	uint8_t id
	uint8_t name_length
	uint64_t payload length
	name_length bytes of name
	payload length bytes of payload
	
	
	id is the type of data
	1 byte (int8_t)
	2 short (int16_t)
	4 int (int32_t)
	5 float (float; 4 bytes)
	8 long long (int64_t)
	9 (double, 8 bytes)
	10 string (null-terminated unsigned char array)
	
	Names are all lower-case!  Why? Speed.  No strcasecmp/stricmp.
	
	The ids are arbitrarialy chosen to be the number of bytes each data type consists of;
	since ints and floats are both 4 bytes, float is 5.  The numbers are arbitrary, yet perminant.
	
	Any data type can have any size payload.  Example, if you read a file that has
	a type 2 (short), and it has 32 bytes, you can assume that the data is an array
	of shorts.  
	Strings are different, and are identical to bytes.  The distinction here is purely
	for data-organizational purpose.
	
	The primary use of this format is to store binary data in a easy to parse, variable
	length, change-friendly format.  
	
	Example: you're reading a bunch of data and you hit an id that you don't know how
	to process.  This is no problem since you have the payload length up-front.
	
	Example: You're storing numbers, and at some point in the developnment,
	you realize you need to make something a 32-bit int instead of a 16-bit int after
	creating hundreds of files.  Even if your data types change all the time, the loading
	code only needs to know how to make the different numbers the right format coming in.
	You can save it out as the new type and go on with your life.
	
	Why not text files?  think: I want to save multi-dimensional data.  .. Crap!

	That's probably enough examples.  No one cares, anyhow.  You'll probably just 
	just replace it with XML or SQL anyway, so have fun escaping your data and worrying 
	about SQL injections.

*/

/*
	btr_file_read_serial requires data_ptr to be a pointer to memory allocated by _malloc.  
	The memory will be reallocated by _realloc to fit the data it's reading in.
	The size of the allocated block must be no smaller than BTR_MEMORY_BLOCK.  
*/
int btr_file_read_serial (FILE *fn1, unsigned char *id, char *name, char **data_ptr, size_t *data_length_read) {
	char *data = *data_ptr;

	struct btr_header header;
	if (feof (fn1)) return (0);
	
	if (!fread (&header, sizeof (header), 1, fn1)) return (0);
	
	*id = header.id;
	if (!fread (name, header.name_length, 1, fn1)) return (0);
	name[header.name_length] = 0;

	size_t seek_it = 0;
	
	if (header.payload_length + 2 > BTR_MEMORY_BLOCK) {
		data = _realloc (data, header.payload_length + 1);
	}

	*data_length_read = header.payload_length;

	if (!fread (data, header.payload_length, 1, fn1)) return (0);

	if (!seek_it) {
		fseek (fn1, seek_it, SEEK_CUR);
		if (header.id == BTR_STRING) data[header.payload_length - 1] = 0;
	}
	*data_ptr = data;

	return (1);
}

int btr_file_write_serial (FILE *fn1, unsigned char id, char *name, char *data, size_t data_length) {

	struct btr_header header;
	memset (&header, 0, sizeof (header));
	
	if (data_length == 0) {
		if (id == BTR_BYTE) data_length = 1;
		else if (id == BTR_SHORT) data_length = 2;
		else if (id == BTR_INT) data_length = 4;
		else if (id == BTR_FLOAT) data_length = 4;
		else if (id == BTR_LONG) data_length = 8;
		else if (id == BTR_DOUBLE) data_length = 8;
		else if (id == BTR_STRING) data_length = strlen (data) + 1;
		else data_length = 1;
	}

	header.id = id;
	header.name_length = strlen (name) + 1;
	if (header.name_length > 254) header.name_length = 254;
	
	header.payload_length = data_length;
	
	fwrite (&header, sizeof (header), 1, fn1);
	fwrite (name, header.name_length, 1, fn1);
	fwrite (data, header.payload_length, 1, fn1);
	
	return (1);

}

// That was much easier than reading NBT, and you didn't have to convert from big endian.
