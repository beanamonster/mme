/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/

#include "global.h"

int config_logic_symbol (char *str) {
    if (strcmp (str, "1") == 0 || strcasecmp (str, "true") == 0 || strcasecmp (str, "on") == 0 || strcasecmp (str, "yes") == 0) return (1);
    else if (strcmp (str, "0") == 0 || strcasecmp (str, "false") == 0 || strcasecmp (str, "off") == 0 || strcasecmp (str, "no") == 0) return (0);
    
    log_printf (NULL, LWARNING, "Unknown logic symbol [%s].", str);
    return (0);
}

int config_salt_save () {
	FILE *fn1;
	fn1 = fopen ("salt.bin", "wb");
	if (fn1 == 0) {
		log_printf (NULL, LERROR, "Unable to save salt.bin: %s", strerror (errno));
		return (0);
	}
	
	fwrite (&config.salt, 20, 1, fn1);
	fclose (fn1);
	return (1);
}

int config_initialize () {
    FILE *fn1;
    memset (&block_palette, 0, sizeof (struct palette) * NUM_PALETTES);
	strcpy (g_shutdown_message, "The server is shutting down.");
	strcpy (g_shutdown_type, "restart");	
	
	#ifdef WIN32
		config.ansi = 0;
		config.pause_exit = 1;
	#else
		config.ansi = 1;
		config.pause_exit = 0;
	#endif
    
    _strncpy (config.name, "MME Map Server", 64);
    config.connection_limit = 8;
    config.connection_timeout = 1200;
    config.restart_dead_time = 1;
    config.local_connections = 0;    
    config.display_rank_names = 0;
	config.display_log = LNOTE;
    config.config_sync = 1;
    strcpy (config.default_rank_name, "guest");
	config.afk_timeout = 300;

	sprintf (config.external_address, ":%i", DEFAULT_TCP_PORT);

    config.minimum_client_version = 0;

	fn1 = fopen ("salt.bin", "rb");
	if (fn1 == 0) {
		unsigned char temp[256];
	    for (int a = 4; a < 256; a++) temp[a] = (255 * (rand() / (RAND_MAX + 1.0)));
		time ((time_t *) &temp);
		sha1 ((char *)config.salt, (char *)temp, 256);

		if (!config_salt_save()) {
			easy_die (NULL, 1);
		}
	} else {
		fread (&config.salt, 20, 1, fn1);
		fclose (fn1);
	}	

    return (1);
}

int config_server_online (int state) {
	int ret = -1;
    if (!config.online && state) {
		if (map_count_active () <= 0) {
			config.online = 0;
			log_printf (NULL, LWARNING, "server.online: No maps are currently loaded; the map server must have at least one map available before allowing connections.");
			ret = 0;
        } else if (texture_active_palette_count () == 0) {
			config.online = 0;
			log_printf (NULL, LWARNING, "server.online: No textures are currently loaded; the map server must have at least one texture palette available before allowing connections.");
			ret = 0;
		} else {
    		socket_listener_unbind();
			config.online = socket_listener_bind();
			if (config.online) {
				ret = config.online;
				log_printf (NULL, LWARNING, "server.online: Online.");
			} else {
				log_printf (NULL, LWARNING, "server.online: The server could not go online.  Check the console or log file for details.");
			}

		}
		g_force_announcement = 1;

	} else if (config.online && !state) {
		log_printf (NULL, LWARNING, "server.online:  Offline.");
		socket_listener_unbind();
		config.online = 0;
		g_force_announcement = 1;
		ret = 0;
	} else {
		log_printf (NULL, LWARNING, "server.online: no change");
		ret = config.online;
	}

	return (ret);
}

void config_save () {
	FILE *fn1;
    int a;
    char file_temp[PATH_MAX];
    char file_perminant[PATH_MAX];
    remove ("config.old");
    rename ("config.txt", "config.old");
    
    snprintf (file_temp, PATH_MAX, ".config.txt");
    snprintf (file_perminant, PATH_MAX, "config.txt");

	fn1 = fopen (file_temp, "wb");
	if (fn1 == 0) {
		log_printf (NULL, LERROR, "Unable to save config.txt: %s", strerror (errno));
	}
	
	fprintf (fn1, "# Warning: This file is overwritten by the server when it saves\r\n# configuration information.\r\n# Refer to readme.txt for documentation.\r\n# If you modify this file, do so while the server is not running.\r\n\r\n");
	fprintf (fn1, "/set server.name %s\r\n", config.name);
	fprintf (fn1, "/set server.external_address %s\r\n", config.external_address);
	fprintf (fn1, "/set server.connection_limit %i\r\n", config.connection_limit);
	fprintf (fn1, "/set server.connection_timeout %i\r\n", config.connection_timeout);
//	fprintf (fn1, "/set server.display_log_level %i\r\n", config.log_level);
	fprintf (fn1, "/set server.afk_timeout %i\r\n", config.afk_timeout);
	fprintf (fn1, "/set server.minimum_client_version %i\r\n", config.minimum_client_version);
	fprintf (fn1, "/set server.local_connections %i\r\n", config.local_connections);
	fprintf (fn1, "/set server.announce_disabled %i\r\n", config.announce_disabled);
	fprintf (fn1, "/set server.ansi %i\r\n", config.ansi);
	fprintf (fn1, "/set server.pause_exit %i\r\n", config.pause_exit);
    fprintf (fn1, "/set server.config_sync %i\r\n", config.config_sync);

	fprintf (fn1, "\r\n# Set up ranks\r\n\r\n");	
	for (a = 0; a < NUM_RANKS; a++) {
		if (rank[a].name[0] == 0) continue;
		if (strcasecmp (rank[a].name, "owner") == 0) continue;
		
		fprintf (fn1, "/rank_create %s\r\n", rank[a].name);
		if (strlen (rank[a].promote_to) > 0) fprintf (fn1, "/set rank.%s.promote_to %s\r\n", rank[a].name, rank[a].promote_to);
		fprintf (fn1, "/set rank.%s.can_chat %i\r\n", rank[a].name, rank[a].can_chat);
		fprintf (fn1, "/set rank.%s.can_build %i\r\n", rank[a].name, rank[a].can_chat);
		fprintf (fn1, "/set rank.%s.can_fly %i\r\n", rank[a].name, rank[a].can_fly);
		fprintf (fn1, "/set rank.%s.can_sonic_fly %i\r\n", rank[a].name, rank[a].can_sonic_fly);
		fprintf (fn1, "/set rank.%s.can_noclip %i\r\n", rank[a].name, rank[a].can_noclip);
		fprintf (fn1, "/set rank.%s.cuboid_volume_limit_meters %g\r\n", rank[a].name, rank[a].cuboid_volume_limit_meters);
		fprintf (fn1, "/set rank.%s.cuboid_size_limit_meters %g\r\n", rank[a].name, rank[a].cuboid_size_limit_meters);
		fprintf (fn1, "/set rank.%s.can_noclip %i\r\n", rank[a].name, rank[a].can_noclip);
		if (rank[a].color < 48) rank[a].color = 48;
		fprintf (fn1, "/set rank.%s.color %c\r\n", rank[a].name, rank[a].color);
		fprintf (fn1, "/set rank.%s.allowed_commands ", rank[a].name);
		for (int b = 0; b < 256; b++) {
			if (rank[a].allowed_commands[b] != NULL) { 
				fprintf (fn1, "%s, ", rank[a].allowed_commands[b]);
			}
		}
		fprintf (fn1, "\r\n");
		
		fprintf (fn1, "/set rank.%s.allowed_menus ", rank[a].name);
		for (int b = 0; b < 256; b++) {
			if (rank[a].allowed_menus[b] != NULL) { 
				fprintf (fn1, "%s, ", rank[a].allowed_menus[b]);
			}
		}
		fprintf (fn1, "\r\n\r\n");
	}
	fprintf (fn1, "\r\n# Maps to load\r\n\r\n");
	    
	for (a = 0; a < NUM_MAPS; a++) {
		if (map_array[a].file[0] == 0) continue;
		if (map_array[a].area_map) fprintf (fn1, "/map_load_area %s\r\n", map_array[a].file);
		else fprintf (fn1, "/map_load %s\r\n", map_array[a].file);
	}

	fprintf (fn1, "\r\n# Set up npc types\r\n\r\n");		

	int idx = 0;
	for (idx = 0; idx < NUM_NPC_TYPES; idx++) {
		if (npc_type[idx].name[0] == 0) continue;
		
		fprintf (fn1, "/npc_create_type %s\r\n", npc_type[idx].name);
		fprintf (fn1, "/set npc_type.%s.skin %s\r\n", npc_type[idx].name, npc_type[idx].skin);
		fprintf (fn1, "/set npc_type.%s.thing_type %i\r\n", npc_type[idx].name, npc_type[idx].thing_type);
		fprintf (fn1, "/set npc_type.%s.hitpoints %i\r\n", npc_type[idx].name, npc_type[idx].hitpoints);
		fprintf (fn1, "/set npc_type.%s.defense %i\r\n", npc_type[idx].name, npc_type[idx].defense);
		fprintf (fn1, "/set npc_type.%s.strength %i\r\n", npc_type[idx].name, npc_type[idx].strength);
		fprintf (fn1, "/set npc_type.%s.attack_range %i\r\n", npc_type[idx].name, npc_type[idx].attack_range);
		fprintf (fn1, "/set npc_type.%s.attack_chance %i\r\n", npc_type[idx].name, npc_type[idx].attack_chance);

		fprintf (fn1, "/set npc_type.%s.randomness %i\r\n", npc_type[idx].name, npc_type[idx].randomness);


		fprintf (fn1, "/set npc_type.%s.sight %i\r\n", npc_type[idx].name, npc_type[idx].sight);
		fprintf (fn1, "/set npc_type.%s.speed %0.02f\r\n", npc_type[idx].name, npc_type[idx].speed);
		fprintf (fn1, "/set npc_type.%s.decay %0.02f\r\n", npc_type[idx].name, npc_type[idx].decay);
	
	}    
	fprintf (fn1, "\r\n# Set up npcs\r\n\r\n");		

	for (idx = 0; idx < NUM_NPCS; idx++) {
		if (npc[idx].active == 0) continue;
		fprintf (fn1, "/npc_spawn_type %s %s %g %g %g\r\n", npc[idx].map->file, npc[idx].type->name, npc[idx].position.x, npc[idx].position.y, npc[idx].position.z);
	}    
	
	fclose (fn1);
    file_replace (file_perminant, file_temp);
}
