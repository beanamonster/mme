/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"

#define BLOCK_INVISIBLE 1
#define BLOCK_IMPASSIBLE 2
#define BLOCK_REVERSE 4

void add_block_group (struct palette *pp, char *str, int block_id) ;

struct texture *texture_find_by_filename (struct palette *pp, char *filename) ;


struct texture * texture_add_with_defaults (struct palette *pp, char *filename) {
//    int ret = 0;
    struct texture *t = NULL;
    
    t = texture_find_by_filename (pp, filename);
    if (t != NULL) return (t);

    t = texture_find_empty (pp);
    _strncpy (t->file, filename, 256);

    t->usage = 1;                
    t->x_pm = -1;
    t->y_pm = -1;
    t->alpha = 1.0;

    if (!sha1_file (t->file, (char *)t->sha1)) {
        return (NULL);
    }  

    request_file_add (t->file);
    pp->num_textures ++;
    return (t);
}

int true_false (char *str) {
    if (strcasecmp ("true", str) == 0 || strcasecmp ("on", str) == 0 || strcasecmp ("1", str) == 0 || strcasecmp ("yes", str) == 0) return (1);
    if (strcasecmp ("false", str) == 0 || strcasecmp ("off", str) == 0 || strcasecmp ("0", str) == 0 || strcasecmp ("no", str) == 0) return (0);
    log_printf (NULL, LERROR, "[%s] is not recognized as a logic state; defaulting to false", str);
    return (0);
}

int sha1_file (char *filename, char *sha1_out) {
    FILE *fn1;
    char *buffer;
    struct stat st;
    fn1 = fopen (filename, "rb");
    if (fn1 == 0) {
        log_printf (NULL, LWARNING, "sha1_file: unable to open [%s]: %s", filename, strerror(errno));
        return (0);
    }
        
    fstat (fileno(fn1), &st);
    buffer = _malloc (st.st_size + 1);
    fread (buffer, st.st_size, 1, fn1);
    fclose (fn1);
    
    sha1(sha1_out, buffer, st.st_size);
    
    _free (buffer);
    return (1);
}

int text_sort (char *str1, char *str2) {
	int a;
	int l1, l2, b;
	l1 = strlen (str1);
	l2 = strlen (str2);
	if (l1 < l2) b = l1; else b = l2;
	
	for (a = 0; a < b; a++) {
		if (str1[a] < str2[a]) break;
		
		if (str1[a] > str2[a]) {
			return (1);
		}
	}

	return (0);
}

void texture_sort_range (struct palette *pp, int first, int last) {
	int sorting = 0;
	int a = first + 1;

	while (1) {
		if (a >= last-1) {
			if (sorting == 0) break;
			sorting = 0;
		
		}
		int ts = text_sort (pp->texture[a - 1].file, pp->texture[a].file);

		if (ts == 1) {
			sorting = 1;			
			struct texture t;
			memmove (&t, &pp->texture[a - 1], sizeof (t));
			memmove (&pp->texture[a - 1], &pp->texture[a], sizeof (t));				
			memmove (&pp->texture[a], &t, sizeof (t));
			a = first + 1;
		} else {
			a ++;
		}
		
	}
}
struct texture *current_new_texture;
/*
void texture_initialize () {
    int b;
    
    for (b = 0; b < NUM_PALETTES; b++) {

        if (!block_palette[b].active) continue;

        int a;
        for (a = 0; a < CLIENT_TEXTURE_LIMIT; a++) {

            block_palette[b].texture[a].id = a + 1;
            block_palette[b].texture[a].x_pm = -1;
            block_palette[b].texture[a].y_pm = -1;
            block_palette[b].texture[a].alpha = 0.0;
            block_palette[b].texture[a].flags = 3;
            block_palette[b].texture[a].usage = 0;
            block_palette[b].texture[a].file[0] = 0;
            
        }

        current_new_texture = &block_palette[b].texture[0];
        block_initialize(&block_palette[b]);
    }

    
}*/


int texture_block_by_description (struct palette *pp, char *name) {
    int a;
    
    for (a = 0; a < 256; a++) {
        if (strcasecmp (name, pp->block[a].name) == 0) return (a);
    }
    
    log_printf (NULL, LWARNING, "block_by_description: unable to match %s to any block name", name);
    return (1);

}

void texture_name_data_parse (struct texture *ptexture) {

	char temp[1024];
	char *args[8];
	_strncpy (temp, ptexture->file, 1024);
	char *cp2 = strrchr (temp, '.');
	if (cp2 != 0) {
		if (strcasecmp (cp2, ".jpg") == 0) *cp2 = 0;
		else if (strcasecmp (cp2, ".png") == 0) *cp2 = 0;		
	}

	int num = csv_parse (temp, ' ', args, 8);


	ptexture->x_pm = -1;
	ptexture->y_pm = -1;
	ptexture->alpha = 0.0;
	ptexture->flags = 3;
	ptexture->usage = 0;


	if (num > 1) ptexture->x_pm = atof (args[1]);
	if (num > 2) ptexture->y_pm = atof (args[2]);
	if (num > 3) ptexture->alpha = atof (args[3]);
	if (num > 4) ptexture->flags = atoi (args[4]);

	log_printf (NULL, LDEBUG, "  Parameters: x%0.2f y%0.2f a%0.2f %i",ptexture->x_pm, ptexture->y_pm , ptexture->alpha, ptexture->flags);
}

    
void block_initialize (struct palette *pp, char *filename) {      
    FILE *fn1;
	
	memset (pp, 0, sizeof (struct palette));
    _strncpy (pp->path, filename, 256);	
    
//    memset (&pp->block, 0, sizeof (struct block) * 256);
    int a;
    
    pp->skybox_top = NULL;
    pp->skybox_bottom = NULL;
    pp->skybox_left = NULL;
    pp->skybox_right = NULL;
    pp->skybox_back = NULL;
    pp->skybox_front = NULL;
    pp->skybox_flags = 1;
    
    for (a = 0; a < CLIENT_TEXTURE_LIMIT; a++) {

        pp->texture[a].id = a + 1;
        pp->texture[a].x_pm = -1;
        pp->texture[a].y_pm = -1;
        pp->texture[a].alpha = 0.0;
        pp->texture[a].flags = 3;
        pp->texture[a].usage = 0;
        pp->texture[a].file[0] = 0;

    }

    current_new_texture = &pp->texture[0];
        
    char temp[256];
    char *cp;

	char config_file[PATH_MAX];

    for (a = 0; a < 256; a++) {
        pp->block[a].texture_top = &pp->texture[0];
        pp->block[a].texture_bottom = &pp->texture[0];
        pp->block[a].texture_left = &pp->texture[0];
        pp->block[a].texture_right = &pp->texture[0];
        pp->block[a].texture_front = &pp->texture[0];
        pp->block[a].texture_back = &pp->texture[0];
        pp->block[a].cuboidable = 1;
    }
    
    _strncpy (pp->block[255].name, "air", 64);

	snprintf (config_file, PATH_MAX, "%s/blocks.txt", pp->path);
	fn1 = fopen (config_file, "rb");
    
	if (fn1 == 0) {
		log_printf (NULL, LERROR, "block_initialize: unable to open %s: %s", config_file, strerror (errno));
		easy_die (NULL, 1);
	}
    
    int id = 0;
    char *cp2;
    int line = 0;

    pp->num_textures = 0;
    
    pp->skin[0].texture = &pp->texture[0];
    _strncpy (pp->skin[0].name, "Client Default", 32);
    pp->skin[0].visible = 1;

    int current_skin = 0;
    char subsection[32];
    
    while (fgets (temp, 256, fn1)) {
        line++;
        cp = strchr (temp, '\r'); if (cp !=0)  *cp = 0;
        cp = strchr (temp, '\n'); if (cp !=0)  *cp = 0;
        strim ("lr", temp);
        if (temp[0] == '#') continue;
        if (temp[0] == 0) continue;


        if (temp[0] == '[' && temp[strlen(temp) - 1] == ']') {

            _strncpy (temp, temp + 1, 256);
            cp = strrchr (temp, ']');
            if (cp != 0) *cp = 0;
            strim ("lr", temp);
            
            cp = strchr (temp, ':');
            if (cp == NULL) {

                log_printf (NULL, LDEBUG, "%s %i: no colon in title.  Assuming it's a block", config_file, line);


				char temp2[256];
				sprintf (temp2, "block:%s", temp);
				strcpy (temp, temp2);
				cp = &temp[5];
				
            }
            *cp = 0;
            cp++;
            
            _strncpy (subsection, temp, 32);
            memmove (temp, cp, strlen (cp) + 1); 
            
            if (strcasecmp (subsection, "block") == 0) {

                cp = strchr (temp, '.');
                if ( cp == 0) {
                    log_printf (NULL, LERROR, "%s %i: no period in block title.  Should be [block#.block_name]", config_file, line);
					easy_die (NULL, 1);
                }

                *cp = 0;
                cp++;


                id = atoi (temp);

                if (id < 1 || id > 254) {
                    log_printf (NULL, LERROR, "%s #%i: block ID %i is not allowed.  Valid range is from 1 to 254.", config_file, line, id);
					easy_die (NULL, 1);
                }

                _strncpy  (pp->block[id].name, cp, 64);

                log_printf (NULL, LDEBUG, "Setting up block #%i: %s", id, pp->block[id].name);
            } else if (strcasecmp (subsection, "skin") == 0) {
                current_skin ++;	
				_strncpy  (pp->skin[current_skin].name, temp, 64);
            } else if (strcasecmp (subsection, "skybox") == 0) {
                
            }

        
            continue;
        }

        cp = temp;
        
        cp2 = strchr (cp, '=');
        if (cp2 == 0) {
            log_printf (NULL, LWARNING, "No = in statement [%s] on line %i", cp, line);
            continue;
        }
        
        *cp2 = 0;
        cp2++;

        strim ("lr", cp);
        strim ("lr", cp2);
        
        if (strcasecmp (subsection, "block") == 0) {
		
			char *subsection = strchr (cp, '.');
			if (subsection != NULL) {
				*subsection = 0;
				subsection++;
			}
		
            if (strcasecmp (cp, "group") == 0 )  {
                _strncpy (pp->block[id].group, cp2, 64);
                add_block_group (pp, pp->block[id].group, id);


            } else if (strcasecmp (cp, "texture") == 0 )  {
                log_printf (NULL, LDEBUG, "    texture file [%s]", cp2);
				
                struct texture *ptexture = texture_find_by_filename (pp, cp2);
                if (ptexture == NULL) {

                    ptexture = current_new_texture = texture_find_empty (pp);
                    _strncpy (current_new_texture->file, cp2, 255);
                    pp->num_textures ++;

                    ptexture = current_new_texture;
                    
                    
                    if (!sha1_file (current_new_texture->file, (char *)current_new_texture->sha1)) {
                        log_printf (NULL, LERROR, "%s %i: texture file %s cannot be opened to read sha1", config_file, line, cp);
						easy_die (NULL, 1);
                    }
                    current_new_texture->usage = 1;
					texture_name_data_parse (current_new_texture);
                    
                    request_file_add (current_new_texture->file);                    


                }
				if (subsection == NULL) {
	                pp->block[id].texture_top = ptexture;				
	                pp->block[id].texture_bottom = ptexture;
                	pp->block[id].texture_left = ptexture;
            	    pp->block[id].texture_right = ptexture;
        	        pp->block[id].texture_front = ptexture;
    	            pp->block[id].texture_back = ptexture;

	                pp->block[id].texture_top->usage++;

				} else if (strcasecmp (subsection, "top") == 0) {
	                pp->block[id].texture_top = ptexture;
					pp->block[id].texture_top->usage++;

				} else if (strcasecmp (subsection, "bottom") == 0) {
	                pp->block[id].texture_bottom = ptexture;
					pp->block[id].texture_bottom->usage++;

				} else if (strcasecmp (subsection, "left") == 0) {
	                pp->block[id].texture_left = ptexture;
					pp->block[id].texture_left->usage++;
					
				} else if (strcasecmp (subsection, "right") == 0) {
	                pp->block[id].texture_right = ptexture;
					pp->block[id].texture_right->usage++;

				} else if (strcasecmp (subsection, "front") == 0) {
	                pp->block[id].texture_front = ptexture;
					pp->block[id].texture_front->usage++;

				} else if (strcasecmp (subsection, "back") == 0) {
	                pp->block[id].texture_back = ptexture;
					pp->block[id].texture_back->usage++;
				} else {
                    log_printf (NULL, LERROR, "Texture \"%s\" on line %i has unknown side \"%s\"", cp2, line, subsection);
					easy_die (NULL, 1);
				}

            } else if (strcasecmp (cp, "texture_property_x") == 0 )  {
                current_new_texture->x_pm = atof (cp2);

            } else if (strcasecmp (cp, "texture_property_y") == 0 )  {
                current_new_texture->y_pm = atof (cp2);

            } else if (strcasecmp (cp, "texture_property_alpha") == 0 )  {
                current_new_texture->alpha = atof (cp2);

            } else if (strcasecmp (cp, "texture_property_flags") == 0 )  {
                current_new_texture->flags = atoi (cp2);

            } else if (strcasecmp (cp, "visible") == 0 )  {
                if (true_false (cp2)) {pp->block[id].flags |= BLOCK_INVISIBLE;}

            } else if (strcasecmp (cp, "impassible") == 0 )  {
                if (true_false (cp2)) pp->block[id].flags |= BLOCK_IMPASSIBLE;
            } else if (strcasecmp (cp, "reverse") == 0 )  {
                if (true_false (cp2)) pp->block[id].flags |= BLOCK_REVERSE;
            } else if (strcasecmp (cp, "hidden") == 0 )  {
                if (true_false (cp2)) pp->block[id].hidden = 1;
            } else if (strcasecmp (cp, "cuboidable") == 0 )  {
                pp->block[id].cuboidable = true_false (cp2);
            } else if (strcasecmp (cp, "damage") == 0 )  {
                pp->block[id].damage = true_false (cp2);
            } else if (strcasecmp (cp, "flow_depth") == 0 )  {
                pp->block[id].flow_depth = atoi (cp2);
            } else if (strcasecmp (cp, "explosiveness") == 0 )  {
                pp->block[id].explosiveness = atof (cp2);
            } else if (strcasecmp (cp, "min_rank") == 0 )  {
                _strncpy (pp->block[id].min_rank, cp2, 32);
			} else if (strcasecmp(cp, "light") == 0) {
				int p = atoi (cp2);
				if (p < 0 || p > 3) {
                	log_printf (NULL, LERROR, "Light value on line %i must be 0, 1, 2, or 3.", line);
           			easy_die (NULL, 1);
				}
				pp->block[id].flags |= (p << 3);	
				

            } else if (strcasecmp (cp, "chainload") == 0 )  {
                fclose (fn1);
                fn1 = fopen (cp2, "rb");
                if (fn1 == 0) {
                    log_printf (NULL, LERROR, "Chainloaded file \"%s\" on line %i cannot be opened.", cp2, line);
               		easy_die (NULL, 1);
                }
                
                line = 0;

            } else {
                log_printf (NULL, LERROR, "%s %i: Unknown block keyword \"%s\".", config_file, line, cp);
           		easy_die (NULL, 1);

            }
            
        } else if (strcasecmp (subsection, "skybox") == 0) {

            if (strcasecmp (cp, "texture_top") == 0) {
                pp->skybox_top = texture_add_with_defaults (pp, cp2);
                if (pp->skybox_top == NULL) {
                    log_printf (NULL, LERROR, "%s %i: [skybox top] texture file %s cannot be opened to read sha1", config_file, line, cp);                
                }
            } else if (strcasecmp (cp, "texture_bottom") == 0) {
                pp->skybox_bottom = texture_add_with_defaults (pp, cp2);
                if (pp->skybox_bottom == NULL) {
                    log_printf (NULL, LERROR, "%s %i: [skybox bottom] texture file %s cannot be opened to read sha1", config_file, line, cp);                
                }
            } else if (strcasecmp (cp, "texture_left") == 0) {
                pp->skybox_left = texture_add_with_defaults (pp, cp2);
                if (pp->skybox_left == NULL) {
                    log_printf (NULL, LERROR, "%s %i: [skybox left] texture file %s cannot be opened to read sha1", config_file, line, cp);                
                }
            } else if (strcasecmp (cp, "texture_right") == 0) {
                pp->skybox_right = texture_add_with_defaults (pp, cp2);
                if (pp->skybox_right == NULL) {
                    log_printf (NULL, LERROR, "%s %i: [skybox right] texture file %s cannot be opened to read sha1", config_file, line, cp);                
                }
            } else if (strcasecmp (cp, "texture_front") == 0) {
                pp->skybox_front = texture_add_with_defaults (pp, cp2);
                if (pp->skybox_front == NULL) {
                    log_printf (NULL, LERROR, "%s %i: [skybox front] texture file %s cannot be opened to read sha1", config_file, line, cp);                
                }
            } else if (strcasecmp (cp, "texture_back") == 0) {
                pp->skybox_back = texture_add_with_defaults (pp, cp2);
                if (pp->skybox_back == NULL) {
                    log_printf (NULL, LERROR, "%s %i: [skybox back] texture file %s cannot be opened to read sha1", config_file, line, cp);                
                }
            } else if (strcasecmp (cp, "flags") == 0) {
                pp->skybox_flags = atoi (cp2);
        
            } else {
                log_printf (NULL, LERROR, "%s %i: [skybox] \"%s\" is not valid", config_file, line, cp, subsection);
            }
        
        } else if (strcasecmp (subsection, "skin") == 0) {
			if (strcasecmp (cp, "texture") == 0 )  {
                pp->skin[current_skin].texture = texture_find_empty (pp);
                _strncpy (pp->skin[current_skin].texture->file, cp2, 256);
                strim ("lr", pp->skin[current_skin].texture->file);
				

                pp->skin[current_skin].visible = 1;							
                pp->skin[current_skin].texture->usage = 1;                
                pp->skin[current_skin].texture->x_pm = -1;
                pp->skin[current_skin].texture->y_pm = -1;
                pp->skin[current_skin].texture->alpha = 1.0;
               
                if (!sha1_file (pp->skin[current_skin].texture->file, (char *)pp->skin[current_skin].texture->sha1)) {
                    log_printf (NULL, LERROR, "%s %i: skin texture file %s cannot be opened to read sha1", config_file, line, pp->skin[current_skin].texture->file);
               		easy_die (NULL, 1);
                }  
 
                request_file_add (pp->skin[current_skin].texture->file);
                
                log_printf (NULL, LDEBUG, "Setting up skin #%i: %s", current_skin, pp->skin[current_skin].texture->file); 
                pp->num_textures ++;                
                
            } else if (strcasecmp (cp, "selectable") == 0 )  {
                pp->skin[current_skin].visible = true_false (cp2);
            }            
        
        } else {
            log_printf (NULL, LERROR, "%s %i: Unknown group keyword \"%s\".", config_file, line, subsection);
       		easy_die (NULL, 1);
        }
    }
    
    
    fclose (fn1);
	pp->active = 1;
}

struct texture *texture_find_by_filename (struct palette *pp, char *filename) {
    int a;
    
    for (a = 0; a < pp->num_textures; a++) {
        if (strcasecmp (pp->texture[a].file, filename) == 0) return (&pp->texture[a]);
    }

    return (NULL);
}

struct texture *texture_find_empty (struct palette *pp) {
    int a;
    
    for (a = 0; a < CLIENT_TEXTURE_LIMIT; a++) {
        if (pp->texture[a].file[0] == 0) return (&pp->texture[a]);
    }
    log_printf (NULL, LERROR, "Block configuration contains too many textures.");
	easy_die (NULL, 1);

    return (NULL);

}

struct texture *texture_find_by_sha1 (struct palette *pp, char *sha1) {
    int a;
    
    for (a = 0; a < pp->num_textures; a++) {
        if (memcmp (pp->texture[a].sha1, sha1, 20) == 0) return (&pp->texture[a]);
    }

    return (NULL);
}


void add_block_group (struct palette *pp, char *str, int block_id) {
    int a;
    
    for (a = 0; a < pp->num_block_groups; a++) {
        if (strcasecmp (str, pp->block_group[a].name) == 0) {
            if (pp->block_group[a].num_blocks >= 255) {
                log_printf (NULL, LERROR, "Block group %s has too many blocks in it.", pp->block_group[a].name);
				easy_die (NULL, 1);
            }
            pp->block_group[a].blocks[pp->block_group[a].num_blocks] = block_id;
            pp->block_group[a].num_blocks++;
            pp->block_group[a].blocks[pp->block_group[a].num_blocks] = 0;
            
            return;
        }
    }
    
    if (a >= 255) {
        log_printf (NULL, LERROR, "You have too many block groups.  The limit is 255.");
        return;
    }
    
    

    memset (&pp->block_group[pp->num_block_groups], 0, sizeof (struct block_group));
    _strncpy (pp->block_group[pp->num_block_groups].name, str, 64);
    pp->block_group[pp->num_block_groups].blocks[0] = block_id;
   pp->block_group[pp->num_block_groups].num_blocks = 1;
    

    pp->num_block_groups ++;
    
}


int texture_send_block_groups (struct user *puser) {
    int a;
    for (a = 0; a < puser->map->palette->num_block_groups; a++) {
        packet_send (puser, PACKET_GROUP_SETUP, a+1, puser->map->palette->block_group[a].blocks, 
            puser->map->palette->block_group[a].name);
    }
    return (1);
    
    
}    
int texture_send_texture_info (struct user *puser) {
    int b;
    struct palette *pp = puser->map->palette;
  
    for (b = 0; b < pp->num_textures; b++) {

      //  if (pp->texture[b].usage == 0) continue;

        log_printf (puser, LDEBUG, "Sending texure data: %i/%i", b+1, pp->num_textures);
        packet_send (puser, PACKET_TEXTURE_SETUP, pp->texture[b].id, pp->texture[b].sha1, 
                pp->texture[b].x_pm, pp->texture[b].y_pm, pp->texture[b].alpha, pp->texture[b].flags);
    }


    return (1);
    
}

int texture_send_blocks (struct user *puser) {
    int a;
   
  

    packet_send (puser, PACKET_BLOCK_SETUP, 255, 0xff, 0xff, 0xff,  0xff, 0xff, 0xff, 0, "air");
    
    for (a = 0; a < 255; a++) {
        if (puser->map->palette->block[a].name[0] == 0) continue;
        log_printf (puser, LDEBUG , "Send block setup for #%i", a);
    
    
    

        packet_send (puser, PACKET_BLOCK_SETUP, a, puser->map->palette->block[a].texture_top->id,
         puser->map->palette->block[a].texture_bottom->id, 
         puser->map->palette->block[a].texture_front->id, 
                puser->map->palette->block[a].texture_back->id, 
                puser->map->palette->block[a].texture_left->id, 
                puser->map->palette->block[a].texture_right->id, 
                puser->map->palette->block[a].flags, 
                puser->map->palette->block[a].name);
    }

    return (1);
}

/*
void texture_send_textures (struct user *puser) {
    log_printf (NULL, LDEBUG, "texture_send_textures %i/%i %x", puser->data_offset, puser->data_length, puser->texture_request[0]);
    int b;
    FILE *fn1;
	
	time (&puser->idle_stamp);	
	
    if (puser->data_offset >= puser->data_length) {
        if (puser->texture_request[0] == 0) {
            for (b = 1; b < CLIENT_TEXTURE_LIMIT; b++) {
                if (puser->texture_request[b] != 0) {
                    puser->texture_request[0] = puser->texture_request[b];
                    puser->texture_request[b] = 0;
                    break;
                }
            }
            
            if (puser->texture_request[0] == 0) {
                puser->texture_request_flag = 0;
                puser->data_length = 0;
                puser->data_offset = 0;
            
                log_printf (NULL, LDEBUG, "No textures left to send.");
                return;
            }
        }
        
        fn1 = fopen (puser->texture_request[0]->file, "rb");
        if (fn1 == 0) {
            log_printf (puser, LERROR, "texture_send_textures: texture file %s can't be found.", puser->texture_request[0]->file);
            puser->data_size = 0;
            return;
        }
        struct stat st;
        
        fstat (fileno(fn1), &st);
        
        puser->data = _realloc (puser->data, st.st_size + 1);
        
        fread (puser->data, st.st_size, 1, fn1);
        fclose (fn1);
        
        puser->data_size = st.st_size;
        puser->data_length = st.st_size;
        puser->data_offset = 0;
        
        unsigned char sha[20];
        sha1 ((char *)sha, puser->data, puser->data_size);
        
        if (memcmp (sha, puser->texture_request[0]->sha1, 20) != 0) {
            unsigned char s1[128];
            unsigned char s2[128];
            
            sha1_to_str ((char *)s1, (char *)puser->texture_request[0]->sha1);
            sha1_to_str ((char *)s2, (char *)sha);
            
            log_printf (puser, LERROR, "file %s's sha1 does not match the one read at load time %s : %s", s1, s2);
        }
        
        packet_send (puser, PACKET_BUFFER_RESET);
        log_printf (NULL, LDEBUG, "File %s has been queued", puser->texture_request[0]->file);
   } 

    if (puser->data_offset <= puser->data_length && puser->texture_request[0] != 0) {

        int data_left = puser->write_size - puser->write_length;
        
        log_printf (puser, LDEBUG, "Texture %s: Buffer has %i bytes left; texture has %i bytes left", 
            puser->texture_request[0]->file, data_left, puser->data_length - puser->data_offset);
        
        if (data_left > 0) {
            if (data_left > puser->data_length - puser->data_offset) data_left = puser->data_length - puser->data_offset;
            
            // Make sure that data is sent in packets which are less than 64k,
            // since this is the maximum data that will fit into a packet.
            if (data_left > 32767) data_left = 32767;
            
            packet_send (puser, PACKET_BUFFER_APPEND, puser->data + puser->data_offset, data_left);
            
            puser->data_offset += data_left;
            
            if (puser->data_offset >= puser->data_length) {
                log_printf (puser, LDEBUG, "Texture %s: transmission complete", puser->texture_request[0]->file);
                
                packet_send (puser, PACKET_BUFFER_IS_FILE_DATA);
                puser->texture_request[0] = 0;
            }
            
    
        } else {
            log_printf (puser, LDEBUG, "texture send pending buffer depleation");
        }
    }
}
*/
int texture_palette_count_active () {
    int a;
    int b = 0;
    for ( a = 0; a < NUM_PALETTES; a++) {
        if (!block_palette[a].active) continue;
        b++;
    }

    return (b);
}


struct palette *texture_find_palette_struct_by_name (char *str) {
    int a;
    for ( a = 0; a < NUM_PALETTES; a++) {
        if (!block_palette[a].active) continue;
        
        if (strcasecmp (str, block_palette[a].path) == 0) return (&block_palette[a]);
    }
    return (NULL);
}


struct palette *texture_find_palette_empty () {
    int a;
    for ( a = 0; a < NUM_PALETTES; a++) {
        if (!block_palette[a].active) return (&block_palette[a]);
    }

    return (NULL);

}


int skin_texture_find_id_by_name (struct palette *pp, char *name) {
    int a;
    
    for (a = 0; a < NUM_SKINS; a++) {
        if (pp->skin[a].name[0] == 0) continue;
        if (strcasecmp (pp->skin[a].name, name) == 0) return (pp->skin[a].texture->id);
    }

    return (-1);

}

int skin_struct_find_id_by_name (struct palette *pp, char *name) {
    int a;
    
    for (a = 0; a < NUM_SKINS; a++) {
        if (pp->skin[a].name[0] == 0) continue;
        if (strcasecmp (pp->skin[a].name, name) == 0) return (a);
    }

    return (-1);

}


int texture_active_palette_count () {
    int count = 0;
    int a;
    for ( a = 0; a < NUM_PALETTES; a++) {
        if (block_palette[a].active) count++;
    }
    return (count);
}

struct palette * texture_palette_load (char *name) {
	struct palette *p = texture_find_palette_struct_by_name (name);
	if (p == NULL) p = texture_find_palette_empty ();
	if (p == NULL) {
		log_printf (NULL, LERROR, "No space for more block palettes.");
		return (NULL);
	}
    if (access (name, F_OK) != 0) {
        log_printf (NULL, LWARNING, "texture_palette_load: '%s' does not exist.", name);
        return (NULL);
    }
    
	block_initialize (p, name);
	
    p = texture_find_palette_struct_by_name (name);    
    if (p == NULL) {
        log_printf (NULL, LERROR, "texture_palette_load: '%s' cannot be loaded.", name);
    }
	return (p);
}

    


void texture_skin_change_broadcast (struct map *pmap, struct user * ignore_user, int model_id, char *skin_name) {
    int mid = skin_struct_find_id_by_name (pmap->palette, skin_name);
    if (mid == -1) {
        log_printf (NULL, LDEBUG, "texture_skin_change: skin %s not found for map %s", skin_name, pmap->file);
        return;
    }
    
    if (pmap->palette->skin[mid].model_id != 0) {
        packet_broadcast (pmap, USER_CONNECTED, ignore_user, PACKET_PLAYER_PROPERTIES, model_id, pmap->palette->skin[mid].texture->id, pmap->palette->skin[mid].model_id);
        printf ("tscb: skin %s gets model %i\n", pmap->palette->skin[mid].name, pmap->palette->skin[mid].model_id);
    } else {
        packet_broadcast (pmap, USER_CONNECTED, ignore_user, PACKET_PLAYER_PROPERTIES, model_id, pmap->palette->skin[mid].texture->id, -1);
    }
}


void texture_skin_change (struct user *puser, int model_id, char *skin_name) {
   int mid = skin_struct_find_id_by_name (puser->map->palette, skin_name);
    if (mid == -1) {
        log_printf (NULL, LDEBUG, "texture_skin_change: skin %s not found for map %s", skin_name, puser->map->file);
        return;
    }
    
    if (puser->map->palette->skin[mid].model_id != 0) {
        packet_send (puser, PACKET_PLAYER_PROPERTIES, model_id, puser->map->palette->skin[mid].texture->id, puser->map->palette->skin[mid].model_id);
        printf ("tscb: skin %s gets model %i\n", puser->map->palette->skin[mid].name, puser->map->palette->skin[mid].model_id);
    } else {
        packet_send (puser, PACKET_PLAYER_PROPERTIES, model_id, puser->map->palette->skin[mid].texture->id, -1);
    }
}

void texture_send_skybox_info (struct user *puser) {
    int ids[6] = {0, 0, 0, 0, 0, 0};
    int sendit = 0;
    
    if (puser->map->palette->skybox_top != NULL) {ids[0] = puser->map->palette->skybox_top->id; sendit = 1;}
    if (puser->map->palette->skybox_bottom != NULL) {ids[1] = puser->map->palette->skybox_bottom->id; sendit = 1;}
    if (puser->map->palette->skybox_left != NULL) {ids[2] = puser->map->palette->skybox_left->id; sendit = 1;}
    if (puser->map->palette->skybox_right != NULL) {ids[3] = puser->map->palette->skybox_right->id; sendit = 1;}
    if (puser->map->palette->skybox_front != NULL) {ids[4] = puser->map->palette->skybox_front->id; sendit = 1;}
    if (puser->map->palette->skybox_back != NULL) {ids[5] = puser->map->palette->skybox_back->id; sendit  = 1;}
    
    if (sendit) {
        packet_send (puser, PACKET_SKY_BOX, ids[0], ids[1], ids[2], ids[3], ids[4], ids[5], puser->map->palette->skybox_flags);
        log_printf (puser, LDEBUG, "Send Skybox packet %i %i %i %i %i %i %i", ids[0], ids[1], ids[2], ids[3], ids[4], ids[5], puser->map->palette->skybox_flags);
    }
}
