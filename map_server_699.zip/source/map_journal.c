/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"
//This is the number of struct-sized chunks it loads at a time; 
//multiply this by 16 to know it's full size
//#define UNDO_BLOCK_SIZE 1024*1024*100
#define UNDO_BLOCK_SIZE 4* 65536

int map_journal_get (struct map *pmap, short x, short y, short z, struct map_journal *data) {
    data->x = x;
    data->y = y;
    data->z = z;
    
	if (!pmap->map_journal) return (1);
	if (pmap->fn_journal == 0) return (1);
	
	int ret = 0;
	
	struct map_journal *pentry;
	struct map_journal entry;
	memset (&entry, 0, sizeof (entry));
	memset (data, 0, sizeof (entry));	
    data->x = x;
    data->y = y;
    data->z = z;    
    int a;

    fseek (pmap->fn_journal, 0, SEEK_END);	
	char *buffer = _malloc (UNDO_BLOCK_SIZE * sizeof (struct map_journal));

	size_t num_records = ftell (pmap->fn_journal) / (size_t)sizeof (struct map_journal);
	size_t current_record = num_records;
	size_t records = 0;
    
    if (num_records < 1) goto end;    
	while (current_record != 0) {
		if (current_record > UNDO_BLOCK_SIZE) {
			current_record -= UNDO_BLOCK_SIZE;
			records = UNDO_BLOCK_SIZE;
		} else {
			records = current_record;
			current_record = 0;
		}
		
		size_t seek_value = current_record * sizeof (struct map_journal);

		fseek (pmap->fn_journal, seek_value , SEEK_SET);	
		fread (buffer, sizeof (struct map_journal), records, pmap->fn_journal);
		
		pentry = (void *)buffer;

		for (a = records; a >= 0; a--) {
		    if (pentry[a].x == x && pentry[a].y == y && pentry[a].z == z && pentry[a].id != 0) {
			    memmove (data, &pentry[a], sizeof (struct map_journal));
                ret = data->id;
                goto end;
		    }
		}
	}

    end:
    a = 0;
	_free (buffer);
    return (ret);
}

void map_journal_update (struct map *pmap, int id, int x, int y, int z, int new_block, int old_block) {
	struct map_journal entry;
	
	if (!pmap->map_journal) return;
	if (pmap->fn_journal == 0) return;
    if (id <= 0) {
///        log_printf (NULL, LERROR, "map_journal_update: zero is not a valid user uid");
        return;
    }

	entry.id = id;
	entry.x = x;
	entry.y = y;
	entry.z = z;
	time (&entry.stamp);
	entry.new = new_block;
	entry.old = old_block;
    
	size_t num_records = ftell (pmap->fn_journal) / (size_t)sizeof (struct map_journal);
    size_t seek_value = num_records * sizeof (struct map_journal);
	fseek (pmap->fn_journal, seek_value , SEEK_SET);	    
    

	//fseek (pmap->fn_journal, 0, SEEK_END);
	fwrite (&entry, 1, sizeof (struct map_journal), pmap->fn_journal);
}

void map_journal_update_fill (struct map *pmap, int id, struct short_xyz start, struct short_xyz finish, int new_block) {
	if (!pmap->map_journal) return;
	if (pmap->fn_journal == 0) return;

    if (id <= 0) {
        log_printf (NULL, LERROR, "map_journal_update_fill: zero is not a valid user uid");
        return;
    }

	struct map_journal *entry;
	
	entry = _malloc (UNDO_BLOCK_SIZE * sizeof (struct map_journal));

	int x, y, z;
	int a = 0;	
	
	for (z = start.z; z <= finish.z; z++) {
		for (y = start.y; y <= finish.y; y++) {
			for (x = start.x; x <= finish.x; x++) {
				entry[a].id = id;
				entry[a].x = x;
				entry[a].y = y;
				entry[a].z = z;
				time (&entry[a].stamp);
				entry[a].new = new_block;
				entry[a].old = map_get (pmap, (struct short_xyz) {x, y, z});
				
				if (entry[a].new == entry[a].old) continue;
				
				a++;
				if (a >= UNDO_BLOCK_SIZE) {
					fseek (pmap->fn_journal, 0, SEEK_END);
					fwrite (entry, sizeof (struct map_journal), a, pmap->fn_journal);
					log_printf (NULL, LDEBUG, "journal: wrote %i records", a);
					a = 0;
				}
			}
		}
	}

	if (a != 0) {
		fseek (pmap->fn_journal, 0, SEEK_END);
		fwrite (entry, sizeof (struct map_journal), a, pmap->fn_journal);

	}

	_free (entry);
	return;
}


void map_journal_undo (struct user *puser, int id, time_t to_stamp) {
	if (!puser->map->map_journal) return;
	if (puser->map->fn_journal == 0) return;
	
	fseek (puser->map->fn_journal, 0, SEEK_END);	
	struct map_journal entry, *pentry;
	memset (&entry, 0, sizeof (entry));

	int changed = 0;
	int a; 
	
	char *buffer = _malloc (UNDO_BLOCK_SIZE * sizeof (struct map_journal));

	unsigned int num_records = ftell (puser->map->fn_journal) / sizeof (struct map_journal);
	unsigned int current_record = num_records - 1;
	unsigned int records = 0;
	while (current_record != 0) {
		if (current_record > UNDO_BLOCK_SIZE) {
			current_record -= UNDO_BLOCK_SIZE;
			records = UNDO_BLOCK_SIZE;
		} else {
			records = current_record;
			current_record = 0;
		}
		
		unsigned int seek_value = current_record * sizeof (struct map_journal);

		fseek (puser->map->fn_journal, seek_value , SEEK_SET);	
		fread (buffer, sizeof (struct map_journal), records, puser->map->fn_journal);

		pentry = (void *)buffer;

		for (a = records; a >= 0; a--) {
			if (pentry[a].id != id) continue;

            if (to_stamp != 0 && to_stamp > pentry[a].stamp) break;
            
			map_modify (puser->map, (struct short_xyz) {pentry[a].x, pentry[a].y, pentry[a].z}, pentry[a].old);
			changed ++;
		}
	}
    
    if (changed == 0) goto end;

	log_printf (puser, LDEBUG, "Cleaning up journal");
	char temp[512];
	
	snprintf (temp, 512, "%s/%s.journal.new", PATH_MAPS, puser->map->file);	
	FILE *fn1 = fopen (temp, "wb");
	if (fn1 == 0) {
		log_printf (puser, LERROR, "Unable to open %s", temp);
		return;
	}

	fseek (puser->map->fn_journal, 0, SEEK_SET);	
	int drop = 0;
	
	while (fread (&entry, sizeof (struct map_journal), 1, puser->map->fn_journal)) {
		if (entry.id == id) {
            if (to_stamp == 0 || entry.stamp < to_stamp) {
                drop++;
                continue;
            }
        }

		fwrite (&entry, sizeof (struct map_journal), 1, fn1);
		map_modify (puser->map, (struct short_xyz) {entry.x, entry.y, entry.z}, entry.new);
	}

	fclose (fn1);
	log_printf (puser, LDEBUG, "%i change records dropped", drop);
	fclose (puser->map->fn_journal);
	char temp2[512];
	sprintf (temp, "%s/%s.journal", PATH_MAPS, puser->map->file);
	sprintf (temp2, "%s/%s.journal.old", PATH_MAPS, puser->map->file);
	remove (temp2);
	rename (temp, temp2);
	
	sprintf (temp2, "%s/%s.journal.new", PATH_MAPS, puser->map->file);
	rename (temp2, temp);	
	
	puser->map->fn_journal = fopen (temp, "r+b");
	if (puser->map->fn_journal == 0) {
		log_printf (puser, LERROR, "Unable to open [%s] after mangling", temp);
        goto end;
	}
	
	user_message (puser, MSYSTEM, "%i blocks reverted", changed);
	if (changed > 0) {
		puser->map->save_counter++;
        map_save(puser->map);
		int a;
		for (a = 1; a < NUM_USERS; a++) {
			if (user[a].current_mode == USER_NOT_CONNECTED || user[a].current_mode == USER_DISCONNECT) continue;
		
			user_mode_set (&user[a], USER_CONNECTING);
			user_set_write_event (&user[a], user_send_map);			
		}
	}
    end:
    _free (buffer);
	return ;
}

void map_journal_open (struct map *pmap) {
    char file_temp[PATH_MAX];
    if (!pmap->map_journal || pmap->area_map) return;
        
	snprintf (file_temp, 256, "%s/%s.journal", PATH_MAPS, pmap->file);
	pmap->fn_journal = fopen (file_temp, "r+b");
	if (pmap->fn_journal == 0) {
		pmap->fn_journal = fopen (file_temp, "wb");
		fclose (pmap->fn_journal);
		pmap->fn_journal = fopen (file_temp, "r+b");	
	}

    if (pmap->fn_journal == 0) {
        log_printf (NULL, LERROR, "map_journal_open: Unable to open %s: %s", file_temp, strerror (errno));
        return;
    }
    struct stat st;
    fstat (fileno (pmap->fn_journal), &st);

	size_t num_records = st.st_size / (size_t)sizeof (struct map_journal);
    size_t expected = num_records * (size_t)sizeof (struct map_journal);

    if (expected != st.st_size) {
        expected = (num_records - 1) * (size_t)sizeof (struct map_journal);
        log_printf (NULL, LNOTE, "map_journal_open: journal file %s is damaged; removing %u bytes from journal", file_temp, st.st_size - expected);
        ftruncate (fileno (pmap->fn_journal), expected);
        fclose (pmap->fn_journal);
		pmap->fn_journal = fopen (file_temp, "r+b");	 
    }

}

void map_journal_close (struct map *pmap) {
    if (pmap->map_journal && pmap->fn_journal != 0) fclose (pmap->fn_journal);
    pmap->fn_journal = 0;
}
