
/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/


#define THREADS_PRESENT

#ifdef WIN32
  typedef HANDLE mutex;
  //#define mutex HANDLE
 
  #define MUTEX_INIT(a) a=CreateSemaphore (0, 1, 256, 0)
 
  #define MUTEX_LOCK(a) WaitForSingleObject(a,INFINITE)
 
  #define MUTEX_UNLOCK(a) ReleaseSemaphore(a,1,0)
 
 
#else
 // #define mutex pthread_mutex_t
 
 typedef pthread_mutex_t mutex;
 
 #define MUTEX_INIT(a) pthread_mutex_init(&a, NULL)
 
 #define MUTEX_LOCK(a) pthread_mutex_lock(&a)
 
 #define MUTEX_UNLOCK(a) pthread_mutex_unlock(&a)
 
 
#endif


struct rw_mutex_t {
  mutex mutex;
  int write_enable;
  int read_enable;
  int sq;
};

struct structure_rwlock {
  mutex change;
  mutex in_use;
  int count;
};
typedef struct rw_mutex_t rw_mutex_t;


//These prototypes depend on the structure above, so they need to be in here.
void rw_lock_read (rw_mutex_t *d);
void rw_unlock_read (rw_mutex_t *d);
void rw_lock_write (rw_mutex_t *d);
void rw_unlock_write (rw_mutex_t *d);

