#define MME_GLOBAL_EVENT_STARTUP 1
#define MME_GLOBAL_EVENT_IDLE 2
#define MME_USER_EVENT_AFK 3
#define MME_USER_EVENT_UNRESPONSIVE 4
#define MME_USER_EVENT_PING 5
#define MME_GLOBAL_EVENT_SHUTDOWN 6
#define MME_USER_PACKET_MENU_REPONSE 7
#define MME_USER_RECEIVE_PACKET_FILE_REQUEST 8
#define MME_GLOBAL_EVENT_ANNOUNCE 9
#define MME_USER_COMMAND 10
#define MME_USER_EVENT_NEW 11
#define MME_USER_EVENT_TEXTURES_SENT 12
#define MME_USER_EVENT_CONNECTED 13
#define MME_USER_EVENT_DISCONNECT 15
#define MME_USER_EVENT_POSITION_CHANGED 16
#define MME_USER_MAP_MODIFY_ALLOW 17
#define MME_USER_RECEIVE_PACKET_DISCONNECT 18
#define MME_USER_RECEIVE_PACKET_MAP_MODIFY 19 
#define MME_USER_RECEIVE_PACKET_CHAT_MESSAGE 20
#define MME_USER_RECEIVE_PACKET_MAP_FILL 21
#define MME_USER_RECEIVE_PACKET_MENU_REQUEST 22
#define MME_USER_RECEIVE_PACKET_CLIENT_VERSION 23
#define MME_USER_EVENT_PLAYER_ANNOUNCED 24
#define MME_USER_EVENT_MAP_SWITCH 25
#define MME_USER_FORMAT_CHAT_MESSAGE 26

#define PLUGIN_CONSTANT const

int (*mme_global_event_startup)(struct user *puser);
/*
int (*mme_global_event_startup)(struct user *puser);
int (*mme_global_event_idle)(struct user *puser);
int (*mme_global_event_afk)(struct user *puser);
int (*mme_global_event_unresponsive)(struct user *puser);
int (*mme_global_event_ping)(struct user *puser);
int (*mme_global_event_shutdown)(struct user *puser);
int (*mme_user_packet_menu_reponse)(struct user *puser, int menu_number, int menu_name, int menu_value, int menu_flags, char *menu_char, int ret);
int (*mme_global_event_announce)(struct user *puser);
int (*mme_user_command)(struct user *puser, char *command, char *meat);
int (*mme_user_event_new)(struct user *puser);
int (*mme_user_event_textures_sent)(struct user *puser);
int (*mme_user_event_connected)(struct user *puser);
int (*mme_user_event_map_switch)(struct user *puser);
int (*mme_user_event_disconnect)(struct user *puser);
int (*mme_user_event_position_changed)(struct user *puser, float x, float y, float z, float u, float v);
int (*mme_user_map_modify_allow)(struct user *puser, short x, short y, short z, unsigned char type, unsigned char who);
int (*mme_user_receive_packet_file_request)(struct user *puser, char *data);
int (*mme_user_receive_packet_disconnect)(struct user *puser, char *data);
int (*mme_user_receive_packet_map_modify)(struct user *puser, short x, short y, short z, unsigned char type, unsigned char who);
int (*mme_user_receive_packet_chat_message)(struct user *puser, char *message);
int (*mme_user_receive_packet_map_fill)(struct user *puser, short lower_x, short lower_y, short lower_z, short upper_x, short upper_y, short upper_z, unsigned char type, unsigned char who);
int (*mme_user_receive_packet_menu_request)(struct user *puser);
int (*mme_user_receive_packet_client_version)(struct user *puser, int version);
int (*mme_user_event_player_announced)(struct user *puser);
int (*mme_user_event_map_switch)(struct user *puser);
int (*mme_user_format_chat_message)(struct user *puser, char *message);
*/

struct plugin {
	char file_name[PATH_MAX];
	#ifndef WIN32
	void *lib_handle;
	#else 
    HINSTANCE lib_handle;	
	#endif
	size_t call_address[1024];
	int (*plugin_initialize)(struct plugin *);
};
