/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"

struct d_menu_rank_editor {
	char name[25];
	int id;
	struct rank mrank;
};

int menu_rank_editor (struct user *puser, int message_id, int id) {
	struct d_menu_rank_editor *d;
	d = menu_get_current_stack_item_memory (puser);

	char temp[1024];
	int lines = 2;
	
	switch (message_id) {
	case MENU_CREATE:
		d = menu_stack_push_init (puser, menu_rank_editor, NULL, sizeof (struct d_menu_rank_editor));
		d->id = id;		
		memmove (&d->mrank, &rank[d->id], sizeof (struct rank));
	case MENU_DRAW:
		sprintf (temp, "Rank Editor - %s", d->mrank.name);
		int index = 1;

        packet_send(puser, PACKET_MENU_RESET, 0, 75, 20, 3); 
        packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 0, temp);
        packet_send(puser, PACKET_MENU_TEXT, index++, 1, 2, "Rank Name");		
        packet_send(puser, PACKET_MENU_INPUT, index++, 10, 2, 1, 0, 24, 24, 0, d->mrank.name);
    	int b = 4;
	
        packet_send(puser, PACKET_MENU_TEXT, index++, 1, b++, "Abilities");		
        packet_send(puser, PACKET_MENU_CHECK, index++, 40, b++, 12, 0, menu_set_check (d->mrank.can_build), "Can Build/Destroy");
        packet_send(puser, PACKET_MENU_CHECK, index++, 40, b++, 13, 0, menu_set_check (d->mrank.can_chat), "Chat With Other Players");		
	//	packet_send(puser, PACKET_MENU_CHECK, index++, 40, b++, 15, 0, menu_set_check (d->mrank.can_who), "Use Who");
		packet_send(puser, PACKET_MENU_BUTTON, index++, 1, 18, 100, 0, 0, 0, "OK");		
		packet_send(puser, PACKET_MENU_BUTTON, index++, 10, 18, 101, 0, 0, 0, "Cancel");		
		break;
		
	case MENU_COMMAND: {
		int menu_number = -1;
		int menu_name = -1;
		int menu_value = -1;
		int menu_flags = -1;
		char menu_char[65535]; 
		
		int text_length =  menu_command_parse (puser, &menu_number, &menu_name, &menu_value, &menu_flags, menu_char);

		if (menu_name == 12 ) d->mrank.can_build = menu_flags;
		else if (menu_name == 13 ) d->mrank.can_chat = menu_flags;		
		else if (menu_name == 1 && menu_value == 0) {
			if (strlen (menu_char) < 2) {
				break;
			}
			_strncpy (d->mrank.name, menu_char, 25);
		} else if (menu_name == 100) {
			log_printf (puser, LDEBUG, "SAVE");
    		memmove (&rank[d->id],&d->mrank,  sizeof (struct rank));
			menu_stack_pop (puser);
			
		} else if ((menu_name == -1 && menu_value == -1) || menu_name == 101) {
			log_printf (puser, LDEBUG, "Cancel");
			menu_stack_pop (puser);
		} else {
			log_printf (puser, LDEBUG, "menu_rank_editor: unhandled response %i %i", menu_name, menu_value);
		}
		break;}	
	}
	return (1);		
}




struct d_menu_rank_manager {
	char name[25];
	int id;
	
};


int menu_rank_manager (struct user *puser, int message_id) {
	struct rank trank;
	

	struct d_menu_rank_manager *d;
	d = menu_get_current_stack_item (puser);
	
	char temp[1024];
	int index = 1;
	int a, len;
	char *cp;

	switch (message_id) {
	case MENU_CREATE:
		log_printf (puser, LDEBUG, "init menu_rank_manager");

		d = menu_stack_push_init (puser, menu_rank_manager, NULL, sizeof (struct d_menu_rank_manager));
		
		
	case MENU_DRAW: 
	
        packet_send(puser, PACKET_MENU_RESET, 0, 80, 24, 3);
		packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 0, "Rank Manager");
		packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 2, "Ranks are listed (top)lowest to (bottom)highest");
		int count = 0;
		for (a = 0; a < NUM_RANKS; a++) {
			if (rank[a].name[0] == 0) continue;
			count ++;		
		}
		
		for (a = 0; a < NUM_RANKS; a++) {
			if (rank[a].name[0] == 0) continue;
			packet_send(puser, PACKET_MENU_LINK, index++, 12, 3+a, 3, a, 0, rank[a].name);			
			if (count > 1) {
				packet_send(puser, PACKET_MENU_LINK, index++, 0, 3+a, 1, a, 0, "[Up]");
				packet_send(puser, PACKET_MENU_LINK, index++, 5, 3+a, 2, a, 0, "[Down]");			
				packet_send(puser, PACKET_MENU_LINK, index++, 45, 3+a, 4, a, 0, "[Delete]");						
			}
		}
		
		if (rank_id_find_empty() == -1) {
			packet_send(puser, PACKET_MENU_TEXT, index++, TEXT_CENTER_COLUMN, 22, "\e\x03The maximum number of ranks has been reached.");		
		} else {
			packet_send(puser, PACKET_MENU_LINK, index++, 1, 22, 5, 0, 0, "[ create a new rank ]");		
		}
		
		

	
/*
        packet_send(puser, PACKET_MENU_LINK, index++, 1, 2, 1, 0, 0, "[ Server Configuration ]");		

		if (config.online) cp = "\e\x05 ONLINE";
		else cp = "\e\x02OFFLINE";

		sprintf (temp, "Server is currently %s", cp);		

        packet_send(puser, PACKET_MENU_TEXT, index++, 1, 22, temp);		
		packet_send(puser, PACKET_MENU_LINK, index++, 29, 22, 1, 1, 0, "[ toggle ]");		
        packet_send(puser, PACKET_MENU_LINK, index++, 1, 3, 1, 2, 0, "[ Shutdown Server ]");
		if (puser->rank->can_do.player_info) packet_send(puser, PACKET_MENU_LINK, index++, 1, 4, 1, 3, 0, "[ Player Editor ]");
		if (puser->manager) packet_send(puser, PACKET_MENU_LINK, index++, 1, 5, 1, 4, 0, "[ Connected Players ]");		
		*/

		break;
	case MENU_COMMAND:{
		int menu_number = -1;
		int menu_name = -1;
		int menu_value = -1;
		int menu_flags = -1;
		char menu_char[65535]; 
		
		int text_length =  menu_command_parse (puser, &menu_number, &menu_name, &menu_value, &menu_flags, menu_char);
		
		
		log_printf (puser, LDEBUG, "menu_rank_manager: %i %i", menu_name, menu_value);
		
		if (menu_name == -1 && menu_value == -1) {
			menu_stack_pop (puser);
		} else if (menu_name == 1) {
			if (menu_value == 0) break;
			memmove (&trank, &rank[menu_value - 1], sizeof (trank));
			memmove (&rank[menu_value - 1], &rank[menu_value], sizeof (trank));
			memmove (&rank[menu_value], &trank, sizeof (trank));
		
//			rank_save_file();
			menu_rank_manager (puser, MENU_DRAW);
			
		} else if (menu_name == 2) {
			memmove (&trank, &rank[menu_value + 1], sizeof (trank));
			memmove (&rank[menu_value + 1], &rank[menu_value], sizeof (trank));
			memmove (&rank[menu_value], &trank, sizeof (trank));
		
//			rank_save_file();		
			menu_rank_manager (puser, MENU_DRAW);
			
		} else if (menu_name == 4) {
			int a;
			for (a = menu_value; a < NUM_RANKS - 1; a++) {
				memmove (&rank[a], &rank[a+1], sizeof (struct rank));
				if (rank[a].name[0] == 0) continue;				
			}
			
			if (menu_value == NUM_RANKS - 1) {
				memset (&rank[menu_value], 0, sizeof (struct rank));
			}
		
//			rank_save_file();		
			menu_rank_manager (puser, MENU_DRAW);

		} else if (menu_name == 5 && menu_value == 0 && rank_id_find_empty() != -1) {
			
			if (menu_number != 255) {
				menu_edit_box (puser, MENU_CREATE, "Enter a name for the new rank", "\x00", 31, 5, 0);
			} else {
				memset (&rank[rank_id_find_empty()], 0, sizeof (struct rank));
				strim ("lr", menu_char);
				if (strlen (menu_char) < 2) {
					menu_dialog (puser, MENU_CREATE, "New Rank", "The name you entered is too short.  The new rank will be called \"new rank\".", "OK");			
					strcpy (rank[rank_id_find_empty()].name, "new rank");
				} else {
					_strncpy (rank[rank_id_find_empty()].name, menu_char, 32);
				}
				menu_rank_manager (puser, MENU_DRAW);			
			}
//			rank_save_file();

		} else if (menu_name == 3) {
			menu_rank_editor (puser, MENU_CREATE, menu_value);
			
		} else {
			log_printf (puser, LDEBUG, "menu_rank_manager: unknown %i %i", menu_name, menu_value);
			menu_rank_manager (puser,  MENU_DRAW);
		}
		
		
		break;}

    }
    

	return (1);
}

