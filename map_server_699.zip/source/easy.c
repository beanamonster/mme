/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"

void easy_die(char * message, int ret) {
  if (message != NULL) printf("Oh no!  %s\n", message);
	if (config.pause_exit) {
	  printf ("The server has terminated.  Close the window or press CTRL+C to exit.\n");
	  #ifdef WIN32
      #include <conio.h>
	  getch();
	  #else
	  getchar();
	  #endif
  } else {
	printf ("The server has terminated.\n");
  }

  exit(ret);
}
double easy_time() {
    #ifdef WIN32
        return ((double)GetTickCount() / 1000.0);
    #else
    // glfwGetTime uses gettimeofday() which is less desriable than
    // CLOCK_MONOTONIC since changing the system time affects
    // gettimeofday() but does not affect CLOCK_MONOTONIC.
    struct timespec bullshit;
    clock_gettime(CLOCK_MONOTONIC, &bullshit);
    return bullshit.tv_sec + bullshit.tv_nsec / 1000000000.0;
  #endif
}

void easy_sleep(double seconds) {
  #ifdef WIN32
    int milliseconds = round(1000 * seconds);
    if (milliseconds > 0) Sleep(milliseconds);
  #else
    struct timespec bullshit;
    if (seconds > 0) {
      bullshit.tv_sec = floor(seconds);
      bullshit.tv_nsec = round((seconds - bullshit.tv_sec) * 1000000000.0);
      while (nanosleep(&bullshit, &bullshit));
    };
  #endif
}

int csv_parse (char *in, unsigned char def, char *argv[], int max) {
	int i=1, a=0, wr=1, len, s;
	char *null=0;
	i=1;
	if (in == NULL) return (0);

	len=strlen (in);
	if (len<1) return (0);
	argv[0]=in;
    
    for (a = 1; a < max; a++) argv[a] = &in[len];

	for (a=0;a<len;a++) {
		if (in[a]=='\"') {
			if (wr==0) {wr=1;}
			else {wr=0;}
		}
		if (wr==1) {
			if ((unsigned char )in[a] == def) {
                if (def == ' ') {
                    int w = a;
                    while (in[w] != 0) {
                        if (in[w + 1] != ' ') {
                            a = w;
                            break;
                        }
                        w++;
                    }
                }
            
				argv[i]=&in[a]+1;
				if (null==0) null=&in[a];
				in[a]=0;
				s=0;
				while (1) {
					if (argv[i][s]!=' ') break;
					s++;
				}

				argv[i]+=s;
				i++;
				if (i>=max) break;
			}
		}
	}
	for (a=0;a<i;a++) strim ("lr", argv[a]);
	return(i);
}

char *_strncpy (char *dest, const char *src, size_t n) {
    size_t offset;
    for (offset = 0; (offset < n && src[offset] != 0); offset++)
        dest[offset] = src[offset];
    for (   ;offset < n; offset++) 
        dest[offset] = 0;
    dest[n - 1] = 0;
    return (dest);
}

void hhmmss (char *output, time_t timer) {
	int h, m, s;
    h=abs((timer/60)/60);
    m=abs((timer-((h*60)*60))/60);
    s=abs(timer-(((h*60)*60)+(m*60)));
    sprintf (output, "%02i:%02i:%02i", h, m, s);
}

void the_date (char *the_date, char *the_time, time_t t) {
	struct tm *tm;
	char *day = "Moosday";
	tm = localtime (&t);
	switch (tm->tm_wday) {
	case 0: day = "Sunday"; break;
	case 1: day = "Monday"; break;	
	case 2: day = "Tuesday"; break;
	case 3: day = "Wednesday"; break;
	case 4: day = "Thursday"; break;
	case 5: day = "Friday"; break;
	case 6: day = "Saturday"; break;
	}
	char *month = "Moostober";
	
	switch (tm->tm_mon) {
	case 0: month = "January"; break;
	case 1: month = "February"; break;
	case 2: month =  "March"; break;
	case 3: month =  "April"; break;	
	case 4: month =  "May"; break;
	case 5: month =  "June"; break;
	case 6: month =  "July"; break;	
	case 7: month = "August"; break;
	case 8: month =  "September"; break;
	case 9: month =  "October"; break;	
	case 10: month = "November"; break;
	case 11: month =  "December"; break;
	}
	
	char date[64];
	snprintf (date, 64, "%2i", tm->tm_mday);
	
	switch (date[1]) {
	case '1': strcat (date, "st"); break;
	case '2': strcat (date, "nd"); break;
	case '3': strcat (date, "rd"); break;
	default:
		strcat (date, "th"); break;
	}	
	
	int hour = tm->tm_hour;
	char *apm = "am";
	if (hour >= 12) {
		hour -= 12;
		apm = "pm";
	}
	
	if (hour == 0) hour = 12;
	
	sprintf (the_date, "%s %s %s", day, month, date);
	sprintf (the_time, "%2i:%02i%s", hour , tm->tm_min, apm);
}

#define MINUTE 60
#define HOUR 3600
#define DAY 86400
#define WEEK 604800

void time_ago (time_t then, time_t now, char *output) {
	int week = 0, day = 0, hour = 0, second = 0, minute = 0;
	int num = 0;

	time_t result = now - then;
	
	if (result >= WEEK) {
		week = result / WEEK;
		result -= (WEEK * week);
	}

	if (result >= DAY) {
		day = result / DAY;
		result -= (DAY * day);
	}
	
	if (result >= HOUR) {
		hour = result / HOUR;
		result -= (HOUR * hour);
	}

	if (result >= MINUTE) {
		minute = result / MINUTE;
		result -=(MINUTE * minute);
	}
	
	second = result;
	
	output[0] = 0;
	
	if (week > 0) num++;
	if (week == 1) sprintf (output + strlen (output), "%i week ", week);
	else if (week > 1) sprintf (output + strlen (output), "%i weeks ", week);
	if (num >= 2) goto done;

	if (day > 0) num++;
	if (day == 1) sprintf (output + strlen (output), "%i day ", day);
	else if (day > 1) sprintf (output + strlen (output), "%i days ", day);
	if (num >= 2) goto done;

	if (hour > 0) num++;
	if (hour == 1) sprintf (output + strlen (output), "%i hour ", hour);
	else if (hour > 1) sprintf (output + strlen (output), "%i hours ", hour);
	if (num >= 2) goto done;

	if (minute > 0) num++;
	if (minute == 1) sprintf (output + strlen (output), "%i minute ", minute);
	else if (minute > 1) sprintf (output + strlen (output), "%i minutes ", minute);
	if (num >= 2) goto done;
	
	if (second > 0) num++;
	if (second == 1) sprintf (output + strlen (output), "%i second ", second);
	else if (second > 1) sprintf (output + strlen (output), "%i seconds ", second);
	
	done:

	if (output[0] == 0) strcpy (output, "Just now");
	else strcat (output, "ago");
}


char *str_invalid (char *str, char *invalid) {
	char  *cp;
	while (*invalid != 0) {
		cp = strchr (str, *invalid);
		if (cp != 0) return (cp);
		invalid++;
	}
	return (NULL);
}

#ifdef LINUX
void _strlwr (char *p) {
	while (*p != 0) {
		*p = tolower (*p);
		p++;
	}
}
#endif

void iso_time_str (time_t stamp, char *str) {
	struct tm *tm;
	tm = localtime (&stamp);
	sprintf (str, "%04i-%02i-%02i %02i:%02i:%02i (EST)", tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec);
}

int copy_file (char *fsrc, char *fdest) {
	FILE *src, *dest;
	char *buffer;
	size_t length, blocksz;
	struct stat st;

	src = fopen(fsrc, "rb");
	if (src == 0) {
		return (0);
	}
	fstat (fileno (src), &st);
	
	length = st.st_size;

	dest = fopen(fdest, "wb");
	if (dest == 0) {
		fclose (src);
		return (0);
	}

	blocksz = 4096;
	if (length < blocksz) blocksz = length;
	buffer = _malloc (4096);

	while (1) {
		fread (buffer, blocksz, 1, src);
		fwrite (buffer, blocksz, 1, dest);
		
		length -= blocksz;
		if (length <= 0) break;
		
		if (length < blocksz) {
			blocksz = length;
		}
	}

	fclose (src);
	fclose (dest);
	_free (buffer);
	return (1);
}

#define MALLOCS_MAX 8912
#define MALLOC_BLOCK 128

struct _malloc_header {
	char by[32];
	size_t size;
	size_t thread;
};

static size_t *malloc_index;
static size_t num_mallocs;

void alloc_exit (void) {
	int a;
	log_printf (NULL,  LDEBUG, ">_malloc_alloc_exit");
	struct _malloc_header *mheader;	
	
	for (a = 0;a < num_mallocs; a++) {
		if (malloc_index[a] != 0) {
			mheader=(void *)malloc_index[a];
            mheader->by[31] = 0;
			log_printf (NULL,  LNOTE, "Unallocated malloc of %i bytes by [%s]",mheader->size, mheader->by);
		}
	}
}

void _malloc_init (void) {
	num_mallocs = MALLOC_BLOCK;
	malloc_index = malloc (sizeof (size_t) * (num_mallocs + 1));
	memset (malloc_index, 0, sizeof (size_t) * (num_mallocs + 1));
}

void * easy_realloc (const char *file, const int line, const void * ma, const size_t ms) {
	log_printf (NULL, LDEBUG, "realloc %s:%i: %i", file, line, ms);
	int a, b=-1;
	struct _malloc_header *header;

	for (a = 0; a < num_mallocs; a++) {
		if (malloc_index[a] == (size_t) ma - sizeof (struct _malloc_header)) {
			b = a;
			break;
		}
	}
	
	if (b == -1) {
		log_printf (NULL,  LERROR, "_realloc: [%s:%i] %x (%x) not in index.", file, line, ma, ma-sizeof (struct _malloc_header));
		return(0);
	}

	header = realloc ((void *)malloc_index[b], (size_t) ms + 12 + sizeof (struct _malloc_header));
	if (header==0) {
		log_printf (NULL,  LERROR, "_realloc: [%s:%i] failed.", file, line);
		return (0);
	}
	
	int *canary;
	canary =(void *) ( (char *)header )+ (ms + 8 + sizeof (struct _malloc_header));    

	*canary = 0xaa55aa;
	
    //It's okay to cry.
    snprintf (header->by, 32, "%s:%i", file, line);
	header->size = ms;
	
	malloc_index[b] = (size_t)header;

	//log_printf (NULL,  LDEBUG, "_realloc: %i: [%s:%i] %x : %x", b, file, line, malloc_index[b], (size_t) header);
	return ((void *)malloc_index[b]+sizeof (struct _malloc_header));	
}

void * easy_malloc (const char *file, const int line, const size_t ms) {
	log_printf (NULL, LDEBUG, "_malloc %s:%i: %zu", file, line, ms);
	int a, b = -1;
	struct _malloc_header *header;
	for (a = 0;a < num_mallocs; a++) {
		if (malloc_index[a] == 0) {
			b = a;
			break;
		}
	} 
	if (b == -1) {
		if (_malloc_memory_increase () == 0) {
			log_printf (NULL,  LERROR, "_malloc: [%s:%i] no empty slots", file, line);
			return(0);
		} 
		log_printf (NULL,  LDEBUG, "\x1b[1;33m_malloc memory increased");
		b = a;
	}

	header = malloc ((size_t) (ms + 12 + sizeof (struct _malloc_header)));
	if (header == 0) {
		log_printf (NULL,  LERROR, "_malloc: [%s:%i] failed.", file, line);
		return (0);
	}
	
	int *canary;
    canary = (void *)( (char *)header )+ (size_t) (ms + 8u + sizeof (struct _malloc_header));
	*canary = 0xaa55aa;
	
    // Doesn't this just make you feel sick inside?
    snprintf (header->by, 32, "%s:%i", file, line);
	header->size=ms;
	
	malloc_index[b] = (size_t)header;

	return ((void *)((size_t) malloc_index[b] + sizeof (struct _malloc_header)));	
}

void _free (void* ms) {
	int a;
	int b=-1;
	log_printf (NULL, LDEBUG, "_free %x", ms);

	for (a=0;a<num_mallocs;a++) {
		if (malloc_index[a]==(size_t) ms-sizeof (struct _malloc_header)) {
			b=a;
			break;
		}
	}
	
	if (b==-1) {
		log_printf (NULL,  LERROR, "_free: %x not in index", ms-sizeof (struct _malloc_header));
		return;
	}
	struct _malloc_header *header = (void *)malloc_index[b];
	int *canary;
	canary = ms + 8 + header->size ;

	if (*canary != 0xaa55aa) {
		log_printf (NULL, LERROR, "Canary died for [%s] (%x)",  header->by, ms);
		easy_die (NULL, 1);
	}

	free ((void *) malloc_index[b]);
	malloc_index[b]=0;

	return ;	
}


void malloc_canary_test () {
	int a;

	for (a = 0; a < num_mallocs; a++) {
		if (malloc_index[a] == 0) continue;
		struct _malloc_header *header = (void *)malloc_index[a];
		int *canary;
		canary = (void *)( (char *)header )+ (size_t) (header->size + 8u + sizeof (struct _malloc_header));

		if (*canary != 0xaa55aa) {
			log_printf (NULL, LERROR, "Canary died for [%s] (%x)",  header->by, malloc_index[a]);
			easy_die (NULL, 1);
		}
	}
	return ;	
}

int _malloc_memory_increase () {
	size_t new_size;
	char *buffer;
	log_printf (NULL, LDEBUG, "_malloc_memory_increase");
	new_size=num_mallocs+MALLOC_BLOCK;

	buffer=realloc (malloc_index, sizeof (size_t)*(new_size+1));
	if (buffer==0) {
		log_printf (NULL, LERROR, "_malloc_memory_increase cannot increase memory - we're screwed");
		return (0);
	}
	
	memset (buffer+(num_mallocs*sizeof (size_t)), 0, MALLOC_BLOCK*sizeof (size_t));
	
	malloc_index=(void *) buffer;

	num_mallocs=new_size;
	return (1);
}

const char color_list[18][18] = {"invalid", "brown", "red", "orange", "yellow", "green", "blue",  "purple", "gray", "white", "black", "rainbow", "pink", "silver",  "gold", "ruby", "emerald"};

int strlen_no_color (char *str) {
	int count = 0;
	while (*str++ != 0) {
		if (*str == '\e') {
			str++;
			continue;
		}
		if (str[0] == '|' && strchr ("0123456789abcdef", str[1]) != 0) {
			str++;
			continue;
		}
		count++;
	}
	return (count);
}

/*
  strim removes spaces from the ends of a character array.
  specify 'l', 'r', or 'lr' for the first parameter.
  'l' means left
  'r' means right
  'lr' means left and right
*/
void strim (char *type, char *str) {
	char *cp, *cr;
	cp = str;
	while (*cp != 0) {
		if (*cp== 9 ) *cp = 32;
		cp++;
	}

	if ((type[0]=='r' || type[1]=='r')) {
		cp--;
		cr = cp;
		while (cr > str) {
			if (*cr != 32) break;
            *cr = 0;
			cr--;
		}

		if (cr != cp) cr[1] = 0;
	}

	if ((type[0] == 'l' || type[1] == 'l') && str[0] == 32) {
		cp = str;
		while (*cp != 0) {
			if (*cp != 32) break;
			cp++;
		}
        int len = strlen (cp);
        
        memmove (str, cp, len);
        str[len] = 0;        
	}
}

char * _strsplitcpy (char *in, unsigned char def, char *out, int outlength) {
    char *cp;
    cp = strchr (in, def);
    if (cp == NULL) return (NULL);
    *cp = 0;
    cp ++;
    if (out != NULL) {
        char *cp2 = cp;
        int a = 0;
        for (a = 0; (a < outlength) && *cp2 != 0; a++) out[a] = *cp2++;
        out[a] = 0;
        strim ("lr", out);
    }
    return (cp);
}

char *psnprintf (char *out, int length, char *str, ... ) {
    va_list  arg;
    va_start(arg, str);
    vsnprintf(out, length, str, arg);
    va_end(arg);
	
    return (out);
}

void easy_mkdir (char *path) {
    #ifdef WIN32
    mkdir (path);
    _chmod (path, _S_IREAD | _S_IWRITE);
    #else
    mkdir (path, 0777);
    #endif
}

void str_color_strip (char *str) { 
	char *cp;
	char *cp2;
	char colors[16] = "1234567890abcdef";
	char *cp3;
	char *output;
	
	output = _malloc (strlen (str) + 1);
	output[0] = 0;
	char *ocp;
	ocp = output;
	
	int length = strlen (str);
	cp = str;

	while (cp < str + length) {
		cp2 = strchr (cp, '|');
		if (cp2 == 0) cp2 = cp + strlen (cp);
		strncpy (ocp, cp, cp2 - cp);
    	ocp += cp2 - cp;
		cp3 = strchr (colors, cp2[1]);		

		if (cp2[1] == '|') {
			*ocp = '|';
			ocp ++;
			cp2++;
			
		} else if (cp3 != 0 && cp2[1] != 0 ) {
//			ocp += 1;
			cp2++;
		}

		cp = cp2 + 1;
		*ocp = 0;		
	}
	
	strcpy (str, output);
	_free (output);
}

float easy_distance_from (struct float_xyzuv from, struct float_xyzuv to) {
    float sx, sy, sz;
    sx = fabs (from.x - to.x);
    sy = fabs (from.y - to.y);
    sz = fabs(from.z - to.z);
    float distance = 0;
    if (sx > distance) sx = distance;
    if (sy > distance) sy = distance;
    if (sz > distance) sz = distance;
    return (distance);
}


int csv_parse_alloc (char *in, unsigned char def, char *argv[], int max) {
    char *buffer;
    buffer = _malloc (strlen (in));
    strcpy (buffer, in);
    char *args[256];
    
    int num = csv_parse (buffer, def, args, max);
    int a;
    for (a = 0; a < num; a++) {
        int len = strlen (args[a]);
    	argv[a] = _malloc (len + 2);
        if (len == 0) argv[a][0] = 0;
        else strcpy (argv[a], args[a]);
    }
    _free (buffer);
	return (num);
}

void csv_unparse (char *argv[], int max, unsigned char def, char *buffer) {
    int a;
    int idx = 0;
    for (a = 0; a < max; a++) {
        for (int b = 0; (argv[a][b] != 0); b++) {
            buffer[idx] = argv[a][b];
            idx++;
        }
        buffer[idx++] = def;
        buffer[idx++] = ' ';
    }
    buffer[idx] = 0;    
}
