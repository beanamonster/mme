--[[
This is pretty simple.  We hook "mme_user_map_modify_allow", which is called 
whenever a block is about to be changed.  If the function returns 1, then the 
map server discards the block change.  If the function returns 0, 
the map server proceeds with the block change.  Here, we check to see if the 
x, y, z coordinates of the change occur within the spawn point, and that the user
is on the correct map.  If so, (and the users' rank isn't "owner") then we send a
message to the user and return 1, meaning that the block change is discarded.

If you use this code, make sure to modify the numbers to match your map.
--]]

function mme_user_map_modify_allow (username, x, y, z, type, who)

	if (mme_user[username].map_file == "default.map") then
		if ((x > 500 and x < 600) and (y > 500 and y < 600) and (z > 30 and z < 96) and mme_user[username].rank_name ~= "owner") then
			mme_user_message (username, "You can't modify the spawn point.")        
			return (1)
		end
	
	end 
	return (0)
end

