Map Server for Multiplayer Map Editor
--------------------------------------

NOTE TO WINDOWS USERS:
    Windows notepad is a horrible piece of crap!  Not only does it have some weird limitations, it also does not know how to properly handle unix linefeeds.  Do yourself a favor and install a better text editor, such as one of these:
    
    http://notepad-plus-plus.org/
    http://www.flos-freeware.ch/notepad2.html

    Additionally, remember to copy the mme_map_server folder out of the zip file and place it somewhere.  Otherwise your user data and maps will be deleted every time you shutdown the server.

How to run this server:
-----------------------
* Learn how to set up port forwarding.  The default MME port is 44434, but any port will do, provided you modify config.txt to match the port you choose.

* Edit the config.txt file with a text editor, and set the name of the server.  Take a look at the other options and make sure they suit your needs.

* Open owner.txt and put your MME username in it.  This will give you owner privileges.

* Run the executable.  For linux, it's ./map_server; for windows, it's map_server.exe.  The server will start up and tell you when it's ready for use.

* The server will report errors and other information to the console, and additionally to log.txt; log.txt gets renamed to log.txt.[number] after it grows past 100MB in size.

* Chat and command history is saved to chat.txt

* The textures/ folder has all of the textures in it.  The blocks.txt file is used to determine the name, size, texture(s), and group of each block type.

* The skins/ folder has all of the skins in it.  The blocks.txt file is used to determine the name and texture for each skin.


Server Features:
----------------
    * Map change journaling and reversion
    * Configurable ranks
    * Functionality is extendable with Lua scripts
    * Loads and saves maps.
    * Supports multiple maps
    * Manages player skins.
    * Manages block types, block groups, and textures.
    * Provides some simple server-side menus for player controls
    * Teleport
    * Respawn
    * Op
    * Kick
    * Ban
    * Supports MME's cuboid packet type
    * Connection timeouts
    * Map is automatically saved every 5 minutes
    * Compiles under Linux and MinGW (windows)
    * /undo your work if you screw up
    

Slightly more detailed information:
-----------------------------------
    There are a number of files which are read and/or maintained by the server.
    
* users/user.txt Contains individual entries for user settings.  Their rank, map location, and chat color are stored here.

* owner.txt Lists the MME user name(s) of the server owners.  Users listed in this file are -always- granted the highest rank available.

* config.txt Contains the basic server configuration data, such as the server name and the connection port

* ip_banned.txt  Any connecting IP which is matched in this file will be denied access.

* rules.txt Is displyed to new users in the chat.  

* command_help.txt Contains the message which is displayed when a user requests help for a command.  It also serves as a command reference.

* The miniupnpc/ folder contains the miniupnpc program which can be used to automatically forward a port on routers which support uPNP.  In this folder you will find a batch file called port_forward.cmd -- this may possibly forward the port for you.

If you intend to compile the source, you need either:
* 32-bit MinGW and atext editor other than Windws notepad.
* Code::Blocks

Folders:
--------
When the map server starts, it creates a number of folders.  Originally, it just stuffed everything into one folder, which was a big mess.  
Maps, Lua scripts, Logs, User records, and area maps each get their own folder.  Whenever a map is loaded, the "maps/" folder is prepended to the filename (except for area maps, see below).  Also, when a new map is created, it will be placed in the "maps" folder.

config.txt:
-----------
In previous versions the config.txt file used a name-value pair format.  The format of config.txt has changed into a command script, similar to DOS's AUTOEXEC.BAT.  When the map server starts, it executes the commands in config.txt before the console is started.  Unlike AUTOEXEC.BAT, config.txt also gets rewritten every time the server exits in order to preserve the server's settings.
For example: If the command "/set server.name new name!" is issued on the console or by a connected user, the server's name will be updated in the server list.  When the server shuts down, it rewrites config.txt to reflect the new name.  This allows the server operator to make changes to the server without having to go back and modify config.txt manually.
You can turn this feature off by issuing "/set config.sync 0" on the console, or adding this to your config.txt file when the server is not running.

Console/commands:
-----------------
The server console allows you to enter server commands or chat messages (via the /say command).  All console commands issued via the console are by the "console" user.  This user is similar to the superuser (root) account in Unix, or the Administrator account in Windows.  This account cannot be removed, modified, or used to log in with.  
Commands are entered into the console in the same way they would be in chat, prefixed by the forward slash: "/".  
Entering text into the console without the / prefix will be ignored.  You can use the /say command to send chat messages.
All parameters of the server can be manipulated from the console, using the "/set" command, or other, more specific commands.  You can get a list of available commands by typing "/help".  You can also look at the command_help.txt file for a more complete reference.

Blocks, textures, and skins:
----------------------------
The server supports multiple sets of blocks/textures as "palettes".  Each loaded map can use a different block palette.  This allows a server to have mutltiple maps with different themes.

By default, there is one texture/block set.  A palette is made up of a container folder which contains "blocks.txt" and other folders which have the textures in it.  blocks.txt defines what the blocks are called and which textures go to which side of a block.
    
The server names the block types by the name of the containing folder.  When a block palette is assigned to a map, (in the case of the default setup) the palette name will be "textures".  
    
For now, skins are also palette-specific.  Although the skin files are stored in skins/, they're loaded by blocks.txt.  In the future, this will change.
    
Maps:
-----
The map server can load multiple maps and allow users to switch between them.  Multiple maps are loaded by issuing multiple /map_load <mapfile.map> in config.txt.  You can load or unload a map at any time by issuing the /map_load or /map_unload command.  The server requires that at at least one map is available, so you will not be able to unload the map if it is the only one loaded.  Map properties are manipulated through the command interface using the set map.<filename.map>.variable command.  New maps can be created using the /map_create command.
    
Area Maps:
----------
Area maps are different than normal maps.  An area map is subdivided into individual plots (areas) which are assigned and reassigned as people connect and disconnect.  When a user connects, a default map (or blank map, if there is no default) is created and loaded into a free space on the area map.  The user can then do as they wish with their plot, including creating multiple plots which they can switch in and out by using the "area manager".
Internally, these areas are a fixed size (determind when the area map was first created) and are stored as individual files inside a folder named by the user's unique ID number.  The "area map", itself is not a map at all -- it is a series of settings stored in a binary file.  When an area map is loaded, a fake map is created, and the individual user areas are loaded into it.
Example:  If you created an area map called "my_area_map", the map server will create a folder under areas/ called "my_area_map".  Inside this folder, it will create two other files, "properties" and "area_list.txt".  As users connect, a folder with their user number will be created inside the "my_area_map" folder, giving you a path such as "areas/my_area_map/1100".  

Template Area for Area Maps:
---------------------------
The "Template area" is what the map is prepopulated with, and what a user gets a copy of the first time they connect to the area map.  To create a template area, simply copy an area from one of the user folders (for instance, make the area you want to have as a template, first) and place it in the area maps' folder with the name "template.bin".
When the map server loads the area map, it will look for this file, and if found, will populate any unassigned areas of the map with a copy of this.  And if you're not sure, your template area file should end up with a path like: areas/my_area_map/template.bin

Lua Scripts:
------------
A version of the Lua scripting language is included in the map server for customization purposes.  The server has a number of hooks which you can attach Lua code to in order to change the behavior of the server.  All Lua scripts are in the lua/ folder.  
The map server supports two different kinds of Lua scripts: hook scripts, and normal scripts.  A normal script is one which does something specific and exits (a series of commands, like resetting a sandbox).  A hook script, on the other hand is one which is loaded and stored in memory, as it contains hooks (functions) which will be called during the server's operation.  You could think of the normal scripts as "programs", and the hook scripts as "libraries", but the comparison is weak, at best.
When the server starts up, it first looks for a lua script called "startup.lua", and if found, executes it.  Any script which you would like to load at startup should be referenced here.
The file lua_calls.txt which is included with the map server contains the documentation for the mme Lua API.  All hook and interface functions are defined here.  

Lua Example Scripts:
--------------------
Inside the Lua folder, you will find a number of additional scripts which are provided to add the most commonly requested functionality.  These scripts also serve as examples of how to use the Lua subsystem.  You can uncomment the appropriate line to load them in startup.lua

Removed Features:
-----------------
Map regions:
In older versions, the map server would read a file called "map_regions.txt/csv" which defined areas of a map which were to have different build ranks.  This feature can easily be implemented with a Lua script (and far easier to understand).

Displaying rank names in chat messages:
One of the most popular server source modifications was to change the formatting of the chat messages.  This feature is no longer available.  Instead, the chat message can be processed by a Lua hook and formatted any way you please.  

ranks.txt:
This file is no longer needed due to the rank setup being in config.txt.

banned.txt:
banned.txt is no longer needed as the user record file (users/user.txt) keeps track of banned users.


