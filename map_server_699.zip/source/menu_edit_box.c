/*
LICENSE
-------
The Anti-Viral License

You may use this source code in any way you like provided that this source code
retains its original licensing terms.  Derivative works of this  source code
must also be licensed under this license,  however,  this  license does not
forbid compiling this source code alongside  source  code  of other licenses
provided that those licenses do not require a change in the licensing of this
source code.  Just use some comments to track what code is of what license,
like any intelligent and rational person might do.   After all, no sane person
thinks that if I glue two books together, I've made a derivative work and
require licensing to sell the result.  Were that the case, it would be illegal
to sell used books with notes written in the margins or papers inserted between
the pages.  Let's not be silly about this.  We all know what it means to derive
something from something else. 

...or, in simpler terms, this license is specifically incompatible with the GNU
GPL, but only because the GNU GPL requires that the GNU GPL be applied to all
source code which is part of a program that includes GNU GPL licensed source
code.  Many other free software licenses, such as the BSD license, make no such
demands and are therefore compatible with this license.   Only licenses which
require the relicensing of this source code are incompatible with this license.
Such licenses are viral in nature, and thus, this is the anti-viral license.
*/
#include "global.h"

struct d_menu_edit_box {
	char info[40];
	char text[255];	
	int length;
	void *callback;
	int name;
	int value;
} d_menu_edit_box;

int menu_edit_box (struct user *puser, int message_id, char *info, char *text, int length, int name, int value) {
	struct d_menu_edit_box *d;
	
	d = menu_get_current_stack_item_memory (puser);

	switch (message_id) {
	case MENU_CREATE:
		log_printf (puser, LDEBUG, "Menu_edit_box");
		d = menu_stack_push_init (puser, menu_edit_box, NULL, sizeof (struct d_menu_edit_box));
		
		_strncpy (d->info, info, 40);
		_strncpy (d->text, text, 255);
		d->length = length;
		d->name = name;
		d->value = value;

	case MENU_DRAW:
        packet_send(puser, PACKET_MENU_RESET, 0, 40, 10, 3); 
        packet_send(puser, PACKET_MENU_TEXT, 1, TEXT_CENTER_COLUMN, 0, "Edit");
        packet_send(puser, PACKET_MENU_TEXT, 2, 1, 2, d->info);
        packet_send(puser, PACKET_MENU_INPUT, 4, 4, 5, 9, 0, 30, d->length, 0, d->text);
		packet_send(puser, PACKET_MENU_BUTTON, 5, TEXT_CENTER_COLUMN, 7, 11, 0, 0, 0, "OK");
		break;
		
	case MENU_COMMAND: {
		int menu_number = -1;
		int menu_name = -1;
		int menu_value = -1;
		int menu_flags = -1;
		unsigned char menu_char[65535]; 
        menu_command_parse (puser, &menu_number, &menu_name, &menu_value, &menu_flags, menu_char);

		if (menu_name == 9 && menu_value == 0) {
			if (puser->menu_data_size > 257) puser->menu_data_size = 257;
			d->text[0] = 0;
			if (puser->menu_data_size > 4)
				_strncpy (d->text, (char *)menu_char, 254);
		} else if (menu_name == 11 && menu_value == 0) {
			menu_stack_pop (puser);
			char data[512];
			data[0] = 255;
			data[1] = d->name;
			data[2] = d->value;
			data[3] = 0;

			_strncpy (data + 4, d->text, d->length + 1);
			

			puser->menu_data = data;
			puser->menu_data_size = 4 + d->length;

			menu_proc (puser, MENU_COMMAND);
			
			
			
		} else if (menu_name == -1 && menu_value == -1) {
		
			menu_stack_pop (puser);
		} else {
			log_printf (puser, LDEBUG, "menu_edit_box: unhandled command: %i %i", menu_name, menu_value);
		
		}

		break;}
	}

	
	return (1);		
}
