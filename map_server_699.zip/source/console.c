#include "global.h"

void console();
int idx = 0;
static struct map fake_map;
#ifdef WIN32
HANDLE hstdin;
#endif
void console_initialize () {
	#ifdef WIN32
    hstdin = GetStdHandle (STD_INPUT_HANDLE);
    FlushConsoleInputBuffer(hstdin);

	#endif
	memset (&fake_map, 0, sizeof (fake_map));
	fake_map.active = 1;

    strcpy (user[0].name, "console");
    user[0].current_mode = USER_CONNECTED;
    user[0].rank = &rank[NUM_RANKS - 1];
    user[0].color = 3;
    user[0].socket = 1;
	strcpy (user[0].rank_name, "owner");
    user[0].map = &fake_map;
	
	memset (&user[0].sendable_packets, 0, 8192);
	memset (&user[0].receivable_packets, 0, 8192);
	if (!console_exec_file ("config.txt")) {
        console_exec_file ("config.old");
        log_printf (NULL, LNOTE, "config.txt could not be opened, using a backup.");
    }
	
	user_message (&user[0], MNULL, "Console is ready");
	setbuf (stdin, 0);

	idx = 0;
}

int console_exec_file (char *file) {
	FILE *fn1;
	char temp[1024];
	char *cp;
	fn1 = fopen (file, "rb");
	if (fn1 == 0) {
		log_printf (NULL, LWARNING, "Unable to open [%s]; %s", file, strerror (errno));
		log_printf (NULL, LWARNING, "The server is not ready.");		
		return (0);
	}
	while (fgets (temp, 1024, fn1)) {
        cp = strchr (temp, '\r'); if (cp != NULL) *cp = 0;
        cp = strchr (temp, '\n'); if (cp != NULL) *cp = 0;
        strim ("lr", temp);
        if (strlen (temp) < 1) continue;
		if (temp[0] == '#') continue;
		if (temp[0] == '/') command_proc (&user[0], temp + 1);

		else if (temp[0] == '@') {
			user_chat_private (&user[0], temp+1);
		} else {
      		//user_message_chat (&user[0], temp);
		}			
	}
	fclose (fn1);
    return (1);
}

char console_buffer[1024];

/*
    Dealing with stdio is a pain in the ass in both Windows and Linux.
    I found that with Linux, even though stdio can be handled with select(),
    you must specify the exception descriptor or select will tell you
    there's data available when there isn't.
    
    In Windows, select() is part of the Winsock API, and as such, only
    works on sockets.  There are at least three different ways of reading
    from stdin, however, all of them have annoying issues.  The code below
    will likely not work if you try and redirect it, which means making a
    frontend is going to be difficult.  You need to use ReadFile instead
    of ReadConsoleInput to make the file redirection work.  However,
    when you do this, WaitForSingleObject will often tell you there is data
    when there is none, causing ReadFile to block.  I suspect that this has
    to do with the stdin handle being signaled that there is "data", but it's
    not actually keyboard data, so ReadFile blocks because there's nothing 
    there.
    You could make this a thread, and actually, I had originally done this 
    in order to avoid doing this stupid shit.  This, of course, just shifts
    the issue over to needing other kinds of workarounds.  There are
    perfectly valid reasons for using threads to handle client connections,
    (there would theoretically be less latency) but handling stdio is not
    one of those. 
   
    I am really tempted to turn the console into a telnet interface,
    just so that I don't have to deal with this bullshit.  It wouldn't be
    as bad as you might think.  The server could then daemonize and behave
    like a "server" process should, allowing the owner to interact with it
    when he chooses by opening a session.  A "server" doesn't need a gui
    perminantly glued to it. There needs to be a way to make this thing run
    without creating a console window.
    Ugh..
*/

#ifdef LINUX
static int get_some() {
	fd_set rfds, efds;
	struct timeval tv;
	tv.tv_sec = 0;
	tv.tv_usec = 1;
	int ret;

	FD_ZERO(&rfds);
	FD_SET(0, &rfds);
	FD_ZERO(&efds);
	FD_SET(0, &efds);

	if (select(1, &rfds, NULL, &efds, &tv) < 1) return (0);
	if(FD_ISSET(0, &efds)) {
	}
	if(FD_ISSET(0, &rfds)) {
		if (idx < 1023) {
			ret = read(0, &console_buffer[idx], 1024 - idx);
			if (ret < 0) {
				g_stdin_open = 0;
				return (0);
			}
			idx += ret;
		}	
		else console_buffer[idx - 1] = '\n';
    }
    return (1);
}
#else
static int get_some () {
    int ret;

    ret = WaitForSingleObject (hstdin, 1);
    if (ret != WAIT_OBJECT_0) return(0);

    int annoyed = 0;
	if (idx < 1023) {
        INPUT_RECORD r;
        ReadConsoleInput (hstdin, &r, 1, (void *)&annoyed);
        if (r.EventType == KEY_EVENT && r.Event.KeyEvent.bKeyDown && r.Event.KeyEvent.uChar.AsciiChar != 0) {
            console_buffer[idx] = r.Event.KeyEvent.uChar.AsciiChar;
            if (console_buffer[idx] == 13) console_buffer[idx] = 10;
            if (console_buffer[idx] == 9) console_buffer[idx] = ' '; // No tabs for you.
            if (idx > 0 && console_buffer[idx] == 8) {
                idx--;
                printf ("\x08 \x08");
            } else {
                printf ("%c", console_buffer[idx]);
                idx ++;
            }
        }
    }
    else console_buffer[idx - 1] = '\n';
	console_buffer[idx + 1] = 0;
    return (1);
}
#endif
void console_proc () {
	if (!get_some()) return;

	if (console_buffer[idx - 1 ] == '\n' || console_buffer[idx] == '\r') {
		console_buffer[idx] = 0;
		idx = 0;

		char *cp;
		cp = strchr (console_buffer, '\r'); if (cp != NULL) *cp = 0;
		cp = strchr (console_buffer, '\n'); if (cp != NULL) *cp = 0;

		strim ("lr", console_buffer);
		if (strlen (console_buffer) > 1) {
			if (console_buffer[0] == '/') {
                if (user[0].map == &fake_map) {
                    struct map *t = map_struct_find_appropriate(&user[0], NULL);
                    if (t != NULL) user[0].map = t;
                }
                command_proc (&user[0], console_buffer + 1);

            } else if (console_buffer[0] == '@') {
				user_chat_private (&user[0], console_buffer+1);
			} else {
                /* Being able to enter chat messages in the console is nice,
                but accidentally sending mistyped commands or other random
                crap is annoying.*/
//				user_message_chat (&user[0], console_buffer);
                user_message (&user[0], MUSER, "Use the /say command to send chat messages.");
			}
		}
	}
}
