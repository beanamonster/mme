#include <stdio.h>
#include <string.h>
#include <stdlib.h>


int main() {
    FILE *fn1;
    char temp[4096];
    int max = -1;
    fn1 = popen ("svn status --verbose", "r");
    while (fgets(temp, 4096, fn1)) {
        strcpy (temp, temp+10);
        temp[9] = 0;
        int val = atoi (temp);
    
        if (val > max || max == -1) max = val;    

    }
    pclose (fn1);
    
    printf ("%i\n", max);
    
    fn1 = fopen ("build_version.c", "rb");
    if (fn1 != 0) {
        fgets (temp, 4096, fn1);
        char *cp;
        cp = strrchr (temp, '\r'); if (cp == NULL) *cp = 0;
        cp = strrchr (temp, '\n'); if (cp == NULL) *cp = 0;    
        fclose (fn1);
        
        cp = temp+2;
        
        if (atoi (cp) >= max) {
//            printf ("Not a new version\n");
            exit(0);
        }
    }
    
    
    fn1 = fopen ("build_version.c", "wb");
    fprintf (fn1, "//%i\r\n", max);
    fprintf (fn1, "const unsigned int build_version = %i;\r\n", max);
    fclose (fn1);
//    printf ("Build version updated.\n");
    exit(0);
}
